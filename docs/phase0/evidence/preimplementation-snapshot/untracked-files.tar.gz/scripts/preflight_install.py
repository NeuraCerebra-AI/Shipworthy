#!/usr/bin/env python3
"""Read-only Shipworthy core and skill compatibility preflight."""

from __future__ import annotations

import argparse
from email.parser import BytesParser
from email.policy import default as email_policy
import json
from pathlib import Path
import re
import sys
from typing import Any, Dict, List, Optional, Tuple


METADATA_FILENAME = "shipworthy-compatibility.json"
METADATA_SCHEMA = "shipworthy-compatibility/v1"
STATUS_SCHEMA = "shipworthy-install-preflight/v1"
EXPECTED_SKILLS = (
    "ship-readiness-orchestrator",
    "ship-deep-review",
    "ship-product-workflows",
    "ship-workflow-clarity",
)
CORE_RESOURCES = (
    "__init__.py",
    "domain/__init__.py",
    "domain/browser_evidence.py",
    "domain/contracts.py",
    "domain/entities.py",
    "domain/enums.py",
    "domain/evidence_attachment.py",
    "domain/ids.py",
    "adapters/__init__.py",
    "adapters/importers/__init__.py",
    "adapters/importers/_evidence_normalization.py",
    "adapters/importers/browser_evidence.py",
    "adapters/importers/legacy_readiness.py",
    "adapters/importers/playwright_report.py",
    "adapters/reporting/__init__.py",
    "adapters/reporting/bundle.py",
    "adapters/reporting/compat_loader.py",
    "adapters/reporting/html.py",
    "adapters/reporting/html_safety.py",
    "adapters/reporting/projection.py",
    "adapters/reporting/sarif.py",
    "schemas/v1/readiness-ledger.schema.json",
    "schemas/v1/report-input.schema.json",
    "schemas/v1/browser-evidence-envelope.schema.json",
    "_legacy_reporting/render_report.py",
    "_legacy_reporting/to_sarif.py",
    "_legacy_reporting/make_bundle.py",
)
MAX_METADATA_BYTES = 64 * 1024
_VERSION = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
_PYTHON_VERSION = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
_DIST_INFO = re.compile(
    r"^shipworthy_core-("
    r"(?:0|[1-9][0-9]*)\."
    r"(?:0|[1-9][0-9]*)\."
    r"(?:0|[1-9][0-9]*)"
    r")\.dist-info$"
)


def _diagnostic(code: str, level: str, message: str) -> Dict[str, str]:
    return {"code": code, "level": level, "message": message}


def _pairs(pairs: List[Tuple[str, Any]]) -> Dict[str, Any]:
    document: Dict[str, Any] = {}
    for key, value in pairs:
        if key in document:
            raise ValueError("duplicate metadata member")
        document[key] = value
    return document


def _read_json(path: Path) -> Dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise ValueError("metadata unavailable")
    if path.stat().st_size > MAX_METADATA_BYTES:
        raise ValueError("metadata too large")
    try:
        value = json.loads(
            path.read_text(encoding="utf-8"), object_pairs_hook=_pairs
        )
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError):
        raise ValueError("metadata invalid") from None
    if not isinstance(value, dict):
        raise ValueError("metadata invalid")
    return value


def _regular_file_without_symlinks(root: Path, path: Path) -> bool:
    try:
        relative = path.relative_to(root)
    except ValueError:
        return False
    current = root
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            return False
    return path.is_file()


def _has_symlink_component(path: Path) -> bool:
    current = Path(path.anchor) if path.is_absolute() else Path()
    parts = path.parts[1:] if path.is_absolute() else path.parts
    for part in parts:
        current = current / part
        if current.is_symlink():
            return True
    return False


def _distribution_metadata_matches(path: Path, version: str) -> bool:
    try:
        if path.is_symlink() or not path.is_file():
            return False
        if path.stat().st_size > MAX_METADATA_BYTES:
            return False
        payload = path.read_bytes()
        if len(payload) > MAX_METADATA_BYTES:
            return False
        metadata = BytesParser(policy=email_policy).parsebytes(payload)
    except (OSError, ValueError):
        return False
    names = metadata.get_all("Name", [])
    versions = metadata.get_all("Version", [])
    metadata_versions = metadata.get_all("Metadata-Version", [])
    return (
        not metadata.defects
        and len(names) == 1
        and names[0] == "shipworthy-core"
        and len(versions) == 1
        and versions[0] == version
        and len(metadata_versions) == 1
    )


def _version(value: object) -> Tuple[int, int, int]:
    if not isinstance(value, str):
        raise ValueError("invalid version")
    match = _VERSION.fullmatch(value)
    if match is None:
        raise ValueError("invalid version")
    return tuple(int(part) for part in match.groups())  # type: ignore[return-value]


def _in_range(version: object, constraint: object) -> bool:
    selected = _version(version)
    if not isinstance(constraint, str):
        return False
    clauses = constraint.split(",")
    if len(clauses) != 2:
        return False
    lower, upper = clauses
    if not lower.startswith(">=") or not upper.startswith("<"):
        return False
    try:
        return _version(lower[2:]) <= selected < _version(upper[1:])
    except ValueError:
        return False


def _validate_metadata(document: Dict[str, Any]) -> None:
    try:
        core = document["core"]
        schema = document["schema"]
        client = document["skill_client"]
        producer = document["producer"]
        features = document["features"]
        skills = document["skills"]
        valid = (
            set(document)
            == {
                "metadata_schema",
                "core",
                "schema",
                "skill_client",
                "producer",
                "features",
                "skills",
            }
            and document["metadata_schema"] == METADATA_SCHEMA
            and isinstance(core, dict)
            and core["package"] == "shipworthy-core"
            and _VERSION.fullmatch(core["package_version"]) is not None
            and core["requires_python"] == ">=3.12,<3.15"
            and isinstance(core["compatible_skill_clients"], str)
            and core["required_resources"] == list(CORE_RESOURCES)
            and isinstance(schema, dict)
            and schema == {
                "name": "shipworthy/readiness-ledger",
                "version": "1.0",
            }
            and isinstance(client, dict)
            and _VERSION.fullmatch(client["version"]) is not None
            and isinstance(client["supported_core"], str)
            and isinstance(producer, dict)
            and producer["expected_name"] == "shipworthy-core"
            and isinstance(producer["supported_versions"], str)
            and isinstance(features, dict)
            and features
            == {
                "browser_evidence_intake": True,
                "evidence_attachment": True,
                "core_contracts": True,
                "core_reporting": True,
                "mandatory_html_report": True,
                "playwright_report_import": True,
                "skill_only": True,
            }
            and skills == list(EXPECTED_SKILLS)
        )
    except (KeyError, TypeError):
        valid = False
    if not valid:
        raise ValueError("metadata invalid")
    if not _in_range(client["version"], core["compatible_skill_clients"]):
        raise ValueError("metadata incompatible")
    if not _in_range(core["package_version"], client["supported_core"]):
        raise ValueError("metadata incompatible")
    if not _in_range(
        core["package_version"], producer["supported_versions"]
    ):
        raise ValueError("metadata incompatible")


def _inspect_skills(
    skills_dir: Path,
) -> Tuple[Dict[str, object], Optional[Dict[str, Any]]]:
    invalid = (
        ".." in skills_dir.parts
        or _has_symlink_component(skills_dir)
        or not skills_dir.is_dir()
    )
    metadata: Optional[Dict[str, Any]] = None
    found = 0
    if not invalid:
        for skill in EXPECTED_SKILLS:
            root = skills_dir / skill
            try:
                if root.is_symlink() or not root.is_dir():
                    raise ValueError("skill unavailable")
                if (root / "SKILL.md").is_symlink() or not (
                    root / "SKILL.md"
                ).is_file():
                    raise ValueError("skill unavailable")
                candidate = _read_json(root / METADATA_FILENAME)
                _validate_metadata(candidate)
                if metadata is None:
                    metadata = candidate
                elif candidate != metadata:
                    raise ValueError("skill metadata mismatch")
                found += 1
            except (OSError, ValueError):
                invalid = True
    if invalid:
        metadata = None
    status = {
        "client_version": (
            metadata["skill_client"]["version"] if metadata is not None else None
        ),
        "expected": len(EXPECTED_SKILLS),
        "found": found,
        "status": "invalid" if invalid else "usable",
        "usable": not invalid,
    }
    return status, metadata


def _python_version(value: str) -> Optional[Tuple[int, int]]:
    match = _PYTHON_VERSION.fullmatch(value)
    if match is None:
        return None
    return int(match.group(1)), int(match.group(2))


def _core_status(
    status: str,
    python_version: str,
    *,
    observed_version: Optional[str] = None,
    schema_version: Optional[str] = None,
    features: Optional[Dict[str, bool]] = None,
) -> Dict[str, object]:
    result: Dict[str, object] = {
        "observed_version": observed_version,
        "python_version": python_version,
        "schema_version": schema_version,
        "status": status,
        "usable": status == "enabled",
    }
    result["features"] = features or {
        "browser_evidence_intake": False,
        "evidence_attachment": False,
        "core_contracts": False,
        "core_reporting": False,
        "mandatory_html_report": False,
        "playwright_report_import": False,
    }
    return result


def _inspect_core(
    site_packages: Path,
    skills_metadata: Optional[Dict[str, Any]],
    python_version: str,
) -> Tuple[Dict[str, object], Dict[str, str]]:
    parsed_python = _python_version(python_version)
    displayed_python = python_version if parsed_python is not None else "invalid"
    if (
        ".." in site_packages.parts
        or _has_symlink_component(site_packages)
        or not site_packages.is_dir()
    ):
        return _core_status("invalid", displayed_python), _diagnostic(
            "CORE_PATH_INVALID",
            "warning",
            "The core install path is invalid; core is disabled and valid "
            "skills remain usable.",
        )
    package = site_packages / "shipworthy"
    dist_infos: List[Tuple[Path, str]] = []
    try:
        for child in site_packages.iterdir():
            match = _DIST_INFO.fullmatch(child.name)
            if match is not None:
                dist_infos.append((child, match.group(1)))
    except OSError:
        return _core_status("invalid", displayed_python), _diagnostic(
            "CORE_PATH_INVALID",
            "warning",
            "The core install path is invalid; core is disabled and valid "
            "skills remain usable.",
        )
    if package.is_symlink():
        return _core_status("invalid", displayed_python), _diagnostic(
            "CORE_PARTIAL",
            "warning",
            "The core package is incomplete; core is disabled and valid skills "
            "remain usable.",
        )
    if not package.exists() and not dist_infos:
        return _core_status("absent", displayed_python), _diagnostic(
            "CORE_ABSENT",
            "info",
            "Shipworthy core is absent; core is disabled and all four skills "
            "remain usable.",
        )
    if not package.is_dir() or len(dist_infos) != 1:
        return _core_status("invalid", displayed_python), _diagnostic(
            "CORE_PARTIAL",
            "warning",
            "The core package is incomplete; core is disabled and valid skills "
            "remain usable.",
        )
    dist_info, observed_version = dist_infos[0]
    required = [
        package / METADATA_FILENAME,
        dist_info / "METADATA",
        *(package / resource for resource in CORE_RESOURCES),
    ]
    if (
        dist_info.is_symlink()
        or not dist_info.is_dir()
        or any(
            not _regular_file_without_symlinks(
                package if path.is_relative_to(package) else dist_info,
                path,
            )
            for path in required
        )
    ):
        return _core_status(
            "invalid", displayed_python, observed_version=observed_version
        ), _diagnostic(
            "CORE_PARTIAL",
            "warning",
            "The core package is incomplete; core is disabled and valid skills "
            "remain usable.",
        )
    if not _distribution_metadata_matches(
        dist_info / "METADATA", observed_version
    ):
        return _core_status(
            "invalid", displayed_python, observed_version=observed_version
        ), _diagnostic(
            "CORE_DISTRIBUTION_INVALID",
            "warning",
            "Core distribution metadata is invalid; core is disabled and valid "
            "skills remain usable.",
        )
    try:
        metadata = _read_json(package / METADATA_FILENAME)
        _validate_metadata(metadata)
    except ValueError:
        return _core_status(
            "invalid", displayed_python, observed_version=observed_version
        ), _diagnostic(
            "CORE_METADATA_INVALID",
            "warning",
            "Core compatibility metadata is invalid; core is disabled and valid "
            "skills remain usable.",
        )
    if parsed_python is None or not ((3, 12) <= parsed_python < (3, 15)):
        return _core_status(
            "disabled",
            displayed_python,
            observed_version=observed_version,
            schema_version=metadata["schema"]["version"],
        ), _diagnostic(
            "PYTHON_INCOMPATIBLE",
            "warning",
            "The Python runtime is incompatible; core is disabled and valid "
            "skills remain usable.",
        )
    if (
        observed_version != metadata["core"]["package_version"]
        or skills_metadata is None
        or not _in_range(
            observed_version, skills_metadata["skill_client"]["supported_core"]
        )
        or not _in_range(
            skills_metadata["skill_client"]["version"],
            metadata["core"]["compatible_skill_clients"],
        )
        or not _in_range(
            observed_version, skills_metadata["producer"]["supported_versions"]
        )
    ):
        return _core_status(
            "disabled",
            displayed_python,
            observed_version=observed_version,
            schema_version=metadata["schema"]["version"],
        ), _diagnostic(
            "CORE_INCOMPATIBLE",
            "warning",
            "The installed core is incompatible; core is disabled and valid "
            "skills remain usable.",
        )
    return _core_status(
        "enabled",
        displayed_python,
        observed_version=observed_version,
        schema_version=metadata["schema"]["version"],
        features={
            "browser_evidence_intake": metadata["features"][
                "browser_evidence_intake"
            ],
            "evidence_attachment": metadata["features"][
                "evidence_attachment"
            ],
            "core_contracts": metadata["features"]["core_contracts"],
            "core_reporting": metadata["features"]["core_reporting"],
            "mandatory_html_report": metadata["features"][
                "mandatory_html_report"
            ],
            "playwright_report_import": metadata["features"][
                "playwright_report_import"
            ],
        },
    ), _diagnostic(
        "PREFLIGHT_READY",
        "info",
        "Shipworthy core and all four skills are compatible.",
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site-packages", required=True)
    parser.add_argument("--skills-dir", required=True)
    parser.add_argument(
        "--python-version",
        default="%d.%d" % (sys.version_info.major, sys.version_info.minor),
        help="Python major.minor to inspect (defaults to this interpreter)",
    )
    parser.add_argument("--format", choices=("human", "json"), default="human")
    return parser


def main() -> int:
    args = _parser().parse_args()
    skills, metadata = _inspect_skills(Path(args.skills_dir))
    core, core_diagnostic = _inspect_core(
        Path(args.site_packages), metadata, args.python_version
    )
    diagnostics = [core_diagnostic]
    if not skills["usable"]:
        diagnostics = [
            _diagnostic(
                "SKILLS_INVALID",
                "error",
                "The four-skill installation is missing or incompatible and is "
                "not usable.",
            )
        ]
    status = (
        "invalid"
        if not skills["usable"]
        else "ready"
        if core["usable"]
        else "skills_only"
    )
    document = {
        "core": core,
        "diagnostics": diagnostics,
        "schema": STATUS_SCHEMA,
        "skills": skills,
        "status": status,
    }
    if args.format == "json":
        print(json.dumps(document, separators=(",", ":"), sort_keys=True))
    else:
        print("Shipworthy install preflight: %s" % status)
        print("Core: %s" % core["status"])
        print("Skills: %s" % skills["status"])
        for item in diagnostics:
            print("[%s] %s" % (item["code"], item["message"]))
    return 0 if skills["usable"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
