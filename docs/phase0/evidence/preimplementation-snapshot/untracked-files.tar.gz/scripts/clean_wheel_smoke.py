#!/usr/bin/env python3
"""Install a Shipworthy wheel offline into an empty venv and smoke it."""

from __future__ import annotations

import argparse
import base64
from collections.abc import Mapping
import csv
from dataclasses import dataclass
from email.parser import BytesParser
from email.policy import default
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile


MAX_WHEEL_BYTES = 64 * 1024 * 1024
MAX_WHEEL_MEMBER_COUNT = 4_096
MAX_WHEEL_MEMBER_BYTES = 16 * 1024 * 1024
MAX_WHEEL_TOTAL_UNCOMPRESSED_BYTES = 128 * 1024 * 1024
MAX_WHEEL_COMPRESSION_RATIO = 200
MAX_RECORD_BYTES = 4 * 1024 * 1024
MAX_RUNTIME_REQUIREMENTS_BYTES = 8 * 1024 * 1024
MAX_LOCK_BYTES = 32 * 1024 * 1024
MAX_SMOKE_BYTES = 2 * 1024 * 1024
MAX_SITE_PACKAGES_ENTRIES = 4_096
MAX_METADATA_BYTES = 1 * 1024 * 1024
STREAM_CHUNK_BYTES = 64 * 1024
SUBPROCESS_TIMEOUT_SECONDS = 300
SANDBOX_EXEC = Path("/usr/bin/sandbox-exec")
SANDBOX_PROFILE = b"(version 1)(allow default)(deny network*)"
_RECORD_HASH = re.compile(r"sha256=([A-Za-z0-9_-]{43})")
_HERMETIC_ENV_KEYS = frozenset(
    {
        "COMSPEC",
        "HOME",
        "LANG",
        "LC_ALL",
        "LC_CTYPE",
        "PATH",
        "PATHEXT",
        "SYSTEMROOT",
        "TEMP",
        "TMP",
        "TMPDIR",
        "WINDIR",
    }
)


# The child proves only installed-code behavior. All distribution and RECORD
# attestation is performed by the trusted parent before and after this runs.
_SMOKE = r'''
import hashlib
import json
import platform
from pathlib import Path
import sys
from shipworthy.adapters.reporting import (
    ReportingProjection,
    build_evidence_bundle,
    render_readiness_html,
    render_readiness_sarif_bytes,
)
from shipworthy.domain.contracts import parse_readiness_ledger_json

fixture = Path("fixture.json").read_bytes()
ledger = parse_readiness_ledger_json(fixture)
projection = ReportingProjection.from_ledger(ledger)
html = render_readiness_html(projection)
sarif = render_readiness_sarif_bytes(projection)
bundle = build_evidence_bundle(projection)
Path("smoke-result.json").write_text(
    json.dumps(
        {
            "bundle_sha256": hashlib.sha256(bundle).hexdigest(),
            "html_bytes": len(html),
            "python_runtime": {
                "implementation": platform.python_implementation(),
                "major": sys.version_info.major,
                "minor": sys.version_info.minor,
                "patch": sys.version_info.micro,
            },
            "sarif_bytes": len(sarif),
            "schema": "shipworthy-functional-smoke/v1",
        },
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)
'''

_BIND_PROBE = r'''
import errno
import socket
import sys
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.bind(("127.0.0.1", 0))
except OSError as error:
    raise SystemExit(0 if error.errno == errno.EPERM else 2)
raise SystemExit(3)
'''

_CONNECT_PROBE = r'''
import errno
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.connect(("127.0.0.1", 9))
except OSError as error:
    raise SystemExit(0 if error.errno == errno.EPERM else 2)
raise SystemExit(3)
'''


@dataclass(frozen=True, slots=True)
class _Containment:
    prefix: tuple[str, ...]
    evidence: dict[str, object]


@dataclass(frozen=True, slots=True)
class _LockSnapshot:
    path: Path
    descriptor: int
    identity: os.stat_result
    raw: bytes


def _open_lock_snapshot(path: Path) -> _LockSnapshot:
    error = "uv.lock failed snapshot validation"
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    descriptor = -1
    try:
        before = path.lstat()
        descriptor = os.open(path, flags)
        opened = os.fstat(descriptor)
        if (
            not stat.S_ISREG(opened.st_mode)
            or opened.st_nlink != 1
            or opened.st_size <= 0
            or opened.st_size > MAX_LOCK_BYTES
            or (
                opened.st_dev,
                opened.st_ino,
                opened.st_size,
                opened.st_mtime_ns,
                opened.st_ctime_ns,
            )
            != (
                before.st_dev,
                before.st_ino,
                before.st_size,
                before.st_mtime_ns,
                before.st_ctime_ns,
            )
        ):
            raise ValueError
        raw = os.read(descriptor, MAX_LOCK_BYTES + 1)
        if len(raw) != opened.st_size:
            raise ValueError
        return _LockSnapshot(path, descriptor, opened, raw)
    except (OSError, ValueError):
        if descriptor >= 0:
            os.close(descriptor)
        raise ValueError(error) from None


def _close_lock_snapshot(snapshot: _LockSnapshot, code: int) -> int:
    error = False
    try:
        os.lseek(snapshot.descriptor, 0, os.SEEK_SET)
        raw = os.read(snapshot.descriptor, MAX_LOCK_BYTES + 1)
        opened = os.fstat(snapshot.descriptor)
        current = snapshot.path.lstat()
        expected = snapshot.identity
        error = (
            raw != snapshot.raw
            or (
                opened.st_dev,
                opened.st_ino,
                opened.st_size,
                opened.st_mtime_ns,
                opened.st_ctime_ns,
            )
            != (
                expected.st_dev,
                expected.st_ino,
                expected.st_size,
                expected.st_mtime_ns,
                expected.st_ctime_ns,
            )
            or (
                current.st_dev,
                current.st_ino,
                current.st_size,
                current.st_mtime_ns,
                current.st_ctime_ns,
            )
            != (
                expected.st_dev,
                expected.st_ino,
                expected.st_size,
                expected.st_mtime_ns,
                expected.st_ctime_ns,
            )
        )
    except OSError:
        error = True
    finally:
        os.close(snapshot.descriptor)
    return 2 if error else code


def _error(message: str) -> int:
    print(f"clean-wheel smoke: {message}", file=sys.stderr)
    return 2


def _installed_origin_is_clean(package: Path, environment: Path) -> bool:
    try:
        package.resolve(strict=False).relative_to(
            environment.resolve(strict=False)
        )
    except ValueError:
        return False
    return True


def _normalize_distribution_name(value: str) -> str:
    return re.sub(r"[-_.]+", "-", value).lower()


def _canonical_archive_path(value: str) -> str:
    if (
        not value
        or "\x00" in value
        or "\\" in value
        or value.startswith(("/", "//"))
        or value.endswith("/")
        or "//" in value
    ):
        raise ValueError
    parts = value.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError
    if re.fullmatch(r"[A-Za-z]:", parts[0]) or ":" in parts[0]:
        raise ValueError
    if PurePosixPath(value).as_posix() != value:
        raise ValueError
    return value


def _stream_member(
    archive: zipfile.ZipFile, info: zipfile.ZipInfo
) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with archive.open(info, "r") as stream:
        while True:
            chunk = stream.read(STREAM_CHUNK_BYTES)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_WHEEL_MEMBER_BYTES:
                raise ValueError
            digest.update(chunk)
    encoded = base64.urlsafe_b64encode(digest.digest()).rstrip(b"=")
    return "sha256=" + encoded.decode("ascii"), size


def _stream_file_sha256(path: Path, maximum_bytes: int) -> str:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(STREAM_CHUNK_BYTES)
            if not chunk:
                break
            size += len(chunk)
            if size > maximum_bytes:
                raise ValueError
            digest.update(chunk)
    return digest.hexdigest()


def _wheel_identity_bytes(
    raw: bytes, filename: str
) -> dict[str, object]:
    try:
        if not raw or len(raw) > MAX_WHEEL_BYTES:
            raise ValueError
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            infos = archive.infolist()
            if not infos or len(infos) > MAX_WHEEL_MEMBER_COUNT:
                raise ValueError
            names = [_canonical_archive_path(info.filename) for info in infos]
            if len(names) != len(set(names)):
                raise ValueError
            total_uncompressed = 0
            streamed: dict[str, tuple[str, int]] = {}
            for info in infos:
                if info.flag_bits & 0x1 or info.file_size > MAX_WHEEL_MEMBER_BYTES:
                    raise ValueError
                total_uncompressed += info.file_size
                if total_uncompressed > MAX_WHEEL_TOTAL_UNCOMPRESSED_BYTES:
                    raise ValueError
                if info.file_size and (
                    info.compress_size == 0
                    or info.file_size / info.compress_size
                    > MAX_WHEEL_COMPRESSION_RATIO
                ):
                    raise ValueError
                digest, size = _stream_member(archive, info)
                if size != info.file_size:
                    raise ValueError
                streamed[info.filename] = (digest, size)
            metadata_names = [
                name for name in names if name.endswith(".dist-info/METADATA")
            ]
            record_names = [
                name for name in names if name.endswith(".dist-info/RECORD")
            ]
            if len(metadata_names) != 1 or len(record_names) != 1:
                raise ValueError
            dist_info = metadata_names[0].removesuffix("/METADATA")
            if record_names[0] != f"{dist_info}/RECORD":
                raise ValueError
            if streamed[record_names[0]][1] > MAX_RECORD_BYTES:
                raise ValueError
            with archive.open(metadata_names[0]) as metadata_stream:
                metadata_bytes = metadata_stream.read(
                    MAX_WHEEL_MEMBER_BYTES + 1
                )
            metadata = BytesParser(policy=default).parsebytes(metadata_bytes)
            names_metadata = metadata.get_all("Name", [])
            versions_metadata = metadata.get_all("Version", [])
            if len(names_metadata) != 1 or len(versions_metadata) != 1:
                raise ValueError
            name = names_metadata[0]
            version = versions_metadata[0]
            filename_parts = filename.removesuffix(".whl").split("-")
            if (
                len(filename_parts) < 5
                or _normalize_distribution_name(filename_parts[0])
                != _normalize_distribution_name(name)
                or filename_parts[1] != version
            ):
                raise ValueError
            with archive.open(record_names[0]) as record_stream:
                record_text = record_stream.read(MAX_RECORD_BYTES + 1).decode(
                    "utf-8"
                )
            rows = list(csv.reader(io.StringIO(record_text), strict=True))
            if any(len(row) != 3 or not row[0] for row in rows):
                raise ValueError
            record_files = [_canonical_archive_path(row[0]) for row in rows]
            if (
                len(record_files) != len(set(record_files))
                or set(record_files) != set(names)
            ):
                raise ValueError
            record_entries: list[dict[str, object]] = []
            for path, hash_value, size_value in rows:
                if path == record_names[0]:
                    if hash_value or size_value:
                        raise ValueError
                    record_entries.append(
                        {"path": path, "sha256": None, "size": None}
                    )
                    continue
                match = _RECORD_HASH.fullmatch(hash_value)
                if (
                    match is None
                    or not size_value.isascii()
                    or not size_value.isdigit()
                ):
                    raise ValueError
                declared_size = int(size_value)
                if str(declared_size) != size_value:
                    raise ValueError
                actual_hash, actual_size = streamed[path]
                if hash_value != actual_hash or declared_size != actual_size:
                    raise ValueError
                record_entries.append(
                    {
                        "path": path,
                        "sha256": hash_value,
                        "size": declared_size,
                    }
                )
    except (
        csv.Error,
        KeyError,
        OSError,
        UnicodeDecodeError,
        zipfile.BadZipFile,
        ValueError,
    ):
        raise ValueError("built wheel identity failed validation") from None
    return {
        "name": name,
        "record_file_count": len(record_files),
        "record_entries": record_entries,
        "record_files": record_files,
        "record_files_sha256": hashlib.sha256(
            "\n".join(record_files).encode("utf-8")
        ).hexdigest(),
        "version": version,
        "wheel_sha256": hashlib.sha256(raw).hexdigest(),
    }


def _wheel_identity(wheel: Path) -> dict[str, object]:
    try:
        chunks: list[bytes] = []
        observed = 0
        with wheel.open("rb") as stream:
            while True:
                chunk = stream.read(STREAM_CHUNK_BYTES)
                if not chunk:
                    break
                observed += len(chunk)
                if observed > MAX_WHEEL_BYTES:
                    raise ValueError
                chunks.append(chunk)
        raw = b"".join(chunks)
    except (OSError, ValueError):
        raise ValueError("built wheel identity failed validation") from None
    return _wheel_identity_bytes(raw, wheel.name)


def _uv_environment(source: Mapping[str, str]) -> dict[str, str]:
    sanitized = {
        key: value
        for key, value in source.items()
        if key.upper() in _HERMETIC_ENV_KEYS
    }
    sanitized.update(
        {
            "UV_NO_CONFIG": "1",
            "UV_NO_MANAGED_PYTHON": "1",
            "UV_OFFLINE": "1",
            "UV_PYTHON_DOWNLOADS": "never",
        }
    )
    return sanitized


def _child_command(
    command: list[str], prefix: tuple[str, ...] = ()
) -> list[str]:
    return [*prefix, *command]


def _uv_venv_command(
    python: str, environment: Path, *, prefix: tuple[str, ...] = ()
) -> list[str]:
    return _child_command(
        [
        "uv",
        "--no-config",
        "--offline",
        "--no-python-downloads",
        "venv",
        "--no-project",
        "--no-managed-python",
        "--python",
        python,
        str(environment),
        ],
        prefix,
    )


def _offline_install_commands(
    python: Path,
    wheel: Path,
    requirements: Path,
    *,
    prefix: tuple[str, ...] = (),
) -> tuple[list[str], list[str]]:
    runtime = _child_command([
        "uv",
        "--no-config",
        "--offline",
        "--no-python-downloads",
        "sync",
        "--locked",
        "--no-default-groups",
        "--no-install-project",
        "--python",
        str(python),
        "--project",
        str(Path(__file__).resolve().parents[1]),
    ], prefix)
    package = _child_command([
        "uv",
        "--no-config",
        "--offline",
        "--no-python-downloads",
        "pip",
        "install",
        "--no-managed-python",
        "--python",
        str(python),
        "--no-deps",
        str(wheel),
    ], prefix)
    return runtime, package


def _venv_python(environment: Path, *, windows: bool | None = None) -> Path:
    use_windows = os.name == "nt" if windows is None else windows
    if use_windows:
        return environment / "Scripts/python.exe"
    return environment / "bin/python"


def _target_python(explicit: str | None) -> str:
    if explicit is not None:
        return explicit
    base = getattr(sys, "_base_executable", None)
    if isinstance(base, str) and base:
        return base
    return sys.executable


def _run_quiet(
    command: list[str], *, cwd: Path, environment: Mapping[str, str]
) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(
        command,
        cwd=cwd,
        check=False,
        env=environment,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=SUBPROCESS_TIMEOUT_SECONDS,
    )


def _prepare_macos_containment(
    temporary: Path, environment: Mapping[str, str]
) -> _Containment:
    error = "required macOS network containment failed validation"
    if sys.platform != "darwin":
        raise ValueError(error)
    try:
        metadata = SANDBOX_EXEC.lstat()
        if (
            not stat.S_ISREG(metadata.st_mode)
            or SANDBOX_EXEC.is_symlink()
            or metadata.st_size <= 0
            or metadata.st_size > MAX_WHEEL_BYTES
        ):
            raise ValueError
        sandbox_sha256 = _stream_file_sha256(
            SANDBOX_EXEC, MAX_WHEEL_BYTES
        )
        profile = temporary / "deny-network.sb"
        profile.write_bytes(SANDBOX_PROFILE)
        if profile.read_bytes() != SANDBOX_PROFILE:
            raise ValueError
    except (OSError, ValueError):
        raise ValueError(error) from None
    prefix = (str(SANDBOX_EXEC), "-f", str(profile))
    for probe in (_BIND_PROBE, _CONNECT_PROBE):
        try:
            result = _run_quiet(
                _child_command(
                    [sys.executable, "-I", "-c", probe], prefix
                ),
                cwd=temporary,
                environment=environment,
            )
        except (OSError, subprocess.TimeoutExpired):
            raise ValueError(error) from None
        if result.returncode != 0:
            raise ValueError(error)
    return _Containment(
        prefix=prefix,
        evidence={
            "bind_probe": "EPERM",
            "connect_probe": "EPERM",
            "dependency_installation": "os_network_contained",
            "installed_code_runtime": "os_network_contained",
            "mechanism": "macos_sandbox_exec_deny_network",
            "profile_sha256": hashlib.sha256(SANDBOX_PROFILE).hexdigest(),
            "sandbox_exec_sha256": sandbox_sha256,
            "scope": "clean_wheel_child_operations_only",
        },
    )


def _validate_expected_runtime(
    runtime: object, expected: str | None
) -> dict[str, object]:
    error = "installed runtime target failed validation"
    if not isinstance(runtime, dict):
        raise ValueError(error)
    implementation = runtime.get("implementation")
    major = runtime.get("major")
    minor = runtime.get("minor")
    patch = runtime.get("patch")
    if (
        implementation != "CPython"
        or not isinstance(major, int)
        or isinstance(major, bool)
        or not isinstance(minor, int)
        or isinstance(minor, bool)
        or not isinstance(patch, int)
        or isinstance(patch, bool)
        or patch < 0
    ):
        raise ValueError(error)
    if expected is not None:
        if re.fullmatch(r"3\.(?:12|13|14)", expected) is None:
            raise ValueError(error)
        expected_major, expected_minor = map(int, expected.split("."))
        if (major, minor) != (expected_major, expected_minor):
            raise ValueError(error)
    return runtime


def _bounded_regular_bytes(path: Path, maximum: int, error: str) -> bytes:
    try:
        metadata = path.lstat()
        if not stat.S_ISREG(metadata.st_mode) or path.is_symlink():
            raise ValueError
        if metadata.st_size <= 0 or metadata.st_size > maximum:
            raise ValueError
        output = bytearray()
        with path.open("rb") as stream:
            while True:
                chunk = stream.read(STREAM_CHUNK_BYTES)
                if not chunk:
                    break
                output.extend(chunk)
                if len(output) > maximum:
                    raise ValueError
        if len(output) != metadata.st_size:
            raise ValueError
        return bytes(output)
    except (OSError, ValueError):
        raise ValueError(error) from None


def _read_smoke_result(path: Path) -> dict[str, object]:
    error = "smoke result failed validation"
    raw = _bounded_regular_bytes(path, MAX_SMOKE_BYTES, error)

    def reject_constant(_value: str) -> object:
        raise ValueError

    def reject_duplicates(
        pairs: list[tuple[str, object]],
    ) -> dict[str, object]:
        document: dict[str, object] = {}
        for key, value in pairs:
            if key in document:
                raise ValueError
            document[key] = value
        return document

    try:
        document = json.loads(
            raw,
            object_pairs_hook=reject_duplicates,
            parse_constant=reject_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
        raise ValueError(error) from None
    if not isinstance(document, dict):
        raise ValueError(error)
    return document


def _safe_installed_file(root: Path, relative: str, maximum: int) -> Path:
    _canonical_archive_path(relative)
    candidate = root
    for part in relative.split("/"):
        candidate = candidate / part
        try:
            if candidate.is_symlink():
                raise ValueError
        except OSError:
            raise ValueError from None
    try:
        candidate.resolve(strict=True).relative_to(root.resolve(strict=True))
        metadata = candidate.lstat()
    except (OSError, ValueError):
        raise ValueError from None
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_size > maximum:
        raise ValueError
    return candidate


def _site_packages_candidates(environment: Path) -> list[Path]:
    candidates = []
    windows = environment / "Lib/site-packages"
    if windows.is_dir() and not windows.is_symlink():
        candidates.append(windows)
    library = environment / "lib"
    if library.is_dir() and not library.is_symlink():
        entries = list(library.iterdir())
        if len(entries) > 64:
            raise ValueError
        for entry in entries:
            if (
                re.fullmatch(r"python\d+\.\d+", entry.name)
                and entry.is_dir()
                and not entry.is_symlink()
            ):
                site = entry / "site-packages"
                if site.is_dir() and not site.is_symlink():
                    candidates.append(site)
    return candidates


def _metadata_identity(path: Path) -> tuple[str, str]:
    raw = _bounded_regular_bytes(
        path, MAX_METADATA_BYTES, "installed metadata failed validation"
    )
    metadata = BytesParser(policy=default).parsebytes(raw)
    names = metadata.get_all("Name", [])
    versions = metadata.get_all("Version", [])
    if len(names) != 1 or len(versions) != 1:
        raise ValueError("installed metadata failed validation")
    return names[0], versions[0]


def _verify_installed_distribution(
    environment: Path, built_identity: dict[str, object]
) -> dict[str, object]:
    error = "installed distribution failed trusted verification"
    try:
        candidates = _site_packages_candidates(environment)
        matches = []
        inventories = []
        for site in candidates:
            entries = list(site.iterdir())
            if len(entries) > MAX_SITE_PACKAGES_ENTRIES:
                raise ValueError
            distributions_found = []
            for entry in entries:
                if not entry.name.endswith(".dist-info"):
                    continue
                if not entry.is_dir() or entry.is_symlink():
                    raise ValueError
                name, version = _metadata_identity(entry / "METADATA")
                distributions_found.append({"name": name, "version": version})
                if _normalize_distribution_name(name) == "shipworthy-core":
                    matches.append((site, entry, name, version))
            inventories.append((site, distributions_found))
        if len(matches) != 1:
            raise ValueError
        site, dist_info, name, version = matches[0]
        inventory_matches = [items for root, items in inventories if root == site]
        if len(inventory_matches) != 1:
            raise ValueError
        runtime_distributions = sorted(
            inventory_matches[0],
            key=lambda item: (
                _normalize_distribution_name(str(item["name"])),
                str(item["version"]),
            ),
        )
        normalized_runtime = [
            (_normalize_distribution_name(str(item["name"])), item["version"])
            for item in runtime_distributions
        ]
        if len(normalized_runtime) != len(set(normalized_runtime)):
            raise ValueError
        if name != built_identity["name"] or version != built_identity["version"]:
            raise ValueError
        record_relative = f"{dist_info.name}/RECORD"
        record_path = _safe_installed_file(site, record_relative, MAX_RECORD_BYTES)
        record_raw = _bounded_regular_bytes(record_path, MAX_RECORD_BYTES, error)
        rows = list(
            csv.reader(io.StringIO(record_raw.decode("utf-8")), strict=True)
        )
        if any(len(row) != 3 or not row[0] for row in rows):
            raise ValueError
        installed_rows = {}
        for path, hash_value, size_value in rows:
            canonical = _canonical_archive_path(path)
            if canonical in installed_rows:
                raise ValueError
            installed_rows[canonical] = (hash_value, size_value)
        expected_entries = built_identity["record_entries"]
        if not isinstance(expected_entries, list):
            raise ValueError
        expected_paths = {
            str(entry["path"])
            for entry in expected_entries
            if isinstance(entry, dict)
        }
        if len(expected_paths) != len(expected_entries):
            raise ValueError
        if not expected_paths.issubset(installed_rows):
            raise ValueError
        for entry in expected_entries:
            path = str(entry["path"])
            installed_hash, installed_size = installed_rows[path]
            if entry["sha256"] is None:
                if path != record_relative or installed_hash or installed_size:
                    raise ValueError
                continue
            if (
                installed_hash != entry["sha256"]
                or installed_size != str(entry["size"])
            ):
                raise ValueError
            installed_path = _safe_installed_file(
                site, path, MAX_WHEEL_MEMBER_BYTES
            )
            digest = _stream_file_record_digest(
                installed_path, MAX_WHEEL_MEMBER_BYTES
            )
            if digest != installed_hash:
                raise ValueError
            if installed_path.stat().st_size != entry["size"]:
                raise ValueError
        for path, (hash_value, size_value) in installed_rows.items():
            if path in expected_paths:
                continue
            installed_path = _safe_installed_file(
                site, path, MAX_WHEEL_MEMBER_BYTES
            )
            if hash_value == "" and size_value == "":
                continue
            if _RECORD_HASH.fullmatch(hash_value) is None:
                raise ValueError
            if not size_value.isascii() or not size_value.isdigit():
                raise ValueError
            if str(int(size_value)) != size_value:
                raise ValueError
            if (
                _stream_file_record_digest(
                    installed_path, MAX_WHEEL_MEMBER_BYTES
                )
                != hash_value
                or installed_path.stat().st_size != int(size_value)
            ):
                raise ValueError
        package_origin = _safe_installed_file(
            site, "shipworthy/__init__.py", MAX_WHEEL_MEMBER_BYTES
        )
        return {
            "file_count": len(installed_rows),
            "missing_wheel_files": [],
            "name": name,
            "package_origin": str(package_origin),
            "record_sha256": _stream_file_sha256(
                record_path, MAX_RECORD_BYTES
            ),
            "runtime_distributions": runtime_distributions,
            "version": version,
            "wheel_record_entries_verified": True,
        }
    except (csv.Error, KeyError, OSError, UnicodeDecodeError, ValueError):
        raise ValueError(error) from None


def _stream_file_record_digest(path: Path, maximum: int) -> str:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(STREAM_CHUNK_BYTES)
            if not chunk:
                break
            size += len(chunk)
            if size > maximum:
                raise ValueError
            digest.update(chunk)
    encoded = base64.urlsafe_b64encode(digest.digest()).rstrip(b"=")
    return "sha256=" + encoded.decode("ascii")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wheel", required=True)
    parser.add_argument("--fixture", required=True)
    parser.add_argument("--python")
    parser.add_argument("--expected-python")
    parser.add_argument("--require-os-network-containment", action="store_true")
    parser.add_argument("--output")
    parser.add_argument("--runtime-requirements", required=True)
    parser.add_argument("--lock", default="uv.lock")
    arguments = parser.parse_args()
    target_python = _target_python(arguments.python)
    wheel = Path(arguments.wheel).resolve()
    fixture = Path(arguments.fixture).resolve()
    runtime_requirements = Path(arguments.runtime_requirements).resolve()
    lock = Path(arguments.lock).resolve()
    if not wheel.is_file():
        return _error("wheel does not exist")
    if not fixture.is_file():
        return _error("fixture does not exist")
    if (
        not runtime_requirements.is_file()
        or runtime_requirements.stat().st_size <= 0
        or runtime_requirements.stat().st_size
        > MAX_RUNTIME_REQUIREMENTS_BYTES
    ):
        return _error("runtime requirements failed validation")
    if (
        not lock.is_file()
        or lock.stat().st_size <= 0
        or lock.stat().st_size > MAX_LOCK_BYTES
    ):
        return _error("uv.lock failed validation")
    try:
        lock_snapshot = _open_lock_snapshot(lock)
    except ValueError:
        return _error("uv.lock failed snapshot validation")

    def finish(code: int) -> int:
        return _close_lock_snapshot(lock_snapshot, code)

    if shutil.which("uv") is None:
        return finish(_error("uv is unavailable"))
    try:
        built_identity = _wheel_identity(wheel)
    except ValueError:
        return finish(_error("built wheel identity failed validation"))

    with tempfile.TemporaryDirectory(prefix="shipworthy-clean-wheel-") as raw:
        temporary = Path(raw)
        environment = temporary / "venv"
        uv_environment = _uv_environment(os.environ)
        containment: _Containment | None = None
        if arguments.require_os_network_containment:
            try:
                containment = _prepare_macos_containment(
                    temporary, uv_environment
                )
            except ValueError:
                return finish(
                    _error("required OS network containment is unavailable")
                )
        prefix = () if containment is None else containment.prefix
        try:
            create = _run_quiet(
                _uv_venv_command(
                    target_python, environment, prefix=prefix
                ),
                cwd=temporary,
                environment=uv_environment,
            )
        except (OSError, subprocess.TimeoutExpired):
            return finish(_error("uv execution failed"))
        if create.returncode != 0:
            return finish(
                _error("offline target Python environment is unavailable")
            )
        python = _venv_python(environment)
        install_environment = dict(uv_environment)
        install_environment["UV_PROJECT_ENVIRONMENT"] = str(environment)
        for install_command in _offline_install_commands(
            python, wheel, runtime_requirements, prefix=prefix
        ):
            try:
                install = _run_quiet(
                    install_command,
                    cwd=temporary,
                    environment=install_environment,
                )
            except (OSError, subprocess.TimeoutExpired):
                return finish(_error("uv execution failed"))
            if install.returncode != 0:
                return finish(_error(
                    "locked wheel dependencies are unavailable offline"
                ))
        shutil.copyfile(fixture, temporary / "fixture.json")
        runtime_requirements_sha256 = _stream_file_sha256(
            runtime_requirements, MAX_RUNTIME_REQUIREMENTS_BYTES
        )
        lock_sha256 = hashlib.sha256(lock_snapshot.raw).hexdigest()
        try:
            trusted_before = _verify_installed_distribution(
                environment, built_identity
            )
        except ValueError:
            return finish(
                _error("installed distribution failed trusted verification")
            )
        smoke_environment = _uv_environment(os.environ)
        smoke_environment["PYTHONNOUSERSITE"] = "1"
        smoke_result = temporary / "smoke-result.json"
        try:
            smoke = _run_quiet(
                _child_command(
                    [str(python), "-I", "-c", _SMOKE], prefix
                ),
                cwd=temporary,
                environment=smoke_environment,
            )
        except (OSError, subprocess.TimeoutExpired):
            return finish(_error("installed-wheel execution failed"))
        if smoke.returncode != 0:
            return finish(
                _error("installed-wheel import or rendering failed")
            )
        try:
            functional = _read_smoke_result(smoke_result)
            python_runtime = _validate_expected_runtime(
                functional.get("python_runtime"), arguments.expected_python
            )
            trusted_after = _verify_installed_distribution(
                environment, built_identity
            )
        except ValueError:
            return finish(
                _error("installed distribution failed trusted verification")
            )
        if trusted_after != trusted_before:
            return finish(
                _error("installed distribution changed during smoke")
            )
        bundle_sha256 = functional.get("bundle_sha256")
        html_bytes = functional.get("html_bytes")
        sarif_bytes = functional.get("sarif_bytes")
        if (
            functional.get("schema") != "shipworthy-functional-smoke/v1"
            or not isinstance(bundle_sha256, str)
            or re.fullmatch(r"[0-9a-f]{64}", bundle_sha256) is None
            or not isinstance(html_bytes, int)
            or isinstance(html_bytes, bool)
            or html_bytes <= 0
            or not isinstance(sarif_bytes, int)
            or isinstance(sarif_bytes, bool)
            or sarif_bytes <= 0
        ):
            return finish(_error("installed-wheel smoke result is invalid"))
        package_origin = Path(str(trusted_after["package_origin"]))
        if not package_origin.is_file() or not _installed_origin_is_clean(
            package_origin, environment
        ):
            return finish(_error("installed package origin is invalid"))
        runtime_distributions = trusted_after["runtime_distributions"]
        installed_distribution = {
            key: value
            for key, value in trusted_after.items()
            if key not in {"package_origin", "runtime_distributions"}
        }
        network_containment = (
            {
                "dependency_installation": "offline_enforced",
                "dependency_source": "uv_sync_locked",
                "installed_code_runtime": "NOT_PROVEN",
                "uv_lock_sha256": lock_sha256,
            }
            if containment is None
            else {
                **containment.evidence,
                "dependency_installation": (
                    "offline_locked_os_network_contained"
                ),
                "dependency_source": "uv_sync_locked",
                "uv_lock_sha256": lock_sha256,
            }
        )
        evidence = {
            "built_wheel": built_identity,
            "bundle_sha256": bundle_sha256,
            "html_bytes": html_bytes,
            "identity_match": True,
            "installed_distribution": installed_distribution,
            "network_containment": network_containment,
            "package": str(package_origin),
            "python_runtime": python_runtime,
            "runtime_distributions": runtime_distributions,
            "runtime_requirements_sha256": runtime_requirements_sha256,
            "runtime_requirements_role": (
                "lock_export_evidence_not_install_input"
            ),
            "sarif_bytes": sarif_bytes,
            "schema": "shipworthy-clean-wheel-smoke/v1",
            "uv_lock_sha256": lock_sha256,
        }
        rendered = json.dumps(evidence, indent=2, sort_keys=True) + "\n"
        if len(rendered.encode("utf-8")) > MAX_SMOKE_BYTES:
            return finish(
                _error("trusted smoke evidence exceeds size budget")
            )
        if arguments.output is not None:
            output = Path(arguments.output)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(rendered, encoding="utf-8")
        print(rendered, end="")
        return finish(0)


if __name__ == "__main__":
    raise SystemExit(main())
