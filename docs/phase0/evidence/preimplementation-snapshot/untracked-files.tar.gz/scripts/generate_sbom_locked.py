#!/usr/bin/env python3
"""Generate CycloneDX only while the exact source lock remains held."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess

from write_build_manifest import (
    MAX_LOCK_BYTES,
    _open_held_input,
    _verify_held_input,
)


def _uv(*arguments: str) -> list[str]:
    return [
        "uv",
        "--no-config",
        "--offline",
        "--no-python-downloads",
        *arguments,
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lock", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    snapshot = _open_held_input(arguments.lock, MAX_LOCK_BYTES)
    try:
        commands = (
            _uv("sync", "--locked", "--all-groups"),
            _uv(
                "run",
                "--no-sync",
                "cyclonedx-py",
                "environment",
                "--output-format",
                "JSON",
                "--output-file",
                str(arguments.output),
            ),
        )
        for command in commands:
            result = subprocess.run(command, check=False, timeout=900)
            _verify_held_input(snapshot)
            if result.returncode != 0:
                return 2
    finally:
        os.close(snapshot.descriptor)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
