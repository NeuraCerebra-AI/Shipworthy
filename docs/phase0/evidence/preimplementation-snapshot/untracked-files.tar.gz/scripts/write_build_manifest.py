#!/usr/bin/env python3
"""Validate CycloneDX output and bind release artifact hashes."""

from __future__ import annotations

import argparse
from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import stat

from clean_wheel_smoke import (
    _normalize_distribution_name,
    _wheel_identity,
    _wheel_identity_bytes,
)
from write_python_target_matrix import MatrixEvidenceError, _validate_proof


MAX_SBOM_BYTES = 32 * 1024 * 1024
MAX_SMOKE_BYTES = 2 * 1024 * 1024
MAX_RUNTIME_REQUIREMENTS_BYTES = 8 * 1024 * 1024
MAX_LOCK_BYTES = 32 * 1024 * 1024
MAX_MANIFEST_ARTIFACT_BYTES = 128 * 1024 * 1024
MAX_PHASE0_RECEIPT_BYTES = 2 * 1024 * 1024
MAX_PHASE0_RECEIPTS_BYTES = 8 * 1024 * 1024
MAX_TARGET_MATRIX_BYTES = 2 * 1024 * 1024
MAX_TARGET_PROOF_BYTES = 64 * 1024
MAX_TARGET_LOG_BYTES = 8 * 1024 * 1024
MAX_TOOLCHAIN_BYTES = 64 * 1024
MAX_WHEEL_BYTES = 64 * 1024 * 1024
STREAM_CHUNK_BYTES = 64 * 1024
PYTHON_TARGETS = ("3.12", "3.13", "3.14")
PHASE0_RECEIPT_SCHEMAS = {
    "contract-hashes.json": "shipworthy-phase0-contract-hashes/v1",
    "legacy-import.json": "shipworthy-legacy-import-evidence/v1",
    "dual-render.json": "shipworthy-dual-render-evidence/v1",
    "installed-parity-codex.json": "shipworthy-installed-parity/v1",
    "installed-parity-claude.json": "shipworthy-installed-parity/v1",
    "upgrade-rollback.json": "shipworthy-lifecycle-upgrade-rehearsal/v1",
    "uninstall-skill-only.json": "shipworthy-lifecycle-uninstall-rehearsal/v1",
}


class _AmbiguousJsonError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class _HeldInput:
    path: Path
    descriptor: int
    identity: os.stat_result
    raw: bytes


def _open_held_input(path: Path, maximum: int) -> _HeldInput:
    error = "build evidence snapshot failed validation"
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    flags |= getattr(os, "O_NONBLOCK", 0)
    descriptor = -1
    try:
        path_row = path.lstat()
        descriptor = os.open(path, flags)
        descriptor_row = os.fstat(descriptor)
        if (
            not stat.S_ISREG(descriptor_row.st_mode)
            or descriptor_row.st_nlink != 1
            or descriptor_row.st_size <= 0
            or descriptor_row.st_size > maximum
            or _stable_identity(path_row) != _stable_identity(descriptor_row)
        ):
            raise ValueError(error)
        chunks: list[bytes] = []
        observed = 0
        while True:
            chunk = os.read(
                descriptor,
                min(STREAM_CHUNK_BYTES, maximum + 1 - observed),
            )
            if not chunk:
                break
            chunks.append(chunk)
            observed += len(chunk)
            if observed > maximum:
                raise ValueError(error)
        raw = b"".join(chunks)
        if len(raw) != descriptor_row.st_size:
            raise ValueError(error)
        return _HeldInput(path, descriptor, descriptor_row, raw)
    except (OSError, ValueError) as exception:
        if descriptor >= 0:
            os.close(descriptor)
        if isinstance(exception, ValueError):
            raise
        raise ValueError(error) from exception


def _verify_held_input(item: _HeldInput) -> None:
    error = "build evidence snapshot changed during validation"
    try:
        os.lseek(item.descriptor, 0, os.SEEK_SET)
        chunks: list[bytes] = []
        observed = 0
        while True:
            chunk = os.read(
                item.descriptor,
                min(STREAM_CHUNK_BYTES, len(item.raw) + 1 - observed),
            )
            if not chunk:
                break
            chunks.append(chunk)
            observed += len(chunk)
            if observed > len(item.raw):
                raise ValueError(error)
        descriptor_row = os.fstat(item.descriptor)
        path_row = item.path.lstat()
        if (
            b"".join(chunks) != item.raw
            or _stable_identity(descriptor_row) != _stable_identity(item.identity)
            or _stable_identity(path_row) != _stable_identity(item.identity)
        ):
            raise ValueError(error)
    except (OSError, ValueError) as exception:
        if isinstance(exception, ValueError):
            raise
        raise ValueError(error) from exception


def _reject_duplicate_members(
    pairs: list[tuple[str, object]],
) -> dict[str, object]:
    document: dict[str, object] = {}
    for key, value in pairs:
        if key in document:
            raise _AmbiguousJsonError
        document[key] = value
    return document


def _reject_nonfinite(_value: str) -> object:
    raise _AmbiguousJsonError


def _load_unambiguous_json(raw: bytes, error: str) -> object:
    try:
        text = raw.decode("utf-8")
        return json.loads(
            text,
            object_pairs_hook=_reject_duplicate_members,
            parse_constant=_reject_nonfinite,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, _AmbiguousJsonError):
        raise ValueError(error) from None


def _validated_cyclonedx(raw: bytes) -> dict[str, object]:
    error = "SBOM failed CycloneDX validation"
    document = _load_unambiguous_json(raw, error)
    if not isinstance(document, dict):
        raise ValueError(error)
    spec_version = document.get("specVersion")
    if not isinstance(spec_version, str):
        raise ValueError(error)
    try:
        from cyclonedx.schema import OutputFormat, SchemaVersion
        from cyclonedx.validation import make_schemabased_validator

        schema_version = SchemaVersion.from_version(spec_version)
        validator = make_schemabased_validator(
            OutputFormat.JSON, schema_version
        )
        validation_errors = validator.validate_str(
            raw.decode("utf-8"), all_errors=True
        )
        if validation_errors is not None:
            tuple(validation_errors)
            raise ValueError(error)
    except ValueError:
        raise ValueError(error) from None
    except Exception:
        raise ValueError(error) from None
    return document


def _validated_toolchain(
    raw: bytes, *, source_lock_sha256: str
) -> dict[str, object]:
    error = "uv toolchain evidence failed validation"
    document = _load_unambiguous_json(raw, error)
    if not isinstance(document, dict):
        raise ValueError(error)
    binary = document.get("binary")
    if (
        set(document)
        != {"binary", "schema", "source_lock_sha256", "uv_version"}
        or document.get("schema") != "shipworthy-uv-toolchain/v1"
        or document.get("uv_version") != "uv 0.11.28"
        or document.get("source_lock_sha256") != source_lock_sha256
        or not isinstance(binary, dict)
        or set(binary) != {"bytes", "name", "path", "sha256"}
        or binary.get("name") != "uv"
        or not isinstance(binary.get("path"), str)
        or not str(binary["path"]).startswith("/")
        or not isinstance(binary.get("bytes"), int)
        or isinstance(binary.get("bytes"), bool)
        or binary["bytes"] <= 0
        or re.fullmatch(r"[0-9a-f]{64}", str(binary.get("sha256"))) is None
    ):
        raise ValueError(error)
    return document


def _validated_smoke(
    raw: bytes,
    wheel: Path | dict[str, object],
    *,
    runtime_requirements_sha256: str,
    expected_python: str | None = None,
    require_os_containment: bool = False,
    lock_sha256: str | None = None,
) -> dict[str, object]:
    error = "clean-wheel identity evidence failed validation"
    document = _load_unambiguous_json(raw, error)
    if not isinstance(document, dict):
        raise ValueError(error)
    built = document.get("built_wheel")
    installed = document.get("installed_distribution")
    actual = _wheel_identity(wheel) if isinstance(wheel, Path) else wheel
    runtime = document.get("runtime_distributions")
    network = document.get("network_containment")
    python_runtime = document.get("python_runtime")
    strict_network = (
        isinstance(network, dict)
        and network.get("bind_probe") == "EPERM"
        and network.get("connect_probe") == "EPERM"
        and network.get("dependency_installation")
        == "offline_locked_os_network_contained"
        and network.get("dependency_source") == "uv_sync_locked"
        and network.get("installed_code_runtime") == "os_network_contained"
        and network.get("mechanism") == "macos_sandbox_exec_deny_network"
        and network.get("scope") == "clean_wheel_child_operations_only"
        and re.fullmatch(r"[0-9a-f]{64}", str(network.get("profile_sha256")))
        is not None
        and network.get("uv_lock_sha256") == lock_sha256
        and document.get("uv_lock_sha256") == lock_sha256
        and re.fullmatch(
            r"[0-9a-f]{64}", str(network.get("sandbox_exec_sha256"))
        )
        is not None
    )
    legacy_network = (
        isinstance(network, dict)
        and network.get("dependency_installation") == "offline_enforced"
        and network.get("installed_code_runtime") == "NOT_PROVEN"
    )
    runtime_matches = expected_python is None
    if expected_python is not None and isinstance(python_runtime, dict):
        expected_major, expected_minor = map(int, expected_python.split("."))
        runtime_matches = (
            python_runtime.get("implementation") == "CPython"
            and python_runtime.get("major") == expected_major
            and python_runtime.get("minor") == expected_minor
            and isinstance(python_runtime.get("patch"), int)
            and not isinstance(python_runtime.get("patch"), bool)
            and python_runtime["patch"] >= 0
        )
    if (
        document.get("schema") != "shipworthy-clean-wheel-smoke/v1"
        or document.get("identity_match") is not True
        or not isinstance(built, dict)
        or not isinstance(installed, dict)
        or built != actual
        or installed.get("name") != actual["name"]
        or installed.get("version") != actual["version"]
        or installed.get("missing_wheel_files") != []
        or installed.get("wheel_record_entries_verified") is not True
        or not isinstance(runtime, list)
        or not runtime
        or (require_os_containment and not strict_network)
        or (not require_os_containment and not legacy_network)
        or not runtime_matches
        or document.get("runtime_requirements_sha256")
        != runtime_requirements_sha256
    ):
        raise ValueError(error)
    seen = set()
    for item in runtime:
        if not isinstance(item, dict):
            raise ValueError(error)
        name = item.get("name")
        version = item.get("version")
        if (
            not isinstance(name, str)
            or not name
            or not isinstance(version, str)
            or not version
        ):
            raise ValueError(error)
        key = (_normalize_distribution_name(name), version)
        if key in seen:
            raise ValueError(error)
        seen.add(key)
    return document


def _validate_sbom_scope(
    document: dict[str, object], runtime: list[object]
) -> None:
    error = "SBOM inventory scope failed validation"
    components = document.get("components")
    if not isinstance(components, list) or not components:
        raise ValueError(error)
    component_keys = set()
    for component in components:
        if not isinstance(component, dict):
            raise ValueError(error)
        name = component.get("name")
        version = component.get("version")
        if isinstance(name, str) and isinstance(version, str):
            component_keys.add((_normalize_distribution_name(name), version))
    runtime_keys = {
        (_normalize_distribution_name(str(item["name"])), str(item["version"]))
        for item in runtime
        if isinstance(item, dict)
    }
    if not runtime_keys or not runtime_keys.issubset(component_keys):
        raise ValueError(error)


def _entry(name: str, path: Path) -> dict[str, object]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(STREAM_CHUNK_BYTES)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_MANIFEST_ARTIFACT_BYTES:
                raise ValueError("build evidence artifact exceeds hash budget")
            digest.update(chunk)
    return {
        "bytes": size,
        "name": name,
        "sha256": digest.hexdigest(),
    }


def _entry_bytes(name: str, raw: bytes) -> dict[str, object]:
    if not raw or len(raw) > MAX_MANIFEST_ARTIFACT_BYTES:
        raise ValueError("build evidence artifact exceeds hash budget")
    return {
        "bytes": len(raw),
        "name": name,
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def _matrix_entry(path: Path) -> dict[str, object]:
    entry = _entry(path.name, path)
    return entry


def _validated_target_matrix(
    raw: bytes,
    *,
    wheel: Path,
    lock: Path,
    smokes: Mapping[str, Path],
    wheel_entry: dict[str, object] | None = None,
    lock_entry: dict[str, object] | None = None,
    smoke_entries: Mapping[str, dict[str, object]] | None = None,
    proof_entries: Mapping[str, dict[str, object]] | None = None,
    log_entries: Mapping[str, dict[str, object]] | None = None,
) -> dict[str, object]:
    error = "python target matrix evidence mismatch"
    if len(raw) <= 0 or len(raw) > MAX_TARGET_MATRIX_BYTES:
        raise ValueError(error)
    if set(smokes) != set(PYTHON_TARGETS):
        raise ValueError(error)
    document = _load_unambiguous_json(raw, error)
    if not isinstance(document, dict):
        raise ValueError(error)
    rows = document.get("targets")
    limitations = document.get("limitations")
    if (
        document.get("schema") != "shipworthy-python-target-matrix/v1"
        or document.get("status") != "PROVEN"
        or document.get("network_containment_scope")
        != "clean_wheel_child_operations_only"
        or document.get("wheel")
        != (wheel_entry if wheel_entry is not None else _matrix_entry(wheel))
        or document.get("lock")
        != (lock_entry if lock_entry is not None else _matrix_entry(lock))
        or not isinstance(rows, list)
        or len(rows) != len(PYTHON_TARGETS)
        or not isinstance(limitations, dict)
        or limitations
        != {
            "all_groups_on_every_target": "NOT_PROVEN",
            "other_os_architectures": "NOT_PROVEN",
            "other_patch_releases": "NOT_PROVEN",
            "outer_release_and_test_containment": "NOT_PROVEN",
        }
    ):
        raise ValueError(error)
    observed_targets = []
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError(error)
        target = row.get("target")
        if not isinstance(target, str) or target not in smokes:
            raise ValueError(error)
        observed_targets.append(target)
        expected_smoke = (
            smoke_entries[target]
            if smoke_entries is not None
            else _matrix_entry(smokes[target])
        )
        if row.get("smoke") != expected_smoke:
            raise ValueError(error)
        for kind in ("proof", "log"):
            entry = row.get(kind)
            if (
                not isinstance(entry, dict)
                or not isinstance(entry.get("name"), str)
                or not isinstance(entry.get("bytes"), int)
                or isinstance(entry.get("bytes"), bool)
                or entry["bytes"] <= 0
                or re.fullmatch(r"[0-9a-f]{64}", str(entry.get("sha256")))
                is None
            ):
                raise ValueError(error)
            exact_entries = proof_entries if kind == "proof" else log_entries
            if exact_entries is not None and entry != exact_entries[target]:
                raise ValueError(error)
    if observed_targets != list(PYTHON_TARGETS):
        raise ValueError(error)
    return {
        "limitations": limitations,
        "requires_python": ">=3.12,<3.15",
        "status": "PROVEN",
        "targets": list(PYTHON_TARGETS),
    }


def _stable_identity(row: os.stat_result) -> tuple[int, ...]:
    return (
        row.st_dev,
        row.st_ino,
        row.st_mode,
        row.st_nlink,
        row.st_size,
        row.st_mtime_ns,
        row.st_ctime_ns,
    )


def _open_phase0_receipt(
    directory_fd: int, name: str
) -> tuple[int, os.stat_result]:
    error = "Phase 0 receipts failed validation"
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    flags |= getattr(os, "O_NONBLOCK", 0)
    try:
        descriptor = os.open(name, flags, dir_fd=directory_fd)
    except OSError as exception:
        raise ValueError(error) from exception
    try:
        before = os.fstat(descriptor)
        path_before = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_size <= 0
            or before.st_size > MAX_PHASE0_RECEIPT_BYTES
            or _stable_identity(path_before) != _stable_identity(before)
        ):
            raise ValueError(error)
    except (OSError, ValueError):
        os.close(descriptor)
        raise
    return descriptor, before


def _read_open_phase0_receipt(
    descriptor: int, expected: os.stat_result
) -> bytes:
    error = "Phase 0 receipts failed validation"
    try:
        os.lseek(descriptor, 0, os.SEEK_SET)
        chunks: list[bytes] = []
        observed = 0
        while True:
            chunk = os.read(
                descriptor,
                min(
                    STREAM_CHUNK_BYTES,
                    MAX_PHASE0_RECEIPT_BYTES + 1 - observed,
                ),
            )
            if not chunk:
                break
            chunks.append(chunk)
            observed += len(chunk)
            if observed > MAX_PHASE0_RECEIPT_BYTES:
                raise ValueError(error)
        after = os.fstat(descriptor)
    except ValueError:
        raise
    except OSError as exception:
        raise ValueError(error) from exception
    payload = b"".join(chunks)
    if (
        len(payload) != expected.st_size
        or _stable_identity(after) != _stable_identity(expected)
    ):
        raise ValueError(error)
    return payload


def _phase0_receipt_entries(receipt_dir: Path) -> list[dict[str, object]]:
    error = "Phase 0 receipts failed validation"
    try:
        before_path = receipt_dir.lstat()
    except OSError as exception:
        raise ValueError(error) from exception
    if not stat.S_ISDIR(before_path.st_mode):
        raise ValueError(error)
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_DIRECTORY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    try:
        directory_fd = os.open(receipt_dir, flags)
    except OSError as exception:
        raise ValueError(error) from exception
    opened: list[tuple[str, int, os.stat_result]] = []
    try:
        before_fd = os.fstat(directory_fd)
        if _stable_identity(before_fd) != _stable_identity(before_path):
            raise ValueError(error)
        names = os.listdir(directory_fd)
        if set(names) != set(PHASE0_RECEIPT_SCHEMAS) or len(names) != len(
            PHASE0_RECEIPT_SCHEMAS
        ):
            raise ValueError(error)
        for name in PHASE0_RECEIPT_SCHEMAS:
            descriptor, identity = _open_phase0_receipt(directory_fd, name)
            opened.append((name, descriptor, identity))
        entries = []
        payloads: dict[str, bytes] = {}
        total = 0
        for name, descriptor, identity in opened:
            payload = _read_open_phase0_receipt(descriptor, identity)
            total += len(payload)
            if total > MAX_PHASE0_RECEIPTS_BYTES:
                raise ValueError(error)
            document = _load_unambiguous_json(payload, error)
            if (
                not isinstance(document, dict)
                or document.get("schema") != PHASE0_RECEIPT_SCHEMAS[name]
            ):
                raise ValueError(error)
            payloads[name] = payload
            entries.append(
                {
                    "bytes": len(payload),
                    "name": f"phase0/{name}",
                    "sha256": hashlib.sha256(payload).hexdigest(),
                }
            )
        for name, descriptor, identity in opened:
            payload = _read_open_phase0_receipt(descriptor, identity)
            document = _load_unambiguous_json(payload, error)
            if (
                payload != payloads[name]
                or not isinstance(document, dict)
                or document.get("schema") != PHASE0_RECEIPT_SCHEMAS[name]
            ):
                raise ValueError(error)
        for name, descriptor, identity in opened:
            current_fd = os.fstat(descriptor)
            current_path = os.stat(
                name, dir_fd=directory_fd, follow_symlinks=False
            )
            if (
                _stable_identity(current_fd) != _stable_identity(identity)
                or _stable_identity(current_path) != _stable_identity(identity)
            ):
                raise ValueError(error)
        after_fd = os.fstat(directory_fd)
    except ValueError:
        raise
    except OSError as exception:
        raise ValueError(error) from exception
    finally:
        for _name, descriptor, _identity in opened:
            os.close(descriptor)
        os.close(directory_fd)
    try:
        after_path = receipt_dir.lstat()
    except OSError as exception:
        raise ValueError(error) from exception
    if (
        _stable_identity(after_fd) != _stable_identity(before_fd)
        or _stable_identity(after_path) != _stable_identity(before_fd)
    ):
        raise ValueError(error)
    return entries


def build_manifest(
    *,
    wheel: Path,
    lock: Path,
    sbom: Path,
    smoke: Path,
    runtime_requirements: Path,
    phase0_receipts: Path | None = None,
    smokes: Mapping[str, Path] | None = None,
    target_matrix: Path | None = None,
    source_lock: Path | None = None,
    toolchain: Path | None = None,
    proofs: Mapping[str, Path] | None = None,
    logs: Mapping[str, Path] | None = None,
) -> dict[str, object]:
    strict_matrix = smokes is not None or target_matrix is not None
    if strict_matrix and (smokes is None or target_matrix is None):
        raise ValueError("python target matrix evidence mismatch")
    if strict_matrix and (
        source_lock is None
        or toolchain is None
        or proofs is None
        or logs is None
        or set(proofs) != set(PYTHON_TARGETS)
        or set(logs) != set(PYTHON_TARGETS)
        or set(smokes or {}) != set(PYTHON_TARGETS)
    ):
        raise ValueError("python target matrix evidence mismatch")

    specifications: list[tuple[str, Path, int]] = [
        ("wheel", wheel, MAX_WHEEL_BYTES),
        ("lock", lock, MAX_LOCK_BYTES),
        ("sbom", sbom, MAX_SBOM_BYTES),
        ("smoke", smoke, MAX_SMOKE_BYTES),
        (
            "runtime_requirements",
            runtime_requirements,
            MAX_RUNTIME_REQUIREMENTS_BYTES,
        ),
    ]
    if strict_matrix:
        assert source_lock is not None
        assert toolchain is not None
        assert target_matrix is not None
        assert smokes is not None
        assert proofs is not None
        assert logs is not None
        if smoke.resolve() != smokes["3.13"].resolve():
            raise ValueError("python target matrix evidence mismatch")
        specifications.extend(
            [
                ("source_lock", source_lock, MAX_LOCK_BYTES),
                ("toolchain", toolchain, MAX_TOOLCHAIN_BYTES),
                ("target_matrix", target_matrix, MAX_TARGET_MATRIX_BYTES),
            ]
        )
        for target in PYTHON_TARGETS:
            specifications.extend(
                [
                    (f"smoke:{target}", smokes[target], MAX_SMOKE_BYTES),
                    (f"proof:{target}", proofs[target], MAX_TARGET_PROOF_BYTES),
                    (f"log:{target}", logs[target], MAX_TARGET_LOG_BYTES),
                ]
            )
    receipt_names: list[str] = []
    if phase0_receipts is not None:
        try:
            if phase0_receipts.is_symlink() or not phase0_receipts.is_dir():
                raise ValueError
            receipt_names = sorted(path.name for path in phase0_receipts.iterdir())
        except (OSError, ValueError):
            raise ValueError("Phase 0 receipts failed validation") from None
        if set(receipt_names) != set(PHASE0_RECEIPT_SCHEMAS):
            raise ValueError("Phase 0 receipts failed validation")
        specifications.extend(
            (
                f"receipt:{name}",
                phase0_receipts / name,
                MAX_PHASE0_RECEIPT_BYTES,
            )
            for name in receipt_names
        )

    held: dict[str, _HeldInput] = {}
    try:
        for key, path, maximum in specifications:
            held[key] = _open_held_input(path, maximum)
        wheel_identity = _wheel_identity_bytes(
            held["wheel"].raw, wheel.name
        )
        lock_entry = _entry_bytes("uv.lock", held["lock"].raw)
        runtime_entry = _entry_bytes(
            "runtime-requirements.txt", held["runtime_requirements"].raw
        )
        lock_sha256 = str(lock_entry["sha256"])
        runtime_requirements_sha256 = str(runtime_entry["sha256"])
        document = _validated_cyclonedx(held["sbom"].raw)
        smoke_documents: dict[str, dict[str, object]] = {}
        if strict_matrix:
            assert smokes is not None
            assert proofs is not None
            assert logs is not None
            if held["source_lock"].raw != held["lock"].raw:
                raise ValueError("source and staged lock evidence mismatch")
            _validated_toolchain(
                held["toolchain"].raw,
                source_lock_sha256=lock_sha256,
            )
            smoke_entries: dict[str, dict[str, object]] = {}
            proof_entries: dict[str, dict[str, object]] = {}
            log_entries: dict[str, dict[str, object]] = {}
            for target in PYTHON_TARGETS:
                smoke_raw = held[f"smoke:{target}"].raw
                proof_raw = held[f"proof:{target}"].raw
                smoke_entries[target] = _entry_bytes(
                    smokes[target].name, smoke_raw
                )
                proof_entries[target] = _entry_bytes(
                    proofs[target].name, proof_raw
                )
                log_entries[target] = _entry_bytes(
                    logs[target].name, held[f"log:{target}"].raw
                )
                try:
                    _validate_proof(proof_raw, target)
                except MatrixEvidenceError as exception:
                    raise ValueError(
                        "python target proof evidence mismatch"
                    ) from exception
                smoke_documents[target] = _validated_smoke(
                    smoke_raw,
                    wheel_identity,
                    runtime_requirements_sha256=runtime_requirements_sha256,
                    expected_python=target,
                    require_os_containment=True,
                    lock_sha256=lock_sha256,
                )
            smoke_document = smoke_documents["3.13"]
            first_runtime = smoke_document["runtime_distributions"]
            if any(
                selected["runtime_distributions"] != first_runtime
                for selected in smoke_documents.values()
            ):
                raise ValueError(
                    "python target matrix runtime inventory mismatch"
                )
            matrix_raw = held["target_matrix"].raw
            matrix_summary = _validated_target_matrix(
                matrix_raw,
                wheel=wheel,
                lock=lock,
                smokes=smokes,
                wheel_entry=_entry_bytes(wheel.name, held["wheel"].raw),
                lock_entry=lock_entry,
                smoke_entries=smoke_entries,
                proof_entries=proof_entries,
                log_entries=log_entries,
            )
            matrix_document = _load_unambiguous_json(
                matrix_raw, "python target matrix evidence mismatch"
            )
            if (
                not isinstance(matrix_document, dict)
                or matrix_document.get("wheel_identity")
                != smoke_document["built_wheel"]
            ):
                raise ValueError("python target matrix evidence mismatch")
        else:
            smoke_document = _validated_smoke(
                held["smoke"].raw,
                wheel_identity,
                runtime_requirements_sha256=runtime_requirements_sha256,
            )
            matrix_summary = None

        runtime_value = smoke_document["runtime_distributions"]
        if not isinstance(runtime_value, list):
            raise ValueError("clean-wheel identity evidence failed validation")
        runtime: list[object] = runtime_value
        _validate_sbom_scope(document, runtime)
        built_value = smoke_document["built_wheel"]
        if not isinstance(built_value, dict):
            raise ValueError("clean-wheel identity evidence failed validation")
        built: dict[str, object] = built_value
        artifacts = [
            _entry_bytes("wheel", held["wheel"].raw),
            lock_entry,
            _entry_bytes("sbom.cdx.json", held["sbom"].raw),
        ]
        if strict_matrix:
            artifacts.append(runtime_entry)
            artifacts.append(_entry_bytes("uv-toolchain.json", held["toolchain"].raw))
            artifacts.extend(
                _entry_bytes(
                    f"clean-wheel-smoke-{target}.json",
                    held[f"smoke:{target}"].raw,
                )
                for target in PYTHON_TARGETS
            )
            artifacts.append(
                _entry_bytes(
                    "python-target-matrix.json", held["target_matrix"].raw
                )
            )
            network_containment: object = {
                "clean_wheel_dependency_installation": "os_network_contained",
                "clean_wheel_installed_code_runtime": "os_network_contained",
                "outer_release_and_test_execution": "NOT_PROVEN",
                "scope": "clean_wheel_child_operations_only",
            }
            python_target_matrix: object = matrix_summary
        else:
            artifacts.append(
                _entry_bytes("clean-wheel-smoke.json", held["smoke"].raw)
            )
            artifacts.append(runtime_entry)
            network_containment = smoke_document["network_containment"]
            python_target_matrix = {
                "requires_python": ">=3.12,<3.15",
                "status": "NOT_PROVEN",
                "targets": ["3.12", "3.13", "3.14"],
            }
        manifest: dict[str, object] = {
            "artifacts": artifacts,
            "network_containment": network_containment,
            "package_identity": {
                "identity_match": True,
                "name": built["name"],
                "record_files_sha256": built["record_files_sha256"],
                "version": built["version"],
                "wheel_sha256": built["wheel_sha256"],
            },
            "python_target_matrix": python_target_matrix,
            "sbom": {
                "bomFormat": "CycloneDX",
                "generated_inventory_scope": "locked_all_groups_environment",
                "specVersion": document["specVersion"],
                "surrounding_all_groups_completeness": "NOT_PROVEN",
                "version": document["version"],
                "verified_inventory_scope": "clean_wheel_runtime_closure_subset",
            },
            "schema": "shipworthy-build-manifest/v1",
        }
        if phase0_receipts is not None:
            receipt_entries = []
            for name in receipt_names:
                raw = held[f"receipt:{name}"].raw
                receipt = _load_unambiguous_json(
                    raw, "Phase 0 receipts failed validation"
                )
                if (
                    not isinstance(receipt, dict)
                    or receipt.get("schema") != PHASE0_RECEIPT_SCHEMAS[name]
                ):
                    raise ValueError("Phase 0 receipts failed validation")
                receipt_entries.append(_entry_bytes(f"phase0/{name}", raw))
            manifest["phase0_receipts"] = receipt_entries
        for item in held.values():
            _verify_held_input(item)
        return manifest
    finally:
        for item in held.values():
            os.close(item.descriptor)


def _parse_target_smokes(values: list[str]) -> dict[str, Path]:
    parsed: dict[str, Path] = {}
    for value in values:
        target, separator, raw_path = value.partition("=")
        if not separator or not raw_path or target in parsed:
            raise ValueError("python target matrix evidence mismatch")
        parsed[target] = Path(raw_path)
    if set(parsed) != set(PYTHON_TARGETS):
        raise ValueError("python target matrix evidence mismatch")
    return parsed


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wheel", type=Path, required=True)
    parser.add_argument("--lock", type=Path, required=True)
    parser.add_argument("--source-lock", type=Path, required=True)
    parser.add_argument("--toolchain", type=Path, required=True)
    parser.add_argument("--sbom", type=Path, required=True)
    parser.add_argument("--smoke", type=Path, required=True)
    parser.add_argument("--runtime-requirements", type=Path, required=True)
    parser.add_argument("--phase0-receipts", type=Path, required=True)
    parser.add_argument("--target-smoke", action="append", required=True)
    parser.add_argument("--target-proof", action="append", required=True)
    parser.add_argument("--target-log", action="append", required=True)
    parser.add_argument("--target-matrix", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    manifest = build_manifest(
        wheel=arguments.wheel,
        lock=arguments.lock,
        sbom=arguments.sbom,
        smoke=arguments.smoke,
        runtime_requirements=arguments.runtime_requirements,
        phase0_receipts=arguments.phase0_receipts,
        smokes=_parse_target_smokes(arguments.target_smoke),
        target_matrix=arguments.target_matrix,
        source_lock=arguments.source_lock,
        toolchain=arguments.toolchain,
        proofs=_parse_target_smokes(arguments.target_proof),
        logs=_parse_target_smokes(arguments.target_log),
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
