#!/usr/bin/env python3
"""Write durable evidence for the exact offline release toolchain."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

from write_build_manifest import (
    MAX_LOCK_BYTES,
    MAX_MANIFEST_ARTIFACT_BYTES,
    _open_held_input,
    _verify_held_input,
)


EXPECTED_UV = "uv 0.11.28"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lock", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    resolved = shutil.which("uv")
    if resolved is None:
        return 2
    uv_path = Path(resolved).resolve()
    lock = None
    binary = None
    try:
        lock = _open_held_input(arguments.lock, MAX_LOCK_BYTES)
        binary = _open_held_input(uv_path, MAX_MANIFEST_ARTIFACT_BYTES)
        result = subprocess.run(
            [str(uv_path), "--version"],
            check=False,
            capture_output=True,
            timeout=30,
        )
        if (
            result.returncode != 0
            or re.fullmatch(rb"uv 0\.11\.28(?: \([^\r\n]{1,160}\))?\n?", result.stdout)
            is None
        ):
            return 2
        document = {
            "binary": {
                "bytes": len(binary.raw),
                "name": "uv",
                "path": str(uv_path),
                "sha256": hashlib.sha256(binary.raw).hexdigest(),
            },
            "schema": "shipworthy-uv-toolchain/v1",
            "source_lock_sha256": hashlib.sha256(lock.raw).hexdigest(),
            "uv_version": EXPECTED_UV,
        }
        _verify_held_input(lock)
        _verify_held_input(binary)
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(document, indent=2, sort_keys=True) + "\n"
        with tempfile.NamedTemporaryFile(
            "w",
            dir=arguments.output.parent,
            delete=False,
            encoding="utf-8",
        ) as stream:
            temporary = Path(stream.name)
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, arguments.output)
    finally:
        if binary is not None:
            os.close(binary.descriptor)
        if lock is not None:
            os.close(lock.descriptor)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
