#!/usr/bin/env python3
"""Bind exact Python target, log, and contained wheel-smoke evidence."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
from typing import Mapping

from run_python_target import COMPILE_PATHS


TARGETS = ("3.12", "3.13", "3.14")
MAX_WHEEL_BYTES = 64 * 1024 * 1024
MAX_LOCK_BYTES = 32 * 1024 * 1024
MAX_PROOF_BYTES = 64 * 1024
MAX_LOG_BYTES = 8 * 1024 * 1024
MAX_SMOKE_BYTES = 2 * 1024 * 1024
MAX_RECEIPT_BYTES = 2 * 1024 * 1024
STREAM_CHUNK_BYTES = 64 * 1024
_SHA256 = re.compile(r"[0-9a-f]{64}")


class MatrixEvidenceError(ValueError):
    """Exact target matrix evidence failed closed."""


@dataclass(frozen=True, slots=True)
class _HeldFile:
    key: str
    path: Path
    descriptor: int
    identity: os.stat_result
    maximum: int


def _identity(row: os.stat_result) -> tuple[int, ...]:
    return (
        row.st_dev,
        row.st_ino,
        row.st_mode,
        row.st_nlink,
        row.st_size,
        row.st_mtime_ns,
        row.st_ctime_ns,
    )


def _open_file(key: str, path: Path, maximum: int) -> _HeldFile:
    descriptor = -1
    try:
        path_row = path.lstat()
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        flags |= getattr(os, "O_NONBLOCK", 0)
        descriptor = os.open(path, flags)
        descriptor_row = os.fstat(descriptor)
    except OSError as error:
        if descriptor >= 0:
            os.close(descriptor)
        raise MatrixEvidenceError("matrix evidence is unavailable") from error
    if (
        not stat.S_ISREG(path_row.st_mode)
        or path_row.st_nlink != 1
        or path_row.st_size <= 0
        or path_row.st_size > maximum
        or _identity(path_row) != _identity(descriptor_row)
    ):
        os.close(descriptor)
        raise MatrixEvidenceError("matrix evidence is invalid")
    return _HeldFile(key, path, descriptor, descriptor_row, maximum)


def _read_held(item: _HeldFile) -> bytes:
    try:
        os.lseek(item.descriptor, 0, os.SEEK_SET)
        chunks = []
        observed = 0
        while True:
            chunk = os.read(
                item.descriptor,
                min(STREAM_CHUNK_BYTES, item.maximum + 1 - observed),
            )
            if not chunk:
                break
            chunks.append(chunk)
            observed += len(chunk)
            if observed > item.maximum:
                raise MatrixEvidenceError("matrix evidence is invalid")
        after = os.fstat(item.descriptor)
    except OSError as error:
        raise MatrixEvidenceError("matrix evidence is unreadable") from error
    payload = b"".join(chunks)
    if (
        len(payload) != item.identity.st_size
        or _identity(after) != _identity(item.identity)
    ):
        raise MatrixEvidenceError("matrix evidence changed during read")
    return payload


def _read_inputs(
    specifications: list[tuple[str, Path, int]],
) -> dict[str, bytes]:
    if len({path for _key, path, _maximum in specifications}) != len(
        specifications
    ):
        raise MatrixEvidenceError("matrix evidence paths are not unique")
    held: list[_HeldFile] = []
    try:
        for key, path, maximum in specifications:
            held.append(_open_file(key, path, maximum))
        payloads = {item.key: _read_held(item) for item in held}
        for item in held:
            try:
                descriptor_row = os.fstat(item.descriptor)
                path_row = item.path.lstat()
            except OSError as error:
                raise MatrixEvidenceError(
                    "matrix evidence changed during read"
                ) from error
            if (
                _identity(descriptor_row) != _identity(item.identity)
                or _identity(path_row) != _identity(item.identity)
            ):
                raise MatrixEvidenceError("matrix evidence changed during read")
        return payloads
    finally:
        for item in held:
            os.close(item.descriptor)


def _json(raw: bytes, error: str) -> dict[str, object]:
    def pairs(rows: list[tuple[str, object]]) -> dict[str, object]:
        document: dict[str, object] = {}
        for key, value in rows:
            if key in document:
                raise MatrixEvidenceError(error)
            document[key] = value
        return document

    try:
        document = json.loads(
            raw,
            object_pairs_hook=pairs,
            parse_constant=lambda _value: (_ for _ in ()).throw(
                MatrixEvidenceError(error)
            ),
        )
    except (UnicodeDecodeError, json.JSONDecodeError, MatrixEvidenceError):
        raise MatrixEvidenceError(error) from None
    if not isinstance(document, dict):
        raise MatrixEvidenceError(error)
    return document


def _runtime_matches(runtime: object, target: str) -> bool:
    if not isinstance(runtime, dict):
        return False
    major, minor = map(int, target.split("."))
    patch = runtime.get("patch")
    return (
        runtime.get("implementation") == "CPython"
        and runtime.get("major") == major
        and runtime.get("minor") == minor
        and isinstance(patch, int)
        and not isinstance(patch, bool)
        and patch >= 0
    )


def _validate_proof(raw: bytes, target: str) -> dict[str, object]:
    document = _json(raw, "target proof failed validation")
    compile_result = document.get("compile")
    validation = document.get("validation")
    observed = document.get("observed_python")
    runtime = (
        {**observed, "implementation": document.get("implementation")}
        if isinstance(observed, dict)
        else observed
    )
    if (
        set(document)
        != {
            "compile",
            "implementation",
            "observed_python",
            "schema",
            "status",
            "target",
            "validation",
        }
        or
        document.get("schema") != "shipworthy-python-target-proof/v1"
        or document.get("status") != "passed"
        or document.get("target") != target
        or document.get("implementation") != "CPython"
        or not _runtime_matches(runtime, target)
        or not isinstance(compile_result, dict)
        or set(compile_result) != {"paths", "status"}
        or compile_result.get("paths") != list(COMPILE_PATHS)
        or compile_result.get("status") != "passed"
        or not isinstance(validation, dict)
        or set(validation) != {"command", "status"}
        or validation.get("command") != "scripts/validate_local.py"
        or validation.get("status") != "passed"
    ):
        raise MatrixEvidenceError("target proof failed validation")
    return document


def _validate_smoke(
    raw: bytes, target: str, wheel_sha256: str, lock_sha256: str
) -> dict[str, object]:
    document = _json(raw, "target smoke failed validation")
    built = document.get("built_wheel")
    containment = document.get("network_containment")
    if (
        document.get("schema") != "shipworthy-clean-wheel-smoke/v1"
        or document.get("identity_match") is not True
        or not isinstance(built, dict)
        or built.get("wheel_sha256") != wheel_sha256
        or not isinstance(built.get("name"), str)
        or not isinstance(built.get("version"), str)
        or _SHA256.fullmatch(str(built.get("record_files_sha256"))) is None
        or not _runtime_matches(document.get("python_runtime"), target)
        or not isinstance(containment, dict)
        or containment.get("bind_probe") != "EPERM"
        or containment.get("connect_probe") != "EPERM"
        or containment.get("dependency_installation")
        != "offline_locked_os_network_contained"
        or containment.get("dependency_source") != "uv_sync_locked"
        or containment.get("installed_code_runtime") != "os_network_contained"
        or containment.get("mechanism")
        != "macos_sandbox_exec_deny_network"
        or containment.get("scope") != "clean_wheel_child_operations_only"
        or _SHA256.fullmatch(str(containment.get("profile_sha256"))) is None
        or _SHA256.fullmatch(str(containment.get("sandbox_exec_sha256"))) is None
        or containment.get("uv_lock_sha256") != lock_sha256
        or document.get("uv_lock_sha256") != lock_sha256
    ):
        raise MatrixEvidenceError("target smoke failed validation")
    return document


def _entry(path: Path, raw: bytes) -> dict[str, object]:
    return {
        "bytes": len(raw),
        "name": path.name,
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def build_target_matrix(
    *,
    wheel: Path,
    lock: Path,
    proofs: Mapping[str, Path],
    logs: Mapping[str, Path],
    smokes: Mapping[str, Path],
) -> dict[str, object]:
    if any(set(selected) != set(TARGETS) for selected in (proofs, logs, smokes)):
        raise MatrixEvidenceError("matrix evidence requires exact targets")
    specifications = [
        ("wheel", wheel, MAX_WHEEL_BYTES),
        ("lock", lock, MAX_LOCK_BYTES),
    ]
    for target in TARGETS:
        specifications.extend(
            (
                (f"proof:{target}", proofs[target], MAX_PROOF_BYTES),
                (f"log:{target}", logs[target], MAX_LOG_BYTES),
                (f"smoke:{target}", smokes[target], MAX_SMOKE_BYTES),
            )
        )
    payloads = _read_inputs(specifications)
    wheel_sha256 = hashlib.sha256(payloads["wheel"]).hexdigest()
    lock_sha256 = hashlib.sha256(payloads["lock"]).hexdigest()
    rows = []
    built_identity: object = None
    for target in TARGETS:
        _validate_proof(payloads[f"proof:{target}"], target)
        smoke = _validate_smoke(
            payloads[f"smoke:{target}"], target, wheel_sha256, lock_sha256
        )
        if built_identity is None:
            built_identity = smoke["built_wheel"]
        elif smoke["built_wheel"] != built_identity:
            raise MatrixEvidenceError("target smoke wheel identity mismatch")
        rows.append(
            {
                "log": _entry(logs[target], payloads[f"log:{target}"]),
                "proof": _entry(proofs[target], payloads[f"proof:{target}"]),
                "smoke": _entry(smokes[target], payloads[f"smoke:{target}"]),
                "target": target,
            }
        )
    return {
        "limitations": {
            "all_groups_on_every_target": "NOT_PROVEN",
            "other_os_architectures": "NOT_PROVEN",
            "other_patch_releases": "NOT_PROVEN",
            "outer_release_and_test_containment": "NOT_PROVEN",
        },
        "lock": _entry(lock, payloads["lock"]),
        "network_containment_scope": "clean_wheel_child_operations_only",
        "schema": "shipworthy-python-target-matrix/v1",
        "status": "PROVEN",
        "targets": rows,
        "wheel": _entry(wheel, payloads["wheel"]),
        "wheel_identity": built_identity,
    }


def _parse_target_paths(values: list[str], label: str) -> dict[str, Path]:
    parsed: dict[str, Path] = {}
    for value in values:
        target, separator, raw_path = value.partition("=")
        if not separator or not raw_path or target in parsed:
            raise MatrixEvidenceError(f"{label} requires exact targets")
        parsed[target] = Path(raw_path)
    if set(parsed) != set(TARGETS):
        raise MatrixEvidenceError(f"{label} requires exact targets")
    return parsed


def _write_output(path: Path, document: Mapping[str, object]) -> None:
    payload = (json.dumps(document, indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )
    if len(payload) > MAX_RECEIPT_BYTES:
        raise MatrixEvidenceError("matrix receipt exceeds size budget")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    flags |= getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags, 0o600)
    try:
        offset = 0
        while offset < len(payload):
            written = os.write(descriptor, payload[offset:])
            if written <= 0:
                raise OSError("matrix receipt write failed")
            offset += written
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wheel", type=Path, required=True)
    parser.add_argument("--lock", type=Path, required=True)
    parser.add_argument("--proof", action="append", required=True)
    parser.add_argument("--log", action="append", required=True)
    parser.add_argument("--smoke", action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    try:
        document = build_target_matrix(
            wheel=arguments.wheel,
            lock=arguments.lock,
            proofs=_parse_target_paths(arguments.proof, "proofs"),
            logs=_parse_target_paths(arguments.log, "logs"),
            smokes=_parse_target_paths(arguments.smoke, "smokes"),
        )
        _write_output(arguments.output, document)
    except (MatrixEvidenceError, OSError) as error:
        print(f"python target matrix: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
