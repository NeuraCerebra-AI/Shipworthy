#!/usr/bin/env python3
"""Prove the repository gates under one exact CPython target."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
COMPILE_PATHS = (
    "src",
    "scripts",
    "tests",
    "plugins/shipworthy/skills/ship-readiness-orchestrator/scripts",
)
MAX_PROOF_BYTES = 64 * 1024
TARGET_TIMEOUT_SECONDS = 1_800
_TARGET = re.compile(r"3\.(?:12|13|14)")
_ENV_KEYS = frozenset(
    {
        "HOME",
        "LANG",
        "LC_ALL",
        "LC_CTYPE",
        "PATH",
        "TEMP",
        "TMP",
        "TMPDIR",
    }
)


def _error(message: str) -> int:
    print(f"python target proof: {message}", file=sys.stderr)
    return 2


def _environment() -> dict[str, str]:
    return {key: value for key, value in os.environ.items() if key in _ENV_KEYS}


def _run_compile_gate() -> bool:
    if any(not (ROOT / relative).exists() for relative in COMPILE_PATHS):
        return False
    with tempfile.TemporaryDirectory(prefix="shipworthy-compile-") as pycache:
        environment = _environment()
        environment["PYTHONPYCACHEPREFIX"] = pycache
        result = subprocess.run(
            [sys.executable, "-m", "compileall", "-q", *COMPILE_PATHS],
            cwd=ROOT,
            check=False,
            env=environment,
            timeout=TARGET_TIMEOUT_SECONDS,
        )
    return result.returncode == 0


def _run_validation_gate() -> bool:
    environment = _environment()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        [sys.executable, "scripts/validate_local.py"],
        cwd=ROOT,
        check=False,
        env=environment,
        timeout=TARGET_TIMEOUT_SECONDS,
    )
    return result.returncode == 0


def _write_proof(output: Path, document: dict[str, object]) -> None:
    payload = (json.dumps(document, indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )
    if len(payload) > MAX_PROOF_BYTES:
        raise ValueError("proof exceeds size budget")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    flags |= getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(output, flags, 0o600)
    try:
        view = memoryview(payload)
        offset = 0
        while offset < len(view):
            written = os.write(descriptor, view[offset:])
            if written <= 0:
                raise OSError("proof write failed")
            offset += written
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def run_target(expected: str, output: Path) -> int:
    observed = (sys.version_info.major, sys.version_info.minor)
    if (
        _TARGET.fullmatch(expected) is None
        or platform.python_implementation() != "CPython"
        or observed != tuple(map(int, expected.split(".")))
    ):
        return _error("runtime target mismatch")
    previous_pycache_prefix = sys.pycache_prefix
    try:
        with tempfile.TemporaryDirectory(
            prefix="shipworthy-runner-pycache-"
        ) as pycache:
            sys.pycache_prefix = pycache
            if not _run_compile_gate():
                return _error("compile gate failed")
            if not _run_validation_gate():
                return _error("validation gate failed")
    finally:
        sys.pycache_prefix = previous_pycache_prefix
    document: dict[str, object] = {
        "compile": {"paths": list(COMPILE_PATHS), "status": "passed"},
        "implementation": "CPython",
        "observed_python": {
            "major": sys.version_info.major,
            "minor": sys.version_info.minor,
            "patch": sys.version_info.micro,
        },
        "schema": "shipworthy-python-target-proof/v1",
        "status": "passed",
        "target": expected,
        "validation": {
            "command": "scripts/validate_local.py",
            "status": "passed",
        },
    }
    try:
        _write_proof(output, document)
    except (OSError, ValueError):
        return _error("proof write failed")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected-python", required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    return run_target(arguments.expected_python, arguments.output)


if __name__ == "__main__":
    raise SystemExit(main())
