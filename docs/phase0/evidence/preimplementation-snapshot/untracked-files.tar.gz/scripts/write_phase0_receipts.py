#!/usr/bin/env python3
"""Write deterministic Phase 0 compatibility and migration receipts."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

from shipworthy.phase0_receipts import Phase0ReceiptError
from shipworthy.phase0_receipts import generate_phase0_receipts


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    try:
        generate_phase0_receipts(
            repository_root=ROOT,
            output_dir=arguments.output,
        )
    except (OSError, Phase0ReceiptError, ValueError):
        print("phase0 receipts: generation failed", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
