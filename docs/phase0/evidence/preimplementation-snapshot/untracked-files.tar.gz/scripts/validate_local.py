#!/usr/bin/env python3
"""Run the local validation matrix, with an opt-in strict release gate."""

from __future__ import annotations

import argparse
from collections.abc import Mapping
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import uuid

from write_build_manifest import (
    MAX_LOCK_BYTES,
    _HeldInput,
    _open_held_input,
    _verify_held_input,
)


ROOT = Path(__file__).resolve().parents[1]
LEGACY = ROOT / "plugins/shipworthy/skills/ship-readiness-orchestrator/scripts"
EXPECTED_UV = "uv 0.11.28"
RELEASE_SUBPROCESS_TIMEOUT_SECONDS = 900
RELEASE_LOG_MAX_BYTES = 8 * 1024 * 1024
RELEASE_PROCESS_TERMINATE_GRACE_SECONDS = 0.25
RELEASE_PROCESS_KILL_GRACE_SECONDS = 0.5
RELEASE_LOG_READER_JOIN_SECONDS = 0.5
RELEASE_PROCESS_MONITOR_INTERVAL_SECONDS = 0.02
RELEASE_PROCESS_SNAPSHOT_TIMEOUT_SECONDS = 0.5
RELEASE_PROCESS_SNAPSHOT_MAX_BYTES = 1024 * 1024
RELEASE_PROCESS_GROUPS_SUPPORTED = os.name == "posix" and hasattr(os, "killpg")
RELEASE_PS = next(
    (candidate for candidate in ("/bin/ps", "/usr/bin/ps") if Path(candidate).is_file()),
    None,
)
RELEASE_LOG_STAGE_NAMES = (
    "01-lock-check",
    "02-runtime-export",
    "03-sync",
    "04-tests",
    "05-legacy-skill-contract",
    "06-legacy-render-report",
    "07-legacy-to-sarif",
    "08-legacy-make-bundle",
    "09-git-diff-check",
    "10-build-wheel",
    "11-python-3.12",
    "12-python-3.13",
    "13-python-3.14",
    "14-sbom",
    "15-clean-wheel-3.12",
    "16-clean-wheel-3.13",
    "17-clean-wheel-3.14",
    "18-phase0-receipts",
    "19-python-target-matrix",
    "20-uv-toolchain",
    "21-build-manifest",
)
_HERMETIC_ENV_KEYS = frozenset(
    {
        "COMSPEC",
        "HOME",
        "LANG",
        "LC_ALL",
        "LC_CTYPE",
        "PATH",
        "PATHEXT",
        "SYSTEMROOT",
        "TEMP",
        "TMP",
        "TMPDIR",
        "WINDIR",
    }
)


def local_stages() -> list[list[str]]:
    return [
        [sys.executable, "-m", "pytest", "tests"],
        [sys.executable, str(LEGACY / "test_skill_contract.py")],
        [sys.executable, str(LEGACY / "test_render_report.py")],
        [sys.executable, str(LEGACY / "test_to_sarif.py")],
        [sys.executable, str(LEGACY / "test_make_bundle.py")],
    ]


def _runtime_notice(version: tuple[int, int]) -> str | None:
    if (3, 12) <= version < (3, 15):
        return None
    rendered = f"{version[0]}.{version[1]}"
    return (
        f"local validation: Python {rendered} is outside >=3.12,<3.15; "
        "result is compatibility-only and target runtime remains NOT_PROVEN"
    )


def _display_stages(stages: list[list[str]]) -> list[list[str]]:
    displayed: list[list[str]] = []
    for command in stages:
        displayed.append(
            [
                str(Path(item).relative_to(ROOT))
                if index != 0 and item.startswith(str(ROOT) + "/")
                else item
                for index, item in enumerate(command)
            ]
        )
    return displayed


def _release_environment(source: Mapping[str, str]) -> dict[str, str]:
    sanitized = {
        key: value
        for key, value in source.items()
        if key.upper() in _HERMETIC_ENV_KEYS
    }
    sanitized.update(
        {
            "UV_NO_CONFIG": "1",
            "UV_OFFLINE": "1",
            "UV_PYTHON_DOWNLOADS": "never",
        }
    )
    return sanitized


def _open_release_log(log_path: Path) -> int:
    if (
        log_path.suffix != ".log"
        or log_path.stem not in RELEASE_LOG_STAGE_NAMES
        or log_path.parent.name != "logs"
    ):
        raise OSError("invalid release log path")
    staging = log_path.parent.parent
    if not stat.S_ISDIR(os.lstat(staging).st_mode):
        raise OSError("invalid release staging directory")
    try:
        os.mkdir(log_path.parent, mode=0o700)
    except FileExistsError:
        pass
    if not stat.S_ISDIR(os.lstat(log_path.parent).st_mode):
        raise OSError("invalid release logs directory")
    if log_path.parent.resolve(strict=True).parent != staging.resolve(strict=True):
        raise OSError("release logs directory escapes staging")

    directory_flags = os.O_RDONLY
    directory_flags |= getattr(os, "O_DIRECTORY", 0)
    directory_flags |= getattr(os, "O_NOFOLLOW", 0)
    log_flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    log_flags |= getattr(os, "O_NOFOLLOW", 0)
    directory_fd = os.open(log_path.parent, directory_flags)
    try:
        log_fd = os.open(
            log_path.name,
            log_flags,
            0o600,
            dir_fd=directory_fd,
        )
    finally:
        os.close(directory_fd)
    if not stat.S_ISREG(os.fstat(log_fd).st_mode):
        os.close(log_fd)
        raise OSError("release log is not a regular file")
    return log_fd


def _write_all(file_descriptor: int, content: bytes) -> None:
    remaining = memoryview(content)
    while remaining:
        written = os.write(file_descriptor, remaining)
        if written <= 0:
            raise OSError("release log write failed")
        remaining = remaining[written:]


@dataclass(frozen=True)
class _ProcessIdentity:
    pid: int
    parent_pid: int
    started: str


def _process_snapshot() -> dict[int, _ProcessIdentity] | None:
    if RELEASE_PS is None:
        return None
    try:
        with tempfile.TemporaryFile() as output:
            result = subprocess.run(
                [RELEASE_PS, "-axo", "pid=,ppid=,lstart="],
                check=False,
                stdout=output,
                stderr=subprocess.DEVNULL,
                env=_release_environment(os.environ),
                timeout=RELEASE_PROCESS_SNAPSHOT_TIMEOUT_SECONDS,
            )
            output.seek(0)
            raw = output.read(RELEASE_PROCESS_SNAPSHOT_MAX_BYTES + 1)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0 or len(raw) > RELEASE_PROCESS_SNAPSHOT_MAX_BYTES:
        return None
    snapshot: dict[int, _ProcessIdentity] = {}
    for line in raw.decode("utf-8", errors="replace").splitlines():
        fields = line.split()
        if len(fields) < 7:
            return None
        try:
            pid = int(fields[0])
            parent_pid = int(fields[1])
        except ValueError:
            return None
        snapshot[pid] = _ProcessIdentity(
            pid=pid,
            parent_pid=parent_pid,
            started=" ".join(fields[2:7]),
        )
    return snapshot


def _record_descendants(
    root_pid: int,
    tracked: dict[int, _ProcessIdentity],
    lock: threading.Lock,
) -> bool:
    snapshot = _process_snapshot()
    if snapshot is None:
        return False
    family = {root_pid}
    changed = True
    while changed:
        changed = False
        for identity in snapshot.values():
            if identity.pid not in family and identity.parent_pid in family:
                family.add(identity.pid)
                changed = True
    with lock:
        for pid in family - {root_pid}:
            candidate = snapshot.get(pid)
            if candidate is not None:
                tracked[pid] = candidate
    return True


def _signal_tracked_descendants(
    tracked: dict[int, _ProcessIdentity],
    lock: threading.Lock,
    selected_signal: signal.Signals,
) -> bool:
    snapshot = _process_snapshot()
    if snapshot is None:
        return False
    with lock:
        identities = tuple(tracked.values())
    signaled = True
    for identity in identities:
        current = snapshot.get(identity.pid)
        if current is None or current.started != identity.started:
            continue
        try:
            os.kill(identity.pid, selected_signal)
        except ProcessLookupError:
            pass
        except OSError:
            signaled = False
    return signaled


def _signal_release_process_group(
    process: subprocess.Popen[bytes], selected_signal: signal.Signals
) -> bool:
    try:
        os.killpg(process.pid, selected_signal)
    except ProcessLookupError:
        return True
    except OSError:
        return False
    return True


def _shutdown_release_process_group(
    process: subprocess.Popen[bytes],
    reader: threading.Thread,
    tracked: dict[int, _ProcessIdentity],
    tracking_lock: threading.Lock,
) -> bool:
    shutdown_cleanly = _signal_tracked_descendants(
        tracked, tracking_lock, signal.SIGTERM
    )
    shutdown_cleanly = (
        _signal_release_process_group(process, signal.SIGTERM)
        and shutdown_cleanly
    )
    try:
        process.wait(timeout=RELEASE_PROCESS_TERMINATE_GRACE_SECONDS)
    except subprocess.TimeoutExpired:
        shutdown_cleanly = (
            _signal_release_process_group(process, signal.SIGKILL)
            and shutdown_cleanly
        )
        try:
            process.wait(timeout=RELEASE_PROCESS_KILL_GRACE_SECONDS)
        except subprocess.TimeoutExpired:
            shutdown_cleanly = False
    reader.join(timeout=RELEASE_LOG_READER_JOIN_SECONDS)
    shutdown_cleanly = (
        _signal_tracked_descendants(tracked, tracking_lock, signal.SIGKILL)
        and shutdown_cleanly
    )
    shutdown_cleanly = (
        _signal_release_process_group(process, signal.SIGKILL)
        and shutdown_cleanly
    )
    if reader.is_alive():
        reader.join(timeout=RELEASE_PROCESS_KILL_GRACE_SECONDS)
    return shutdown_cleanly and process.poll() is not None and not reader.is_alive()


def _run_release(command: list[str], log_path: Path) -> bool:
    print("release validation: running subprocess", flush=True)
    if not RELEASE_PROCESS_GROUPS_SUPPORTED:
        print(
            "release validation: process isolation unavailable",
            file=sys.stderr,
        )
        return False
    try:
        log_fd = _open_release_log(log_path)
    except OSError:
        print("release validation: log creation failed", file=sys.stderr)
        return False

    try:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            env=_release_environment(os.environ),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=0,
            start_new_session=True,
        )
    except OSError:
        os.close(log_fd)
        print("release validation: subprocess execution failed", file=sys.stderr)
        return False

    exceeded = threading.Event()
    capture_failed = threading.Event()
    tracking_failed = threading.Event()
    tracking_stop = threading.Event()
    tracking_lock = threading.Lock()
    tracked: dict[int, _ProcessIdentity] = {}

    def monitor_descendants() -> None:
        # This is bounded, best-effort cleanup for trusted local release
        # commands, not a process sandbox.  A descendant that is spawned and
        # reparented entirely between polling snapshots can evade observation;
        # OS-level containment must therefore be evidenced separately and must
        # not be inferred from this monitor.
        while not tracking_stop.is_set():
            if not _record_descendants(process.pid, tracked, tracking_lock):
                tracking_failed.set()
                return
            tracking_stop.wait(RELEASE_PROCESS_MONITOR_INTERVAL_SECONDS)

    def capture_output() -> None:
        captured = 0
        try:
            assert process.stdout is not None
            with process.stdout:
                while True:
                    chunk = process.stdout.read(64 * 1024)
                    if not chunk:
                        break
                    available = max(RELEASE_LOG_MAX_BYTES - captured, 0)
                    if available:
                        retained = chunk[:available]
                        _write_all(log_fd, retained)
                        captured += len(retained)
                    if len(chunk) > available:
                        exceeded.set()
                        _signal_release_process_group(process, signal.SIGKILL)
        except OSError:
            capture_failed.set()
            _signal_release_process_group(process, signal.SIGKILL)

    reader = threading.Thread(target=capture_output, daemon=True)
    monitor = threading.Thread(target=monitor_descendants, daemon=True)
    reader.start()
    monitor.start()
    timed_out = False
    try:
        return_code = process.wait(
            timeout=RELEASE_SUBPROCESS_TIMEOUT_SECONDS
        )
    except subprocess.TimeoutExpired:
        timed_out = True
        return_code = -1
    if timed_out and not _record_descendants(
        process.pid, tracked, tracking_lock
    ):
        tracking_failed.set()
    tracking_stop.set()
    monitor.join(timeout=RELEASE_LOG_READER_JOIN_SECONDS)
    if monitor.is_alive():
        tracking_failed.set()
    shutdown_failed = False
    if (
        timed_out
        or exceeded.is_set()
        or capture_failed.is_set()
        or tracking_failed.is_set()
    ):
        shutdown_failed = not _shutdown_release_process_group(
            process, reader, tracked, tracking_lock
        )
    else:
        reader.join(timeout=RELEASE_LOG_READER_JOIN_SECONDS)
        if reader.is_alive():
            capture_failed.set()
            shutdown_failed = not _shutdown_release_process_group(
                process, reader, tracked, tracking_lock
            )
    try:
        os.fsync(log_fd)
    except OSError:
        capture_failed.set()
    finally:
        os.close(log_fd)

    if exceeded.is_set():
        print(
            "release validation: subprocess log exceeded limit",
            file=sys.stderr,
        )
        return False
    if timed_out:
        print("release validation: subprocess timed out", file=sys.stderr)
        return False
    if capture_failed.is_set():
        print("release validation: log capture failed", file=sys.stderr)
        return False
    if tracking_failed.is_set():
        print("release validation: process containment failed", file=sys.stderr)
        return False
    if shutdown_failed:
        print("release validation: subprocess shutdown failed", file=sys.stderr)
        return False
    return return_code == 0


def _run(
    command: list[str],
    *,
    release: bool = False,
    log_path: Path | None = None,
) -> bool:
    if release:
        if log_path is None:
            print("release validation: log creation failed", file=sys.stderr)
            return False
        return _run_release(command, log_path)
    else:
        print(f"validation: {' '.join(command)}", flush=True)
    try:
        result = subprocess.run(
            command,
            cwd=ROOT,
            check=False,
            env=None,
            timeout=RELEASE_SUBPROCESS_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        print("validation: subprocess timed out", file=sys.stderr)
        return False
    except OSError:
        print("validation: subprocess execution failed", file=sys.stderr)
        return False
    return result.returncode == 0


@dataclass(frozen=True)
class ReleasePaths:
    artifacts: Path
    run_id: str
    staging: Path
    dist: Path
    release: Path
    status: Path
    current: Path


def _atomic_json(path: Path, document: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(
        json.dumps(document, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _atomic_bytes(path: Path, raw: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    temporary.write_bytes(raw)
    os.replace(temporary, path)


def _run_release_stage(
    snapshot: _HeldInput,
    staged_lock: Path,
    command: list[str],
    *,
    log_path: Path,
) -> bool:
    passed = _run(command, release=True, log_path=log_path)
    try:
        _verify_held_input(snapshot)
        if staged_lock.read_bytes() != snapshot.raw:
            raise ValueError
    except (OSError, ValueError):
        print("release validation: source lock changed", file=sys.stderr)
        return False
    return passed


def _new_release_paths(
    artifacts: Path, *, run_id: str | None = None
) -> ReleasePaths:
    selected = uuid.uuid4().hex if run_id is None else run_id
    if re.fullmatch(r"[A-Za-z0-9_-]{1,64}", selected) is None:
        raise ValueError("invalid release run id")
    staging = artifacts / ".staging" / selected
    release = artifacts / "releases" / selected
    staging.mkdir(parents=True, exist_ok=False)
    (staging / "dist").mkdir()
    release.parent.mkdir(parents=True, exist_ok=True)
    paths = ReleasePaths(
        artifacts=artifacts,
        run_id=selected,
        staging=staging,
        dist=staging / "dist",
        release=release,
        status=artifacts / "release-status.json",
        current=artifacts / "current.json",
    )
    _atomic_json(paths.status, {"run_id": selected, "status": "running"})
    _atomic_json(
        paths.current, {"run_id": selected, "status": "not_current"}
    )
    return paths


def _fail_release(paths: ReleasePaths) -> None:
    _atomic_json(
        paths.current,
        {"run_id": paths.run_id, "status": "not_current"},
    )
    _atomic_json(
        paths.status, {"run_id": paths.run_id, "status": "failed"}
    )


def _promote_release(paths: ReleasePaths) -> None:
    if paths.release.exists():
        raise ValueError("release destination already exists")
    os.replace(paths.staging, paths.release)
    pointer = {
        "path": f"releases/{paths.run_id}",
        "run_id": paths.run_id,
        "status": "passed",
    }
    _atomic_json(paths.status, pointer)
    _atomic_json(paths.current, pointer)


def _strict_release_prerequisites() -> bool:
    if shutil.which("uv") is None:
        print("release validation: uv is unavailable", file=sys.stderr)
        return False
    if not (ROOT / "uv.lock").is_file():
        print("release validation: uv.lock is missing", file=sys.stderr)
        return False
    try:
        with tempfile.TemporaryFile() as version_output:
            result = subprocess.run(
                ["uv", "--version"],
                check=False,
                stdout=version_output,
                stderr=subprocess.DEVNULL,
                env=_release_environment(os.environ),
                timeout=30,
            )
            version_output.seek(0)
            version_bytes = version_output.read(257)
    except (OSError, subprocess.TimeoutExpired):
        print("release validation: uv execution failed", file=sys.stderr)
        return False
    if (
        result.returncode != 0
        or len(version_bytes) > 256
        or not _uv_version_is_expected(version_bytes)
    ):
        print(
            f"release validation: requires {EXPECTED_UV}", file=sys.stderr
        )
        return False
    return True


def _uv_version_is_expected(raw: bytes) -> bool:
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return False
    return (
        re.fullmatch(
            r"uv 0\.11\.28(?: \([A-Za-z0-9._+ -]{1,160}\))?\n?",
            text,
        )
        is not None
    )


def _uv_command(*arguments: str) -> list[str]:
    return [
        "uv",
        "--no-config",
        "--offline",
        "--no-python-downloads",
        *arguments,
    ]


def _release_commands(
    staging: Path = Path("artifacts/.staging/TEST"),
) -> list[list[str]]:
    release_prefix = _uv_command("run", "--no-sync", "python")
    return [
        _uv_command("lock", "--check"),
        _uv_command(
            "export",
            "--locked",
            "--no-dev",
            "--no-emit-project",
            "--output-file",
            str(staging / "runtime-requirements.txt"),
        ),
        _uv_command("sync", "--locked", "--all-groups"),
        [*release_prefix, "-m", "pytest", "tests"],
        *[
            [*release_prefix, str(script.relative_to(ROOT))]
            for script in (
                LEGACY / "test_skill_contract.py",
                LEGACY / "test_render_report.py",
                LEGACY / "test_to_sarif.py",
                LEGACY / "test_make_bundle.py",
            )
        ],
        ["git", "diff", "--check"],
        _uv_command(
            "build", "--wheel", "--out-dir", str(staging / "dist")
        ),
    ]


def _phase0_receipt_command(staging: Path) -> list[str]:
    return [
        *_uv_command("run", "--no-sync", "python"),
        "scripts/write_phase0_receipts.py",
        "--output",
        str(staging / "phase0"),
    ]


def _sbom_command(staging: Path) -> list[str]:
    return [
        *_uv_command("run", "--no-sync", "python"),
        "scripts/generate_sbom_locked.py",
        "--lock",
        "uv.lock",
        "--output",
        str(staging / "sbom.cdx.json"),
    ]


def _uv_toolchain_command(staging: Path) -> list[str]:
    return [
        *_uv_command("run", "--no-sync", "python"),
        "scripts/write_uv_toolchain.py",
        "--lock",
        "uv.lock",
        "--output",
        str(staging / "uv-toolchain.json"),
    ]


def _python_target_commands(staging: Path) -> list[list[str]]:
    commands = []
    for target in ("3.12", "3.13", "3.14"):
        commands.append(
            [
                *_uv_command(
                    "run",
                    "--isolated",
                    "--locked",
                    "--no-default-groups",
                    "--group",
                    "test",
                    "--python",
                    target,
                    "python",
                ),
                "scripts/run_python_target.py",
                "--expected-python",
                target,
                "--output",
                str(staging / f"python-target-{target}.json"),
            ]
        )
    return commands


def _clean_wheel_smoke_commands(
    staging: Path, wheel: Path, runtime_requirements: Path
) -> list[list[str]]:
    commands = []
    for target in ("3.12", "3.13", "3.14"):
        commands.append(
            [
                *_uv_command(
                    "run",
                    "--isolated",
                    "--locked",
                    "--no-default-groups",
                    "--python",
                    target,
                    "python",
                ),
                "scripts/clean_wheel_smoke.py",
                "--wheel",
                str(wheel),
                "--fixture",
                "tests/fixtures/v1/incomplete-ledger.json",
                "--output",
                str(staging / f"clean-wheel-smoke-{target}.json"),
                "--runtime-requirements",
                str(runtime_requirements),
                "--lock",
                "uv.lock",
                "--expected-python",
                target,
                "--require-os-network-containment",
            ]
        )
    return commands


def _python_matrix_receipt_command(
    staging: Path, wheel: Path
) -> list[str]:
    command = [
        *_uv_command("run", "--no-sync", "python"),
        "scripts/write_python_target_matrix.py",
        "--wheel",
        str(wheel),
        "--lock",
        str(staging / "uv.lock"),
    ]
    for index, target in enumerate(("3.12", "3.13", "3.14"), start=11):
        command.extend(
            [
                "--proof",
                f"{target}={staging / f'python-target-{target}.json'}",
                "--log",
                f"{target}={staging / 'logs' / f'{index:02d}-python-{target}.log'}",
                "--smoke",
                f"{target}={staging / f'clean-wheel-smoke-{target}.json'}",
            ]
        )
    command.extend(
        ["--output", str(staging / "python-target-matrix.json")]
    )
    return command


def _build_manifest_command(
    staging: Path,
    wheel: Path,
    sbom: Path,
    smoke_evidence: Path,
    runtime_requirements: Path,
) -> list[str]:
    command = [
        *_uv_command("run", "--no-sync", "python"),
        "scripts/write_build_manifest.py",
        "--wheel",
        str(wheel),
        "--lock",
        str(staging / "uv.lock"),
        "--source-lock",
        "uv.lock",
        "--toolchain",
        str(staging / "uv-toolchain.json"),
        "--sbom",
        str(sbom),
        "--smoke",
        str(smoke_evidence),
        "--runtime-requirements",
        str(runtime_requirements),
        "--phase0-receipts",
        str(staging / "phase0"),
        "--target-matrix",
        str(staging / "python-target-matrix.json"),
    ]
    for target in ("3.12", "3.13", "3.14"):
        command.extend([
            "--target-smoke",
            f"{target}={staging / f'clean-wheel-smoke-{target}.json'}",
            "--target-proof",
            f"{target}={staging / f'python-target-{target}.json'}",
        ])
    for index, target in enumerate(("3.12", "3.13", "3.14"), start=11):
        command.extend([
            "--target-log",
            f"{target}={staging / 'logs' / f'{index:02d}-python-{target}.log'}",
        ])
    command.extend(
        ["--output", str(staging / "build-manifest.json")]
    )
    return command


def _release_body(paths: ReleasePaths, snapshot: _HeldInput) -> int:
    staged_lock = paths.staging / "uv.lock"
    for stage_name, command in zip(
        RELEASE_LOG_STAGE_NAMES[:10],
        _release_commands(paths.staging),
        strict=True,
    ):
        if not _run_release_stage(
            snapshot,
            staged_lock,
            command,
            log_path=paths.staging / "logs" / f"{stage_name}.log",
        ):
            _fail_release(paths)
            return 1
    wheels = sorted(paths.dist.glob("shipworthy_core-*.whl"))
    if len(wheels) != 1:
        print("release validation: expected exactly one wheel", file=sys.stderr)
        _fail_release(paths)
        return 1
    wheel = wheels[0]
    sbom = paths.staging / "sbom.cdx.json"
    runtime_requirements = paths.staging / "runtime-requirements.txt"
    for stage_name, command in zip(
        RELEASE_LOG_STAGE_NAMES[10:13],
        _python_target_commands(paths.staging),
        strict=True,
    ):
        if not _run_release_stage(
            snapshot,
            staged_lock,
            command,
            log_path=paths.staging / "logs" / f"{stage_name}.log",
        ):
            _fail_release(paths)
            return 1
    if not _run_release_stage(
        snapshot,
        staged_lock,
        _sbom_command(paths.staging),
        log_path=paths.staging / "logs/14-sbom.log",
    ):
        _fail_release(paths)
        return 1
    for stage_name, command in zip(
        RELEASE_LOG_STAGE_NAMES[14:17],
        _clean_wheel_smoke_commands(
            paths.staging, wheel, runtime_requirements
        ),
        strict=True,
    ):
        if not _run_release_stage(
            snapshot,
            staged_lock,
            command,
            log_path=paths.staging / "logs" / f"{stage_name}.log",
        ):
            _fail_release(paths)
            return 1
    if not _run_release_stage(
        snapshot,
        staged_lock,
        _phase0_receipt_command(paths.staging),
        log_path=paths.staging / "logs/18-phase0-receipts.log",
    ):
        _fail_release(paths)
        return 1
    if not _run_release_stage(
        snapshot,
        staged_lock,
        _python_matrix_receipt_command(paths.staging, wheel),
        log_path=paths.staging / "logs/19-python-target-matrix.log",
    ):
        _fail_release(paths)
        return 1
    if not _run_release_stage(
        snapshot,
        staged_lock,
        _uv_toolchain_command(paths.staging),
        log_path=paths.staging / "logs/20-uv-toolchain.log",
    ):
        _fail_release(paths)
        return 1
    manifest_command = _build_manifest_command(
        paths.staging,
        wheel,
        sbom,
        paths.staging / "clean-wheel-smoke-3.13.json",
        runtime_requirements,
    )
    if not _run_release_stage(
        snapshot,
        staged_lock,
        manifest_command,
        log_path=paths.staging / "logs/21-build-manifest.log",
    ):
        _fail_release(paths)
        return 1
    try:
        _promote_release(paths)
    except (OSError, ValueError):
        _fail_release(paths)
        return 1
    return 0


def _release() -> int:
    paths = _new_release_paths(ROOT / "artifacts")
    if not _strict_release_prerequisites():
        _fail_release(paths)
        return 2
    try:
        snapshot = _open_held_input(ROOT / "uv.lock", MAX_LOCK_BYTES)
    except ValueError:
        _fail_release(paths)
        return 2
    try:
        _atomic_bytes(paths.staging / "uv.lock", snapshot.raw)
        return _release_body(paths, snapshot)
    finally:
        os.close(snapshot.descriptor)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--release", action="store_true")
    arguments = parser.parse_args()
    if arguments.list:
        print(json.dumps(_display_stages(local_stages())))
        return 0
    if arguments.release:
        return _release()
    notice = _runtime_notice((sys.version_info.major, sys.version_info.minor))
    if notice is not None:
        print(notice, file=sys.stderr)
    return 0 if all(_run(command) for command in local_stages()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
