from __future__ import annotations

from typing import Annotated

from pydantic import StringConstraints


_ID_SUFFIX = r"[A-Z0-9][A-Z0-9._-]{0,62}"

ArtifactId = Annotated[
    str, StringConstraints(pattern=rf"^ART-{_ID_SUFFIX}$", min_length=5, max_length=67)
]
DebtId = Annotated[
    str, StringConstraints(pattern=rf"^ED-{_ID_SUFFIX}$", min_length=4, max_length=66)
]
FindingId = Annotated[
    str, StringConstraints(pattern=rf"^FND-{_ID_SUFFIX}$", min_length=5, max_length=67)
]
LedgerId = Annotated[
    str, StringConstraints(pattern=rf"^LED-{_ID_SUFFIX}$", min_length=5, max_length=67)
]
ReportInputId = Annotated[
    str, StringConstraints(pattern=rf"^RPT-{_ID_SUFFIX}$", min_length=5, max_length=67)
]
StableId = Annotated[
    str,
    StringConstraints(
        pattern=r"^[A-Z][A-Z0-9]{1,7}-[A-Z0-9][A-Z0-9._-]{0,62}$",
        min_length=4,
        max_length=71,
    ),
]
