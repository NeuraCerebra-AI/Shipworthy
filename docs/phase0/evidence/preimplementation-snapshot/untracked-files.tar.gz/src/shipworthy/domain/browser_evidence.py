from __future__ import annotations

from typing import Annotated, Tuple

from pydantic import Field, StringConstraints, field_validator, model_validator

from shipworthy.domain.entities import (
    BoundedRef,
    BoundedText,
    CanonicalTimestamp,
    MediaType,
    Producer,
    SafeRepoRelativePath,
    Sha256Digest,
    StrictContractModel,
)
from shipworthy.domain.enums import (
    BrowserEvidenceChannel,
    BrowserEvidenceMode,
    HostFamily,
)
from shipworthy.domain.ids import ArtifactId, FindingId


class BrowserEvidenceHost(StrictContractModel):
    family: HostFamily
    driver: BoundedRef


class BrowserEvidenceTarget(StrictContractModel):
    fingerprint: Sha256Digest
    path_intent: BoundedRef


class BrowserEvidenceStep(StrictContractModel):
    step_id: BoundedRef
    action: BoundedText
    observed_outcome: BoundedText


class LocalArtifactDescriptor(StrictContractModel):
    relative_path: SafeRepoRelativePath
    declared_media_type: MediaType
    digest_algorithm: Annotated[str, StringConstraints(pattern=r"^sha256$")]
    digest: Sha256Digest
    byte_size: int = Field(ge=0, le=1_073_741_824)


class BrowserEvidenceArtifact(StrictContractModel):
    artifact_id: ArtifactId
    channel: BrowserEvidenceChannel
    descriptor: LocalArtifactDescriptor


class BrowserEvidenceEnvelope(StrictContractModel):
    schema_name: Annotated[
        str, StringConstraints(pattern=r"^shipworthy/browser-evidence-envelope$")
    ]
    schema_version: Annotated[str, StringConstraints(pattern=r"^1\.0$")]
    generated_at: CanonicalTimestamp
    producer: Producer
    host: BrowserEvidenceHost
    mode: BrowserEvidenceMode
    target: BrowserEvidenceTarget
    steps: Tuple[BrowserEvidenceStep, ...] = Field(
        min_length=1, max_length=128, json_schema_extra={"uniqueItems": True}
    )
    artifacts: Tuple[BrowserEvidenceArtifact, ...] = Field(
        max_length=64, json_schema_extra={"uniqueItems": True}
    )
    unavailable_channels: Tuple[BrowserEvidenceChannel, ...] = Field(
        max_length=6, json_schema_extra={"uniqueItems": True}
    )
    limitations: Tuple[BoundedText, ...] = Field(
        max_length=64, json_schema_extra={"uniqueItems": True}
    )
    not_proven: Tuple[BoundedText, ...] = Field(
        min_length=1, max_length=64, json_schema_extra={"uniqueItems": True}
    )
    finding_ids: Tuple[FindingId, ...] = Field(
        max_length=128, json_schema_extra={"uniqueItems": True}
    )

    @field_validator("steps")
    @classmethod
    def step_ids_are_unique(
        cls, value: Tuple[BrowserEvidenceStep, ...]
    ) -> Tuple[BrowserEvidenceStep, ...]:
        identifiers = [step.step_id for step in value]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("step_id values must be unique")
        return value

    @field_validator(
        "unavailable_channels", "limitations", "not_proven", "finding_ids"
    )
    @classmethod
    def tuple_values_are_unique(cls, value: tuple[object, ...]) -> tuple[object, ...]:
        if len(value) != len(set(value)):
            raise ValueError("tuple values must be unique")
        return value

    @model_validator(mode="after")
    def artifact_identity_and_channels_are_consistent(
        self,
    ) -> "BrowserEvidenceEnvelope":
        artifact_ids = [artifact.artifact_id for artifact in self.artifacts]
        if len(artifact_ids) != len(set(artifact_ids)):
            raise ValueError("artifact_id values must be unique")
        available_channels = {artifact.channel for artifact in self.artifacts}
        overlap = available_channels.intersection(self.unavailable_channels)
        if overlap:
            raise ValueError("artifact channels cannot also be unavailable")
        return self


__all__ = [
    "BrowserEvidenceArtifact",
    "BrowserEvidenceEnvelope",
    "BrowserEvidenceHost",
    "BrowserEvidenceStep",
    "BrowserEvidenceTarget",
    "LocalArtifactDescriptor",
]
