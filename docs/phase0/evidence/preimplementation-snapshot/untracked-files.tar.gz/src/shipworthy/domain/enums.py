from __future__ import annotations

from enum import Enum


class Action(str, Enum):
    FIX = "Fix"
    PROVE = "Prove"
    DECIDE = "Decide"
    SKIP = "Skip"
    KEEP = "Keep"


class ArtifactAvailability(str, Enum):
    AVAILABLE = "available"
    MISSING = "missing"
    CORRUPT = "corrupt"
    EXTERNALLY_LINKED = "externally_linked"


class BrowserEvidenceChannel(str, Enum):
    SCREENSHOT = "screenshot"
    DOM_ACCESSIBILITY = "dom_accessibility"
    CONSOLE = "console"
    NETWORK = "network"
    TRACE = "trace"
    RECORDING = "recording"


class BrowserEvidenceMode(str, Enum):
    EXPLORATORY = "exploratory"
    DETERMINISTIC_REPLAY = "deterministic_replay"


class CompletionStatus(str, Enum):
    COMPLETE = "complete"
    INCOMPLETE = "incomplete"


class Confidence(str, Enum):
    CONFIRMED = "Confirmed"
    STRONG = "Strong"
    PROVISIONAL = "Provisional"
    HYPOTHESIS = "Hypothesis"


class CustodyState(str, Enum):
    LOCAL_CONTENT_INTEGRITY = "LOCAL_CONTENT_INTEGRITY"


class DebtStatus(str, Enum):
    NEEDS_PROOF = "needs-proof"
    BLOCKED = "blocked"
    SCOPED_OUT = "scoped-out"


class FindingSection(str, Enum):
    CLEAR_BEFORE_SHIP = "clear_before_ship"
    FIX_NEXT = "fix_next"
    NOT_PROVEN_NOT_TESTED = "not_proven_not_tested"
    PASSED_KEEP = "passed_keep"


class GateOutcome(str, Enum):
    PASSED = "passed"
    FAILED = "failed"
    INCOMPLETE = "incomplete"


class GatePolicy(str, Enum):
    CONFIRMED_ONLY = "confirmed_only"


class HostFamily(str, Enum):
    CODEX = "codex"
    CLAUDE_CODE = "claude_code"
    OTHER = "other"


class Proof(str, Enum):
    CONFIRMED = "Confirmed"
    PARTIAL = "Partial"
    INFERRED = "Inferred"
    NOT_TESTED = "Not tested"


class ReadinessDisposition(str, Enum):
    READY = "ready"
    CONDITIONALLY_READY = "conditionally_ready"
    NOT_READY = "not_ready"
    CANNOT_DETERMINE = "cannot_determine"


class Severity(str, Enum):
    P0_BLOCKER = "P0 Blocker"
    P1_MAJOR = "P1 Major"
    P2_MODERATE = "P2 Moderate"
    P3_MINOR = "P3 Minor"
    UNSCORED = "Unscored"


class SubjectKind(str, Enum):
    WORKFLOW = "workflow"
    PATH = "path"
    ARTIFACT = "artifact"
    RELEASE_GATE = "release_gate"
    EVIDENCE_GAP = "evidence_gap"


class VerifierStatus(str, Enum):
    APPROVED = "approved"
    DOWNGRADED = "downgraded"
    REJECTED = "rejected"
    NEEDS_PROOF = "needs-proof"
    BLOCKED = "blocked"
