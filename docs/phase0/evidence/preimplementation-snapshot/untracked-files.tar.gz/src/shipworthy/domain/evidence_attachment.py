"""Pure attachment of normalized browser evidence to a readiness ledger.

Validation authenticates importer-produced internal material and local byte
seals. It does not establish the external identity of a browser, Playwright,
producer, user, or machine.

Browser source metadata survives without changing the v1 ``ArtifactLineage``
schema.  A source artifact uses this bounded operation convention::

    browser-evidence/v1?role=source&mode=<mode>&driver=<quoted-driver>&producer_version=<quoted-version>

The declared source producer is stored in ``ArtifactLineage.producer``.  All
values are URL-quoted and the existing 200-character lineage-operation bound
is enforced; inputs that cannot fit are rejected rather than truncated.
"""

from __future__ import annotations

import hashlib
from urllib.parse import quote

from pydantic import TypeAdapter, ValidationError

from shipworthy.adapters.importers._evidence_normalization import (
    MAX_ATTACHMENTS,
    MAX_SINGLE_ATTACHMENT_BYTES,
    MAX_TOTAL_ATTACHMENT_BYTES,
    EvidenceDebtDraft,
    EvidenceSourceIdentity,
    NormalizedEvidenceResult,
    NormalizedObservation,
    SealedAttachmentBytes,
    safe_path,
)
from shipworthy.domain.entities import (
    Artifact,
    ArtifactLineage,
    EvidenceDebt,
    ReadinessLedger,
)
from shipworthy.domain.enums import (
    Action,
    ArtifactAvailability,
    BrowserEvidenceMode,
    CompletionStatus,
    Confidence,
    DebtStatus,
    FindingSection,
    Proof,
    ReadinessDisposition,
    Severity,
    VerifierStatus,
)
from shipworthy.domain.ids import FindingId


_OPERATION_PREFIX = "browser-evidence/v1?"
_FINDING_ID_ADAPTER = TypeAdapter(FindingId)
_SOURCE_CONTRACTS = {
    "shipworthy/browser-evidence-envelope": (
        "BROWSER-SOURCE",
        "shipworthy-browser-evidence-importer",
        "seal-supplied-browser-evidence",
    ),
    "playwright/json-reporter": (
        "PLAYWRIGHT-SOURCE",
        "shipworthy-playwright-report-importer",
        "seal-supplied-playwright-report",
    ),
}


class EvidenceAttachmentError(ValueError):
    """Raised when normalized evidence cannot safely join a ledger."""


def _revalidate_artifact(artifact: object) -> Artifact:
    if not isinstance(artifact, Artifact):
        raise ValueError
    return Artifact.model_validate(artifact.model_dump(mode="python"), strict=True)


def _validate_normalized_result(result: NormalizedEvidenceResult) -> None:
    if (
        type(result.raw_bytes) is not bytes
        or not result.raw_bytes
        or type(result.byte_size) is not int
        or result.byte_size != len(result.raw_bytes)
        or not isinstance(result.sha256, str)
        or result.sha256 != hashlib.sha256(result.raw_bytes).hexdigest()
        or not isinstance(result.source, EvidenceSourceIdentity)
        or not isinstance(result.mode, BrowserEvidenceMode)
        or not isinstance(result.driver, str)
        or not 1 <= len(result.driver) <= 200
        or (
            result.target_fingerprint is not None
            and (
                not isinstance(result.target_fingerprint, str)
                or len(result.target_fingerprint) != 64
                or any(
                    character not in "0123456789abcdef"
                    for character in result.target_fingerprint
                )
            )
        )
        or (
            result.path_intent is not None
            and (
                not isinstance(result.path_intent, str)
                or not 1 <= len(result.path_intent) <= 200
            )
        )
    ):
        raise ValueError

    if (
        not isinstance(result.sealed_attachments, tuple)
        or len(result.sealed_attachments) > MAX_ATTACHMENTS
    ):
        raise ValueError
    sealed_by_path: dict[str, bytes] = {}
    aggregate_bytes = 0
    for sealed in result.sealed_attachments:
        if (
            not isinstance(sealed, SealedAttachmentBytes)
            or safe_path(sealed.relative_path) is None
            or type(sealed.raw_bytes) is not bytes
            or len(sealed.raw_bytes) > MAX_SINGLE_ATTACHMENT_BYTES
            or sealed.relative_path in sealed_by_path
        ):
            raise ValueError
        aggregate_bytes += len(sealed.raw_bytes)
        if aggregate_bytes > MAX_TOTAL_ATTACHMENT_BYTES:
            raise ValueError
        sealed_by_path[sealed.relative_path] = sealed.raw_bytes

    source_contract = _SOURCE_CONTRACTS.get(result.source.schema_name)
    if source_contract is None:
        raise ValueError
    prefix, lineage_producer, lineage_operation = source_contract
    if (
        not isinstance(result.source.relative_path, str)
        or not isinstance(result.source.producer_name, str)
        or not 1 <= len(result.source.producer_name) <= 64
        or not isinstance(result.source.producer_version, str)
        or not 1 <= len(result.source.producer_version) <= 32
    ):
        raise ValueError

    source = _revalidate_artifact(result.source_artifact)
    expected_source_id = f"ART-{prefix}-{result.sha256[:24].upper()}"
    if (
        source.artifact_id != expected_source_id
        or source.availability is not ArtifactAvailability.AVAILABLE
        or source.descriptor.relative_path != result.source.relative_path
        or source.descriptor.declared_media_type != "application/json"
        or source.descriptor.digest != result.sha256
        or source.descriptor.byte_size != result.byte_size
        or source.lineage.producer != lineage_producer
        or source.lineage.operation != lineage_operation
        or source.lineage.source_ids != ()
    ):
        raise ValueError

    if not isinstance(result.artifacts, tuple) or len(result.artifacts) > 1024:
        raise ValueError
    artifact_ids: set[str] = set()
    for raw_artifact in result.artifacts:
        artifact = _revalidate_artifact(raw_artifact)
        if artifact.artifact_id in artifact_ids or artifact.lineage.source_ids != (
            source.artifact_id,
        ):
            raise ValueError
        artifact_ids.add(artifact.artifact_id)
        sealed_bytes = sealed_by_path.get(artifact.descriptor.relative_path)
        if artifact.availability in (
            ArtifactAvailability.AVAILABLE,
            ArtifactAvailability.CORRUPT,
        ):
            if (
                sealed_bytes is None
                or artifact.descriptor.digest
                != hashlib.sha256(sealed_bytes).hexdigest()
                or artifact.descriptor.byte_size != len(sealed_bytes)
            ):
                raise ValueError
        elif sealed_bytes is not None:
            raise ValueError

    sealed_artifact_paths = {
        artifact.descriptor.relative_path
        for artifact in result.artifacts
        if artifact.availability
        in (ArtifactAvailability.AVAILABLE, ArtifactAvailability.CORRUPT)
    }
    if not sealed_artifact_paths.issubset(sealed_by_path):
        raise ValueError

    observations_valid = (
        isinstance(result.observations, tuple) and len(result.observations) <= 4096
    )
    observation_ids: set[str] = set()
    if observations_valid:
        for observation in result.observations:
            if (
                not isinstance(observation, NormalizedObservation)
                or not isinstance(observation.observation_id, str)
                or not 1 <= len(observation.observation_id) <= 200
                or observation.observation_id in observation_ids
                or (
                    observation.official_id is not None
                    and (
                        not isinstance(observation.official_id, str)
                        or len(observation.official_id) > 200
                    )
                )
                or (
                    observation.project is not None
                    and (
                        not isinstance(observation.project, str)
                        or len(observation.project) > 200
                    )
                )
                or (
                    observation.project_id is not None
                    and (
                        not isinstance(observation.project_id, str)
                        or len(observation.project_id) > 200
                    )
                )
                or not isinstance(observation.subject, str)
                or not 1 <= len(observation.subject) <= 1000
                or not isinstance(observation.action, str)
                or not 1 <= len(observation.action) <= 1000
                or not isinstance(observation.observed_outcome, str)
                or not 1 <= len(observation.observed_outcome) <= 1000
                or not isinstance(observation.outcome, str)
                or not 1 <= len(observation.outcome) <= 64
                or type(observation.retry_count) is not int
                or not 0 <= observation.retry_count <= 100
                or type(observation.flaky) is not bool
                or not isinstance(observation.artifact_ids, tuple)
                or len(observation.artifact_ids) > 128
                or len(observation.artifact_ids) != len(set(observation.artifact_ids))
                or bool(set(observation.artifact_ids) - artifact_ids)
            ):
                observations_valid = False
                break
            observation_ids.add(observation.observation_id)

    if (
        not observations_valid
        or not isinstance(result.limitations, tuple)
        or len(result.limitations) > 64
        or len(result.limitations) != len(set(result.limitations))
        or not all(
            isinstance(item, str) and 1 <= len(item) <= 1000
            for item in result.limitations
        )
        or not isinstance(result.evidence_debt, tuple)
        or len(result.evidence_debt) > 512
        or not all(
            isinstance(item, EvidenceDebtDraft)
            and isinstance(item.code, str)
            and 1 <= len(item.code) <= 64
            and isinstance(item.subject, str)
            and 1 <= len(item.subject) <= 1000
            and isinstance(item.proof_needed, str)
            and 1 <= len(item.proof_needed) <= 1000
            and isinstance(item.reason, str)
            and 1 <= len(item.reason)
            and len(item.code) + 2 + len(item.reason) <= 1000
            and isinstance(item.artifact_ids, tuple)
            and len(item.artifact_ids) <= 128
            and len(item.artifact_ids) == len(set(item.artifact_ids))
            and all(isinstance(artifact_id, str) for artifact_id in item.artifact_ids)
            for item in result.evidence_debt
        )
        or not isinstance(result.finding_ids, tuple)
        or len(result.finding_ids) > 128
        or len(result.finding_ids) != len(set(result.finding_ids))
    ):
        raise ValueError
    for finding_id in result.finding_ids:
        _FINDING_ID_ADAPTER.validate_python(finding_id, strict=True)

    if result.source.schema_name == "shipworthy/browser-evidence-envelope":
        from shipworthy.adapters.importers.browser_evidence import (
            import_browser_evidence_json,
        )

        authenticated = import_browser_evidence_json(
            result.raw_bytes,
            source_relative_path=result.source.relative_path,
            attachment_bytes=sealed_by_path,
        )
    elif result.source.schema_name == "playwright/json-reporter":
        from shipworthy.adapters.importers.playwright_report import (
            import_playwright_json_report,
        )

        authenticated = import_playwright_json_report(
            result.raw_bytes,
            source_relative_path=result.source.relative_path,
            attachment_bytes=sealed_by_path,
            finding_ids=result.finding_ids,
        )
    else:
        raise ValueError
    if authenticated != result:
        raise ValueError


def _source_operation(result: NormalizedEvidenceResult) -> str:
    operation = (
        f"{_OPERATION_PREFIX}role=source"
        f"&mode={quote(result.mode.value, safe='._-')}"
        f"&driver={quote(result.driver, safe='._-')}"
        f"&producer_version={quote(result.source.producer_version, safe='._-')}"
    )
    if len(operation) > 200:
        raise EvidenceAttachmentError(
            "browser evidence lineage metadata exceeds its bound"
        )
    return operation


def _browser_source(result: NormalizedEvidenceResult) -> Artifact:
    return result.source_artifact.model_copy(
        update={
            "lineage": ArtifactLineage(
                producer=result.source.producer_name,
                operation=_source_operation(result),
                source_ids=result.source_artifact.lineage.source_ids,
            )
        }
    )


def _artifact_collision_key(artifact: Artifact) -> tuple[str, str, str | None]:
    return (
        artifact.artifact_id,
        artifact.descriptor.relative_path,
        artifact.descriptor.digest,
    )


def _reject_artifact_collisions(
    existing: tuple[Artifact, ...], incoming: tuple[Artifact, ...]
) -> None:
    identifiers = {artifact.artifact_id for artifact in existing}
    paths = {artifact.descriptor.relative_path for artifact in existing}
    digests = {
        artifact.descriptor.digest
        for artifact in existing
        if artifact.descriptor.digest is not None
    }
    for artifact in incoming:
        artifact_id, path, digest = _artifact_collision_key(artifact)
        if (
            artifact_id in identifiers
            or path in paths
            or (digest is not None and digest in digests)
        ):
            raise EvidenceAttachmentError("browser evidence artifact collision")
        identifiers.add(artifact_id)
        paths.add(path)
        if digest is not None:
            digests.add(digest)


def _debt_id(*parts: str) -> str:
    digest = hashlib.sha256("\x00".join(parts).encode("utf-8")).hexdigest()
    return f"ED-BROWSER-{digest[:24].upper()}"


def _bounded_subject(value: str, *, code: str) -> str:
    if len(value) <= 200:
        return value
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:16].upper()
    return f"browser evidence {code} item {digest}"


def _draft_debt(draft: EvidenceDebtDraft) -> EvidenceDebt:
    return EvidenceDebt(
        debt_id=_debt_id(
            "draft",
            draft.code,
            draft.subject,
            draft.proof_needed,
            draft.reason,
            *draft.artifact_ids,
        ),
        subject=_bounded_subject(draft.subject, code=draft.code),
        proof_needed=draft.proof_needed,
        reason=f"{draft.code}: {draft.reason}",
        status=DebtStatus.NEEDS_PROOF,
        artifact_ids=draft.artifact_ids,
    )


def _limitation_debt(
    limitation: str, source_artifact_id: str, index: int
) -> EvidenceDebt:
    return EvidenceDebt(
        debt_id=_debt_id("limitation", str(index), limitation, source_artifact_id),
        subject="browser-evidence limitation",
        proof_needed="Obtain evidence that closes or explicitly scopes this limitation.",
        reason=f"LIMITATION: {limitation}",
        status=DebtStatus.SCOPED_OUT,
        artifact_ids=(source_artifact_id,),
    )


def _has_confirmed_blocker(ledger: ReadinessLedger) -> bool:
    return any(
        finding.action is Action.FIX
        and finding.proof is Proof.CONFIRMED
        and finding.section is FindingSection.CLEAR_BEFORE_SHIP
        and finding.severity is Severity.P0_BLOCKER
        and finding.confidence is Confidence.CONFIRMED
        and finding.verifier_status is VerifierStatus.APPROVED
        for finding in ledger.findings
    )


def attach_evidence(
    ledger: ReadinessLedger, normalized_result: NormalizedEvidenceResult
) -> ReadinessLedger:
    """Return a new canonical ledger containing caller-supplied evidence.

    This function performs no reads and has no persistence surface.  It trusts
    the normalized result's sealed bytes contract and only reconciles immutable
    ledger identities, artifacts, debt, and conservative completion state.
    """

    if not isinstance(ledger, ReadinessLedger):
        raise TypeError("ledger must be a ReadinessLedger")
    if not isinstance(normalized_result, NormalizedEvidenceResult):
        raise TypeError("normalized_result must be a NormalizedEvidenceResult")
    normalized_failed = False
    try:
        _validate_normalized_result(normalized_result)
    except (ValidationError, ValueError, TypeError):
        normalized_failed = True
    if normalized_failed:
        raise EvidenceAttachmentError(
            "normalized browser evidence failed seal validation"
        )

    known_findings = {finding.finding_id for finding in ledger.findings}
    unknown = sorted(set(normalized_result.finding_ids) - known_findings)
    if unknown:
        raise EvidenceAttachmentError("browser evidence references an unknown finding")

    source = _browser_source(normalized_result)
    incoming = (source, *normalized_result.artifacts)
    _reject_artifact_collisions(ledger.artifacts, incoming)

    known_artifacts = {
        artifact.artifact_id for artifact in (*ledger.artifacts, *incoming)
    }
    for draft in normalized_result.evidence_debt:
        if set(draft.artifact_ids) - known_artifacts:
            raise EvidenceAttachmentError(
                "browser evidence debt references an unknown artifact"
            )

    attachable_ids = tuple(
        artifact.artifact_id
        for artifact in incoming
        if artifact.availability is ArtifactAvailability.AVAILABLE
    )
    target_ids = set(normalized_result.finding_ids)
    findings = tuple(
        finding.model_copy(
            update={"artifact_ids": (*finding.artifact_ids, *attachable_ids)}
        )
        if finding.finding_id in target_ids
        else finding
        for finding in ledger.findings
    )

    new_debt = tuple(_draft_debt(draft) for draft in normalized_result.evidence_debt)
    new_debt += tuple(
        _limitation_debt(limitation, source.artifact_id, index)
        for index, limitation in enumerate(normalized_result.limitations)
    )
    existing_debt_ids = {debt.debt_id for debt in ledger.evidence_debt}
    new_debt_ids = [debt.debt_id for debt in new_debt]
    if len(new_debt_ids) != len(set(new_debt_ids)) or existing_debt_ids.intersection(
        new_debt_ids
    ):
        raise EvidenceAttachmentError("browser evidence debt collision")

    has_unavailable = any(
        artifact.availability is not ArtifactAvailability.AVAILABLE
        for artifact in incoming
    )
    becomes_incomplete = bool(normalized_result.evidence_debt) or has_unavailable
    completion = (
        CompletionStatus.INCOMPLETE if becomes_incomplete else ledger.completion_status
    )
    if becomes_incomplete:
        if ledger.readiness_disposition is ReadinessDisposition.CANNOT_DETERMINE:
            disposition = ReadinessDisposition.CANNOT_DETERMINE
        elif _has_confirmed_blocker(ledger):
            disposition = ReadinessDisposition.NOT_READY
        else:
            disposition = ReadinessDisposition.CANNOT_DETERMINE
    else:
        disposition = ledger.readiness_disposition

    candidate = ledger.model_dump(mode="python")
    candidate.pop("gate_contract")
    candidate.update(
        {
            "artifacts": (*ledger.artifacts, *incoming),
            "completion_status": completion,
            "evidence_debt": (*ledger.evidence_debt, *new_debt),
            "findings": findings,
            "gate": ledger.gate_contract,
            "readiness_disposition": disposition,
        }
    )
    try:
        return ReadinessLedger.model_validate(candidate, strict=True)
    except EvidenceAttachmentError:
        raise
    except Exception:
        raise EvidenceAttachmentError(
            "browser evidence could not satisfy canonical ledger invariants"
        ) from None


__all__ = ("EvidenceAttachmentError", "attach_evidence")
