"""Strict canonical domain contracts."""
