from __future__ import annotations

from datetime import datetime
from typing import Annotated, Optional, Tuple

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    AfterValidator,
    field_validator,
    model_validator,
)

from shipworthy.domain.enums import (
    Action,
    ArtifactAvailability,
    CompletionStatus,
    Confidence,
    CustodyState,
    DebtStatus,
    FindingSection,
    GateOutcome,
    GatePolicy,
    Proof,
    ReadinessDisposition,
    Severity,
    SubjectKind,
    VerifierStatus,
)
from shipworthy.domain.ids import ArtifactId, DebtId, FindingId, LedgerId, ReportInputId, StableId


BoundedName = Annotated[str, StringConstraints(min_length=1, max_length=64)]
BoundedVersion = Annotated[str, StringConstraints(min_length=1, max_length=32)]
BoundedRef = Annotated[str, StringConstraints(min_length=1, max_length=200)]
BoundedTitle = Annotated[str, StringConstraints(min_length=1, max_length=200)]
BoundedText = Annotated[str, StringConstraints(min_length=1, max_length=1000)]
MediaType = Annotated[
    str,
    StringConstraints(
        pattern=r"^[a-z0-9][a-z0-9!#$&^_.+-]{0,126}/[a-z0-9][a-z0-9!#$&^_.+-]{0,126}$",
        min_length=3,
        max_length=255,
    ),
]
Sha256Digest = Annotated[
    str, StringConstraints(pattern=r"^[a-f0-9]{64}$", min_length=64, max_length=64)
]
SafeRepoRelativePath = Annotated[
    str,
    StringConstraints(
        pattern=r"^(?:[A-Za-z0-9_-][A-Za-z0-9._-]*/)*[A-Za-z0-9_-][A-Za-z0-9._-]*$",
        min_length=1,
        max_length=512,
    ),
]


def _validate_canonical_timestamp(value: str) -> str:
    try:
        datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError as exc:
        raise ValueError("timestamp must be a valid UTC second timestamp") from exc
    return value


CanonicalTimestamp = Annotated[
    str,
    StringConstraints(
        pattern=r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$",
        min_length=20,
        max_length=20,
    ),
    AfterValidator(_validate_canonical_timestamp),
    Field(json_schema_extra={"format": "date-time"}),
]


class StrictContractModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        strict=True,
        validate_default=True,
    )


class Producer(StrictContractModel):
    name: BoundedName
    version: BoundedVersion


class ArtifactDescriptor(StrictContractModel):
    relative_path: SafeRepoRelativePath
    declared_media_type: MediaType
    digest_algorithm: Annotated[str, StringConstraints(pattern=r"^sha256$")]
    digest: Optional[Sha256Digest]
    byte_size: Optional[int] = Field(ge=0, le=1_073_741_824)


class ArtifactLineage(StrictContractModel):
    producer: BoundedName
    operation: BoundedRef
    source_ids: Tuple[StableId, ...] = Field(
        max_length=128, json_schema_extra={"uniqueItems": True}
    )

    @field_validator("source_ids")
    @classmethod
    def source_ids_are_unique(cls, value: Tuple[str, ...]) -> Tuple[str, ...]:
        if len(value) != len(set(value)):
            raise ValueError("source_ids must be unique")
        return value


class Artifact(StrictContractModel):
    artifact_id: ArtifactId
    availability: ArtifactAvailability
    descriptor: ArtifactDescriptor
    lineage: ArtifactLineage
    custody_state: CustodyState

    @model_validator(mode="after")
    def descriptor_matches_availability(self) -> "Artifact":
        has_seal = self.descriptor.digest is not None and self.descriptor.byte_size is not None
        if self.availability is ArtifactAvailability.AVAILABLE and not has_seal:
            raise ValueError("available artifacts require digest and byte_size")
        if self.availability is ArtifactAvailability.MISSING and (
            self.descriptor.digest is not None or self.descriptor.byte_size is not None
        ):
            raise ValueError("missing artifacts must not claim sealed bytes")
        return self


class FindingSubject(StrictContractModel):
    kind: SubjectKind
    ref: BoundedRef
    title: BoundedTitle
    location: Optional[SafeRepoRelativePath]


class Finding(StrictContractModel):
    finding_id: FindingId
    revision: int = Field(ge=1, le=2_147_483_647)
    subject: FindingSubject
    action: Action
    proof: Proof
    section: FindingSection
    severity: Severity
    confidence: Confidence
    verifier_status: VerifierStatus
    summary: BoundedText
    artifact_ids: Tuple[ArtifactId, ...] = Field(
        max_length=128, json_schema_extra={"uniqueItems": True}
    )

    @field_validator("artifact_ids")
    @classmethod
    def artifact_ids_are_unique(cls, value: Tuple[str, ...]) -> Tuple[str, ...]:
        if len(value) != len(set(value)):
            raise ValueError("artifact_ids must be unique")
        return value

    @model_validator(mode="after")
    def confirmed_proof_is_evidence_bearing(self) -> "Finding":
        if self.proof is Proof.CONFIRMED:
            if self.confidence is not Confidence.CONFIRMED:
                raise ValueError("confirmed proof requires confirmed confidence")
            if self.verifier_status is not VerifierStatus.APPROVED:
                raise ValueError("confirmed proof requires approved verifier status")
            if not self.artifact_ids:
                raise ValueError("confirmed proof requires an evidence artifact")
        if self.severity is Severity.P0_BLOCKER and self.proof is Proof.CONFIRMED:
            if self.action is not Action.FIX:
                raise ValueError("confirmed P0 blockers require the Fix action")
            if self.section is not FindingSection.CLEAR_BEFORE_SHIP:
                raise ValueError(
                    "confirmed P0 blockers require the clear_before_ship section"
                )
        return self


class EvidenceDebt(StrictContractModel):
    debt_id: DebtId
    subject: BoundedRef
    proof_needed: BoundedText
    reason: BoundedText
    status: DebtStatus
    artifact_ids: Tuple[ArtifactId, ...] = Field(
        max_length=128, json_schema_extra={"uniqueItems": True}
    )

    @field_validator("artifact_ids")
    @classmethod
    def artifact_ids_are_unique(cls, value: Tuple[str, ...]) -> Tuple[str, ...]:
        if len(value) != len(set(value)):
            raise ValueError("artifact_ids must be unique")
        return value


class ConfirmedOnlyGateContract(StrictContractModel):
    policy: GatePolicy


class ConfirmedOnlyGateProjection(StrictContractModel):
    policy: GatePolicy
    outcome: GateOutcome
    blocking_finding_ids: Tuple[FindingId, ...] = Field(max_length=512)

    @field_validator("blocking_finding_ids")
    @classmethod
    def blocker_ids_are_unique(cls, value: Tuple[str, ...]) -> Tuple[str, ...]:
        if len(value) != len(set(value)):
            raise ValueError("blocking_finding_ids must be unique")
        return tuple(sorted(value))

    @model_validator(mode="after")
    def outcome_matches_blockers(self) -> "ConfirmedOnlyGateProjection":
        has_blockers = bool(self.blocking_finding_ids)
        if (self.outcome is GateOutcome.FAILED) != has_blockers:
            raise ValueError("failed gate outcome must match blocker presence")
        return self


class ReadinessLedger(StrictContractModel):
    schema_name: Annotated[
        str, StringConstraints(pattern=r"^shipworthy/readiness-ledger$")
    ]
    schema_version: Annotated[str, StringConstraints(pattern=r"^1\.0$")]
    generated_at: CanonicalTimestamp
    producer: Producer
    ledger_id: LedgerId
    revision: int = Field(ge=1, le=2_147_483_647)
    completion_status: CompletionStatus
    readiness_disposition: ReadinessDisposition
    gate_contract: ConfirmedOnlyGateContract = Field(validation_alias="gate")
    findings: Tuple[Finding, ...] = Field(max_length=512)
    artifacts: Tuple[Artifact, ...] = Field(max_length=1024)
    evidence_debt: Tuple[EvidenceDebt, ...] = Field(max_length=512)

    @property
    def gate(self) -> ConfirmedOnlyGateProjection:
        blocking_finding_ids = tuple(
            sorted(
                finding.finding_id
                for finding in self.findings
                if finding.action is Action.FIX
                and finding.proof is Proof.CONFIRMED
                and finding.section is FindingSection.CLEAR_BEFORE_SHIP
                and finding.severity is Severity.P0_BLOCKER
                and finding.confidence is Confidence.CONFIRMED
                and finding.verifier_status is VerifierStatus.APPROVED
            )
        )
        outcome = (
            GateOutcome.FAILED
            if blocking_finding_ids
            else GateOutcome.INCOMPLETE
            if self.completion_status is CompletionStatus.INCOMPLETE
            else GateOutcome.PASSED
        )
        return ConfirmedOnlyGateProjection(
            policy=self.gate_contract.policy,
            outcome=outcome,
            blocking_finding_ids=blocking_finding_ids,
        )

    @model_validator(mode="after")
    def ledger_references_and_gate_are_consistent(self) -> "ReadinessLedger":
        finding_ids = [finding.finding_id for finding in self.findings]
        artifact_ids = [artifact.artifact_id for artifact in self.artifacts]
        debt_ids = [debt.debt_id for debt in self.evidence_debt]
        for label, values in (
            ("finding_id", finding_ids),
            ("artifact_id", artifact_ids),
            ("debt_id", debt_ids),
        ):
            if len(values) != len(set(values)):
                raise ValueError(f"{label} values must be unique")

        artifact_by_id = {artifact.artifact_id: artifact for artifact in self.artifacts}
        for finding in self.findings:
            unknown = set(finding.artifact_ids) - artifact_by_id.keys()
            if unknown:
                raise ValueError(f"finding references unknown artifacts: {sorted(unknown)}")
            if finding.proof is Proof.CONFIRMED:
                unavailable = [
                    artifact_id
                    for artifact_id in finding.artifact_ids
                    if artifact_by_id[artifact_id].availability
                    is not ArtifactAvailability.AVAILABLE
                ]
                if unavailable:
                    raise ValueError(
                        f"confirmed finding references unavailable artifacts: {unavailable}"
                    )

        debt_artifact_ids = set()
        for debt in self.evidence_debt:
            unknown = set(debt.artifact_ids) - artifact_by_id.keys()
            if unknown:
                raise ValueError(f"evidence debt references unknown artifacts: {sorted(unknown)}")
            if debt.status in (DebtStatus.NEEDS_PROOF, DebtStatus.BLOCKED):
                debt_artifact_ids.update(debt.artifact_ids)

        unavailable_ids = {
            artifact.artifact_id
            for artifact in self.artifacts
            if artifact.availability is not ArtifactAvailability.AVAILABLE
        }
        if not unavailable_ids.issubset(debt_artifact_ids):
            raise ValueError("every unavailable artifact requires unresolved evidence debt")

        confirmed_blockers = [
            finding.finding_id
            for finding in self.findings
            if finding.action is Action.FIX
            and finding.proof is Proof.CONFIRMED
            and finding.section is FindingSection.CLEAR_BEFORE_SHIP
            and finding.severity is Severity.P0_BLOCKER
            and finding.confidence is Confidence.CONFIRMED
            and finding.verifier_status is VerifierStatus.APPROVED
        ]
        unresolved_finding = any(
            finding.proof is Proof.NOT_TESTED
            or finding.verifier_status
            in (VerifierStatus.NEEDS_PROOF, VerifierStatus.BLOCKED)
            for finding in self.findings
        )
        unresolved_debt = any(
            debt.status in (DebtStatus.NEEDS_PROOF, DebtStatus.BLOCKED)
            for debt in self.evidence_debt
        )
        if unresolved_finding and not unresolved_debt:
            raise ValueError("unproven findings require explicit unresolved evidence debt")
        if unresolved_finding and (
            self.completion_status is not CompletionStatus.INCOMPLETE
            or self.readiness_disposition is not ReadinessDisposition.CANNOT_DETERMINE
        ):
            raise ValueError(
                "unproven findings require incomplete/cannot_determine state"
            )
        if self.completion_status is CompletionStatus.INCOMPLETE and not (
            unresolved_debt or unavailable_ids
        ):
            raise ValueError("incomplete ledgers require explicit unresolved evidence debt")
        if self.completion_status is CompletionStatus.COMPLETE and (
            unresolved_debt or unavailable_ids
        ):
            raise ValueError("complete ledgers cannot contain unresolved evidence debt")

        if unresolved_finding:
            expected_disposition = ReadinessDisposition.CANNOT_DETERMINE
        elif confirmed_blockers:
            expected_disposition = ReadinessDisposition.NOT_READY
        elif self.completion_status is CompletionStatus.INCOMPLETE:
            expected_disposition = ReadinessDisposition.CANNOT_DETERMINE
        else:
            expected_disposition = None
        if (
            expected_disposition is not None
            and self.readiness_disposition is not expected_disposition
        ):
            raise ValueError("readiness disposition does not match evidence state")
        if (
            self.completion_status is CompletionStatus.COMPLETE
            and not unresolved_finding
            and not confirmed_blockers
            and self.readiness_disposition
            not in (
                ReadinessDisposition.READY,
                ReadinessDisposition.CONDITIONALLY_READY,
            )
        ):
            raise ValueError("complete non-blocked ledger has an invalid disposition")
        return self


class ReportInput(StrictContractModel):
    schema_name: Annotated[
        str, StringConstraints(pattern=r"^shipworthy/readiness-report-input$")
    ]
    schema_version: Annotated[str, StringConstraints(pattern=r"^1\.0$")]
    generated_at: CanonicalTimestamp
    producer: Producer
    report_input_id: ReportInputId
    source_ledger: ReadinessLedger
