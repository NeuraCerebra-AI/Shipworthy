from __future__ import annotations

from copy import deepcopy
import json
from enum import Enum
from typing import Any, Dict

from pydantic import TypeAdapter, ValidationError

from shipworthy.domain.browser_evidence import BrowserEvidenceEnvelope
from shipworthy.domain.entities import (
    Artifact,
    ArtifactDescriptor,
    ArtifactLineage,
    ConfirmedOnlyGateContract,
    ConfirmedOnlyGateProjection,
    EvidenceDebt,
    Finding,
    FindingSubject,
    Producer,
    ReadinessLedger,
    ReportInput,
)


MAX_CONTRACT_BYTES = 1_048_576
_LEDGER_ADAPTER = TypeAdapter(ReadinessLedger)
_REPORT_INPUT_ADAPTER = TypeAdapter(ReportInput)
_GATE_PROJECTION_ADAPTER = TypeAdapter(ConfirmedOnlyGateProjection)
_BROWSER_EVIDENCE_ADAPTER = TypeAdapter(BrowserEvidenceEnvelope)


class ContractValidationError(ValueError):
    """Raised when external JSON cannot enter the strict v1 boundary."""


class _DuplicateJsonMemberError(ValueError):
    """Internal sentinel for an ambiguous JSON object."""


def _reject_duplicate_members(pairs: list[tuple[str, object]]) -> Dict[str, object]:
    members: Dict[str, object] = {}
    for key, value in pairs:
        if key in members:
            raise _DuplicateJsonMemberError
        members[key] = value
    return members


def _has_unambiguous_json_members(raw: bytes) -> bool:
    try:
        json.loads(raw, object_pairs_hook=_reject_duplicate_members)
    except (UnicodeDecodeError, ValueError, RecursionError):
        return False
    return True


def _validate_json(adapter: TypeAdapter[Any], raw: bytes) -> Any:
    validation_failed = False
    validated: Any = None
    try:
        validated = adapter.validate_json(raw, strict=True)
    except (ValidationError, ValueError):
        validation_failed = True
    if validation_failed:
        raise ContractValidationError("contract JSON failed strict v1 validation")
    return validated


def _parse_json(adapter: TypeAdapter[Any], raw: bytes) -> Any:
    if not isinstance(raw, bytes):
        raise ContractValidationError("contract input must be bytes")
    if not raw:
        raise ContractValidationError("contract input must not be empty")
    if len(raw) > MAX_CONTRACT_BYTES:
        raise ContractValidationError("contract input exceeds the 1 MiB boundary")
    if not _has_unambiguous_json_members(raw):
        raise ContractValidationError("contract JSON failed strict v1 validation")
    return _validate_json(adapter, raw)


def parse_readiness_ledger_json(raw: bytes) -> ReadinessLedger:
    return _parse_json(_LEDGER_ADAPTER, raw)


def parse_report_input_json(raw: bytes) -> ReportInput:
    return _parse_json(_REPORT_INPUT_ADAPTER, raw)


def parse_browser_evidence_json(raw: bytes) -> BrowserEvidenceEnvelope:
    return _parse_json(_BROWSER_EVIDENCE_ADAPTER, raw)


def _enum(value: Enum) -> str:
    return str(value.value)


def _timestamp(value: str) -> str:
    return value


def _producer(value: Producer) -> Dict[str, object]:
    return {"name": value.name, "version": value.version}


def _descriptor(value: ArtifactDescriptor) -> Dict[str, object]:
    return {
        "byte_size": value.byte_size,
        "declared_media_type": value.declared_media_type,
        "digest": value.digest,
        "digest_algorithm": value.digest_algorithm,
        "relative_path": value.relative_path,
    }


def _lineage(value: ArtifactLineage) -> Dict[str, object]:
    return {
        "operation": value.operation,
        "producer": value.producer,
        "source_ids": list(value.source_ids),
    }


def _artifact(value: Artifact) -> Dict[str, object]:
    return {
        "artifact_id": value.artifact_id,
        "availability": _enum(value.availability),
        "custody_state": _enum(value.custody_state),
        "descriptor": _descriptor(value.descriptor),
        "lineage": _lineage(value.lineage),
    }


def _subject(value: FindingSubject) -> Dict[str, object]:
    return {
        "kind": _enum(value.kind),
        "location": value.location,
        "ref": value.ref,
        "title": value.title,
    }


def _finding(value: Finding) -> Dict[str, object]:
    return {
        "action": _enum(value.action),
        "artifact_ids": list(value.artifact_ids),
        "confidence": _enum(value.confidence),
        "finding_id": value.finding_id,
        "proof": _enum(value.proof),
        "revision": value.revision,
        "section": _enum(value.section),
        "severity": _enum(value.severity),
        "subject": _subject(value.subject),
        "summary": value.summary,
        "verifier_status": _enum(value.verifier_status),
    }


def _debt(value: EvidenceDebt) -> Dict[str, object]:
    return {
        "artifact_ids": list(value.artifact_ids),
        "debt_id": value.debt_id,
        "proof_needed": value.proof_needed,
        "reason": value.reason,
        "status": _enum(value.status),
        "subject": value.subject,
    }


def _gate_contract(value: ConfirmedOnlyGateContract) -> Dict[str, object]:
    return {"policy": _enum(value.policy)}


def _gate_projection(value: ConfirmedOnlyGateProjection) -> Dict[str, object]:
    return {
        "blocking_finding_ids": list(value.blocking_finding_ids),
        "outcome": _enum(value.outcome),
        "policy": _enum(value.policy),
    }


def _ledger(value: ReadinessLedger) -> Dict[str, object]:
    return {
        "artifacts": [_artifact(item) for item in value.artifacts],
        "completion_status": _enum(value.completion_status),
        "evidence_debt": [_debt(item) for item in value.evidence_debt],
        "findings": [_finding(item) for item in value.findings],
        "gate": _gate_contract(value.gate_contract),
        "generated_at": _timestamp(value.generated_at),
        "ledger_id": value.ledger_id,
        "producer": _producer(value.producer),
        "readiness_disposition": _enum(value.readiness_disposition),
        "revision": value.revision,
        "schema_name": value.schema_name,
        "schema_version": value.schema_version,
    }


def _canonical_json(value: Dict[str, object]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()


def serialize_readiness_ledger_json(value: ReadinessLedger) -> bytes:
    if not isinstance(value, ReadinessLedger):
        raise TypeError("value must be a ReadinessLedger")
    raw = _canonical_json(_ledger(value))
    _parse_json(_LEDGER_ADAPTER, raw)
    return raw


def serialize_report_input_json(value: ReportInput) -> bytes:
    if not isinstance(value, ReportInput):
        raise TypeError("value must be a ReportInput")
    raw = _canonical_json(
        {
            "generated_at": _timestamp(value.generated_at),
            "producer": _producer(value.producer),
            "report_input_id": value.report_input_id,
            "schema_name": value.schema_name,
            "schema_version": value.schema_version,
            "source_ledger": _ledger(value.source_ledger),
        }
    )
    _parse_json(_REPORT_INPUT_ADAPTER, raw)
    return raw


def serialize_confirmed_only_gate_json(value: ConfirmedOnlyGateProjection) -> bytes:
    if not isinstance(value, ConfirmedOnlyGateProjection):
        raise TypeError("value must be a ConfirmedOnlyGateProjection")
    raw = _canonical_json(_gate_projection(value))
    _parse_json(_GATE_PROJECTION_ADAPTER, raw)
    return raw


def serialize_browser_evidence_json(value: BrowserEvidenceEnvelope) -> bytes:
    if not isinstance(value, BrowserEvidenceEnvelope):
        raise TypeError("value must be a BrowserEvidenceEnvelope")
    raw = _canonical_json(
        value.model_dump(mode="json", by_alias=True, exclude_none=False)
    )
    _parse_json(_BROWSER_EVIDENCE_ADAPTER, raw)
    return raw


def _fresh_schema_fragment(fragment: Dict[str, object]) -> Dict[str, object]:
    return deepcopy(fragment)


def _augment_semantic_constraints(schema: Dict[str, object], model: type) -> None:
    definitions = schema.get("$defs")
    if not isinstance(definitions, dict):
        raise RuntimeError("generated schema is missing $defs")

    artifact = definitions.get("Artifact")
    if not isinstance(artifact, dict):
        raise RuntimeError("generated schema is missing Artifact")
    artifact["allOf"] = [
        {
            "if": {
                "properties": {"availability": {"const": "available"}},
                "required": ["availability"],
            },
            "then": {
                "properties": {
                    "descriptor": {
                        "properties": {
                            "byte_size": {"type": "integer"},
                            "digest": {"type": "string"},
                        },
                        "required": ["byte_size", "digest"],
                    }
                }
            },
        },
        {
            "if": {
                "properties": {"availability": {"const": "missing"}},
                "required": ["availability"],
            },
            "then": {
                "properties": {
                    "descriptor": {
                        "properties": {
                            "byte_size": {"type": "null"},
                            "digest": {"type": "null"},
                        },
                        "required": ["byte_size", "digest"],
                    }
                }
            },
        },
    ]

    finding = definitions.get("Finding")
    if not isinstance(finding, dict):
        raise RuntimeError("generated schema is missing Finding")
    finding["allOf"] = [
        {
            "if": {
                "properties": {"proof": {"const": "Confirmed"}},
                "required": ["proof"],
            },
            "then": {
                "properties": {
                    "artifact_ids": {"minItems": 1},
                    "confidence": {"const": "Confirmed"},
                    "verifier_status": {"const": "approved"},
                }
            },
        },
        {
            "if": {
                "properties": {
                    "proof": {"const": "Confirmed"},
                    "severity": {"const": "P0 Blocker"},
                },
                "required": ["proof", "severity"],
            },
            "then": {
                "properties": {
                    "action": {"const": "Fix"},
                    "section": {"const": "clear_before_ship"},
                }
            },
        }
    ]

    ledger_schema = (
        schema if model is ReadinessLedger else definitions.get("ReadinessLedger")
    )
    if not isinstance(ledger_schema, dict):
        raise RuntimeError("generated schema is missing ReadinessLedger")

    unresolved_debt = {
        "properties": {"status": {"enum": ["needs-proof", "blocked"]}},
        "required": ["status"],
    }
    unavailable_artifact = {
        "properties": {
            "availability": {"enum": ["missing", "corrupt", "externally_linked"]}
        },
        "required": ["availability"],
    }
    unresolved_finding = {
        "anyOf": [
            {
                "properties": {"proof": {"const": "Not tested"}},
                "required": ["proof"],
            },
            {
                "properties": {
                    "verifier_status": {"enum": ["needs-proof", "blocked"]}
                },
                "required": ["verifier_status"],
            },
        ]
    }
    confirmed_blocker = {
        "properties": {
            "action": {"const": "Fix"},
            "confidence": {"const": "Confirmed"},
            "proof": {"const": "Confirmed"},
            "section": {"const": "clear_before_ship"},
            "severity": {"const": "P0 Blocker"},
            "verifier_status": {"const": "approved"},
        },
        "required": [
            "action",
            "confidence",
            "proof",
            "section",
            "severity",
            "verifier_status",
        ],
    }
    no_unresolved_finding = {
        "properties": {"findings": {"not": {"contains": unresolved_finding}}},
        "required": ["findings"],
    }
    no_confirmed_blocker = {
        "properties": {"findings": {"not": {"contains": confirmed_blocker}}},
        "required": ["findings"],
    }

    ledger_schema["allOf"] = [
        {
            "if": {
                "properties": {
                    "findings": {
                        "contains": _fresh_schema_fragment(unresolved_finding)
                    }
                },
                "required": ["findings"],
            },
            "then": {
                "properties": {
                    "completion_status": {"const": "incomplete"},
                    "evidence_debt": {
                        "contains": _fresh_schema_fragment(unresolved_debt),
                        "minItems": 1,
                    },
                    "readiness_disposition": {"const": "cannot_determine"},
                }
            },
        },
        {
            "if": {
                "properties": {"completion_status": {"const": "incomplete"}},
                "required": ["completion_status"],
            },
            "then": {
                "anyOf": [
                    {
                        "properties": {
                            "evidence_debt": {
                                "contains": _fresh_schema_fragment(unresolved_debt)
                            }
                        }
                    },
                    {
                        "properties": {
                            "artifacts": {
                                "contains": _fresh_schema_fragment(unavailable_artifact)
                            }
                        }
                    },
                ]
            },
        },
        {
            "if": {
                "properties": {"completion_status": {"const": "complete"}},
                "required": ["completion_status"],
            },
            "then": {
                "properties": {
                    "artifacts": {
                        "not": {
                            "contains": _fresh_schema_fragment(unavailable_artifact)
                        }
                    },
                    "evidence_debt": {
                        "not": {"contains": _fresh_schema_fragment(unresolved_debt)}
                    },
                }
            },
        },
        {
            "if": {
                "allOf": [
                    _fresh_schema_fragment(no_unresolved_finding),
                    {
                        "properties": {
                            "findings": {
                                "contains": _fresh_schema_fragment(confirmed_blocker)
                            }
                        },
                        "required": ["findings"],
                    },
                ]
            },
            "then": {
                "properties": {"readiness_disposition": {"const": "not_ready"}}
            },
        },
        {
            "if": {
                "allOf": [
                    _fresh_schema_fragment(no_unresolved_finding),
                    _fresh_schema_fragment(no_confirmed_blocker),
                    {
                        "properties": {
                            "completion_status": {"const": "incomplete"}
                        },
                        "required": ["completion_status"],
                    },
                ]
            },
            "then": {
                "properties": {
                    "readiness_disposition": {"const": "cannot_determine"}
                }
            },
        },
        {
            "if": {
                "allOf": [
                    _fresh_schema_fragment(no_unresolved_finding),
                    _fresh_schema_fragment(no_confirmed_blocker),
                    {
                        "properties": {
                            "completion_status": {"const": "complete"}
                        },
                        "required": ["completion_status"],
                    },
                ]
            },
            "then": {
                "properties": {
                    "readiness_disposition": {
                        "enum": ["ready", "conditionally_ready"]
                    }
                }
            },
        },
    ]


def _augment_browser_evidence_constraints(schema: Dict[str, object]) -> None:
    schema["allOf"] = [
        {
            "if": {
                "properties": {
                    "artifacts": {
                        "contains": {
                            "properties": {"channel": {"const": channel}},
                            "required": ["channel"],
                        }
                    }
                },
                "required": ["artifacts"],
            },
            "then": {
                "properties": {
                    "unavailable_channels": {
                        "not": {"contains": {"const": channel}}
                    }
                },
                "required": ["unavailable_channels"],
            },
        }
        for channel in (
            "screenshot",
            "dom_accessibility",
            "console",
            "network",
            "trace",
            "recording",
        )
    ]
    schema["x-shipworthy-runtime-constraints"] = {
        "artifact_id_uniqueness": (
            "Runtime enforces unique artifacts[*].artifact_id values; JSON Schema "
            "uniqueItems compares whole array items and cannot express uniqueness "
            "of one property across nonidentical objects."
        ),
        "step_id_uniqueness": (
            "Runtime enforces unique steps[*].step_id values; JSON Schema "
            "uniqueItems compares whole array items and cannot express uniqueness "
            "of one property across nonidentical objects."
        ),
    }


def _schema(model: type) -> Dict[str, object]:
    schema = model.model_json_schema(mode="validation", by_alias=True)
    if model in (ReadinessLedger, ReportInput):
        _augment_semantic_constraints(schema, model)
    elif model is BrowserEvidenceEnvelope:
        _augment_browser_evidence_constraints(schema)
    filenames = {
        ReadinessLedger: "readiness-ledger.schema.json",
        ReportInput: "report-input.schema.json",
        BrowserEvidenceEnvelope: "browser-evidence-envelope.schema.json",
    }
    schema["$id"] = "https://shipworthy.local/schemas/v1/" + filenames[model]
    schema["$schema"] = "https://json-schema.org/draft/2020-12/schema"
    return schema


def readiness_ledger_json_schema() -> Dict[str, object]:
    return _schema(ReadinessLedger)


def report_input_json_schema() -> Dict[str, object]:
    return _schema(ReportInput)


def browser_evidence_json_schema() -> Dict[str, object]:
    return _schema(BrowserEvidenceEnvelope)


__all__ = [
    "ContractValidationError",
    "BrowserEvidenceEnvelope",
    "ReadinessLedger",
    "ReportInput",
    "parse_readiness_ledger_json",
    "parse_report_input_json",
    "parse_browser_evidence_json",
    "browser_evidence_json_schema",
    "readiness_ledger_json_schema",
    "report_input_json_schema",
    "serialize_readiness_ledger_json",
    "serialize_report_input_json",
    "serialize_browser_evidence_json",
    "serialize_confirmed_only_gate_json",
]
