"""Immutable reporting projection derived from the strict readiness ledger."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Dict, Mapping, Optional, Tuple
from urllib.parse import parse_qsl, quote

from shipworthy.domain.contracts import (
    ContractValidationError,
    parse_readiness_ledger_json,
    serialize_readiness_ledger_json,
)
from shipworthy.domain.entities import Artifact, EvidenceDebt, Finding, ReadinessLedger
from shipworthy.domain.enums import (
    Action,
    BrowserEvidenceMode,
    Confidence,
    FindingSection,
    Proof,
    ReadinessDisposition,
    Severity,
)


_COMPATIBILITY_SEVERITY: Mapping[Severity, str] = {
    Severity.P0_BLOCKER: "blocker",
    Severity.P1_MAJOR: "strong",
    Severity.P2_MODERATE: "provisional",
    Severity.P3_MINOR: "info",
    Severity.UNSCORED: "info",
}
_SECTION_ORDER = tuple(section.value for section in FindingSection)
_ACTION_ORDER = tuple(action.value for action in Action)
_COMPATIBILITY_SEVERITY_ORDER = ("blocker", "strong", "provisional", "info")
_VERDICT: Mapping[ReadinessDisposition, str] = {
    ReadinessDisposition.READY: "READY",
    ReadinessDisposition.CONDITIONALLY_READY: "CONDITIONALLY READY",
    ReadinessDisposition.NOT_READY: "NOT READY",
    ReadinessDisposition.CANNOT_DETERMINE: "CANNOT DETERMINE",
}


CountItems = Tuple[Tuple[str, int], ...]


def _ordered_nonzero_counts(
    values: Tuple[str, ...], order: Tuple[str, ...]
) -> CountItems:
    counts = Counter(values)
    return tuple((name, counts[name]) for name in order if counts[name])


def _artifact_evidence(
    artifact_ids: Tuple[str, ...], artifact_by_id: Mapping[str, Artifact]
) -> str:
    if not artifact_ids:
        return "No evidence artifact is attached to this record."
    rendered = []
    for artifact_id in artifact_ids:
        artifact = artifact_by_id[artifact_id]
        digest = artifact.descriptor.digest or "not sealed"
        rendered.append(
            f"{artifact_id} ({artifact.availability.value}; "
            f"{artifact.descriptor.relative_path}; sha256={digest}; "
            f"producer={artifact.lineage.producer}; "
            f"operation={artifact.lineage.operation})"
        )
    return "Artifacts: " + "; ".join(rendered)


@dataclass(frozen=True, slots=True)
class ReportRow:
    record_id: str
    record_kind: str
    title: str
    summary: str
    action: str
    proof: str
    section: str
    severity: str
    compatibility_severity: str
    confidence: str
    location: Optional[str]
    artifact_ids: Tuple[str, ...]
    evidence: str
    fix: Optional[str]
    verify: str

    def legacy_finding(self) -> Dict[str, object]:
        row: Dict[str, object] = {
            "action": self.action,
            "artifact_ids": list(self.artifact_ids),
            "canonical_confidence": self.confidence,
            "canonical_severity": self.severity,
            "confidence": self.confidence,
            "consequence": self.summary,
            "evidence": self.evidence,
            "proof": self.proof,
            "record_id": self.record_id,
            "record_kind": self.record_kind,
            "section": self.section,
            "severity": self.compatibility_severity,
            "title": self.title,
            "verify": self.verify,
        }
        if self.fix is not None:
            row["fix"] = self.fix
        if self.location is not None:
            row["location"] = {"file": self.location}
        return row


@dataclass(frozen=True, slots=True)
class ReportingArtifact:
    artifact_id: str
    availability: str
    relative_path: str
    declared_media_type: str
    digest_algorithm: str
    digest: Optional[str]
    byte_size: Optional[int]
    lineage_producer: str
    lineage_operation: str
    lineage_source_ids: Tuple[str, ...]


@dataclass(frozen=True, slots=True)
class BrowserEvidenceReporting:
    artifact_id: str
    mode: str
    driver: str
    source_producer_name: str
    source_producer_version: str
    lineage_operation: str
    finding_ids: Tuple[str, ...]
    attachments: Tuple[ReportingArtifact, ...]

    def report_data(self) -> Dict[str, object]:
        return {
            "artifact_id": self.artifact_id,
            "attachments": [
                {
                    "artifact_id": artifact.artifact_id,
                    "availability": artifact.availability,
                    "digest": artifact.digest,
                    "digest_algorithm": artifact.digest_algorithm,
                    "lineage_operation": artifact.lineage_operation,
                    "relative_path": artifact.relative_path,
                }
                for artifact in self.attachments
            ],
            "driver": self.driver,
            "finding_ids": list(self.finding_ids),
            "lineage_operation": self.lineage_operation,
            "mode": self.mode,
            "source_producer": {
                "name": self.source_producer_name,
                "version": self.source_producer_version,
            },
        }


def _browser_source_metadata(
    artifact: ReportingArtifact,
    *,
    artifacts: Tuple[ReportingArtifact, ...],
    findings: Tuple[Finding, ...],
) -> Optional[BrowserEvidenceReporting]:
    prefix = "browser-evidence/v1?"
    if not artifact.lineage_operation.startswith(prefix):
        return None
    try:
        pairs = parse_qsl(
            artifact.lineage_operation.removeprefix(prefix),
            keep_blank_values=True,
            strict_parsing=True,
        )
        metadata = dict(pairs)
    except ValueError:
        return None
    expected_keys = ("role", "mode", "driver", "producer_version")
    if (
        tuple(key for key, _value in pairs) != expected_keys
        or len(metadata) != len(pairs)
        or metadata.get("role") != "source"
    ):
        return None
    mode = metadata.get("mode")
    driver = metadata.get("driver")
    producer_version = metadata.get("producer_version")
    if (
        mode not in {item.value for item in BrowserEvidenceMode}
        or not driver
        or not producer_version
    ):
        return None
    canonical_operation = (
        f"{prefix}role=source"
        f"&mode={quote(mode, safe='._-')}"
        f"&driver={quote(driver, safe='._-')}"
        f"&producer_version={quote(producer_version, safe='._-')}"
    )
    if artifact.lineage_operation != canonical_operation:
        return None
    attachments = tuple(
        candidate
        for candidate in artifacts
        if artifact.artifact_id in candidate.lineage_source_ids
    )
    related_artifact_ids = {
        artifact.artifact_id,
        *(candidate.artifact_id for candidate in attachments),
    }
    finding_ids = tuple(
        finding.finding_id
        for finding in findings
        if related_artifact_ids.intersection(finding.artifact_ids)
    )
    return BrowserEvidenceReporting(
        artifact_id=artifact.artifact_id,
        mode=mode,
        driver=driver,
        source_producer_name=artifact.lineage_producer,
        source_producer_version=producer_version,
        lineage_operation=artifact.lineage_operation,
        finding_ids=finding_ids,
        attachments=attachments,
    )


def _finding_row(finding: Finding, artifact_by_id: Mapping[str, Artifact]) -> ReportRow:
    evidence = f"Record: {finding.finding_id} (finding). " + _artifact_evidence(
        finding.artifact_ids, artifact_by_id
    )
    return ReportRow(
        record_id=finding.finding_id,
        record_kind="finding",
        title=f"{finding.finding_id} — {finding.subject.title}",
        summary=finding.summary,
        action=finding.action.value,
        proof=finding.proof.value,
        section=finding.section.value,
        severity=finding.severity.value,
        compatibility_severity=_COMPATIBILITY_SEVERITY[finding.severity],
        confidence=finding.confidence.value,
        location=finding.subject.location,
        artifact_ids=finding.artifact_ids,
        evidence=evidence,
        fix=None,
        verify=(
            f"Proof: {finding.proof.value}; confidence: {finding.confidence.value}; "
            f"verifier: {finding.verifier_status.value}."
        ),
    )


def _debt_row(debt: EvidenceDebt, artifact_by_id: Mapping[str, Artifact]) -> ReportRow:
    evidence = (
        f"Record: {debt.debt_id} (evidence_debt). Reason: {debt.reason} "
        + _artifact_evidence(debt.artifact_ids, artifact_by_id)
    )
    return ReportRow(
        record_id=debt.debt_id,
        record_kind="evidence_debt",
        title=f"{debt.debt_id} — Evidence required for {debt.subject}",
        summary=debt.reason,
        action=Action.PROVE.value,
        proof=Proof.NOT_TESTED.value,
        section=FindingSection.NOT_PROVEN_NOT_TESTED.value,
        severity=Severity.UNSCORED.value,
        compatibility_severity="info",
        confidence=Confidence.HYPOTHESIS.value,
        location=None,
        artifact_ids=debt.artifact_ids,
        evidence=evidence,
        fix=debt.proof_needed,
        verify=f"Evidence-debt status: {debt.status.value}.",
    )


@dataclass(frozen=True, slots=True)
class ReportingProjection:
    ledger: ReadinessLedger
    ledger_json: bytes
    rows: Tuple[ReportRow, ...]
    artifacts: Tuple[ReportingArtifact, ...]
    browser_evidence: Tuple[BrowserEvidenceReporting, ...]
    section_counts: CountItems
    action_counts: CountItems
    compatibility_severity_counts: CountItems
    canonical_finding_count: int
    evidence_debt_count: int
    total_report_row_count: int
    completion_status: str
    readiness_disposition: str
    renderer_verdict: str
    gate_policy: str
    gate_outcome: str
    gate_blocking_finding_ids: Tuple[str, ...]

    @classmethod
    def from_ledger(cls, ledger: ReadinessLedger) -> "ReportingProjection":
        if not isinstance(ledger, ReadinessLedger):
            raise TypeError("ledger must be a ReadinessLedger")
        failed = False
        canonical_bytes: bytes = b""
        try:
            canonical_bytes = serialize_readiness_ledger_json(ledger)
        except ContractValidationError:
            raise
        except Exception:
            failed = True
        if failed:
            raise ContractValidationError("contract JSON failed strict v1 validation")

        canonical = parse_readiness_ledger_json(canonical_bytes)
        artifact_by_id = {
            artifact.artifact_id: artifact for artifact in canonical.artifacts
        }
        rows = tuple(
            _finding_row(finding, artifact_by_id) for finding in canonical.findings
        ) + tuple(_debt_row(debt, artifact_by_id) for debt in canonical.evidence_debt)
        artifacts = tuple(
            ReportingArtifact(
                artifact_id=artifact.artifact_id,
                availability=artifact.availability.value,
                relative_path=artifact.descriptor.relative_path,
                declared_media_type=artifact.descriptor.declared_media_type,
                digest_algorithm=artifact.descriptor.digest_algorithm,
                digest=artifact.descriptor.digest,
                byte_size=artifact.descriptor.byte_size,
                lineage_producer=artifact.lineage.producer,
                lineage_operation=artifact.lineage.operation,
                lineage_source_ids=artifact.lineage.source_ids,
            )
            for artifact in canonical.artifacts
        )
        browser_evidence = tuple(
            metadata
            for artifact in artifacts
            if (
                metadata := _browser_source_metadata(
                    artifact,
                    artifacts=artifacts,
                    findings=canonical.findings,
                )
            )
            is not None
        )
        gate = canonical.gate
        return cls(
            ledger=canonical,
            ledger_json=canonical_bytes,
            rows=rows,
            artifacts=artifacts,
            browser_evidence=browser_evidence,
            section_counts=_ordered_nonzero_counts(
                tuple(row.section for row in rows), _SECTION_ORDER
            ),
            action_counts=_ordered_nonzero_counts(
                tuple(row.action for row in rows), _ACTION_ORDER
            ),
            compatibility_severity_counts=_ordered_nonzero_counts(
                tuple(row.compatibility_severity for row in rows),
                _COMPATIBILITY_SEVERITY_ORDER,
            ),
            canonical_finding_count=len(canonical.findings),
            evidence_debt_count=len(canonical.evidence_debt),
            total_report_row_count=len(rows),
            completion_status=canonical.completion_status.value,
            readiness_disposition=canonical.readiness_disposition.value,
            renderer_verdict=_VERDICT[canonical.readiness_disposition],
            gate_policy=gate.policy.value,
            gate_outcome=gate.outcome.value,
            gate_blocking_finding_ids=gate.blocking_finding_ids,
        )

    @property
    def record_ids(self) -> Tuple[str, ...]:
        return tuple(row.record_id for row in self.rows)

    def legacy_report_data(self) -> Dict[str, object]:
        section_counts = dict(self.section_counts)
        blocker_ids = (
            ", ".join(self.gate_blocking_finding_ids)
            if self.gate_blocking_finding_ids
            else "none"
        )
        browser_evidence_locations = [
            (
                f"Browser evidence: mode={source.mode}; driver={source.driver}; "
                f"producer={source.source_producer_name}@{source.source_producer_version}; "
                f"operation={source.lineage_operation}"
            )
            for source in self.browser_evidence
        ]
        return {
            "checkpoint": {
                "completion_status": self.completion_status,
                "evidence_locations": [
                    f"confirmed blocker IDs: {blocker_ids}",
                    *browser_evidence_locations,
                ],
                "readiness_disposition": self.readiness_disposition,
                "gate_outcome": self.gate_outcome,
                "gate_blocking_finding_ids": list(self.gate_blocking_finding_ids),
                "gate_policy": self.gate_policy,
                "mode": (
                    f"completion: {self.completion_status}; readiness disposition: "
                    f"{self.readiness_disposition}"
                ),
                "verifier": (f"{self.gate_policy} gate outcome: {self.gate_outcome}"),
            },
            "findings": [row.legacy_finding() for row in self.rows],
            "generated_at": self.ledger.generated_at,
            "summary": {
                section: section_counts.get(section, 0) for section in _SECTION_ORDER
            },
            "target": self.ledger.ledger_id,
            "tool_version": self.ledger.producer.version,
            "verdict": self.renderer_verdict,
        }

    def browser_evidence_data(self) -> Tuple[Dict[str, object], ...]:
        return tuple(source.report_data() for source in self.browser_evidence)
