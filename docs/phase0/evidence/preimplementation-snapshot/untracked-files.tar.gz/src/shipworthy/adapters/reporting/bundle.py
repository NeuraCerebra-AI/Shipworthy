"""Deterministic, resource-bounded, in-memory evidence bundles.

The limits in this module apply only to Phase 0 local reporting bundles. They
are intentionally sized for the current raw legacy JSON boundary (at most
1 MiB per artifact) and are not Phase 1 runner or execution budgets.
"""

from __future__ import annotations

from collections.abc import Mapping
import hashlib
import io
import json
from typing import Dict, Optional, Tuple
import zipfile

from shipworthy.adapters.reporting.html import render_readiness_html
from shipworthy.adapters.reporting.projection import (
    ReportRow,
    ReportingArtifact,
    ReportingProjection,
)
from shipworthy.adapters.reporting.sarif import render_readiness_sarif_bytes


PHASE0_MAX_INCLUDED_ARTIFACT_COUNT = 64
PHASE0_MAX_ARTIFACT_BYTES = 1_048_576
PHASE0_MAX_AGGREGATE_ARTIFACT_BYTES = 8_388_608
PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES = 16_777_216


class ReportingArtifactError(ValueError):
    """Raised when artifact bytes or bundle budgets fail validation."""


_README = (
    "Shipworthy local evidence bundle\n"
    "=================================\n\n"
    "ledger.json is the canonical strict-v1 readiness ledger.\n"
    "readiness-report.html is the mandatory human-readable report.\n"
    "readiness.sarif is the machine-readable projection of the same rows.\n"
    "manifest.json records canonical gate/count state and local payload hashes.\n\n"
    "Integrity scope: hashes provide LOCAL_CONTENT_INTEGRITY checks for the bytes "
    "inside this bundle. This bundle is not signed, not attested, and not "
    "tamper-proof. Authenticity and external custody are not established.\n"
).encode("utf-8")

_FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)
_MANDATORY_NAMES = frozenset(
    (
        "ledger.json",
        "readiness-report.html",
        "readiness.sarif",
        "manifest.json",
        "README.txt",
    )
)
_MANDATORY_MEDIA_TYPES = {
    "ledger.json": "application/json",
    "readiness-report.html": "text/html; charset=utf-8",
    "readiness.sarif": "application/sarif+json",
    "README.txt": "text/plain; charset=utf-8",
}


def _sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _artifact_bundle_path(artifact: ReportingArtifact) -> str:
    relative = artifact.relative_path
    if relative.startswith("/") or ".." in relative.split("/") or "\\" in relative:
        raise ValueError
    name = f"artifacts/{artifact.artifact_id}/{relative}"
    if name in _MANDATORY_NAMES:
        raise ValueError
    return name


def _verify_artifact_payloads(
    projection: ReportingProjection,
    artifact_bytes: Optional[Mapping[str, bytes]],
) -> Tuple[Dict[str, bytes], Tuple[Dict[str, object], ...], Dict[str, str]]:
    if artifact_bytes is None:
        provided: Mapping[str, bytes] = {}
    elif isinstance(artifact_bytes, Mapping):
        provided = artifact_bytes
    else:
        raise ValueError

    artifact_by_id = {
        artifact.artifact_id: artifact for artifact in projection.artifacts
    }
    maximum_entries = min(len(projection.artifacts), PHASE0_MAX_INCLUDED_ARTIFACT_COUNT)
    seen_ids: set[str] = set()
    verified: Dict[str, bytes] = {}
    aggregate_bytes = 0
    iterator = iter(provided.items())
    while True:
        try:
            item = next(iterator)
        except StopIteration:
            break
        if not isinstance(item, tuple) or len(item) != 2:
            raise ValueError
        artifact_id, payload = item
        if len(seen_ids) >= maximum_entries:
            raise ValueError
        if not isinstance(artifact_id, str) or artifact_id in seen_ids:
            raise ValueError
        seen_ids.add(artifact_id)
        artifact = artifact_by_id.get(artifact_id)
        if (
            artifact is None
            or artifact.availability != "available"
            or artifact.digest is None
            or artifact.byte_size is None
            or type(payload) is not bytes
        ):
            raise ValueError
        payload_size = len(payload)
        if (
            payload_size > PHASE0_MAX_ARTIFACT_BYTES
            or payload_size != artifact.byte_size
        ):
            raise ValueError
        aggregate_bytes += payload_size
        if aggregate_bytes > PHASE0_MAX_AGGREGATE_ARTIFACT_BYTES:
            raise ValueError
        if _sha256(payload) != artifact.digest:
            raise ValueError
        verified[artifact_id] = payload

    bundled: Dict[str, bytes] = {}
    media_types: Dict[str, str] = {}
    statuses: list[Dict[str, object]] = []
    for artifact in projection.artifacts:
        bundled_payload = verified.get(artifact.artifact_id)
        if bundled_payload is not None:
            bundle_path = _artifact_bundle_path(artifact)
            if bundle_path in bundled:
                raise ValueError
            bundled[bundle_path] = bundled_payload
            media_types[bundle_path] = artifact.declared_media_type
            inclusion_status = "included"
        elif artifact.availability == "available":
            bundle_path = None
            inclusion_status = "referenced_only"
        else:
            bundle_path = None
            inclusion_status = "not_includable"
        statuses.append(
            {
                "artifact_id": artifact.artifact_id,
                "availability": artifact.availability,
                "byte_size": artifact.byte_size,
                "bundle_path": bundle_path,
                "declared_media_type": artifact.declared_media_type,
                "digest": artifact.digest,
                "digest_algorithm": artifact.digest_algorithm,
                "inclusion_status": inclusion_status,
                "relative_path": artifact.relative_path,
                **(
                    {
                        "lineage": {
                            "operation": artifact.lineage_operation,
                            "producer": artifact.lineage_producer,
                            "source_ids": list(artifact.lineage_source_ids),
                        }
                    }
                    if artifact.lineage_operation.startswith("browser-evidence/v1?")
                    or any(
                        source.artifact_id in artifact.lineage_source_ids
                        for source in projection.browser_evidence
                    )
                    else {}
                ),
            }
        )
    return bundled, tuple(statuses), media_types


def _verified_artifact_payloads(
    projection: ReportingProjection,
    artifact_bytes: Optional[Mapping[str, bytes]],
) -> Tuple[Dict[str, bytes], Tuple[Dict[str, object], ...], Dict[str, str]]:
    failed = False
    result = None
    try:
        result = _verify_artifact_payloads(projection, artifact_bytes)
    except Exception:
        failed = True
    if failed or result is None:
        raise ReportingArtifactError("artifact bytes failed validation")
    return result


def _entry(name: str, payload: bytes, media_type: str) -> Dict[str, object]:
    return {
        "bytes": len(payload),
        "media_type": media_type,
        "name": name,
        "sha256": _sha256(payload),
    }


def _zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=_FIXED_ZIP_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    return info


def _write_entry(archive: zipfile.ZipFile, name: str, payload: bytes) -> None:
    archive.writestr(_zip_info(name), payload)


def _manifest_record(
    projection: ReportingProjection, row: ReportRow
) -> Dict[str, object]:
    record: Dict[str, object] = {
        "action": row.action,
        "artifact_ids": list(row.artifact_ids),
        "proof": row.proof,
        "record_id": row.record_id,
        "record_kind": row.record_kind,
        "section": row.section,
        "title": row.title,
    }
    if row.record_kind == "evidence_debt":
        debt = next(
            (
                item
                for item in projection.ledger.evidence_debt
                if item.debt_id == row.record_id
            ),
            None,
        )
        if debt is None:
            raise ValueError
        record.update(
            {
                "debt_status": debt.status.value,
                "proof_needed": debt.proof_needed,
                "reason": debt.reason,
                "subject": debt.subject,
            }
        )
    return record


def _manifest(
    projection: ReportingProjection,
    artifact_statuses: Tuple[Dict[str, object], ...],
    payloads: Mapping[str, bytes],
    payload_order: Tuple[str, ...],
    media_types: Mapping[str, str],
) -> Dict[str, object]:
    return {
        "artifacts": list(artifact_statuses),
        "browser_evidence": list(projection.browser_evidence_data()),
        "completion_status": projection.completion_status,
        "counts": {
            "action": dict(projection.action_counts),
            "canonical_findings": projection.canonical_finding_count,
            "compatibility_severity": dict(projection.compatibility_severity_counts),
            "evidence_debt": projection.evidence_debt_count,
            "section": dict(projection.section_counts),
            "total_report_rows": projection.total_report_row_count,
        },
        "entries": [
            _entry(name, payloads[name], media_types[name]) for name in payload_order
        ],
        "gate": {
            "blocking_finding_ids": list(projection.gate_blocking_finding_ids),
            "outcome": projection.gate_outcome,
            "policy": projection.gate_policy,
        },
        "generated_at": projection.ledger.generated_at,
        "integrity": {
            "attested": False,
            "custody_state": "LOCAL_CONTENT_INTEGRITY",
            "signed": False,
            "tamper_proof": False,
        },
        "phase0_bundle_policy": {
            "applies_to": "Phase 0 local reporting bundles only",
            "max_aggregate_artifact_bytes": (PHASE0_MAX_AGGREGATE_ARTIFACT_BYTES),
            "max_artifact_bytes": PHASE0_MAX_ARTIFACT_BYTES,
            "max_included_artifact_count": (PHASE0_MAX_INCLUDED_ARTIFACT_COUNT),
            "max_total_uncompressed_bundle_bytes": (
                PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES
            ),
        },
        "producer": {
            "name": projection.ledger.producer.name,
            "version": projection.ledger.producer.version,
        },
        "readiness_disposition": projection.readiness_disposition,
        "records": [_manifest_record(projection, row) for row in projection.rows],
        "schema_name": projection.ledger.schema_name,
        "schema_version": projection.ledger.schema_version,
    }


def _archive_bytes(
    projection: ReportingProjection,
    html_bytes: bytes,
    sarif_bytes: bytes,
    manifest_bytes: bytes,
    optional_payloads: Mapping[str, bytes],
) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(
        output, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        _write_entry(archive, "ledger.json", projection.ledger_json)
        _write_entry(archive, "readiness-report.html", html_bytes)
        _write_entry(archive, "readiness.sarif", sarif_bytes)
        _write_entry(archive, "manifest.json", manifest_bytes)
        _write_entry(archive, "README.txt", _README)
        for name in sorted(optional_payloads):
            _write_entry(archive, name, optional_payloads[name])
    return output.getvalue()


def build_evidence_bundle(
    projection: ReportingProjection,
    *,
    artifact_bytes: Optional[Mapping[str, bytes]] = None,
) -> bytes:
    if not isinstance(projection, ReportingProjection):
        raise TypeError("projection must be a ReportingProjection")

    optional_payloads, artifact_statuses, optional_media_types = (
        _verified_artifact_payloads(projection, artifact_bytes)
    )
    html_bytes = render_readiness_html(projection)
    sarif_bytes = render_readiness_sarif_bytes(projection)
    payloads: Dict[str, bytes] = {
        "ledger.json": projection.ledger_json,
        "readiness-report.html": html_bytes,
        "readiness.sarif": sarif_bytes,
        "README.txt": _README,
        **optional_payloads,
    }
    media_types = {**_MANDATORY_MEDIA_TYPES, **optional_media_types}
    payload_order = (
        "ledger.json",
        "readiness-report.html",
        "readiness.sarif",
        "README.txt",
        *sorted(optional_payloads),
    )
    manifest = _manifest(
        projection,
        artifact_statuses,
        payloads,
        payload_order,
        media_types,
    )
    manifest_bytes = (
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    total_uncompressed_bytes = sum(len(payload) for payload in payloads.values())
    total_uncompressed_bytes += len(manifest_bytes)
    if total_uncompressed_bytes > PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES:
        raise ReportingArtifactError("evidence bundle exceeds Phase 0 budget")

    failed = False
    bundle: bytes | None = None
    try:
        bundle = _archive_bytes(
            projection,
            html_bytes,
            sarif_bytes,
            manifest_bytes,
            optional_payloads,
        )
    except Exception:
        failed = True
    if failed or bundle is None:
        raise ReportingArtifactError("evidence bundle creation failed")
    return bundle
