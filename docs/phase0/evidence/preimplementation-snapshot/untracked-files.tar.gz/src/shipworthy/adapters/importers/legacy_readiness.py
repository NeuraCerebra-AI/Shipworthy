"""Side-effect-free, raw-first projection of unversioned readiness JSON."""

from __future__ import annotations

import hashlib
import json
import unicodedata
from dataclasses import dataclass
from typing import Any, Mapping, Optional, Sequence, cast

from pydantic import TypeAdapter, ValidationError

from shipworthy.domain.entities import (
    Artifact,
    ArtifactDescriptor,
    ArtifactLineage,
    CanonicalTimestamp,
    ConfirmedOnlyGateContract,
    EvidenceDebt,
    Finding,
    FindingSubject,
    Producer,
    ReadinessLedger,
    SafeRepoRelativePath,
)
from shipworthy.domain.enums import (
    Action,
    ArtifactAvailability,
    CompletionStatus,
    Confidence,
    CustodyState,
    DebtStatus,
    FindingSection,
    GatePolicy,
    Proof,
    ReadinessDisposition,
    Severity,
    SubjectKind,
    VerifierStatus,
)


SOURCE_SCHEMA_NAME = "legacy/readiness-v0"
IMPORTER_NAME = "shipworthy-legacy-readiness-importer"
IMPORTER_VERSION = "0.1.0"
MAX_INPUT_BYTES = 1_048_576
MAX_FINDINGS = 512
MAX_ARRAY_ITEMS = 4_096
MAX_OBJECT_MEMBERS = 512
MAX_JSON_NODES = 100_000
MAX_JSON_DEPTH = 32
MAX_KEY_CHARS = 64
MAX_GENERAL_STRING_CHARS = 1_000
MAX_TITLE_CHARS = 200
MAX_TARGET_CHARS = 200
MAX_ENUM_CHARS = 64
MAX_MAPPING_DEBT = 512


_SOURCE_PATH_ADAPTER = TypeAdapter(SafeRepoRelativePath)
_TIMESTAMP_ADAPTER = TypeAdapter(CanonicalTimestamp)


class LegacyReadinessImportError(ValueError):
    """A sanitized failure at the raw legacy readiness boundary."""


class _DuplicateJsonMemberError(ValueError):
    """Internal sentinel for ambiguous JSON objects."""


class _InvalidJsonConstantError(ValueError):
    """Internal sentinel for non-standard numeric constants."""


@dataclass(frozen=True, slots=True)
class LegacyMappingDebt:
    debt_id: str
    code: str
    source_path: str
    reason: str


@dataclass(frozen=True, slots=True)
class LegacyReadinessImportResult:
    source_schema_name: str
    source_relative_path: str
    imported_at: str
    raw_bytes: bytes
    sha256: str
    byte_size: int
    mapping_debt: tuple[LegacyMappingDebt, ...]
    ledger: ReadinessLedger


@dataclass(frozen=True, slots=True)
class _DebtDraft:
    code: str
    source_path: str
    reason: str


_ACTION_MAP: Mapping[str, Action] = {
    "Fix": Action.FIX,
    "fix": Action.FIX,
    "Prove": Action.PROVE,
    "prove": Action.PROVE,
    "Decide": Action.DECIDE,
    "decide": Action.DECIDE,
    "Skip": Action.SKIP,
    "skip": Action.SKIP,
    "Keep": Action.KEEP,
    "keep": Action.KEEP,
}

_SECTION_MAP: Mapping[str, FindingSection] = {
    "clear_before_ship": FindingSection.CLEAR_BEFORE_SHIP,
    "Clear Before Ship": FindingSection.CLEAR_BEFORE_SHIP,
    "fix_next": FindingSection.FIX_NEXT,
    "Fix Next": FindingSection.FIX_NEXT,
    "not_proven_not_tested": FindingSection.NOT_PROVEN_NOT_TESTED,
    "Not Proven / Not Tested": FindingSection.NOT_PROVEN_NOT_TESTED,
    "passed_keep": FindingSection.PASSED_KEEP,
    "Passed / Keep": FindingSection.PASSED_KEEP,
}

_SEVERITY_MAP: Mapping[str, Severity] = {
    "P0 Blocker": Severity.P0_BLOCKER,
    "p0": Severity.P0_BLOCKER,
    "P0": Severity.P0_BLOCKER,
    "blocker": Severity.P0_BLOCKER,
    "critical": Severity.P0_BLOCKER,
    "P1 Major": Severity.P1_MAJOR,
    "p1": Severity.P1_MAJOR,
    "P1": Severity.P1_MAJOR,
    "major": Severity.P1_MAJOR,
    "high": Severity.P1_MAJOR,
    "P2 Moderate": Severity.P2_MODERATE,
    "p2": Severity.P2_MODERATE,
    "P2": Severity.P2_MODERATE,
    "moderate": Severity.P2_MODERATE,
    "medium": Severity.P2_MODERATE,
    "P3 Minor": Severity.P3_MINOR,
    "p3": Severity.P3_MINOR,
    "P3": Severity.P3_MINOR,
    "minor": Severity.P3_MINOR,
    "low": Severity.P3_MINOR,
    "Unscored": Severity.UNSCORED,
    "unscored": Severity.UNSCORED,
}

_PROOF_MAP: Mapping[str, Proof] = {
    "Partial": Proof.PARTIAL,
    "partial": Proof.PARTIAL,
    "Inferred": Proof.INFERRED,
    "inferred": Proof.INFERRED,
    "Not tested": Proof.NOT_TESTED,
    "not tested": Proof.NOT_TESTED,
    "not_tested": Proof.NOT_TESTED,
    "untested": Proof.NOT_TESTED,
}

_CONFIDENCE_MAP: Mapping[str, Confidence] = {
    "Strong": Confidence.STRONG,
    "strong": Confidence.STRONG,
    "Provisional": Confidence.PROVISIONAL,
    "provisional": Confidence.PROVISIONAL,
    "Hypothesis": Confidence.HYPOTHESIS,
    "hypothesis": Confidence.HYPOTHESIS,
}

_TOP_LEVEL_PROJECTED_FIELDS = frozenset(("findings", "target"))
_FINDING_PROJECTED_FIELDS = frozenset(
    ("action", "confidence", "location", "proof", "section", "severity", "title")
)
_FORBIDDEN_DISPLAY_CATEGORIES = frozenset(("Cc", "Cf", "Cs"))
_VISIBLE_BASE_CATEGORY_PREFIXES = frozenset(("L", "N", "P", "S"))
_DENIED_DISPLAY_CODE_POINTS = frozenset(
    (0x115F, 0x1160, 0x2800, 0x3164, 0xFFA0)
)


def _reject_duplicate_members(
    pairs: list[tuple[str, object]],
) -> dict[str, object]:
    members: dict[str, object] = {}
    for key, value in pairs:
        if key in members:
            raise _DuplicateJsonMemberError
        members[key] = value
    return members


def _reject_nonstandard_constant(_value: str) -> None:
    raise _InvalidJsonConstantError


def _validated_string(
    adapter: TypeAdapter[Any], value: object
) -> Optional[str]:
    failed = False
    validated: Optional[str] = None
    try:
        validated = adapter.validate_python(value, strict=True)
    except (ValidationError, ValueError, TypeError):
        failed = True
    if failed:
        return None
    return validated


def _parse_json_object(raw: bytes) -> Optional[dict[str, object]]:
    decode_failed = False
    decoded: Optional[str] = None
    try:
        decoded = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError:
        decode_failed = True
    if decode_failed or decoded is None:
        return None

    failed = False
    parsed: object = None
    try:
        parsed = json.loads(
            decoded,
            object_pairs_hook=_reject_duplicate_members,
            parse_constant=_reject_nonstandard_constant,
        )
    except (
        UnicodeDecodeError,
        json.JSONDecodeError,
        _DuplicateJsonMemberError,
        _InvalidJsonConstantError,
        RecursionError,
        ValueError,
    ):
        failed = True
    if failed or not isinstance(parsed, dict):
        return None
    return parsed


def _shape_is_bounded(value: object) -> bool:
    stack: list[tuple[object, int]] = [(value, 0)]
    visited = 0
    while stack:
        current, depth = stack.pop()
        visited += 1
        if visited > MAX_JSON_NODES or depth > MAX_JSON_DEPTH:
            return False
        if isinstance(current, str):
            if len(current) > MAX_GENERAL_STRING_CHARS:
                return False
        elif isinstance(current, dict):
            if len(current) > MAX_OBJECT_MEMBERS:
                return False
            for key, child in current.items():
                if not isinstance(key, str) or len(key) > MAX_KEY_CHARS:
                    return False
                stack.append((child, depth + 1))
        elif isinstance(current, list):
            if len(current) > MAX_ARRAY_ITEMS:
                return False
            stack.extend((child, depth + 1) for child in current)
    return True


def _legacy_shape_is_valid(document: dict[str, object]) -> bool:
    if not _shape_is_bounded(document):
        return False

    target = document.get("target")
    if isinstance(target, str) and len(target) > MAX_TARGET_CHARS:
        return False

    findings = document.get("findings", [])
    if not isinstance(findings, list) or len(findings) > MAX_FINDINGS:
        return False
    for candidate in findings:
        if not isinstance(candidate, dict):
            continue
        title = candidate.get("title")
        if isinstance(title, str) and len(title) > MAX_TITLE_CHARS:
            return False
        for field in ("action", "confidence", "proof", "section", "severity"):
            value = candidate.get(field)
            if isinstance(value, str) and len(value) > MAX_ENUM_CHARS:
                return False
    return True


def _json_path(parent: str, key: str) -> str:
    if key.replace("_", "a").isalnum() and not key[:1].isdigit():
        return f"{parent}.{key}"
    quoted = json.dumps(key, ensure_ascii=True, separators=(",", ":"))
    return f"{parent}[{quoted}]"


def _combine_paired_surrogates(value: str) -> Optional[str]:
    combined: list[str] = []
    index = 0
    while index < len(value):
        code_point = ord(value[index])
        if 0xD800 <= code_point <= 0xDBFF:
            if index + 1 >= len(value):
                return None
            low_surrogate = ord(value[index + 1])
            if not 0xDC00 <= low_surrogate <= 0xDFFF:
                return None
            scalar = (
                0x10000
                + ((code_point - 0xD800) << 10)
                + (low_surrogate - 0xDC00)
            )
            combined.append(chr(scalar))
            index += 2
            continue
        if 0xDC00 <= code_point <= 0xDFFF:
            return None
        combined.append(value[index])
        index += 1
    return "".join(combined)


def _is_projectable_display_text(value: object) -> bool:
    """Return whether text is safe and has at least one visible base scalar."""

    if not isinstance(value, str) or not value or not value.isprintable():
        return False
    has_visible_base = False
    for character in value:
        if ord(character) in _DENIED_DISPLAY_CODE_POINTS:
            return False
        category = unicodedata.category(character)
        if category in _FORBIDDEN_DISPLAY_CATEGORIES:
            return False
        if category[:1] in _VISIBLE_BASE_CATEGORY_PREFIXES:
            has_visible_base = True
    return has_visible_base


def _projectable_display_text(value: object) -> Optional[str]:
    if not isinstance(value, str):
        return None
    normalized = _combine_paired_surrogates(value)
    if normalized is None or not _is_projectable_display_text(normalized):
        return None
    return normalized


def _derived_id(
    prefix: str,
    raw_digest: str,
    source_relative_path: str,
    *identity_parts: object,
) -> str:
    digest = hashlib.sha256()
    digest.update(SOURCE_SCHEMA_NAME.encode("ascii"))
    digest.update(b"\x00")
    digest.update(raw_digest.encode("ascii"))
    digest.update(b"\x00")
    digest.update(source_relative_path.encode("utf-8"))
    for part in identity_parts:
        digest.update(b"\x00")
        digest.update(str(part).encode("utf-8"))
    return f"{prefix}-LEGACY-{digest.hexdigest()[:24].upper()}"


def _append_debt(
    debt: list[_DebtDraft], code: str, source_path: str, reason: str
) -> None:
    if len(debt) >= MAX_MAPPING_DEBT:
        raise LegacyReadinessImportError(
            "legacy readiness shape exceeds safe bounds"
        )
    debt.append(_DebtDraft(code=code, source_path=source_path, reason=reason))


def _map_with_default(
    *,
    value: object,
    table: Mapping[str, Any],
    default: Any,
    debt: list[_DebtDraft],
    code: str,
    source_path: str,
    field_name: str,
) -> Any:
    if isinstance(value, str) and value in table:
        return table[value]
    _append_debt(
        debt,
        code,
        source_path,
        f"Legacy {field_name} is missing or has no explicit v1 mapping; "
        "a conservative value was used.",
    )
    return default


def _map_proof(
    value: object, debt: list[_DebtDraft], source_path: str
) -> Proof:
    if value in ("Confirmed", "confirmed"):
        _append_debt(
            debt,
            "LEGACY_CONFIRMED_PROOF_DOWNGRADED",
            source_path,
            "Legacy confirmed proof is not independent runtime verification "
            "and was downgraded to Partial.",
        )
        return Proof.PARTIAL
    return _map_with_default(
        value=value,
        table=_PROOF_MAP,
        default=Proof.NOT_TESTED,
        debt=debt,
        code="LEGACY_PROOF_DEFAULTED",
        source_path=source_path,
        field_name="proof",
    )


def _map_confidence(
    value: object, debt: list[_DebtDraft], source_path: str
) -> Confidence:
    if value in ("Confirmed", "confirmed"):
        _append_debt(
            debt,
            "LEGACY_CONFIRMED_CONFIDENCE_DOWNGRADED",
            source_path,
            "Legacy confirmed confidence is not independently verified and "
            "was downgraded to Provisional.",
        )
        return Confidence.PROVISIONAL
    return _map_with_default(
        value=value,
        table=_CONFIDENCE_MAP,
        default=Confidence.HYPOTHESIS,
        debt=debt,
        code="LEGACY_CONFIDENCE_DEFAULTED",
        source_path=source_path,
        field_name="confidence",
    )


def _producer() -> Producer:
    return Producer(name=IMPORTER_NAME, version=IMPORTER_VERSION)


def _build_projection(
    document: dict[str, object],
    *,
    raw_digest: str,
    byte_size: int,
    source_relative_path: str,
    imported_at: str,
) -> tuple[ReadinessLedger, tuple[LegacyMappingDebt, ...]]:
    debt: list[_DebtDraft] = []
    _append_debt(
        debt,
        "LEGACY_SCHEMA_UNVERSIONED",
        "$",
        "The source has no versioned readiness schema; this is an importer "
        "projection, not a legacy claim upgrade.",
    )

    for key in sorted(document):
        if key not in _TOP_LEVEL_PROJECTED_FIELDS:
            _append_debt(
                debt,
                "LEGACY_FIELD_RAW_ONLY",
                _json_path("$", key),
                "This legacy field has no representation in the Phase 0 v1 "
                "ledger and remains only in raw bytes.",
            )

    findings_value = document.get("findings")
    if findings_value is None:
        findings: Sequence[object] = ()
        _append_debt(
            debt,
            "LEGACY_FINDINGS_DEFAULTED",
            "$.findings",
            "The legacy findings array is missing; the projection uses no "
            "findings and remains incomplete.",
        )
    else:
        findings = cast(Sequence[object], findings_value)

    target = _projectable_display_text(document.get("target"))
    usable_target = target is not None
    if not usable_target:
        _append_debt(
            debt,
            "LEGACY_TARGET_DEFAULTED",
            "$.target",
            "The legacy target is missing or unusable; projected subjects "
            "use their raw JSON position as a provenance reference.",
        )

    artifact_id = _derived_id(
        "ART", raw_digest, source_relative_path, "raw-artifact"
    )
    projected_findings: list[Finding] = []
    for index, candidate in enumerate(findings):
        finding_path = f"$.findings[{index}]"
        if not isinstance(candidate, dict):
            _append_debt(
                debt,
                "LEGACY_FINDING_RAW_ONLY",
                finding_path,
                "This legacy finding is not an object and remains only in raw bytes.",
            )
            continue

        for key in sorted(candidate):
            if key not in _FINDING_PROJECTED_FIELDS:
                _append_debt(
                    debt,
                    "LEGACY_FIELD_RAW_ONLY",
                    _json_path(finding_path, key),
                    "This legacy finding field has no v1 representation and "
                    "remains only in raw bytes.",
                )

        if "location" in candidate:
            _append_debt(
                debt,
                "LEGACY_LOCATION_RAW_ONLY",
                f"{finding_path}.location",
                "Legacy location data is untrusted and is not projected into "
                "the strict repo-relative path field.",
            )

        raw_title = candidate.get("title")
        title = _projectable_display_text(raw_title)
        if title is None:
            title_is_missing = "title" not in candidate
            _append_debt(
                debt,
                (
                    "LEGACY_FINDING_TITLE_MISSING"
                    if title_is_missing
                    else "LEGACY_FINDING_TITLE_UNUSABLE"
                ),
                f"{finding_path}.title",
                (
                    "A title is required for a v1 finding; the legacy record "
                    "remains only in raw bytes."
                    if title_is_missing
                    else "The legacy title is not safe projectable display text; "
                    "the record remains only in raw bytes."
                ),
            )
            continue

        action = _map_with_default(
            value=candidate.get("action"),
            table=_ACTION_MAP,
            default=Action.PROVE,
            debt=debt,
            code="LEGACY_ACTION_DEFAULTED",
            source_path=f"{finding_path}.action",
            field_name="action",
        )
        section = _map_with_default(
            value=candidate.get("section"),
            table=_SECTION_MAP,
            default=FindingSection.NOT_PROVEN_NOT_TESTED,
            debt=debt,
            code="LEGACY_SECTION_DEFAULTED",
            source_path=f"{finding_path}.section",
            field_name="section",
        )
        severity = _map_with_default(
            value=candidate.get("severity"),
            table=_SEVERITY_MAP,
            default=Severity.UNSCORED,
            debt=debt,
            code="LEGACY_SEVERITY_DEFAULTED",
            source_path=f"{finding_path}.severity",
            field_name="severity",
        )
        proof = _map_proof(candidate.get("proof"), debt, f"{finding_path}.proof")
        confidence = _map_confidence(
            candidate.get("confidence"), debt, f"{finding_path}.confidence"
        )
        _append_debt(
            debt,
            "LEGACY_FINDING_NEEDS_PROOF",
            finding_path,
            "Imported legacy findings require independent verification before "
            "approval or gate blocking.",
        )

        subject_ref = target if usable_target else f"legacy/findings/{index}"
        finding_id = _derived_id(
            "FND",
            raw_digest,
            source_relative_path,
            "finding",
            index,
            title,
        )
        projected_findings.append(
            Finding(
                finding_id=finding_id,
                revision=1,
                subject=FindingSubject(
                    kind=SubjectKind.EVIDENCE_GAP,
                    ref=subject_ref,
                    title=title,
                    location=None,
                ),
                action=action,
                proof=proof,
                section=section,
                severity=severity,
                confidence=confidence,
                verifier_status=VerifierStatus.NEEDS_PROOF,
                summary=title,
                artifact_ids=(artifact_id,),
            )
        )

    if usable_target and not projected_findings:
        _append_debt(
            debt,
            "LEGACY_TARGET_RAW_ONLY",
            "$.target",
            "No projected finding can carry the legacy target; it remains only in raw bytes.",
        )

    mapping_debt = tuple(
        LegacyMappingDebt(
            debt_id=_derived_id(
                "ED",
                raw_digest,
                source_relative_path,
                "mapping-debt",
                index,
                draft.code,
                draft.source_path,
            ),
            code=draft.code,
            source_path=draft.source_path,
            reason=draft.reason,
        )
        for index, draft in enumerate(debt)
    )

    artifact = Artifact(
        artifact_id=artifact_id,
        availability=ArtifactAvailability.AVAILABLE,
        descriptor=ArtifactDescriptor(
            relative_path=source_relative_path,
            declared_media_type="application/json",
            digest_algorithm="sha256",
            digest=raw_digest,
            byte_size=byte_size,
        ),
        lineage=ArtifactLineage(
            producer=IMPORTER_NAME,
            operation=f"import {SOURCE_SCHEMA_NAME}",
            source_ids=(),
        ),
        custody_state=CustodyState.LOCAL_CONTENT_INTEGRITY,
    )
    evidence_debt = tuple(
        EvidenceDebt(
            debt_id=row.debt_id,
            subject=row.source_path,
            proof_needed=(
                "Independently verify the raw legacy assertion or supply a "
                "versioned source."
            ),
            reason=row.reason,
            status=DebtStatus.NEEDS_PROOF,
            artifact_ids=(artifact_id,),
        )
        for row in mapping_debt
    )
    ledger = ReadinessLedger(
        schema_name="shipworthy/readiness-ledger",
        schema_version="1.0",
        generated_at=imported_at,
        producer=_producer(),
        ledger_id=_derived_id(
            "LED", raw_digest, source_relative_path, "ledger"
        ),
        revision=1,
        completion_status=CompletionStatus.INCOMPLETE,
        readiness_disposition=ReadinessDisposition.CANNOT_DETERMINE,
        gate=ConfirmedOnlyGateContract(policy=GatePolicy.CONFIRMED_ONLY),
        findings=tuple(projected_findings),
        artifacts=(artifact,),
        evidence_debt=evidence_debt,
    )
    return ledger, mapping_debt


def import_legacy_readiness_json(
    raw: bytes,
    *,
    source_relative_path: str,
    imported_at: str,
) -> LegacyReadinessImportResult:
    """Project exact unversioned readiness JSON into an honest strict-v1 ledger.

    The adapter is deliberately side-effect free: callers provide already-read bytes,
    a safe provenance path, and an explicit canonical import timestamp.
    """

    if not isinstance(raw, bytes):
        raise LegacyReadinessImportError("legacy readiness input must be bytes")
    if not raw:
        raise LegacyReadinessImportError("legacy readiness input must not be empty")
    if len(raw) > MAX_INPUT_BYTES:
        raise LegacyReadinessImportError(
            "legacy readiness input exceeds the 1 MiB boundary"
        )

    safe_source_path = _validated_string(
        _SOURCE_PATH_ADAPTER, source_relative_path
    )
    if safe_source_path is None:
        raise LegacyReadinessImportError(
            "legacy readiness source path failed safe validation"
        )
    canonical_imported_at = _validated_string(_TIMESTAMP_ADAPTER, imported_at)
    if canonical_imported_at is None:
        raise LegacyReadinessImportError(
            "legacy readiness import timestamp failed canonical validation"
        )

    document = _parse_json_object(raw)
    if document is None:
        raise LegacyReadinessImportError(
            "legacy readiness JSON failed safe import validation"
        )
    if not _legacy_shape_is_valid(document):
        raise LegacyReadinessImportError(
            "legacy readiness shape exceeds safe bounds"
        )

    raw_digest = hashlib.sha256(raw).hexdigest()
    shape_bounds_failed = False
    projection_failed = False
    projection: Optional[
        tuple[ReadinessLedger, tuple[LegacyMappingDebt, ...]]
    ] = None
    try:
        projection = _build_projection(
            document,
            raw_digest=raw_digest,
            byte_size=len(raw),
            source_relative_path=safe_source_path,
            imported_at=canonical_imported_at,
        )
    except LegacyReadinessImportError:
        shape_bounds_failed = True
    except (ValidationError, ValueError, TypeError):
        projection_failed = True
    if shape_bounds_failed:
        raise LegacyReadinessImportError(
            "legacy readiness shape exceeds safe bounds"
        )
    if projection_failed or projection is None:
        raise LegacyReadinessImportError(
            "legacy readiness projection failed strict v1 validation"
        )

    ledger, mapping_debt = projection
    return LegacyReadinessImportResult(
        source_schema_name=SOURCE_SCHEMA_NAME,
        source_relative_path=safe_source_path,
        imported_at=canonical_imported_at,
        raw_bytes=raw,
        sha256=raw_digest,
        byte_size=len(raw),
        mapping_debt=mapping_debt,
        ledger=ledger,
    )


__all__ = (
    "LegacyMappingDebt",
    "LegacyReadinessImportError",
    "LegacyReadinessImportResult",
    "import_legacy_readiness_json",
)
