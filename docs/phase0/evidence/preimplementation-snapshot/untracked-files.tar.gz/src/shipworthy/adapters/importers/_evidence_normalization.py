"""Shared immutable records and byte-only sealing helpers for evidence importers."""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
from typing import Mapping

from pydantic import TypeAdapter, ValidationError

from shipworthy.domain.entities import (
    Artifact,
    ArtifactDescriptor,
    ArtifactLineage,
    SafeRepoRelativePath,
)
from shipworthy.domain.enums import (
    ArtifactAvailability,
    BrowserEvidenceMode,
    CustodyState,
)


MAX_ATTACHMENTS = 128
MAX_SINGLE_ATTACHMENT_BYTES = 16 * 1_048_576
MAX_TOTAL_ATTACHMENT_BYTES = 64 * 1_048_576
_PATH_ADAPTER = TypeAdapter(SafeRepoRelativePath)


@dataclass(frozen=True, slots=True)
class EvidenceSourceIdentity:
    schema_name: str
    relative_path: str
    producer_name: str
    producer_version: str


@dataclass(frozen=True, slots=True)
class NormalizedObservation:
    observation_id: str
    official_id: str | None
    project: str | None
    project_id: str | None
    subject: str
    action: str
    observed_outcome: str
    outcome: str
    retry_count: int
    flaky: bool
    artifact_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class EvidenceDebtDraft:
    code: str
    subject: str
    proof_needed: str
    reason: str
    artifact_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class SealedAttachmentBytes:
    """Importer-retained local bytes used only for provenance verification."""

    relative_path: str
    raw_bytes: bytes = field(repr=False)


@dataclass(frozen=True, slots=True)
class NormalizedEvidenceResult:
    source: EvidenceSourceIdentity
    mode: BrowserEvidenceMode
    driver: str
    raw_bytes: bytes = field(repr=False)
    sha256: str
    byte_size: int
    source_artifact: Artifact
    artifacts: tuple[Artifact, ...]
    observations: tuple[NormalizedObservation, ...]
    limitations: tuple[str, ...]
    evidence_debt: tuple[EvidenceDebtDraft, ...]
    finding_ids: tuple[str, ...]
    target_fingerprint: str | None
    path_intent: str | None
    sealed_attachments: tuple[SealedAttachmentBytes, ...]


def safe_path(value: object) -> str | None:
    failed = False
    path: str | None = None
    try:
        path = _PATH_ADAPTER.validate_python(value, strict=True)
    except (ValidationError, ValueError, TypeError):
        failed = True
    return None if failed else path


def validate_attachment_mapping(
    attachment_bytes: object,
) -> dict[str, bytes] | None:
    if not isinstance(attachment_bytes, Mapping):
        return None
    if len(attachment_bytes) > MAX_ATTACHMENTS:
        return None
    validated: dict[str, bytes] = {}
    total = 0
    for raw_path, raw_bytes in attachment_bytes.items():
        path = safe_path(raw_path)
        if path is None or not isinstance(raw_bytes, bytes):
            return None
        total += len(raw_bytes)
        if len(raw_bytes) > MAX_SINGLE_ATTACHMENT_BYTES:
            return None
        if total > MAX_TOTAL_ATTACHMENT_BYTES:
            return None
        validated[path] = raw_bytes
    return validated


def artifact_id(prefix: str, digest: str) -> str:
    return f"ART-{prefix}-{digest[:24].upper()}"


def available_artifact(
    *,
    artifact_id_value: str,
    relative_path: str,
    media_type: str,
    raw: bytes,
    operation: str,
    source_ids: tuple[str, ...],
    producer: str,
    availability: ArtifactAvailability = ArtifactAvailability.AVAILABLE,
) -> Artifact:
    return Artifact(
        artifact_id=artifact_id_value,
        availability=availability,
        descriptor=ArtifactDescriptor(
            relative_path=relative_path,
            declared_media_type=media_type,
            digest_algorithm="sha256",
            digest=hashlib.sha256(raw).hexdigest(),
            byte_size=len(raw),
        ),
        lineage=ArtifactLineage(
            producer=producer,
            operation=operation,
            source_ids=source_ids,
        ),
        custody_state=CustodyState.LOCAL_CONTENT_INTEGRITY,
    )


def missing_artifact(
    *,
    artifact_id_value: str,
    relative_path: str,
    media_type: str,
    source_id: str,
    producer: str,
    operation: str,
) -> Artifact:
    return Artifact(
        artifact_id=artifact_id_value,
        availability=ArtifactAvailability.MISSING,
        descriptor=ArtifactDescriptor(
            relative_path=relative_path,
            declared_media_type=media_type,
            digest_algorithm="sha256",
            digest=None,
            byte_size=None,
        ),
        lineage=ArtifactLineage(
            producer=producer,
            operation=operation,
            source_ids=(source_id,),
        ),
        custody_state=CustodyState.LOCAL_CONTENT_INTEGRITY,
    )


def source_artifact(
    raw: bytes,
    source_relative_path: str,
    *,
    artifact_prefix: str,
    producer: str,
    operation: str,
) -> Artifact:
    digest = hashlib.sha256(raw).hexdigest()
    return available_artifact(
        artifact_id_value=artifact_id(artifact_prefix, digest),
        relative_path=source_relative_path,
        media_type="application/json",
        raw=raw,
        operation=operation,
        source_ids=(),
        producer=producer,
    )


__all__ = (
    "MAX_ATTACHMENTS",
    "MAX_SINGLE_ATTACHMENT_BYTES",
    "MAX_TOTAL_ATTACHMENT_BYTES",
    "EvidenceDebtDraft",
    "EvidenceSourceIdentity",
    "NormalizedEvidenceResult",
    "NormalizedObservation",
    "SealedAttachmentBytes",
    "artifact_id",
    "available_artifact",
    "missing_artifact",
    "safe_path",
    "source_artifact",
    "validate_attachment_mapping",
)
