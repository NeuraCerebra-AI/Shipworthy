"""Isolated source-tree loading for the existing report transforms."""

from __future__ import annotations

from functools import lru_cache
from importlib import resources
import importlib.util
from pathlib import Path
from types import ModuleType


class ReportingTransformError(RuntimeError):
    """Raised when a required reporting transform is unavailable or fails."""


class _PackagedResourceError(RuntimeError):
    """Internal fail-closed signal for a present but unreadable resource."""


def _repository_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _legacy_script_path(filename: str) -> Path:
    return (
        _repository_root()
        / "plugins"
        / "shipworthy"
        / "skills"
        / "ship-readiness-orchestrator"
        / "scripts"
        / filename
    )


def _is_source_checkout() -> bool:
    root = _repository_root()
    expected_module = (
        root
        / "src/shipworthy/adapters/reporting/compat_loader.py"
    )
    return (
        Path(__file__).resolve() == expected_module.resolve()
        and (root / ".git").exists()
        and (root / "pyproject.toml").is_file()
        and _legacy_script_path("render_report.py").is_file()
        and _legacy_script_path("to_sarif.py").is_file()
    )


def _packaged_legacy_bytes(filename: str) -> bytes | None:
    """Return an immutable transform bundled in the core wheel, if present."""
    try:
        directory = resources.files("shipworthy").joinpath(
            "_legacy_reporting"
        )
        if not directory.is_dir():
            return None
        resource = directory.joinpath(filename)
        if not resource.is_file():
            raise _PackagedResourceError
        return resource.read_bytes()
    except _PackagedResourceError:
        raise
    except Exception:
        raise _PackagedResourceError from None


def _module_from_source(module_name: str, filename: str, source: bytes) -> ModuleType:
    origin = f"shipworthy-wheel-resource:{filename}"
    module = ModuleType(module_name)
    module.__file__ = origin
    module.__package__ = ""
    code = compile(source, origin, "exec")
    exec(code, module.__dict__)
    return module


@lru_cache(maxsize=3)
def _load_legacy_script(module_name: str, filename: str) -> ModuleType:
    failed = False
    module: ModuleType | None = None
    try:
        packaged_source = _packaged_legacy_bytes(filename)
        if packaged_source is not None:
            module = _module_from_source(module_name, filename, packaged_source)
        elif _is_source_checkout():
            # Explicit source-checkout fallback. Installed wheels carry the
            # transform bytes and never need a repository root.
            path = _legacy_script_path(filename)
            if not path.is_file():
                failed = True
            else:
                spec = importlib.util.spec_from_file_location(module_name, path)
                if spec is not None and spec.loader is not None:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                else:
                    failed = True
        else:
            failed = True
    except Exception:
        failed = True
    if failed or module is None:
        raise ReportingTransformError("legacy reporting transform unavailable")
    return module


def load_legacy_renderer() -> ModuleType:
    return _load_legacy_script(
        "_shipworthy_legacy_render_report", "render_report.py"
    )


def load_legacy_sarif() -> ModuleType:
    return _load_legacy_script("_shipworthy_legacy_to_sarif", "to_sarif.py")


def load_legacy_bundle() -> ModuleType:
    return _load_legacy_script(
        "_shipworthy_legacy_make_bundle", "make_bundle.py"
    )
