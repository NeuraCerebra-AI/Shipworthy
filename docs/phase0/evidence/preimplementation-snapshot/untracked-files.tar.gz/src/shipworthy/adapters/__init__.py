"""Adapters at Shipworthy's explicit external-data boundaries."""
