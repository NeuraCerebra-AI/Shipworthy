"""Structural validation for self-contained, inert readiness HTML."""

from __future__ import annotations

from html import unescape
from html.parser import HTMLParser
import re
from typing import List, Optional, Sequence, Tuple
from urllib.parse import unquote


_ALLOWED_ELEMENTS = frozenset(
    (
        "article",
        "b",
        "body",
        "details",
        "div",
        "footer",
        "h1",
        "h2",
        "h3",
        "head",
        "header",
        "html",
        "meta",
        "p",
        "section",
        "span",
        "style",
        "summary",
        "title",
    )
)
_ALLOWED_PARENT_CHILD_PAIRS = frozenset(
    (
        ("article", "details"),
        ("article", "div"),
        ("article", "h3"),
        ("article", "p"),
        ("body", "div"),
        ("details", "div"),
        ("details", "summary"),
        ("div", "div"),
        ("div", "footer"),
        ("div", "h2"),
        ("div", "header"),
        ("div", "p"),
        ("div", "section"),
        ("div", "span"),
        ("footer", "b"),
        ("head", "meta"),
        ("head", "style"),
        ("head", "title"),
        ("header", "div"),
        ("header", "h1"),
        ("header", "p"),
        ("html", "body"),
        ("html", "head"),
        ("p", "b"),
        ("p", "span"),
        ("root", "html"),
        ("section", "article"),
        ("section", "div"),
        ("section", "p"),
        ("span", "span"),
    )
)
_VOID_ELEMENTS = frozenset(("meta",))
_URL_ATTRIBUTES = frozenset(
    (
        "action",
        "archive",
        "background",
        "cite",
        "classid",
        "code",
        "codebase",
        "data",
        "formaction",
        "href",
        "icon",
        "longdesc",
        "manifest",
        "ping",
        "poster",
        "profile",
        "src",
        "srcset",
        "usemap",
        "xlink:href",
    )
)
_ASCII_CONTROL_OR_SPACE = re.compile(r"[\x00-\x20\x7f]+")
_CSS_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)
_CSS_HEX_ESCAPE = re.compile(r"\\([0-9a-fA-F]{1,6})(?:\s)?")
_CSS_SIMPLE_ESCAPE = re.compile(r"\\(.)", re.DOTALL)
_CSS_ACTIVE = re.compile(
    r"@import\b|"
    r"@font-face\b|"
    r"(?:^|[;{])\s*(?:behavior|-moz-binding)\s*:|"
    r"(?:url|expression|image|image-set|-webkit-image-set)\s*\(",
    re.IGNORECASE,
)


def _normalized_url(value: str) -> str:
    normalized = unescape(value)
    for _ in range(2):
        decoded = unquote(normalized)
        if decoded == normalized:
            break
        normalized = decoded
    return _ASCII_CONTROL_OR_SPACE.sub("", normalized).casefold()


def _url_attribute_is_safe(name: str, value: Optional[str]) -> bool:
    if value is None:
        return False
    normalized = _normalized_url(value)
    return name == "href" and normalized.startswith("#") and len(normalized) > 1


def _decode_css_escapes(value: str) -> str:
    def hex_value(match: re.Match[str]) -> str:
        code_point = int(match.group(1), 16)
        if code_point == 0 or code_point > 0x10FFFF:
            return "\N{REPLACEMENT CHARACTER}"
        return chr(code_point)

    decoded = _CSS_HEX_ESCAPE.sub(hex_value, value)
    return _CSS_SIMPLE_ESCAPE.sub(lambda match: match.group(1), decoded)


def _css_is_safe(value: str) -> bool:
    decoded = _decode_css_escapes(value)
    without_comments = _CSS_COMMENT.sub("", decoded)
    return _CSS_ACTIVE.search(without_comments) is None


class _SelfContainedHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.safe = True
        self._stack: List[str] = []
        self._style_chunks: Optional[List[str]] = None
        self._doctype_seen = False
        self._html_seen = False
        self._html_closed = False
        self._head_seen = False
        self._head_closed = False
        self._body_seen = False
        self._body_closed = False

    def _invalidate(self) -> None:
        self.safe = False

    def handle_decl(self, decl: str) -> None:
        if (
            self._doctype_seen
            or self._html_seen
            or decl.strip().casefold() != "doctype html"
        ):
            self._invalidate()
        self._doctype_seen = True

    def unknown_decl(self, _data: str) -> None:
        self._invalidate()

    def handle_pi(self, _data: str) -> None:
        self._invalidate()

    def handle_comment(self, _data: str) -> None:
        self._invalidate()

    def handle_starttag(
        self, tag: str, attrs: Sequence[Tuple[str, Optional[str]]]
    ) -> None:
        self._start(tag, attrs, self_closing=False)

    def handle_startendtag(
        self, tag: str, attrs: Sequence[Tuple[str, Optional[str]]]
    ) -> None:
        self._start(tag, attrs, self_closing=True)

    def _start(
        self,
        tag: str,
        attrs: Sequence[Tuple[str, Optional[str]]],
        *,
        self_closing: bool,
    ) -> None:
        normalized_tag = tag.casefold()
        parent = self._stack[-1] if self._stack else "root"
        if (
            normalized_tag not in _ALLOWED_ELEMENTS
            or (parent, normalized_tag) not in _ALLOWED_PARENT_CHILD_PAIRS
        ):
            self._invalidate()
        if self_closing and normalized_tag not in _VOID_ELEMENTS:
            self._invalidate()
        if self._html_closed:
            self._invalidate()
        if normalized_tag == "html":
            if self._html_seen or self._stack:
                self._invalidate()
            self._html_seen = True
        elif not self._html_seen or not self._stack:
            self._invalidate()
        if normalized_tag == "head":
            if (
                self_closing
                or self._head_seen
                or self._body_seen
                or self._stack != ["html"]
            ):
                self._invalidate()
            self._head_seen = True
        elif normalized_tag == "body":
            if (
                self_closing
                or self._body_seen
                or not self._head_closed
                or self._stack != ["html"]
            ):
                self._invalidate()
            self._body_seen = True
        elif normalized_tag != "html":
            if not self._head_seen:
                self._invalidate()
            elif self._head_closed and not self._body_seen:
                self._invalidate()
            elif self._body_closed:
                self._invalidate()

        for raw_name, value in attrs:
            name = raw_name.casefold()
            if name.startswith("on"):
                self._invalidate()
            if normalized_tag == "meta" and name == "http-equiv":
                self._invalidate()
            if name in _URL_ATTRIBUTES and not _url_attribute_is_safe(name, value):
                self._invalidate()
            if name == "style" and (value is None or not _css_is_safe(value)):
                self._invalidate()

        if normalized_tag == "style":
            if self._style_chunks is not None:
                self._invalidate()
            self._style_chunks = []
        if not self_closing and normalized_tag not in _VOID_ELEMENTS:
            self._stack.append(normalized_tag)
        elif normalized_tag == "html":
            self._html_closed = True

    def handle_endtag(self, tag: str) -> None:
        normalized_tag = tag.casefold()
        if normalized_tag in _VOID_ELEMENTS or not self._stack:
            self._invalidate()
            return
        if self._stack[-1] != normalized_tag:
            self._invalidate()
            return
        if normalized_tag == "style":
            if self._style_chunks is None or not _css_is_safe(
                "".join(self._style_chunks)
            ):
                self._invalidate()
            self._style_chunks = None
        self._stack.pop()
        if normalized_tag == "head":
            self._head_closed = True
        elif normalized_tag == "body":
            self._body_closed = True
        elif normalized_tag == "html":
            self._html_closed = True

    def handle_data(self, data: str) -> None:
        if self._style_chunks is not None:
            self._style_chunks.append(data)
        if (not self._html_seen or self._html_closed) and data.strip():
            self._invalidate()
        if data.strip() and self._stack and self._stack[-1] in ("html", "head"):
            self._invalidate()

    def close(self) -> None:
        super().close()
        if (
            not self._doctype_seen
            or not self._html_seen
            or not self._html_closed
            or not self._head_seen
            or not self._head_closed
            or not self._body_seen
            or not self._body_closed
            or self._stack
            or self._style_chunks is not None
        ):
            self._invalidate()


def is_safe_self_contained_html(document: str) -> bool:
    parser = _SelfContainedHTMLParser()
    failed = False
    try:
        parser.feed(document)
        parser.close()
    except Exception:
        failed = True
    return not failed and parser.safe
