"""Strict-ledger HTML adapter around the existing self-contained renderer."""

from __future__ import annotations

from shipworthy.adapters.reporting.compat_loader import (
    ReportingTransformError,
    load_legacy_renderer,
)
from shipworthy.adapters.reporting.html_safety import is_safe_self_contained_html
from shipworthy.adapters.reporting.projection import ReportingProjection


def render_readiness_html(projection: ReportingProjection) -> bytes:
    if not isinstance(projection, ReportingProjection):
        raise TypeError("projection must be a ReportingProjection")
    renderer = load_legacy_renderer()
    render = getattr(renderer, "render", None)
    if not callable(render):
        raise ReportingTransformError("legacy reporting transform unavailable")

    failed = False
    rendered: object = None
    try:
        rendered = render(projection.legacy_report_data(), interactive=False)
    except Exception:
        failed = True
    if failed or not isinstance(rendered, str):
        raise ReportingTransformError("readiness HTML rendering failed")
    if not is_safe_self_contained_html(rendered):
        raise ReportingTransformError("readiness HTML safety validation failed")
    return rendered.encode("utf-8")
