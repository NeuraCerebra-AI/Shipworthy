"""Bounded, raw-first import adapters."""

from shipworthy.adapters.importers.browser_evidence import (
    BrowserEvidenceImportError,
    EvidenceDebtDraft,
    EvidenceSourceIdentity,
    NormalizedEvidenceResult,
    NormalizedObservation,
    import_browser_evidence_json,
)
from shipworthy.adapters.importers.legacy_readiness import (
    LegacyMappingDebt,
    LegacyReadinessImportError,
    LegacyReadinessImportResult,
    import_legacy_readiness_json,
)
from shipworthy.adapters.importers.playwright_report import (
    PlaywrightReportImportError,
    import_playwright_json_report,
)

__all__ = (
    "BrowserEvidenceImportError",
    "EvidenceDebtDraft",
    "EvidenceSourceIdentity",
    "LegacyMappingDebt",
    "LegacyReadinessImportError",
    "LegacyReadinessImportResult",
    "NormalizedEvidenceResult",
    "NormalizedObservation",
    "PlaywrightReportImportError",
    "import_browser_evidence_json",
    "import_legacy_readiness_json",
    "import_playwright_json_report",
)
