"""Strict-ledger reporting projection, transforms, and evidence bundle."""

from shipworthy.adapters.reporting.bundle import (
    PHASE0_MAX_AGGREGATE_ARTIFACT_BYTES,
    PHASE0_MAX_ARTIFACT_BYTES,
    PHASE0_MAX_INCLUDED_ARTIFACT_COUNT,
    PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES,
    ReportingArtifactError,
    build_evidence_bundle,
)
from shipworthy.adapters.reporting.compat_loader import ReportingTransformError
from shipworthy.adapters.reporting.html import render_readiness_html
from shipworthy.adapters.reporting.projection import (
    BrowserEvidenceReporting,
    ReportRow,
    ReportingArtifact,
    ReportingProjection,
)
from shipworthy.adapters.reporting.sarif import (
    render_readiness_sarif,
    render_readiness_sarif_bytes,
)

__all__ = [
    "BrowserEvidenceReporting",
    "ReportRow",
    "PHASE0_MAX_AGGREGATE_ARTIFACT_BYTES",
    "PHASE0_MAX_ARTIFACT_BYTES",
    "PHASE0_MAX_INCLUDED_ARTIFACT_COUNT",
    "PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES",
    "ReportingArtifact",
    "ReportingArtifactError",
    "ReportingProjection",
    "ReportingTransformError",
    "build_evidence_bundle",
    "render_readiness_html",
    "render_readiness_sarif",
    "render_readiness_sarif_bytes",
]
