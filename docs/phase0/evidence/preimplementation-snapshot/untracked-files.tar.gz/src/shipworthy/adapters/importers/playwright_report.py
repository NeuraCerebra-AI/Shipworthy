"""Bounded translation of caller-supplied Playwright JSON reporter bytes."""

from __future__ import annotations

import hashlib
import json
from typing import Iterator, Mapping

from pydantic import TypeAdapter, ValidationError

from shipworthy.adapters.importers._evidence_normalization import (
    MAX_ATTACHMENTS,
    MAX_SINGLE_ATTACHMENT_BYTES,
    MAX_TOTAL_ATTACHMENT_BYTES,
    EvidenceDebtDraft,
    EvidenceSourceIdentity,
    NormalizedEvidenceResult,
    NormalizedObservation,
    SealedAttachmentBytes,
    artifact_id,
    available_artifact,
    missing_artifact,
    safe_path,
    source_artifact,
    validate_attachment_mapping,
)
from shipworthy.domain.entities import Artifact, MediaType
from shipworthy.domain.enums import BrowserEvidenceMode
from shipworthy.domain.ids import FindingId


MAX_REPORT_BYTES = 16 * 1_048_576
MAX_JSON_DEPTH = 32
MAX_JSON_NODES = 100_000
MAX_COLLECTION_ITEMS = 4_096
MAX_TESTS = 4_096
MAX_ARTIFACTS = 1_024
# Raw-only reporter strings, including embedded attachment bodies, are bounded by
# the whole-report byte ceiling. Every interpreted identifier/display/path field
# receives its own tighter validation below.
MAX_STRING_CHARS = MAX_REPORT_BYTES
IMPORTER_NAME = "shipworthy-playwright-report-importer"
_AGGREGATE_OUTCOMES = {
    "expected": "passed",
    "unexpected": "failed",
    "flaky": "passed",
    "skipped": "skipped",
}
_RESULT_STATUSES = {"passed", "failed", "skipped", "timedOut", "interrupted"}
_MEDIA_TYPE_ADAPTER = TypeAdapter(MediaType)
_FINDING_ID_ADAPTER = TypeAdapter(FindingId)


class PlaywrightReportImportError(ValueError):
    """A sanitized failure at the supplied Playwright report boundary."""


class _DuplicateMember(ValueError):
    pass


class _InvalidConstant(ValueError):
    pass


def _reject_duplicate_members(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateMember
        result[key] = value
    return result


def _reject_constant(_value: str) -> None:
    raise _InvalidConstant


def _bounded_tree(value: object) -> bool:
    nodes = 0
    stack = [(value, 1)]
    while stack:
        current, depth = stack.pop()
        nodes += 1
        if nodes > MAX_JSON_NODES or depth > MAX_JSON_DEPTH:
            return False
        if isinstance(current, str):
            if len(current) > MAX_STRING_CHARS:
                return False
        elif isinstance(current, list):
            if len(current) > MAX_COLLECTION_ITEMS:
                return False
            stack.extend((item, depth + 1) for item in current)
        elif isinstance(current, dict):
            if len(current) > MAX_COLLECTION_ITEMS:
                return False
            stack.extend((item, depth + 1) for item in current.values())
        elif current is not None and not isinstance(current, (bool, int, float)):
            return False
    return True


def _parse_report(raw: object) -> dict[str, object] | None:
    if not isinstance(raw, bytes) or not raw or len(raw) > MAX_REPORT_BYTES:
        return None
    parsed: object = None
    failed = False
    try:
        parsed = json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=_reject_duplicate_members,
            parse_constant=_reject_constant,
        )
    except (
        UnicodeDecodeError,
        json.JSONDecodeError,
        _DuplicateMember,
        _InvalidConstant,
        RecursionError,
        ValueError,
    ):
        failed = True
    if failed or not isinstance(parsed, dict) or not _bounded_tree(parsed):
        return None
    if not isinstance(parsed.get("suites"), list):
        return None
    config = parsed.get("config")
    if config is not None and not isinstance(config, dict):
        return None
    return parsed


def _suite_specs(
    suites: list[object],
) -> Iterator[tuple[tuple[str, ...], str, object]]:
    stack: list[tuple[object, tuple[str, ...]]] = [
        (suite, ()) for suite in reversed(suites)
    ]
    while stack:
        suite, parents = stack.pop()
        if not isinstance(suite, dict):
            raise ValueError
        title = suite.get("title", "unnamed suite")
        nested = suite.get("suites", [])
        specs = suite.get("specs", [])
        file_name = suite.get("file", "unknown.spec")
        if not isinstance(title, str) or not title or len(title) > 200:
            raise ValueError
        if not isinstance(nested, list) or not isinstance(specs, list):
            raise ValueError
        if not isinstance(file_name, str) or not file_name or len(file_name) > 512:
            raise ValueError
        ancestry = (*parents, title)
        stack.extend((child, ancestry) for child in reversed(nested))
        for spec in specs:
            yield ancestry, file_name, spec


def _producer_version(report: Mapping[str, object]) -> str:
    config = report.get("config")
    if isinstance(config, dict):
        version = config.get("version")
        if isinstance(version, str) and 0 < len(version) <= 32:
            return version
    return "unknown"


def _location_subject(
    ancestry: tuple[str, ...],
    suite_file: str,
    spec: Mapping[str, object],
    title: str,
    project: str,
) -> str:
    file_name = spec.get("file", suite_file)
    line = spec.get("line")
    column = spec.get("column")
    if not isinstance(file_name, str) or not file_name or len(file_name) > 512:
        raise ValueError
    if not isinstance(line, int) or isinstance(line, bool) or line < 1:
        raise ValueError
    if not isinstance(column, int) or isinstance(column, bool) or column < 1:
        raise ValueError
    subject = (
        f"{' > '.join(ancestry)} > {file_name}:{line}:{column} :: {title} [{project}]"
    )
    if len(subject) > 1_000:
        raise ValueError
    return subject


def _observation_id(official_id: str, project_id: str) -> str:
    digest = hashlib.sha256(f"{official_id}\0{project_id}".encode()).hexdigest()
    return f"playwright-{digest[:24]}"


def _valid_media_type(value: object) -> str | None:
    failed = False
    media_type: str | None = None
    try:
        media_type = _MEDIA_TYPE_ADAPTER.validate_python(value, strict=True)
    except (ValidationError, ValueError, TypeError):
        failed = True
    return None if failed else media_type


def _embedded_attachment_debt(
    official_id: str,
    project_id: str,
    name: str,
    ordinal: int,
) -> EvidenceDebtDraft:
    return EvidenceDebtDraft(
        code="ATTACHMENT_BODY_UNIMPORTED",
        subject=(f"{official_id}[{project_id}] embedded attachment {ordinal}: {name}"),
        proof_needed="Supply the attachment as bounded local bytes with a safe relative path.",
        reason="Embedded reporter attachment content was retained only in the sealed raw report.",
        artifact_ids=(),
    )


def _normalize(
    report: dict[str, object],
    raw: bytes,
    source_relative_path: str,
    attachments: Mapping[str, bytes],
    finding_ids: tuple[str, ...],
) -> NormalizedEvidenceResult:
    sealed_source = source_artifact(
        raw,
        source_relative_path,
        artifact_prefix="PLAYWRIGHT-SOURCE",
        producer=IMPORTER_NAME,
        operation="seal-supplied-playwright-report",
    )
    observations: list[NormalizedObservation] = []
    artifacts: list[Artifact] = []
    debts: list[EvidenceDebtDraft] = []
    identities: set[tuple[str, str]] = set()
    declared_paths: set[str] = set()

    suites = report["suites"]
    if not isinstance(suites, list):
        raise ValueError
    for ancestry, suite_file, raw_spec in _suite_specs(suites):
        if not isinstance(raw_spec, dict):
            raise ValueError
        official_id = raw_spec.get("id")
        title = raw_spec.get("title")
        tests = raw_spec.get("tests")
        if (
            not isinstance(official_id, str)
            or not official_id
            or len(official_id) > 200
        ):
            raise ValueError
        if (
            not isinstance(title, str)
            or not title
            or len(title) > 200
            or not isinstance(tests, list)
        ):
            raise ValueError
        for test in tests:
            if not isinstance(test, dict):
                raise ValueError
            project_name = test.get("projectName", "")
            project_id = test.get("projectId")
            aggregate_status = test.get("status")
            expected_status = test.get("expectedStatus")
            results = test.get("results")
            if not isinstance(project_name, str) or len(project_name) > 200:
                raise ValueError
            if not isinstance(project_id, str) or len(project_id) > 200:
                raise ValueError
            project = project_name or "default"
            if aggregate_status not in _AGGREGATE_OUTCOMES:
                raise ValueError
            if expected_status not in _RESULT_STATUSES:
                raise ValueError
            if not isinstance(results, list):
                raise ValueError
            identity = (official_id, project_id)
            if identity in identities:
                raise ValueError
            identities.add(identity)
            if len(identities) > MAX_TESTS:
                raise ValueError
            subject = _location_subject(ancestry, suite_file, raw_spec, title, project)
            result_statuses: list[str] = []
            retry_count = 0
            observation_artifact_ids: list[str] = []
            for result in results:
                if not isinstance(result, dict):
                    raise ValueError
                status = result.get("status")
                retry = result.get("retry", 0)
                result_attachments = result.get("attachments", [])
                if status not in _RESULT_STATUSES:
                    raise ValueError
                if (
                    not isinstance(retry, int)
                    or isinstance(retry, bool)
                    or retry < 0
                    or retry > 100
                ):
                    raise ValueError
                if not isinstance(result_attachments, list):
                    raise ValueError
                result_statuses.append(status)
                retry_count = max(retry_count, retry)
                for attachment_ordinal, attachment in enumerate(
                    result_attachments, start=1
                ):
                    if not isinstance(attachment, dict):
                        raise ValueError
                    raw_path = attachment.get("path")
                    if raw_path is None and "body" in attachment:
                        name = attachment.get("name")
                        media_type = _valid_media_type(attachment.get("contentType"))
                        body = attachment.get("body")
                        if (
                            not isinstance(name, str)
                            or not name
                            or len(name) > 200
                            or media_type is None
                            or not isinstance(body, str)
                        ):
                            raise ValueError
                        debts.append(
                            _embedded_attachment_debt(
                                official_id,
                                project_id,
                                name,
                                attachment_ordinal,
                            )
                        )
                        continue
                    path = safe_path(raw_path)
                    media_type = attachment.get("contentType")
                    if path is None or not isinstance(media_type, str):
                        raise ValueError
                    if path in declared_paths or len(artifacts) >= MAX_ARTIFACTS:
                        raise ValueError
                    declared_paths.add(path)
                    supplied = attachments.get(path)
                    identity_digest = hashlib.sha256(
                        f"{official_id}\0{project_id}\0{path}".encode()
                    ).hexdigest()
                    attachment_id = artifact_id("PLAYWRIGHT", identity_digest)
                    observation_artifact_ids.append(attachment_id)
                    if supplied is None:
                        artifacts.append(
                            missing_artifact(
                                artifact_id_value=attachment_id,
                                relative_path=path,
                                media_type=media_type,
                                source_id=sealed_source.artifact_id,
                                producer=IMPORTER_NAME,
                                operation="declare-missing-supplied-playwright-attachment",
                            )
                        )
                        debts.append(
                            EvidenceDebtDraft(
                                code="ATTACHMENT_MISSING",
                                subject=path,
                                proof_needed="Supply the local Playwright attachment bytes.",
                                reason="The report named an attachment but no bytes were supplied.",
                                artifact_ids=(attachment_id,),
                            )
                        )
                    else:
                        artifacts.append(
                            available_artifact(
                                artifact_id_value=attachment_id,
                                relative_path=path,
                                media_type=media_type,
                                raw=supplied,
                                operation="seal-supplied-playwright-attachment",
                                source_ids=(sealed_source.artifact_id,),
                                producer=IMPORTER_NAME,
                            )
                        )
            attempts = ", ".join(result_statuses) if result_statuses else "none"
            outcome = _AGGREGATE_OUTCOMES[aggregate_status]
            observations.append(
                NormalizedObservation(
                    observation_id=_observation_id(official_id, project_id),
                    official_id=official_id,
                    project=project,
                    project_id=project_id,
                    subject=subject,
                    action="Import existing target-owned Playwright result",
                    observed_outcome=(
                        f"Playwright aggregate status {aggregate_status}; expected status "
                        f"{expected_status}; attempts: {attempts}."
                    ),
                    outcome=outcome,
                    retry_count=retry_count,
                    flaky=aggregate_status == "flaky",
                    artifact_ids=tuple(observation_artifact_ids),
                )
            )

    for path in sorted(set(attachments).difference(declared_paths)):
        debts.append(
            EvidenceDebtDraft(
                code="ATTACHMENT_UNDECLARED",
                subject=path,
                proof_needed="Reference the attachment from the Playwright report.",
                reason="Attachment bytes were supplied without a report declaration.",
                artifact_ids=(),
            )
        )

    return NormalizedEvidenceResult(
        source=EvidenceSourceIdentity(
            schema_name="playwright/json-reporter",
            relative_path=source_relative_path,
            producer_name="playwright",
            producer_version=_producer_version(report),
        ),
        mode=BrowserEvidenceMode.DETERMINISTIC_REPLAY,
        driver="existing-playwright-json-reporter",
        raw_bytes=raw,
        sha256=hashlib.sha256(raw).hexdigest(),
        byte_size=len(raw),
        source_artifact=sealed_source,
        artifacts=tuple(artifacts),
        observations=tuple(observations),
        limitations=(
            "Imported reporter output does not prove unconfigured browsers or paths.",
            "Shipworthy did not run Playwright and did not independently verify assertions.",
        ),
        evidence_debt=tuple(debts),
        finding_ids=finding_ids,
        target_fingerprint=None,
        path_intent=None,
        sealed_attachments=tuple(
            SealedAttachmentBytes(relative_path=path, raw_bytes=attachments[path])
            for path in sorted(attachments)
        ),
    )


def import_playwright_json_report(
    raw: bytes,
    *,
    source_relative_path: str,
    attachment_bytes: Mapping[str, bytes],
    finding_ids: tuple[str, ...] = (),
) -> NormalizedEvidenceResult:
    """Translate an existing JSON reporter payload; never invoke Playwright."""

    report = _parse_report(raw)
    path = safe_path(source_relative_path)
    attachments = validate_attachment_mapping(attachment_bytes)
    validated_finding_ids: tuple[str, ...] | None = None
    if (
        isinstance(finding_ids, tuple)
        and len(finding_ids) <= 128
        and len(finding_ids) == len(set(finding_ids))
    ):
        try:
            validated_finding_ids = tuple(
                _FINDING_ID_ADAPTER.validate_python(item, strict=True)
                for item in finding_ids
            )
        except (ValidationError, ValueError, TypeError):
            validated_finding_ids = None
    failed = (
        report is None
        or path is None
        or attachments is None
        or validated_finding_ids is None
    )
    result: NormalizedEvidenceResult | None = None
    if (
        report is not None
        and path is not None
        and attachments is not None
        and validated_finding_ids is not None
    ):
        try:
            result = _normalize(report, raw, path, attachments, validated_finding_ids)
        except (ValueError, TypeError, KeyError):
            failed = True
    if failed or result is None:
        raise PlaywrightReportImportError(
            "playwright report failed safe import validation"
        )
    return result


__all__ = (
    "MAX_ATTACHMENTS",
    "MAX_REPORT_BYTES",
    "MAX_SINGLE_ATTACHMENT_BYTES",
    "MAX_TOTAL_ATTACHMENT_BYTES",
    "PlaywrightReportImportError",
    "import_playwright_json_report",
)
