"""Strict-ledger SARIF adapter around the existing SARIF transform."""

from __future__ import annotations

import copy
import hashlib
import json
from typing import Dict, cast

from shipworthy.adapters.reporting.compat_loader import (
    ReportingTransformError,
    load_legacy_sarif,
)
from shipworthy.adapters.reporting.projection import ReportRow, ReportingProjection


_SARIF_SCHEMA = "https://json.schemastore.org/sarif-2.1.0.json"
_SARIF_VERSION = "2.1.0"
_INFORMATION_URI = "https://github.com/NeuraCerebra-AI/shipworthy"
_AUTOMATION_ID = "shipworthy-readiness"
_LEVEL = {
    "blocker": "error",
    "strong": "warning",
    "provisional": "note",
    "info": "note",
}
_RULE_NAME = {
    "blocker": "Blocker",
    "strong": "Strong signal",
    "provisional": "Provisional finding",
    "info": "Note",
}


def _fingerprint(record_kind: str, record_id: str) -> str:
    return hashlib.sha256(f"{record_kind}\x00{record_id}".encode("utf-8")).hexdigest()


def _expected_message(row: ReportRow) -> str:
    parts = [
        row.title,
        f"Impact: {row.summary}",
        f"Evidence: {row.evidence}",
    ]
    if row.fix is not None:
        parts.append(f"Fix: {row.fix}")
    parts.append(f"Verify: {row.verify}")
    return "  ".join(parts)


def _validate_rules(
    rules: object, projection: ReportingProjection
) -> list[Dict[str, object]]:
    if not isinstance(rules, list):
        raise ValueError
    expected_ids = sorted(
        {f"shipworthy/{row.compatibility_severity}" for row in projection.rows}
    )
    actual_ids = []
    reconstructed: list[Dict[str, object]] = []
    for rule in rules:
        if not isinstance(rule, dict):
            raise ValueError
        rule_id = rule.get("id")
        name = rule.get("name")
        description = rule.get("shortDescription")
        default = rule.get("defaultConfiguration")
        if (
            not isinstance(rule_id, str)
            or not isinstance(name, str)
            or not name
            or not isinstance(description, dict)
            or not isinstance(description.get("text"), str)
            or not isinstance(default, dict)
        ):
            raise ValueError
        severity = rule_id.removeprefix("shipworthy/")
        expected_name = _RULE_NAME.get(severity)
        if (
            rule_id not in expected_ids
            or name != expected_name
            or description.get("text") != f"Shipworthy {expected_name}"
            or default.get("level") != _LEVEL.get(severity)
        ):
            raise ValueError
        actual_ids.append(rule_id)
        reconstructed.append(
            {
                "defaultConfiguration": {"level": _LEVEL[severity]},
                "id": rule_id,
                "name": expected_name,
                "shortDescription": {"text": f"Shipworthy {expected_name}"},
            }
        )
    if actual_ids != expected_ids or len(actual_ids) != len(set(actual_ids)):
        raise ValueError
    return reconstructed


def _validate_result(result: object, row: ReportRow) -> Dict[str, object]:
    if not isinstance(result, dict):
        raise ValueError
    expected_rule_id = f"shipworthy/{row.compatibility_severity}"
    if (
        result.get("ruleId") != expected_rule_id
        or result.get("level") != _LEVEL[row.compatibility_severity]
    ):
        raise ValueError
    message = result.get("message")
    if not isinstance(message, dict) or message.get("text") != _expected_message(row):
        raise ValueError

    if row.location is None:
        if "locations" in result:
            raise ValueError
        locations = None
    else:
        expected_locations = [
            {"physicalLocation": {"artifactLocation": {"uri": row.location}}}
        ]
        if result.get("locations") != expected_locations:
            raise ValueError
        locations = expected_locations
    reconstructed: Dict[str, object] = {
        "level": _LEVEL[row.compatibility_severity],
        "message": {"text": _expected_message(row)},
        "ruleId": expected_rule_id,
    }
    if locations is not None:
        reconstructed["locations"] = locations
    return reconstructed


def _validated_copy(
    transformed: object, projection: ReportingProjection
) -> Dict[str, object]:
    if not isinstance(transformed, dict):
        raise ValueError
    document = copy.deepcopy(transformed)
    json.dumps(document, ensure_ascii=False, allow_nan=False)
    if (
        document.get("$schema") != _SARIF_SCHEMA
        or document.get("version") != _SARIF_VERSION
    ):
        raise ValueError
    runs = document.get("runs")
    if not isinstance(runs, list) or len(runs) != 1:
        raise ValueError
    run = runs[0]
    if not isinstance(run, dict):
        raise ValueError
    tool = run.get("tool")
    driver = tool.get("driver") if isinstance(tool, dict) else None
    if (
        not isinstance(driver, dict)
        or driver.get("name") != "Shipworthy"
        or driver.get("version") != projection.ledger.producer.version
        or driver.get("informationUri") != _INFORMATION_URI
    ):
        raise ValueError
    rules = _validate_rules(driver.get("rules"), projection)
    automation = run.get("automationDetails")
    if not isinstance(automation, dict) or automation.get("id") != _AUTOMATION_ID:
        raise ValueError

    results = run.get("results")
    if (
        not isinstance(results, list)
        or len(results) != projection.total_report_row_count
    ):
        raise ValueError
    reconstructed_results = [
        _validate_result(results[index], row)
        for index, row in enumerate(projection.rows)
    ]
    return {
        "$schema": _SARIF_SCHEMA,
        "runs": [
            {
                "automationDetails": {"id": _AUTOMATION_ID},
                "results": reconstructed_results,
                "tool": {
                    "driver": {
                        "informationUri": _INFORMATION_URI,
                        "name": "Shipworthy",
                        "rules": rules,
                        "version": projection.ledger.producer.version,
                    }
                },
            }
        ],
        "version": _SARIF_VERSION,
    }


def _enrich(
    document: Dict[str, object], projection: ReportingProjection
) -> Dict[str, object]:
    run = cast(dict[str, object], cast(list[object], document["runs"])[0])
    results = cast(list[dict[str, object]], run["results"])
    for row, result in zip(projection.rows, results):
        result["partialFingerprints"] = {
            "shipworthyRecordHash/v1": _fingerprint(row.record_kind, row.record_id)
        }
        result["properties"] = {
            "action": row.action,
            "canonical_confidence": row.confidence,
            "canonical_severity": row.severity,
            "proof": row.proof,
            "record_id": row.record_id,
            "record_kind": row.record_kind,
            "section": row.section,
        }
    run["properties"] = {
        "browser_evidence": list(projection.browser_evidence_data()),
        "completion_status": projection.completion_status,
        "counts": {
            "canonical_findings": projection.canonical_finding_count,
            "evidence_debt": projection.evidence_debt_count,
            "total_report_rows": projection.total_report_row_count,
        },
        "gate": {
            "blocking_finding_ids": list(projection.gate_blocking_finding_ids),
            "outcome": projection.gate_outcome,
            "policy": projection.gate_policy,
        },
        "readiness_disposition": projection.readiness_disposition,
    }
    json.dumps(document, ensure_ascii=False, allow_nan=False)
    return document


def _render(projection: ReportingProjection) -> Dict[str, object]:
    transform_module = load_legacy_sarif()
    transform = getattr(transform_module, "to_sarif", None)
    if not callable(transform):
        raise ValueError
    transformed = transform(projection.legacy_report_data())
    return _enrich(_validated_copy(transformed, projection), projection)


def render_readiness_sarif(projection: ReportingProjection) -> Dict[str, object]:
    if not isinstance(projection, ReportingProjection):
        raise TypeError("projection must be a ReportingProjection")
    failed = False
    document: Dict[str, object] | None = None
    try:
        document = _render(projection)
    except Exception:
        failed = True
    if failed or document is None:
        raise ReportingTransformError("readiness SARIF rendering failed")
    return document


def render_readiness_sarif_bytes(projection: ReportingProjection) -> bytes:
    failed = False
    payload: bytes | None = None
    try:
        document = render_readiness_sarif(projection)
        payload = (
            json.dumps(
                document,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
                allow_nan=False,
            )
            + "\n"
        ).encode("utf-8")
    except Exception:
        failed = True
    if failed or payload is None:
        raise ReportingTransformError("readiness SARIF rendering failed")
    return payload
