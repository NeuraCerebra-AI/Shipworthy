"""Side-effect-free normalization of a validated browser-evidence envelope."""

from __future__ import annotations

import hashlib
from typing import Mapping

from shipworthy.adapters.importers._evidence_normalization import (
    EvidenceDebtDraft,
    EvidenceSourceIdentity,
    NormalizedEvidenceResult,
    NormalizedObservation,
    SealedAttachmentBytes,
    available_artifact,
    missing_artifact,
    safe_path,
    source_artifact,
    validate_attachment_mapping,
)
from shipworthy.domain.browser_evidence import BrowserEvidenceEnvelope
from shipworthy.domain.contracts import (
    ContractValidationError,
    parse_browser_evidence_json,
)
from shipworthy.domain.entities import Artifact
from shipworthy.domain.enums import (
    ArtifactAvailability,
)


IMPORTER_NAME = "shipworthy-browser-evidence-importer"


class BrowserEvidenceImportError(ValueError):
    """A sanitized failure at the supplied browser-evidence boundary."""


def _normalize_envelope(
    envelope: BrowserEvidenceEnvelope,
    raw: bytes,
    source_relative_path: str,
    attachments: Mapping[str, bytes],
) -> NormalizedEvidenceResult:
    sealed_source = source_artifact(
        raw,
        source_relative_path,
        artifact_prefix="BROWSER-SOURCE",
        producer=IMPORTER_NAME,
        operation="seal-supplied-browser-evidence",
    )
    artifacts: list[Artifact] = []
    debts: list[EvidenceDebtDraft] = []
    declared_paths: set[str] = set()

    for declaration in envelope.artifacts:
        descriptor = declaration.descriptor
        path = descriptor.relative_path
        declared_paths.add(path)
        supplied = attachments.get(path)
        if supplied is None:
            artifact = missing_artifact(
                artifact_id_value=declaration.artifact_id,
                relative_path=path,
                media_type=descriptor.declared_media_type,
                source_id=sealed_source.artifact_id,
                producer=IMPORTER_NAME,
                operation="declare-missing-supplied-browser-attachment",
            )
            debts.append(
                EvidenceDebtDraft(
                    code="ATTACHMENT_MISSING",
                    subject=path,
                    proof_needed="Supply bytes matching the declared SHA-256 and size.",
                    reason="The envelope declared an attachment but no bytes were supplied.",
                    artifact_ids=(declaration.artifact_id,),
                )
            )
        else:
            digest_matches = hashlib.sha256(supplied).hexdigest() == descriptor.digest
            size_matches = len(supplied) == descriptor.byte_size
            availability = (
                ArtifactAvailability.AVAILABLE
                if digest_matches and size_matches
                else ArtifactAvailability.CORRUPT
            )
            artifact = available_artifact(
                artifact_id_value=declaration.artifact_id,
                relative_path=path,
                media_type=descriptor.declared_media_type,
                raw=supplied,
                operation="verify-supplied-browser-attachment",
                source_ids=(sealed_source.artifact_id,),
                producer=IMPORTER_NAME,
                availability=availability,
            )
            if not digest_matches:
                debts.append(
                    EvidenceDebtDraft(
                        code="ATTACHMENT_DIGEST_MISMATCH",
                        subject=path,
                        proof_needed="Supply bytes matching the declared SHA-256.",
                        reason="Supplied attachment bytes did not match the declared digest.",
                        artifact_ids=(declaration.artifact_id,),
                    )
                )
            elif not size_matches:
                debts.append(
                    EvidenceDebtDraft(
                        code="ATTACHMENT_SIZE_MISMATCH",
                        subject=path,
                        proof_needed="Supply bytes matching the declared byte size.",
                        reason="Supplied attachment bytes did not match the declared size.",
                        artifact_ids=(declaration.artifact_id,),
                    )
                )
        artifacts.append(artifact)

    for path in sorted(set(attachments).difference(declared_paths)):
        debts.append(
            EvidenceDebtDraft(
                code="ATTACHMENT_UNDECLARED",
                subject=path,
                proof_needed="Declare the attachment in the evidence envelope before use.",
                reason="Attachment bytes were supplied without a matching declaration.",
                artifact_ids=(),
            )
        )

    observations = tuple(
        NormalizedObservation(
            observation_id=step.step_id,
            official_id=None,
            project=None,
            project_id=None,
            subject=envelope.target.path_intent,
            action=step.action,
            observed_outcome=step.observed_outcome,
            outcome="observed",
            retry_count=0,
            flaky=False,
            artifact_ids=(),
        )
        for step in envelope.steps
    )
    limitations = tuple((*envelope.limitations, *envelope.not_proven)) + tuple(
        f"Evidence channel unavailable: {channel.value}."
        for channel in envelope.unavailable_channels
    )
    return NormalizedEvidenceResult(
        source=EvidenceSourceIdentity(
            schema_name=envelope.schema_name,
            relative_path=source_relative_path,
            producer_name=envelope.producer.name,
            producer_version=envelope.producer.version,
        ),
        mode=envelope.mode,
        driver=envelope.host.driver,
        raw_bytes=raw,
        sha256=hashlib.sha256(raw).hexdigest(),
        byte_size=len(raw),
        source_artifact=sealed_source,
        artifacts=tuple(artifacts),
        observations=observations,
        limitations=limitations,
        evidence_debt=tuple(debts),
        finding_ids=envelope.finding_ids,
        target_fingerprint=envelope.target.fingerprint,
        path_intent=envelope.target.path_intent,
        sealed_attachments=tuple(
            SealedAttachmentBytes(relative_path=path, raw_bytes=attachments[path])
            for path in sorted(attachments)
        ),
    )


def import_browser_evidence_json(
    raw: bytes,
    *,
    source_relative_path: str,
    attachment_bytes: Mapping[str, bytes],
) -> NormalizedEvidenceResult:
    """Normalize caller-supplied evidence bytes without reading declared paths."""

    path = safe_path(source_relative_path)
    attachments = validate_attachment_mapping(attachment_bytes)
    envelope: BrowserEvidenceEnvelope | None = None
    failed = path is None or attachments is None
    if not failed:
        try:
            envelope = parse_browser_evidence_json(raw)
        except (ContractValidationError, ValueError, TypeError):
            failed = True
    if failed or envelope is None or path is None or attachments is None:
        raise BrowserEvidenceImportError(
            "browser evidence failed safe import validation"
        )
    return _normalize_envelope(envelope, raw, path, attachments)


__all__ = (
    "BrowserEvidenceImportError",
    "EvidenceDebtDraft",
    "EvidenceSourceIdentity",
    "NormalizedEvidenceResult",
    "NormalizedObservation",
    "SealedAttachmentBytes",
    "import_browser_evidence_json",
)
