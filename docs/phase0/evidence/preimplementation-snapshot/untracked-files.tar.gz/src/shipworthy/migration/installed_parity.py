"""Read-only exact parity checks for explicitly marked synthetic skill fixtures."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import stat
from typing import Dict, Tuple


_MARKER = ".shipworthy-synthetic-fixture"
_MARKER_VALUE = b"shipworthy-parity-fixture-v1\n"
_CLIENT_SUFFIX = {
    "codex": (".codex", "skills"),
    "claude": (".claude", "skills"),
}
_CATEGORIES = (
    "skill_body",
    "script",
    "manifest",
    "metadata",
    "test",
    "reference_or_template",
)
_MAX_FILES = 10_000
_MAX_FILE_BYTES = 2_097_152
_MAX_TOTAL_BYTES = 67_108_864


class ParityFixtureError(ValueError):
    """The installed-copy target is not a bounded synthetic fixture."""


@dataclass(frozen=True, slots=True)
class ParityIssue:
    kind: str
    relative_path: str
    category: str
    repository_sha256: str | None
    installed_sha256: str | None


@dataclass(frozen=True, slots=True)
class InstalledParityReport:
    client: str
    status: str
    exact: bool
    file_count: int
    categories: Tuple[str, ...]
    category_counts: Tuple[Tuple[str, int], ...]
    issues: Tuple[ParityIssue, ...]
    repository_tree_sha256: str
    installed_tree_sha256: str

    def to_json_bytes(self) -> bytes:
        document = {
            "schema": "shipworthy-installed-parity/v1",
            "client": self.client,
            "status": self.status,
            "exact": self.exact,
            "file_count": self.file_count,
            "categories": list(self.categories),
            "category_counts": dict(self.category_counts),
            "issues": [
                {
                    "kind": row.kind,
                    "relative_path": row.relative_path,
                    "category": row.category,
                    "repository_sha256": row.repository_sha256,
                    "installed_sha256": row.installed_sha256,
                }
                for row in self.issues
            ],
            "repository_tree_sha256": self.repository_tree_sha256,
            "installed_tree_sha256": self.installed_tree_sha256,
        }
        return (json.dumps(document, sort_keys=True, indent=2) + "\n").encode("utf-8")


@dataclass(slots=True)
class _FixtureBinding:
    fixture: Path
    installed: Path
    fixture_fd: int
    marker_fd: int
    installed_fd: int
    marker_size: int
    marker_mtime_ns: int
    marker_ctime_ns: int

    def assert_current(self) -> None:
        try:
            fixture_path = os.stat(self.fixture, follow_symlinks=False)
            fixture_opened = os.fstat(self.fixture_fd)
            marker_path = os.stat(
                _MARKER, dir_fd=self.fixture_fd, follow_symlinks=False
            )
            marker_opened = os.fstat(self.marker_fd)
            marker_payload = os.pread(
                self.marker_fd, len(_MARKER_VALUE) + 1, 0
            )
            installed_path = os.stat(self.installed, follow_symlinks=False)
            installed_opened = os.fstat(self.installed_fd)
        except OSError:
            raise ParityFixtureError(
                "synthetic fixture changed during comparison"
            ) from None
        if (
            not stat.S_ISDIR(fixture_path.st_mode)
            or fixture_path.st_dev != fixture_opened.st_dev
            or fixture_path.st_ino != fixture_opened.st_ino
            or not stat.S_ISREG(marker_path.st_mode)
            or marker_path.st_dev != marker_opened.st_dev
            or marker_path.st_ino != marker_opened.st_ino
            or marker_opened.st_nlink != 1
            or marker_opened.st_size != self.marker_size
            or marker_opened.st_mtime_ns != self.marker_mtime_ns
            or marker_opened.st_ctime_ns != self.marker_ctime_ns
            or marker_payload != _MARKER_VALUE
            or not stat.S_ISDIR(installed_path.st_mode)
            or installed_path.st_dev != installed_opened.st_dev
            or installed_path.st_ino != installed_opened.st_ino
        ):
            raise ParityFixtureError(
                "synthetic fixture changed during comparison"
            )

    def close(self) -> None:
        first_error: OSError | None = None
        for descriptor in (self.installed_fd, self.marker_fd, self.fixture_fd):
            try:
                os.close(descriptor)
            except OSError as error:
                if first_error is None:
                    first_error = error
        if first_error is not None:
            raise first_error


def _inside(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def _validate_fixture(
    fixture_root: Path, installed_root: Path, client: str
) -> _FixtureBinding:
    if client not in _CLIENT_SUFFIX:
        raise ParityFixtureError("unsupported synthetic fixture client")
    if fixture_root.is_symlink() or installed_root.is_symlink():
        raise ParityFixtureError("synthetic fixture paths must not be symlinks")
    fixture = fixture_root.resolve()
    installed = installed_root.resolve()
    home = Path.home().resolve()
    if fixture == home or _inside(fixture, home / ".codex") or _inside(fixture, home / ".claude"):
        raise ParityFixtureError("real installed skill paths are not synthetic fixtures")
    if not _inside(installed, fixture):
        raise ParityFixtureError("installed skill root escaped synthetic fixture")
    expected = fixture.joinpath(*_CLIENT_SUFFIX[client]).resolve()
    if installed != expected:
        raise ParityFixtureError("installed skill root does not match synthetic fixture client")
    fixture_fd = marker_fd = installed_fd = None
    returned = False
    try:
        fixture_fd = os.open(
            fixture,
            os.O_RDONLY
            | getattr(os, "O_DIRECTORY", 0)
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_CLOEXEC", 0),
        )
        marker_fd = os.open(
            _MARKER,
            os.O_RDONLY
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_CLOEXEC", 0),
            dir_fd=fixture_fd,
        )
        marker_stat = os.fstat(marker_fd)
        if (
            not stat.S_ISREG(marker_stat.st_mode)
            or marker_stat.st_nlink != 1
            or marker_stat.st_size != len(_MARKER_VALUE)
            or _read_inventory_file(marker_fd, marker_stat.st_size) != _MARKER_VALUE
        ):
            raise ParityFixtureError(
                "installed-copy parity requires a marked synthetic fixture"
            )
        installed_fd = os.open(
            installed,
            os.O_RDONLY
            | getattr(os, "O_DIRECTORY", 0)
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_CLOEXEC", 0),
        )
        binding = _FixtureBinding(
            fixture,
            installed,
            fixture_fd,
            marker_fd,
            installed_fd,
            marker_stat.st_size,
            marker_stat.st_mtime_ns,
            marker_stat.st_ctime_ns,
        )
        binding.assert_current()
        returned = True
        return binding
    except ParityFixtureError:
        raise
    except OSError:
        raise ParityFixtureError(
            "installed-copy parity requires a marked synthetic fixture"
        ) from None
    finally:
        if not returned and "binding" in locals():
            binding.close()
        elif not returned:
            if installed_fd is not None:
                os.close(installed_fd)
            if marker_fd is not None:
                os.close(marker_fd)
            if fixture_fd is not None:
                os.close(fixture_fd)


def _inventory(root: Path) -> Dict[str, str]:
    if root.is_symlink():
        raise ParityFixtureError("skill inventory root is invalid")
    try:
        root_before = os.stat(root, follow_symlinks=False)
        root_fd = os.open(
            root,
            os.O_RDONLY
            | getattr(os, "O_DIRECTORY", 0)
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_CLOEXEC", 0),
        )
    except OSError:
        raise ParityFixtureError("skill inventory root is invalid") from None
    opened_root = os.fstat(root_fd)
    if (
        not stat.S_ISDIR(root_before.st_mode)
        or opened_root.st_dev != root_before.st_dev
        or opened_root.st_ino != root_before.st_ino
    ):
        os.close(root_fd)
        raise ParityFixtureError("skill inventory root changed during read")
    inventory: Dict[str, str] = {}
    count = 0
    total_bytes = 0

    def walk(directory_fd: int, parts: Tuple[str, ...]) -> None:
        nonlocal count, total_bytes
        try:
            with os.scandir(directory_fd) as iterator:
                entries = sorted(iterator, key=lambda row: row.name)
        except OSError:
            raise ParityFixtureError(
                "synthetic parity inventory changed during read"
            ) from None
        for entry in entries:
            if entry.is_symlink():
                raise ParityFixtureError(
                    "synthetic parity inventory contains a symlink"
                )
            relative_parts = (*parts, entry.name)
            relative_path = Path(*relative_parts)
            relative = relative_path.as_posix()
            try:
                row_stat = entry.stat(follow_symlinks=False)
            except OSError:
                raise ParityFixtureError(
                    "synthetic parity inventory changed during read"
                ) from None
            if stat.S_ISDIR(row_stat.st_mode):
                child_fd = _open_inventory_directory(directory_fd, entry.name)
                try:
                    child_stat = os.fstat(child_fd)
                    if (
                        child_stat.st_dev != row_stat.st_dev
                        or child_stat.st_ino != row_stat.st_ino
                    ):
                        raise ParityFixtureError(
                            "synthetic parity inventory changed during read"
                        )
                    walk(child_fd, relative_parts)
                    _assert_entry_binding(directory_fd, entry.name, child_fd)
                finally:
                    os.close(child_fd)
                continue
            if not stat.S_ISREG(row_stat.st_mode):
                raise ParityFixtureError(
                    "synthetic parity inventory contains an invalid entry"
                )
            count += 1
            if count > _MAX_FILES:
                raise ParityFixtureError(
                    "synthetic parity inventory exceeds file limit"
                )
            byte_size = row_stat.st_size
            if len(relative) > 512 or byte_size > _MAX_FILE_BYTES:
                raise ParityFixtureError(
                    "synthetic parity inventory exceeds resource limits"
                )
            total_bytes += byte_size
            if total_bytes > _MAX_TOTAL_BYTES:
                raise ParityFixtureError(
                    "synthetic parity inventory exceeds aggregate byte limit"
                )
            if (
                "__pycache__" in relative_path.parts
                or relative_path.suffix in {".pyc", ".pyo"}
            ):
                continue
            file_fd = _open_inventory_file(directory_fd, entry.name)
            try:
                opened = os.fstat(file_fd)
                if (
                    not stat.S_ISREG(opened.st_mode)
                    or opened.st_nlink != 1
                    or row_stat.st_nlink != 1
                    or opened.st_dev != row_stat.st_dev
                    or opened.st_ino != row_stat.st_ino
                    or opened.st_size != byte_size
                ):
                    raise ParityFixtureError(
                        "synthetic parity inventory changed during read"
                    )
                payload = _read_inventory_file(file_fd, byte_size)
                after = os.fstat(file_fd)
                if (
                    after.st_dev != opened.st_dev
                    or after.st_ino != opened.st_ino
                    or after.st_size != opened.st_size
                    or after.st_mtime_ns != opened.st_mtime_ns
                    or after.st_ctime_ns != opened.st_ctime_ns
                ):
                    raise ParityFixtureError(
                        "synthetic parity inventory changed during read"
                    )
                _assert_entry_binding(directory_fd, entry.name, file_fd)
            finally:
                os.close(file_fd)
            inventory[relative] = hashlib.sha256(payload).hexdigest()

    try:
        walk(root_fd, ())
        root_after = os.stat(root, follow_symlinks=False)
        opened_after = os.fstat(root_fd)
        if (
            root_after.st_dev != opened_after.st_dev
            or root_after.st_ino != opened_after.st_ino
        ):
            raise ParityFixtureError("skill inventory root changed during read")
        return inventory
    except OSError:
        raise ParityFixtureError(
            "synthetic parity inventory changed during read"
        ) from None
    finally:
        os.close(root_fd)


def _open_inventory_directory(parent_fd: int, name: str) -> int:
    try:
        return os.open(
            name,
            os.O_RDONLY
            | getattr(os, "O_DIRECTORY", 0)
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_CLOEXEC", 0),
            dir_fd=parent_fd,
        )
    except OSError:
        raise ParityFixtureError(
            "synthetic parity inventory changed during read"
        ) from None


def _open_inventory_file(parent_fd: int, name: str) -> int:
    try:
        return os.open(
            name,
            os.O_RDONLY
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_CLOEXEC", 0),
            dir_fd=parent_fd,
        )
    except OSError:
        raise ParityFixtureError(
            "synthetic parity inventory changed during read"
        ) from None


def _read_inventory_file(file_fd: int, expected_size: int) -> bytes:
    chunks = []
    remaining = expected_size + 1
    while remaining:
        try:
            chunk = os.read(file_fd, min(remaining, 1_048_576))
        except OSError:
            raise ParityFixtureError(
                "synthetic parity inventory changed during read"
            ) from None
        if not chunk:
            break
        chunks.append(chunk)
        remaining -= len(chunk)
    payload = b"".join(chunks)
    if len(payload) != expected_size:
        raise ParityFixtureError(
            "synthetic parity inventory changed during read"
        )
    return payload


def _assert_entry_binding(parent_fd: int, name: str, opened_fd: int) -> None:
    try:
        observed = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
        opened = os.fstat(opened_fd)
    except OSError:
        raise ParityFixtureError(
            "synthetic parity inventory changed during read"
        ) from None
    if observed.st_dev != opened.st_dev or observed.st_ino != opened.st_ino:
        raise ParityFixtureError(
            "synthetic parity inventory changed during read"
        )


def _category(relative_path: str) -> str:
    name = relative_path.rsplit("/", 1)[-1]
    parts = relative_path.split("/")
    if name == "SKILL.md":
        return "skill_body"
    if name == "shipworthy-compatibility.json":
        return "metadata"
    if name == "openai.yaml" or ".claude-plugin" in parts or name.endswith("manifest.json"):
        return "manifest"
    if name.startswith("test_") or "/tests/" in f"/{relative_path}/":
        return "test"
    if "scripts" in parts:
        return "script"
    return "reference_or_template"


def _tree_digest(inventory: Dict[str, str]) -> str:
    payload = "".join(f"{path}\0{inventory[path]}\n" for path in sorted(inventory)).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def validate_installed_copy_parity(
    *,
    repository_skills_root: Path,
    installed_skills_root: Path,
    synthetic_fixture_root: Path,
    client: str,
) -> InstalledParityReport:
    """Compare bytes without copying or modifying either tree."""

    binding = _validate_fixture(
        synthetic_fixture_root, installed_skills_root, client
    )
    try:
        repository = _inventory(repository_skills_root)
        binding.assert_current()
        installed = _inventory(installed_skills_root)
        binding.assert_current()
        if repository != _inventory(repository_skills_root):
            raise ParityFixtureError(
                "repository skill inventory changed during comparison"
            )
        binding.assert_current()
        if installed != _inventory(installed_skills_root):
            raise ParityFixtureError(
                "installed skill inventory changed during comparison"
            )
        binding.assert_current()
        issues = []
        for relative in sorted(set(repository) | set(installed)):
            expected = repository.get(relative)
            observed = installed.get(relative)
            if expected is None:
                kind = "stale"
            elif observed is None:
                kind = "missing"
            elif expected != observed:
                kind = "modified"
            else:
                continue
            issues.append(
                ParityIssue(kind, relative, _category(relative), expected, observed)
            )
        ordered = tuple(
            sorted(issues, key=lambda row: (row.kind, row.relative_path))
        )
        exact = not ordered
        category_counts = tuple(
            (category, sum(1 for path in repository if _category(path) == category))
            for category in _CATEGORIES
        )
        binding.assert_current()
        return InstalledParityReport(
            client,
            "exact" if exact else "drift",
            exact,
            len(repository),
            _CATEGORIES,
            category_counts,
            ordered,
            _tree_digest(repository),
            _tree_digest(installed),
        )
    finally:
        binding.close()
