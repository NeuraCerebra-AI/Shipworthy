"""Marker-gated upgrade, rollback, and uninstall rehearsals for temp fixtures."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile
from typing import Callable, Dict, Mapping, Tuple


_MARKER = ".shipworthy-lifecycle-sandbox"
_MARKER_VALUE = b"shipworthy-lifecycle-sandbox-v1\n"
_MAX_FILES = 10_000
_MAX_FILE_BYTES = 4_194_304
_MAX_SNAPSHOT_BYTES = 268_435_456
_MAX_TARGET_FILES = 1_000
_MAX_TARGET_TOTAL_BYTES = 67_108_864
_MAX_METADATA_BYTES = 65_536
_MAX_SKILL_INVENTORY_BYTES = 67_108_864
_SKILL_NAMES = frozenset(
    (
        "ship-readiness-orchestrator",
        "ship-deep-review",
        "ship-product-workflows",
        "ship-workflow-clarity",
    )
)


class LifecycleSandboxError(ValueError):
    """The requested rehearsal target is not a safe temporary sandbox."""


class LifecycleAuthorizationError(PermissionError):
    """A destructive rehearsal was requested without explicit authorization."""


class _InjectedFailure(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class BackupEntry:
    relative_path: str
    byte_size: int
    sha256: str


@dataclass(frozen=True, slots=True)
class UpgradeRehearsalResult:
    status: str
    from_version: str
    to_version: str
    backup_created: bool
    backup_entries: Tuple[BackupEntry, ...]
    state_before_sha256: str
    state_after_sha256: str
    rollback_attempted: bool
    rollback_exact: bool
    canonical_evidence_preserved: bool
    skills_preserved: bool

    def to_json_bytes(self) -> bytes:
        document = {
            "schema": "shipworthy-lifecycle-upgrade-rehearsal/v1",
            "status": self.status,
            "from_version": self.from_version,
            "to_version": self.to_version,
            "backup_created": self.backup_created,
            "backup_entries": [
                {
                    "relative_path": row.relative_path,
                    "byte_size": row.byte_size,
                    "sha256": row.sha256,
                }
                for row in self.backup_entries
            ],
            "state_before_sha256": self.state_before_sha256,
            "state_after_sha256": self.state_after_sha256,
            "rollback_attempted": self.rollback_attempted,
            "rollback_exact": self.rollback_exact,
            "canonical_evidence_preserved": self.canonical_evidence_preserved,
            "skills_preserved": self.skills_preserved,
        }
        return (json.dumps(document, sort_keys=True, indent=2) + "\n").encode("utf-8")


@dataclass(frozen=True, slots=True)
class UninstallRehearsalResult:
    status: str
    removed_roots: Tuple[str, ...]
    canonical_evidence_preserved: bool
    skill_only_operational: bool
    evidence_sha256: str
    skills_sha256: str

    def to_json_bytes(self) -> bytes:
        document = {
            "schema": "shipworthy-lifecycle-uninstall-rehearsal/v1",
            "status": self.status,
            "removed_roots": list(self.removed_roots),
            "canonical_evidence_preserved": self.canonical_evidence_preserved,
            "skill_only_operational": self.skill_only_operational,
            "evidence_sha256": self.evidence_sha256,
            "skills_sha256": self.skills_sha256,
        }
        return (json.dumps(document, sort_keys=True, indent=2) + "\n").encode("utf-8")


@dataclass(frozen=True, slots=True)
class _FileState:
    payload: bytes
    mode: int
    is_directory: bool


def _inside(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def _validated_root(root: Path) -> Path:
    resolved, root_fd, _ = _open_validated_root(root)
    os.close(root_fd)
    return resolved


def _assert_root_binding(root: Path, root_fd: int) -> None:
    try:
        observed = os.stat(root, follow_symlinks=False)
        opened = os.fstat(root_fd)
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox changed during operation"
        ) from None
    if (
        not stat.S_ISDIR(observed.st_mode)
        or observed.st_dev != opened.st_dev
        or observed.st_ino != opened.st_ino
    ):
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox changed during operation"
        )


def _open_validated_root(root: Path) -> Tuple[Path, int, Dict[str, _FileState]]:
    if root.is_symlink():
        raise LifecycleSandboxError(
            "lifecycle rehearsal requires a marked temporary sandbox"
        )
    resolved = root.resolve()
    temp = Path(tempfile.gettempdir()).resolve()
    if not _inside(resolved, temp):
        raise LifecycleSandboxError(
            "lifecycle rehearsal requires a marked temporary sandbox"
        )
    try:
        before_open = os.stat(resolved, follow_symlinks=False)
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal requires a marked temporary sandbox"
        ) from None
    if not stat.S_ISDIR(before_open.st_mode):
        raise LifecycleSandboxError(
            "lifecycle rehearsal requires a marked temporary sandbox"
        )
    root_fd = _open_root_fd(resolved)
    try:
        opened = os.fstat(root_fd)
        if (
            opened.st_dev != before_open.st_dev
            or opened.st_ino != before_open.st_ino
        ):
            raise LifecycleSandboxError(
                "lifecycle rehearsal sandbox changed during operation"
            )
        state = _snapshot_from_fd(root_fd)
        marker = state.get(_MARKER)
        if (
            marker is None
            or marker.is_directory
            or marker.payload != _MARKER_VALUE
        ):
            raise LifecycleSandboxError(
                "lifecycle rehearsal requires a marked temporary sandbox"
            )
        _assert_root_binding(resolved, root_fd)
        return resolved, root_fd, state
    except Exception:
        os.close(root_fd)
        raise


def _directory_open_flags() -> int:
    if not hasattr(os, "O_DIRECTORY") or not hasattr(os, "O_NOFOLLOW"):
        raise LifecycleSandboxError(
            "lifecycle rehearsal requires descriptor-safe filesystem support"
        )
    return os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)


def _file_open_flags() -> int:
    if not hasattr(os, "O_NOFOLLOW"):
        raise LifecycleSandboxError(
            "lifecycle rehearsal requires descriptor-safe filesystem support"
        )
    return os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)


def _open_root_fd(root: Path) -> int:
    try:
        return os.open(root, _directory_open_flags())
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox contains an invalid entry"
        ) from None


def _open_directory_at(parent_fd: int, name: str) -> int:
    try:
        return os.open(name, _directory_open_flags(), dir_fd=parent_fd)
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox contains an invalid directory"
        ) from None


def _open_file_readonly_at(parent_fd: int, name: str) -> int:
    try:
        return os.open(
            name,
            os.O_RDONLY | _file_open_flags(),
            dir_fd=parent_fd,
        )
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox contains an invalid entry"
        ) from None


def _read_file_descriptor(file_fd: int, expected_size: int) -> bytes:
    chunks = []
    remaining = expected_size + 1
    try:
        while remaining > 0:
            chunk = os.read(file_fd, min(remaining, 1_048_576))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox changed during snapshot"
        ) from None
    payload = b"".join(chunks)
    if len(payload) != expected_size:
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox changed during snapshot"
        )
    return payload


def _open_directory_path(parent_fd: int, parts: Tuple[str, ...]) -> int:
    current_fd = os.dup(parent_fd)
    try:
        for part in parts:
            next_fd = _open_directory_at(current_fd, part)
            os.close(current_fd)
            current_fd = next_fd
        return current_fd
    except Exception:
        os.close(current_fd)
        raise


def _ensure_directory_path(parent_fd: int, parts: Tuple[str, ...]) -> int:
    current_fd = os.dup(parent_fd)
    try:
        for part in parts:
            try:
                next_fd = _open_directory_at(current_fd, part)
            except LifecycleSandboxError:
                try:
                    os.mkdir(part, 0o755, dir_fd=current_fd)
                except FileExistsError:
                    pass
                except OSError:
                    raise LifecycleSandboxError(
                        "lifecycle rehearsal could not create a safe directory"
                    ) from None
                next_fd = _open_directory_at(current_fd, part)
            os.close(current_fd)
            current_fd = next_fd
        return current_fd
    except Exception:
        os.close(current_fd)
        raise


def _ensure_directory_chain(
    parent_fd: int, parts: Tuple[str, ...]
) -> Tuple[
    int,
    Tuple[Tuple[int, str, int], ...],
    Tuple[int, ...],
]:
    owned = [os.dup(parent_fd)]
    bindings = []
    current_fd = owned[0]
    try:
        for part in parts:
            try:
                next_fd = _open_directory_at(current_fd, part)
            except LifecycleSandboxError:
                try:
                    os.mkdir(part, 0o755, dir_fd=current_fd)
                except FileExistsError:
                    pass
                except OSError:
                    raise LifecycleSandboxError(
                        "lifecycle rehearsal could not create a safe directory"
                    ) from None
                next_fd = _open_directory_at(current_fd, part)
            bindings.append((current_fd, part, next_fd))
            owned.append(next_fd)
            current_fd = next_fd
        return current_fd, tuple(bindings), tuple(owned)
    except Exception:
        for descriptor in reversed(owned):
            os.close(descriptor)
        raise


def _assert_directory_chain(
    bindings: Tuple[Tuple[int, str, int], ...]
) -> None:
    for parent_fd, name, directory_fd in bindings:
        _assert_directory_binding(parent_fd, name, directory_fd)


def _write_file_at(
    parent_fd: int,
    relative: str,
    payload: bytes,
    *,
    mode: int = 0o644,
) -> None:
    parts = PurePosixPath(relative).parts
    if not parts:
        raise LifecycleSandboxError("target core files must use safe relative paths")
    directory_fd, directory_bindings, owned_descriptors = (
        _ensure_directory_chain(parent_fd, parts[:-1])
    )
    stage_name = None
    try:
        _assert_directory_chain(directory_bindings)
        directory_before = os.fstat(directory_fd)
        try:
            target_before = os.stat(
                parts[-1], dir_fd=directory_fd, follow_symlinks=False
            )
        except FileNotFoundError:
            target_before = None
        except OSError:
            raise LifecycleSandboxError(
                "lifecycle rehearsal refused an unsafe target file"
            ) from None
        if target_before is not None and (
            not stat.S_ISREG(target_before.st_mode)
            or target_before.st_nlink != 1
        ):
            raise LifecycleSandboxError(
                "lifecycle rehearsal refused an unsafe target file"
            )
        file_fd = None
        for attempt in range(128):
            candidate = f".shipworthy-stage-{os.getpid()}-{attempt:03d}"
            try:
                file_fd = os.open(
                    candidate,
                    os.O_WRONLY
                    | os.O_CREAT
                    | os.O_EXCL
                    | _file_open_flags(),
                    mode,
                    dir_fd=directory_fd,
                )
            except FileExistsError:
                continue
            except OSError:
                raise LifecycleSandboxError(
                    "lifecycle rehearsal could not create a safe staged file"
                ) from None
            stage_name = candidate
            break
        if file_fd is None or stage_name is None:
            raise LifecycleSandboxError(
                "lifecycle rehearsal could not create a safe staged file"
            )
        try:
            view = memoryview(payload)
            written = 0
            while written < len(view):
                count = os.write(file_fd, view[written:])
                if count <= 0:
                    raise LifecycleSandboxError(
                        "lifecycle rehearsal could not write target file"
                    )
                written += count
            os.fchmod(file_fd, mode)
            staged = os.fstat(file_fd)
            if not stat.S_ISREG(staged.st_mode) or staged.st_nlink != 1:
                raise LifecycleSandboxError(
                    "lifecycle rehearsal staged file is invalid"
                )
        finally:
            os.close(file_fd)
        directory_after = os.fstat(directory_fd)
        if (
            directory_after.st_dev != directory_before.st_dev
            or directory_after.st_ino != directory_before.st_ino
        ):
            raise LifecycleSandboxError(
                "lifecycle rehearsal target directory changed during mutation"
            )
        try:
            target_now = os.stat(
                parts[-1], dir_fd=directory_fd, follow_symlinks=False
            )
        except FileNotFoundError:
            target_now = None
        except OSError:
            raise LifecycleSandboxError(
                "lifecycle rehearsal target file changed during mutation"
            ) from None
        if (
            (target_before is None) != (target_now is None)
            or (
                target_before is not None
                and target_now is not None
                and (
                    target_now.st_dev != target_before.st_dev
                    or target_now.st_ino != target_before.st_ino
                    or target_now.st_nlink != 1
                    or not stat.S_ISREG(target_now.st_mode)
                )
            )
        ):
            raise LifecycleSandboxError(
                "lifecycle rehearsal target file changed during mutation"
            )
        _assert_directory_chain(directory_bindings)
        try:
            os.replace(
                stage_name,
                parts[-1],
                src_dir_fd=directory_fd,
                dst_dir_fd=directory_fd,
            )
        except OSError:
            raise LifecycleSandboxError(
                "lifecycle rehearsal could not replace target file safely"
            ) from None
        stage_name = None
        installed = os.stat(
            parts[-1], dir_fd=directory_fd, follow_symlinks=False
        )
        if (
            not stat.S_ISREG(installed.st_mode)
            or installed.st_nlink != 1
            or installed.st_dev != staged.st_dev
            or installed.st_ino != staged.st_ino
        ):
            raise LifecycleSandboxError(
                "lifecycle rehearsal could not verify replaced target file"
            )
        _assert_directory_chain(directory_bindings)
    finally:
        cleanup_failed = False
        if stage_name is not None:
            try:
                os.unlink(stage_name, dir_fd=directory_fd)
            except FileNotFoundError:
                pass
            except OSError:
                cleanup_failed = True
        for descriptor in reversed(owned_descriptors):
            os.close(descriptor)
        if cleanup_failed:
            raise LifecycleSandboxError(
                "lifecycle rehearsal could not clean staged file"
            ) from None


def _clear_directory(directory_fd: int) -> None:
    try:
        with os.scandir(directory_fd) as iterator:
            entries = sorted(iterator, key=lambda row: row.name)
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal rollback could not inspect sandbox"
        ) from None
    for entry in entries:
        try:
            row_stat = entry.stat(follow_symlinks=False)
            if stat.S_ISDIR(row_stat.st_mode):
                child_fd = _open_directory_at(directory_fd, entry.name)
                try:
                    _clear_directory(child_fd)
                finally:
                    os.close(child_fd)
                os.rmdir(entry.name, dir_fd=directory_fd)
            else:
                os.unlink(entry.name, dir_fd=directory_fd)
        except LifecycleSandboxError:
            raise
        except OSError:
            raise LifecycleSandboxError(
                "lifecycle rehearsal rollback refused an unsafe entry"
            ) from None


def _assert_directory_binding(parent_fd: int, name: str, directory_fd: int) -> None:
    try:
        observed = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
        opened = os.fstat(directory_fd)
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox changed during mutation"
        ) from None
    if (
        not stat.S_ISDIR(observed.st_mode)
        or observed.st_dev != opened.st_dev
        or observed.st_ino != opened.st_ino
    ):
        raise LifecycleSandboxError(
            "lifecycle rehearsal sandbox changed during mutation"
        )


def _lock_root_namespace(root_fd: int) -> int:
    original_mode = None
    try:
        original_mode = stat.S_IMODE(os.fstat(root_fd).st_mode)
        locked_mode = original_mode & ~0o222
        os.fchmod(root_fd, locked_mode)
        if stat.S_IMODE(os.fstat(root_fd).st_mode) != locked_mode:
            raise OSError
    except OSError:
        if original_mode is not None:
            try:
                os.fchmod(root_fd, original_mode)
            except OSError:
                pass
        raise LifecycleSandboxError(
            "lifecycle rehearsal could not lock the sandbox namespace"
        ) from None
    return original_mode


def _restore_root_mode(root_fd: int, original_mode: int) -> None:
    try:
        os.fchmod(root_fd, original_mode)
        if stat.S_IMODE(os.fstat(root_fd).st_mode) != original_mode:
            raise OSError
    except OSError:
        raise LifecycleSandboxError(
            "lifecycle rehearsal could not restore sandbox mode"
        ) from None


def _remove_directory_tree_at(
    parent_fd: int,
    name: str,
    *,
    unlock_for_remove: Callable[[], None],
) -> None:
    directory_fd = _open_directory_at(parent_fd, name)
    try:
        _assert_directory_binding(parent_fd, name, directory_fd)
        _clear_directory(directory_fd)
        _assert_directory_binding(parent_fd, name, directory_fd)
        unlock_for_remove()
        _assert_directory_binding(parent_fd, name, directory_fd)
        try:
            os.rmdir(name, dir_fd=parent_fd)
        except OSError:
            raise LifecycleSandboxError(
                "lifecycle rehearsal refused an unsafe core deletion"
            ) from None
    finally:
        os.close(directory_fd)


def _snapshot(root: Path) -> Dict[str, _FileState]:
    root_fd = _open_root_fd(root)
    try:
        return _snapshot_from_fd(root_fd)
    finally:
        os.close(root_fd)


def _snapshot_from_fd(root_fd: int) -> Dict[str, _FileState]:
    files: Dict[str, _FileState] = {}
    total_bytes = 0

    def walk(directory_fd: int, prefix: str) -> None:
        nonlocal total_bytes
        try:
            with os.scandir(directory_fd) as iterator:
                entries = sorted(iterator, key=lambda row: row.name)
        except OSError:
            raise LifecycleSandboxError(
                "lifecycle rehearsal sandbox contains an invalid entry"
            ) from None
        for entry in entries:
            if entry.is_symlink():
                raise LifecycleSandboxError(
                    "lifecycle rehearsal sandbox contains a symlink"
                )
            if len(files) >= _MAX_FILES:
                raise LifecycleSandboxError(
                    "lifecycle rehearsal sandbox contains an invalid entry"
                )
            relative = f"{prefix}/{entry.name}" if prefix else entry.name
            try:
                row_stat = entry.stat(follow_symlinks=False)
            except OSError:
                raise LifecycleSandboxError(
                    "lifecycle rehearsal sandbox contains an invalid entry"
                ) from None
            mode = stat.S_IMODE(row_stat.st_mode)
            if stat.S_ISDIR(row_stat.st_mode):
                child_fd = _open_directory_at(directory_fd, entry.name)
                files[relative] = _FileState(b"", mode, True)
                try:
                    walk(child_fd, relative)
                finally:
                    os.close(child_fd)
                continue
            if not stat.S_ISREG(row_stat.st_mode):
                raise LifecycleSandboxError(
                    "lifecycle rehearsal sandbox contains an invalid entry"
                )
            file_fd = _open_file_readonly_at(directory_fd, entry.name)
            try:
                opened = os.fstat(file_fd)
                if opened.st_nlink != 1 or row_stat.st_nlink != 1:
                    raise LifecycleSandboxError(
                        "lifecycle rehearsal sandbox contains a hard-linked file"
                    )
                if (
                    not stat.S_ISREG(opened.st_mode)
                    or opened.st_dev != row_stat.st_dev
                    or opened.st_ino != row_stat.st_ino
                    or opened.st_size > _MAX_FILE_BYTES
                ):
                    raise LifecycleSandboxError(
                        "lifecycle rehearsal sandbox exceeds resource limits"
                    )
                if total_bytes + opened.st_size > _MAX_SNAPSHOT_BYTES:
                    raise LifecycleSandboxError(
                        "lifecycle rehearsal sandbox exceeds aggregate byte limit"
                    )
                payload = _read_file_descriptor(file_fd, opened.st_size)
            finally:
                os.close(file_fd)
            total_bytes += len(payload)
            files[relative] = _FileState(payload, mode, False)

    walk(root_fd, "")
    return files


def _state_digest(state: Mapping[str, _FileState]) -> str:
    digest = hashlib.sha256()
    for relative in sorted(state):
        row = state[relative]
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(f"{row.mode:o}".encode("ascii"))
        digest.update(b"\0")
        digest.update(b"d" if row.is_directory else b"f")
        digest.update(b"\0")
        digest.update(hashlib.sha256(row.payload).digest())
    return digest.hexdigest()


def _subtree_digest(state: Mapping[str, _FileState], prefix: str) -> str:
    selected = {path: value for path, value in state.items() if path == prefix or path.startswith(prefix + "/")}
    return _state_digest(selected)


def _restore(root_fd: int, state: Mapping[str, _FileState]) -> None:
    _clear_directory(root_fd)
    directories = sorted(
        (relative for relative, row in state.items() if row.is_directory),
        key=lambda value: (value.count("/"), value),
    )
    for relative in directories:
        directory_fd = _ensure_directory_path(root_fd, PurePosixPath(relative).parts)
        os.close(directory_fd)
    for relative in sorted(state):
        row = state[relative]
        if row.is_directory:
            continue
        _write_file_at(root_fd, relative, row.payload, mode=row.mode)
    for relative in sorted(directories, key=lambda value: (-value.count("/"), value)):
        directory_fd = _open_directory_path(
            root_fd, PurePosixPath(relative).parts
        )
        try:
            os.fchmod(directory_fd, state[relative].mode)
        finally:
            os.close(directory_fd)


def _backup_entries(state: Mapping[str, _FileState]) -> Tuple[BackupEntry, ...]:
    selected = []
    for relative in sorted(state):
        if (
            not state[relative].is_directory
            and (relative == "core/metadata.json" or relative.startswith("core/data/"))
        ):
            payload = state[relative].payload
            selected.append(BackupEntry(relative, len(payload), hashlib.sha256(payload).hexdigest()))
    return tuple(selected)


def _version(value: object) -> Tuple[int, int, int] | None:
    if not isinstance(value, str):
        return None
    parts = value.split(".")
    if len(parts) != 3 or any(not part.isdigit() for part in parts):
        return None
    numbers = tuple(int(part) for part in parts)
    if any(number > 999_999 for number in numbers):
        return None
    return numbers  # type: ignore[return-value]


def _in_range(version: Tuple[int, int, int], expression: object) -> bool:
    if not isinstance(expression, str):
        return False
    clauses = expression.split(",")
    if not clauses or len(clauses) > 4:
        return False
    for clause in clauses:
        if clause.startswith(">="):
            expected = _version(clause[2:])
            if expected is None or version < expected:
                return False
        elif clause.startswith("<"):
            expected = _version(clause[1:])
            if expected is None or version >= expected:
                return False
        else:
            return False
    return True


def _metadata(root: Path) -> Dict[str, object]:
    """Compatibility helper for tests and callers inspecting a static tree."""

    state = _snapshot(root)
    return _metadata_from_state(state)


def _metadata_from_state(state: Mapping[str, _FileState]) -> Dict[str, object]:
    row = state.get("core/metadata.json")
    try:
        if row is None or row.is_directory:
            raise LifecycleSandboxError("core metadata is invalid")
        payload = row.payload
        if len(payload) > _MAX_METADATA_BYTES:
            raise LifecycleSandboxError("core metadata exceeds resource limits")
        parsed = json.loads(payload.decode("utf-8", errors="strict"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise LifecycleSandboxError("core metadata is invalid") from None
    if not isinstance(parsed, dict):
        raise LifecycleSandboxError("core metadata is invalid")
    return parsed


def _canonical_target_metadata(metadata: Mapping[str, object]) -> bytes:
    if not isinstance(metadata, Mapping):
        raise LifecycleSandboxError("upgrade metadata is invalid")
    try:
        payload = (
            json.dumps(
                dict(metadata),
                allow_nan=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeEncodeError):
        raise LifecycleSandboxError("upgrade metadata is invalid") from None
    if len(payload) > _MAX_METADATA_BYTES:
        raise LifecycleSandboxError("upgrade metadata exceeds resource limits")
    return payload


def _validated_target_files(files: Mapping[str, bytes]) -> Tuple[Tuple[str, bytes], ...]:
    if not isinstance(files, Mapping) or len(files) > _MAX_TARGET_FILES:
        raise LifecycleSandboxError("target core files exceed resource limits")
    rows = []
    total_bytes = 0
    for relative, payload in files.items():
        if not isinstance(relative, str) or not isinstance(payload, bytes):
            raise LifecycleSandboxError("target core files must use safe relative paths")
        pure = PurePosixPath(relative)
        if (
            pure.is_absolute()
            or not pure.parts
            or ".." in pure.parts
            or "." in pure.parts
            or "\\" in relative
            or "\x00" in relative
            or relative == "metadata.json"
            or len(relative) > 256
            or len(payload) > _MAX_FILE_BYTES
        ):
            raise LifecycleSandboxError("target core files must use safe relative paths")
        total_bytes += len(payload)
        if total_bytes > _MAX_TARGET_TOTAL_BYTES:
            raise LifecycleSandboxError(
                "target core files exceed aggregate byte limit"
            )
        rows.append((pure.as_posix(), payload))
    return tuple(sorted(rows))


def rehearse_upgrade(
    *,
    sandbox_root: Path,
    target_metadata: Mapping[str, object],
    target_core_files: Mapping[str, bytes],
    inject_failure_after_writes: int | None = None,
) -> UpgradeRehearsalResult:
    """Apply an upgrade only inside a marked temp fixture and roll back on failure."""

    metadata_bytes = _canonical_target_metadata(target_metadata)
    target_document = json.loads(metadata_bytes)
    files = _validated_target_files(target_core_files)
    root, root_fd, before = _open_validated_root(sandbox_root)
    before_digest = _state_digest(before)
    evidence_before = _subtree_digest(before, "evidence")
    skills_before = _subtree_digest(before, "skills")
    backups = _backup_entries(before)
    try:
        current_document = _metadata_from_state(before)
        current = current_document.get("package_version")
        current_version = _version(current)
        target_version_text = target_document.get("package_version")
        target_version = _version(target_version_text)
        compatible = target_document.get("compatible_upgrade_from")
        if (
            current_version is None
            or target_version is None
            or not isinstance(current, str)
            or not isinstance(target_version_text, str)
        ):
            raise LifecycleSandboxError("upgrade metadata is invalid")
    except Exception:
        os.close(root_fd)
        raise
    writes = (("metadata.json", metadata_bytes), *files)
    core_fd = None
    original_root_mode = None
    root_locked = False
    try:
        _assert_root_binding(root, root_fd)
        original_root_mode = _lock_root_namespace(root_fd)
        root_locked = True
        _assert_root_binding(root, root_fd)
        core_fd = _open_directory_at(root_fd, "core")
        _assert_directory_binding(root_fd, "core", core_fd)
        if target_version <= current_version:
            return UpgradeRehearsalResult(
                "not_upgrade", current, target_version_text, True, backups,
                before_digest, before_digest, False, False, True, True,
            )
        if not _in_range(current_version, compatible):
            return UpgradeRehearsalResult(
                "incompatible", current, target_version_text, True, backups,
                before_digest, before_digest, False, False, True, True,
            )
        for index, (relative, payload) in enumerate(writes, start=1):
            _assert_root_binding(root, root_fd)
            _assert_directory_binding(root_fd, "core", core_fd)
            _write_file_at(core_fd, relative, payload)
            _assert_directory_binding(root_fd, "core", core_fd)
            _assert_root_binding(root, root_fd)
            if inject_failure_after_writes is not None and index >= inject_failure_after_writes:
                raise _InjectedFailure
        after = _snapshot_from_fd(root_fd)
        _assert_root_binding(root, root_fd)
        _assert_directory_binding(root_fd, "core", core_fd)
        for relative, payload in writes:
            observed = after.get(f"core/{relative}")
            if (
                observed is None
                or observed.is_directory
                or observed.payload != payload
            ):
                raise LifecycleSandboxError(
                    "lifecycle rehearsal could not verify upgraded state"
                )
        evidence_preserved = _subtree_digest(after, "evidence") == evidence_before
        skills_preserved = _subtree_digest(after, "skills") == skills_before
        if not evidence_preserved or not skills_preserved:
            raise LifecycleSandboxError(
                "lifecycle rehearsal detected protected-state drift"
            )
        return UpgradeRehearsalResult(
            "upgraded", current, target_version_text, True, backups,
            before_digest, _state_digest(after), False, False,
            evidence_preserved, skills_preserved,
        )
    except Exception:
        if root_locked and original_root_mode is not None:
            _restore_root_mode(root_fd, original_root_mode)
            root_locked = False
        _restore(root_fd, before)
        after = _snapshot_from_fd(root_fd)
        after_digest = _state_digest(after)
        exact = after == before and after_digest == before_digest
        return UpgradeRehearsalResult(
            "rolled_back", current, target_version_text, True, backups,
            before_digest, after_digest, True, exact,
            _subtree_digest(after, "evidence") == evidence_before,
            _subtree_digest(after, "skills") == skills_before,
        )
    finally:
        try:
            if root_locked and original_root_mode is not None:
                _restore_root_mode(root_fd, original_root_mode)
        finally:
            try:
                if core_fd is not None:
                    os.close(core_fd)
            finally:
                os.close(root_fd)


def _skill_inventory(root: Path) -> Dict[str, str] | None:
    if not root.is_dir() or root.is_symlink():
        return None
    inventory: Dict[str, str] = {}
    total_bytes = 0
    for path in sorted(root.rglob("*")):
        if path.is_symlink() or (not path.is_file() and not path.is_dir()):
            return None
        if path.is_dir():
            continue
        byte_size = path.stat().st_size
        if len(inventory) >= _MAX_FILES or byte_size > _MAX_FILE_BYTES:
            return None
        total_bytes += byte_size
        if total_bytes > _MAX_SKILL_INVENTORY_BYTES:
            return None
        payload = path.read_bytes()
        if len(payload) != byte_size:
            return None
        inventory[path.relative_to(root).as_posix()] = hashlib.sha256(
            payload
        ).hexdigest()
    return inventory


def _skill_only_operational(
    root: Path, repository_skills_root: Path
) -> bool:
    skills = root / "skills"
    installed_inventory = _skill_inventory(skills)
    repository_inventory = _skill_inventory(repository_skills_root)
    if (
        installed_inventory is None
        or repository_inventory is None
        or installed_inventory != repository_inventory
    ):
        return False
    rows = [path for path in skills.iterdir() if path.is_dir() and not path.is_symlink()]
    if {path.name for path in rows} != _SKILL_NAMES:
        return False
    for path in rows:
        skill_body = path / "SKILL.md"
        sidecar = path / "shipworthy-compatibility.json"
        if (
            not skill_body.is_file()
            or skill_body.is_symlink()
            or not skill_body.read_bytes()
            or not sidecar.is_file()
            or sidecar.is_symlink()
        ):
            return False
        try:
            metadata = json.loads(sidecar.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            return False
        if (
            not isinstance(metadata, dict)
            or not isinstance(metadata.get("features"), dict)
            or metadata["features"].get("skill_only") is not True
        ):
            return False
    mandatory_tests = (
        "ship-readiness-orchestrator/scripts/test_render_report.py",
        "ship-readiness-orchestrator/scripts/test_skill_contract.py",
        "ship-readiness-orchestrator/scripts/test_to_sarif.py",
        "ship-readiness-orchestrator/scripts/test_make_bundle.py",
    )
    if not all(relative in installed_inventory for relative in mandatory_tests):
        return False
    return True


def rehearse_uninstall(
    *,
    sandbox_root: Path,
    authorize_destructive_delete: bool,
    repository_skills_root: Path,
) -> UninstallRehearsalResult:
    """Remove only the optional core after an explicit authorization bit."""

    if authorize_destructive_delete is not True:
        raise LifecycleAuthorizationError("optional-core deletion requires explicit authorization")
    root, root_fd, before = _open_validated_root(sandbox_root)
    evidence = _subtree_digest(before, "evidence")
    skills = _subtree_digest(before, "skills")
    original_root_mode = None
    root_locked = False
    try:
        operational_before = _skill_only_operational(
            root, repository_skills_root
        )
        _assert_root_binding(root, root_fd)
        if not operational_before:
            return UninstallRehearsalResult(
                "invalid_skills",
                (),
                True,
                False,
                evidence,
                skills,
            )
        original_root_mode = _lock_root_namespace(root_fd)
        root_locked = True
        _assert_root_binding(root, root_fd)
        try:
            core_stat = os.stat("core", dir_fd=root_fd, follow_symlinks=False)
        except FileNotFoundError:
            removed = ()
        except OSError:
            raise LifecycleSandboxError("optional core path is invalid") from None
        else:
            if not stat.S_ISDIR(core_stat.st_mode):
                raise LifecycleSandboxError("optional core path is invalid")
            if original_root_mode is None:
                raise LifecycleSandboxError(
                    "lifecycle rehearsal sandbox mode is unavailable"
                )
            mode_to_restore = original_root_mode

            def unlock_for_remove() -> None:
                nonlocal root_locked
                _restore_root_mode(root_fd, mode_to_restore)
                root_locked = False

            _remove_directory_tree_at(
                root_fd,
                "core",
                unlock_for_remove=unlock_for_remove,
            )
            removed = ("core",)
        after = _snapshot_from_fd(root_fd)
        _assert_root_binding(root, root_fd)
        evidence_after = _subtree_digest(after, "evidence")
        skills_after = _subtree_digest(after, "skills")
        operational = (
            skills_after == skills
            and _skill_only_operational(root, repository_skills_root)
        )
        _assert_root_binding(root, root_fd)
        return UninstallRehearsalResult(
            "skill_only" if operational else "invalid_skills",
            removed,
            evidence_after == evidence,
            operational,
            evidence_after,
            skills_after,
        )
    except Exception:
        if root_locked and original_root_mode is not None:
            _restore_root_mode(root_fd, original_root_mode)
            root_locked = False
        _restore(root_fd, before)
        raise
    finally:
        try:
            if root_locked and original_root_mode is not None:
                _restore_root_mode(root_fd, original_root_mode)
        finally:
            os.close(root_fd)
