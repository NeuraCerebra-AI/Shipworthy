"""Side-by-side legacy/v1 rendering with explicit structured evidence debt."""

from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
import hashlib
import html as html_module
import io
import json
from typing import Mapping, Tuple, cast
import zipfile

from shipworthy.adapters.importers.legacy_readiness import (
    LegacyReadinessImportResult,
    import_legacy_readiness_json,
)
from shipworthy.adapters.reporting.bundle import build_evidence_bundle
from shipworthy.adapters.reporting.compat_loader import (
    load_legacy_bundle,
    load_legacy_renderer,
    load_legacy_sarif,
)
from shipworthy.adapters.reporting.html import render_readiness_html
from shipworthy.adapters.reporting.projection import ReportingProjection
from shipworthy.adapters.reporting.sarif import (
    render_readiness_sarif,
    render_readiness_sarif_bytes,
)
from shipworthy.domain.contracts import parse_readiness_ledger_json


_CATEGORIES = (
    "finding_identity",
    "action",
    "proof",
    "gate",
    "counts",
    "html",
    "sarif",
    "bundle",
    "artifact_lineage",
)


@dataclass(frozen=True, slots=True)
class GateSnapshot:
    policy: str
    outcome: str
    blocking_identities: Tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CountSnapshot:
    canonical_findings: int
    evidence_debt: int
    total_report_rows: int
    section: Tuple[Tuple[str, int], ...]
    action: Tuple[Tuple[str, int], ...]


@dataclass(frozen=True, slots=True)
class BundleEntry:
    name: str
    byte_size: int
    sha256: str


@dataclass(frozen=True, slots=True)
class BundleSnapshot:
    contract: str
    bytes: bytes
    entries: Tuple[BundleEntry, ...]

    @property
    def entry_names(self) -> Tuple[str, ...]:
        return tuple(entry.name for entry in self.entries)


@dataclass(frozen=True, slots=True)
class HtmlSemantics:
    payload_sha256: str
    self_contained_document: bool
    canonical_finding_count: int
    total_report_rows: int
    finding_titles_present: Tuple[bool, ...]
    canonical_ids_present: Tuple[bool, ...]


@dataclass(frozen=True, slots=True)
class RenderSide:
    format_name: str
    source_bytes: bytes
    canonical_ledger_json: bytes
    finding_identity: Tuple[str, ...]
    finding_titles: Tuple[str, ...]
    record_kinds: Tuple[str, ...]
    actions: Tuple[str, ...]
    proofs: Tuple[str, ...]
    gate: GateSnapshot
    counts: CountSnapshot
    html: bytes
    html_semantics: HtmlSemantics
    sarif: Mapping[str, object]
    sarif_bytes: bytes
    bundle: BundleSnapshot
    artifact_lineage: Tuple[Tuple[str, str, str, str], ...]


@dataclass(frozen=True, slots=True)
class RenderDifference:
    category: str
    path: str
    legacy_value: str
    v1_value: str
    explained: bool
    explanation: str | None


@dataclass(frozen=True, slots=True)
class DualRenderEvidenceDebt:
    difference_id: str
    category: str
    path: str
    reason: str
    legacy_sha256: str
    v1_sha256: str


@dataclass(frozen=True, slots=True)
class DualRenderResult:
    source_schema_name: str
    activation: str
    skills_switched_to_core: bool
    mapping_debt_codes: Tuple[str, ...]
    legacy: RenderSide
    v1: RenderSide
    compared_categories: Tuple[str, ...]
    differences: Tuple[RenderDifference, ...]
    unexplained_evidence_debt: Tuple[DualRenderEvidenceDebt, ...]


def _canonical_json(value: object) -> bytes:
    if is_dataclass(value) and not isinstance(value, type):
        value = asdict(value)
    elif isinstance(value, tuple):
        value = [asdict(item) if is_dataclass(item) else item for item in value]
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def _digest(value: object) -> str:
    if isinstance(value, bytes):
        payload = value
    else:
        payload = _canonical_json(value)
    return hashlib.sha256(payload).hexdigest()


def _safe_display(value: object) -> str:
    payload = _canonical_json(value).decode("utf-8").rstrip("\n")
    if len(payload) <= 240:
        return payload
    return f"sha256:{hashlib.sha256(payload.encode('utf-8')).hexdigest()}"


def _bundle_snapshot(payload: bytes, *, contract: str) -> BundleSnapshot:
    rows = []
    with zipfile.ZipFile(io.BytesIO(payload), "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("dual-render bundle contains duplicate entries")
        for name in sorted(names):
            member = archive.read(name)
            rows.append(BundleEntry(name, len(member), hashlib.sha256(member).hexdigest()))
    return BundleSnapshot(contract, payload, tuple(rows))


def _html_semantics(
    payload: bytes,
    *,
    finding_ids: Tuple[str, ...],
    finding_titles: Tuple[str, ...],
    canonical_finding_count: int,
    total_report_rows: int,
) -> HtmlSemantics:
    try:
        text = payload.decode("utf-8", errors="strict")
    except UnicodeDecodeError:
        text = ""
    lowered = text.lower()
    return HtmlSemantics(
        hashlib.sha256(payload).hexdigest(),
        lowered.startswith("<!doctype html>")
        and "<script src=" not in lowered
        and "<link rel=" not in lowered,
        canonical_finding_count,
        total_report_rows,
        tuple(html_module.escape(title) in text for title in finding_titles),
        tuple(identity in text for identity in finding_ids),
    )


def _legacy_bundle(
    document: Mapping[str, object],
    raw: bytes,
    html: bytes,
    sarif_bytes: bytes,
    generated_at: str,
) -> bytes:
    payloads = {
        "ledger.json": raw,
        "readiness-report.html": html,
        "readiness.sarif": sarif_bytes,
    }
    module = load_legacy_bundle()
    builder = getattr(module, "build_bundle_bytes", None)
    if not callable(builder):
        raise ValueError("legacy bundle transform unavailable")
    output = builder(dict(document), payloads, generated_at)
    if not isinstance(output, bytes):
        raise ValueError("legacy bundle transform returned invalid bytes")
    return output


def _legacy_side(
    raw: bytes,
    document: Mapping[str, object],
    canonical_identities: Tuple[str, ...],
    generated_at: str,
) -> RenderSide:
    raw_findings = document.get("findings", [])
    if not isinstance(raw_findings, list):
        raw_findings = []
    findings = tuple(
        row for row in cast(list[object], raw_findings)
        if isinstance(row, dict)
    )
    titles = tuple(str(row.get("title", "(untitled finding)")) for row in findings)
    if len(canonical_identities) != len(findings):
        raise ValueError("canonical legacy finding identity mismatch")
    actions = tuple(str(row.get("action", "Prove")) for row in findings)
    proofs = tuple(str(row.get("proof", "Not tested")) for row in findings)
    sections = {}
    action_counts = {}
    for index, row in enumerate(findings):
        section = str(row.get("section", "not_proven_not_tested"))
        action = actions[index]
        sections[section] = sections.get(section, 0) + 1
        action_counts[action] = action_counts.get(action, 0) + 1

    sarif_module = load_legacy_sarif()
    renderer_module = load_legacy_renderer()
    sarif = sarif_module.to_sarif(dict(document))
    sarif_bytes = json.dumps(sarif, indent=2).encode("utf-8")
    html = renderer_module.render(dict(document)).encode("utf-8")
    bundle_bytes = _legacy_bundle(
        document, raw, html, sarif_bytes, generated_at
    )
    failures, _, require_confirmed = sarif_module.gate_failures(dict(document))
    gate = GateSnapshot(
        "confirmed_only" if require_confirmed else "configured_legacy",
        "fail" if failures else "pass",
        tuple(str(item) for item in failures),
    )
    return RenderSide(
        format_name="legacy/readiness-v0",
        source_bytes=raw,
        canonical_ledger_json=raw,
        finding_identity=canonical_identities,
        finding_titles=titles,
        record_kinds=tuple("finding" for _ in findings),
        actions=actions,
        proofs=proofs,
        gate=gate,
        counts=CountSnapshot(
            len(findings), 0, len(findings), tuple(sorted(sections.items())), tuple(sorted(action_counts.items()))
        ),
        html=html,
        html_semantics=_html_semantics(
            html,
            finding_ids=canonical_identities,
            finding_titles=titles,
            canonical_finding_count=len(findings),
            total_report_rows=len(findings),
        ),
        sarif=sarif,
        sarif_bytes=sarif_bytes,
        bundle=_bundle_snapshot(
            bundle_bytes,
            contract="legacy/make_bundle.py",
        ),
        artifact_lineage=(("legacy-source", "raw", "unversioned", hashlib.sha256(raw).hexdigest()),),
    )


def _v1_side(imported: LegacyReadinessImportResult) -> RenderSide:
    projection = ReportingProjection.from_ledger(imported.ledger)
    sarif = render_readiness_sarif(projection)
    sarif_bytes = render_readiness_sarif_bytes(projection)
    html = render_readiness_html(projection)
    bundle_bytes = build_evidence_bundle(projection, artifact_bytes={imported.ledger.artifacts[0].artifact_id: imported.raw_bytes})
    finding_ids = tuple(finding.finding_id for finding in imported.ledger.findings)
    finding_titles = tuple(finding.subject.title for finding in imported.ledger.findings)
    return RenderSide(
        format_name="shipworthy/readiness-ledger@1.0",
        source_bytes=imported.raw_bytes,
        canonical_ledger_json=projection.ledger_json,
        finding_identity=finding_ids,
        finding_titles=finding_titles,
        record_kinds=tuple(row.record_kind for row in projection.rows),
        actions=tuple(row.action for row in projection.rows),
        proofs=tuple(row.proof for row in projection.rows),
        gate=GateSnapshot(projection.gate_policy, projection.gate_outcome, projection.gate_blocking_finding_ids),
        counts=CountSnapshot(
            projection.canonical_finding_count,
            projection.evidence_debt_count,
            projection.total_report_row_count,
            projection.section_counts,
            projection.action_counts,
        ),
        html=html,
        html_semantics=_html_semantics(
            html,
            finding_ids=finding_ids,
            finding_titles=finding_titles,
            canonical_finding_count=projection.canonical_finding_count,
            total_report_rows=projection.total_report_row_count,
        ),
        sarif=sarif,
        sarif_bytes=sarif_bytes,
        bundle=_bundle_snapshot(
            bundle_bytes,
            contract="shipworthy/evidence-bundle-v1",
        ),
        artifact_lineage=tuple(
            (
                artifact.artifact_id,
                artifact.lineage.producer,
                artifact.lineage.operation,
                artifact.descriptor.digest or "",
            )
            for artifact in imported.ledger.artifacts
        ),
    )


def _difference(
    category: str,
    path: str,
    legacy_value: object,
    v1_value: object,
    *,
    explained: bool,
    explanation: str | None,
) -> RenderDifference:
    return RenderDifference(
        category,
        path,
        _safe_display(legacy_value),
        _safe_display(v1_value),
        explained,
        explanation if explained else None,
    )


def _debt(row: RenderDifference) -> DualRenderEvidenceDebt:
    seed = f"{row.category}\x00{row.path}\x00{row.legacy_value}\x00{row.v1_value}".encode("utf-8")
    return DualRenderEvidenceDebt(
        "DDR-" + hashlib.sha256(seed).hexdigest()[:20].upper(),
        row.category,
        row.path,
        "Unexplained dual-render difference requires review.",
        hashlib.sha256(row.legacy_value.encode("utf-8")).hexdigest(),
        hashlib.sha256(row.v1_value.encode("utf-8")).hexdigest(),
    )


def _recomputed_sides(
    legacy: RenderSide, v1: RenderSide
) -> Tuple[RenderSide, RenderSide, Tuple[str, ...]] | None:
    """Rebuild both sides from raw input and strict ledger provenance roots."""
    try:
        ledger = parse_readiness_ledger_json(v1.canonical_ledger_json)
        if not ledger.artifacts:
            return None
        imported = import_legacy_readiness_json(
            legacy.source_bytes,
            source_relative_path=ledger.artifacts[0].descriptor.relative_path,
            imported_at=ledger.generated_at,
        )
        expected_v1 = _v1_side(imported)
        document = json.loads(legacy.source_bytes.decode("utf-8"))
        if not isinstance(document, dict):
            return None
        expected_legacy = _legacy_side(
            legacy.source_bytes,
            document,
            tuple(finding.finding_id for finding in imported.ledger.findings),
            ledger.generated_at.removesuffix("Z") + "+00:00",
        )
        codes = tuple(sorted({row.code for row in imported.mapping_debt}))
        return expected_legacy, expected_v1, codes
    except Exception:
        return None


def compare_render_sides(
    legacy: RenderSide,
    v1: RenderSide,
    *,
    mapping_debt_codes: Tuple[str, ...],
) -> Tuple[Tuple[RenderDifference, ...], Tuple[DualRenderEvidenceDebt, ...]]:
    """Compare stable semantic surfaces; raw output bytes are retained, not equated."""

    differences = []
    recomputed = _recomputed_sides(legacy, v1)
    if recomputed is None:
        expected_legacy = None
        expected_v1 = None
        expected_codes: Tuple[str, ...] = ()
    else:
        expected_legacy, expected_v1, expected_codes = recomputed
    roots_valid = (
        expected_legacy is not None
        and expected_v1 is not None
        and expected_codes == tuple(sorted(mapping_debt_codes))
        and legacy.source_bytes == v1.source_bytes
        and v1.canonical_ledger_json == expected_v1.canonical_ledger_json
    )
    finding_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.finding_identity != expected_legacy.finding_identity
            or v1.finding_identity != expected_v1.finding_identity
        )
    )
    if legacy.finding_identity != v1.finding_identity or finding_drift:
        differences.append(_difference("finding_identity", "findings.identity", legacy.finding_identity, v1.finding_identity, explained=False, explanation=None))

    finding_count = (
        expected_legacy.counts.canonical_findings
        if expected_legacy is not None
        else legacy.counts.canonical_findings
    )
    expected_extra_debt = (
        expected_v1 is not None
        and all(
            kind == "evidence_debt"
            for kind in expected_v1.record_kinds[finding_count:]
        )
    )
    action_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.actions != expected_legacy.actions
            or v1.actions != expected_v1.actions
        )
    )
    action_explained = (
        roots_valid
        and expected_legacy.actions == expected_v1.actions[:finding_count]
        and expected_extra_debt
        and not action_drift
    )
    if legacy.actions != v1.actions or action_drift:
        mismatch = next((index for index, values in enumerate(zip(legacy.actions, v1.actions)) if values[0] != values[1]), None)
        path = f"findings[{mismatch}].action" if mismatch is not None else "report_rows.action"
        differences.append(_difference("action", path, legacy.actions, v1.actions, explained=action_explained, explanation="Strict-v1 mapping debt is rendered as additional Prove rows."))

    proof_prefix_explained = (
        expected_legacy is not None
        and expected_v1 is not None
        and len(expected_legacy.proofs) == finding_count
        and all(
            old == new
            or (
                old == "Confirmed"
                and new == "Partial"
                and "LEGACY_CONFIRMED_PROOF_DOWNGRADED" in mapping_debt_codes
            )
            for old, new in zip(
                expected_legacy.proofs, expected_v1.proofs[:finding_count]
            )
        )
    )
    proof_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.proofs != expected_legacy.proofs
            or v1.proofs != expected_v1.proofs
        )
    )
    proof_explained = (
        roots_valid
        and proof_prefix_explained
        and expected_extra_debt
        and not proof_drift
    )
    if legacy.proofs != v1.proofs or proof_drift:
        mismatch = next((index for index, values in enumerate(zip(legacy.proofs, v1.proofs)) if values[0] != values[1]), None)
        path = f"findings[{mismatch}].proof" if mismatch is not None else "report_rows.proof"
        differences.append(_difference("proof", path, legacy.proofs, v1.proofs, explained=proof_explained, explanation="Legacy proof is conservatively mapped and explicit mapping debt is rendered as additional rows."))

    gate_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.gate != expected_legacy.gate
            or v1.gate != expected_v1.gate
        )
    )
    if legacy.gate != v1.gate or gate_drift:
        gate_explained = (
            roots_valid
            and bool(mapping_debt_codes)
            and proof_prefix_explained
            and expected_legacy.gate.policy
            in ("confirmed_only", "configured_legacy")
            and expected_legacy.gate.outcome in ("fail", "pass")
            and expected_v1.gate.policy == "confirmed_only"
            and expected_v1.gate.outcome == "incomplete"
            and expected_v1.gate.blocking_identities == ()
            and not gate_drift
        )
        differences.append(_difference("gate", "gate", legacy.gate, v1.gate, explained=gate_explained, explanation="The strict confirmed-only gate cannot treat imported legacy claims as confirmed."))
    counts_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.counts != expected_legacy.counts
            or v1.counts != expected_v1.counts
        )
    )
    if legacy.counts != v1.counts or counts_drift:
        counts_explained = (
            roots_valid
            and expected_extra_debt
            and expected_legacy.counts.canonical_findings
            == len(expected_legacy.finding_identity)
            and expected_v1.counts.canonical_findings
            == len(expected_v1.finding_identity)
            and expected_v1.counts.evidence_debt
            == len(expected_v1.record_kinds) - finding_count
            and expected_v1.counts.total_report_rows
            == len(expected_v1.record_kinds)
            and sum(count for _, count in expected_v1.counts.action)
            == len(expected_v1.actions)
            and not counts_drift
        )
        differences.append(_difference("counts", "counts", legacy.counts, v1.counts, explained=counts_explained, explanation="Strict-v1 counts include explicit evidence-debt report rows."))
    html_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.html != expected_legacy.html
            or legacy.html_semantics != expected_legacy.html_semantics
            or v1.html != expected_v1.html
            or v1.html_semantics != expected_v1.html_semantics
        )
    )
    if legacy.html != v1.html or html_drift:
        legacy_html_root = expected_legacy or legacy
        v1_html_root = expected_v1 or v1
        observed_legacy_html = _html_semantics(
            legacy.html,
            finding_ids=legacy_html_root.finding_identity,
            finding_titles=legacy_html_root.finding_titles,
            canonical_finding_count=legacy_html_root.counts.canonical_findings,
            total_report_rows=legacy_html_root.counts.total_report_rows,
        )
        observed_v1_html = _html_semantics(
            v1.html,
            finding_ids=v1_html_root.finding_identity,
            finding_titles=v1_html_root.finding_titles,
            canonical_finding_count=v1_html_root.counts.canonical_findings,
            total_report_rows=v1_html_root.counts.total_report_rows,
        )
        html_explained = (
            roots_valid
            and expected_extra_debt
            and observed_legacy_html == legacy.html_semantics
            and observed_v1_html == v1.html_semantics
            and expected_legacy.html_semantics.self_contained_document
            and expected_v1.html_semantics.self_contained_document
            and all(expected_legacy.html_semantics.finding_titles_present)
            and all(expected_v1.html_semantics.finding_titles_present)
            and all(expected_v1.html_semantics.canonical_ids_present)
            and expected_v1.html_semantics.total_report_rows
            == expected_legacy.html_semantics.total_report_rows
            + expected_v1.counts.evidence_debt
            and not html_drift
        )
        differences.append(_difference("html", "readiness-report.html", _digest(legacy.html), _digest(v1.html), explained=html_explained, explanation="The v1 report renders canonical IDs and explicit evidence debt."))
    sarif_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.sarif != expected_legacy.sarif
            or legacy.sarif_bytes != expected_legacy.sarif_bytes
            or v1.sarif != expected_v1.sarif
            or v1.sarif_bytes != expected_v1.sarif_bytes
        )
    )
    if legacy.sarif != v1.sarif or sarif_drift:
        try:
            legacy_sarif_consistent = json.loads(legacy.sarif_bytes) == legacy.sarif
            v1_sarif_consistent = json.loads(v1.sarif_bytes) == v1.sarif
            legacy_results = cast(list[object], cast(list[object], legacy.sarif["runs"])[0]["results"])  # type: ignore[index]
            v1_run = cast(dict[str, object], cast(list[object], v1.sarif["runs"])[0])
            v1_results = cast(list[object], v1_run["results"])
            sarif_explained = (
                roots_valid
                and expected_extra_debt
                and legacy_sarif_consistent
                and v1_sarif_consistent
                and len(legacy_results) == finding_count
                and len(v1_results) == len(v1.record_kinds)
                and isinstance(v1_run.get("properties"), dict)
                and not sarif_drift
            )
        except (KeyError, IndexError, TypeError, json.JSONDecodeError):
            sarif_explained = False
        differences.append(_difference("sarif", "readiness.sarif", _digest(legacy.sarif), _digest(v1.sarif), explained=sarif_explained, explanation="V1 SARIF adds canonical record identity, gate state, and debt rows."))
    bundle_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.bundle != expected_legacy.bundle
            or v1.bundle != expected_v1.bundle
        )
    )
    if legacy.bundle.entries != v1.bundle.entries or bundle_drift:
        mandatory = {"ledger.json", "readiness-report.html", "readiness.sarif", "manifest.json", "README.txt"}
        try:
            bundle_explained = (
                roots_valid
                and _bundle_snapshot(
                    legacy.bundle.bytes, contract=legacy.bundle.contract
                ).entries
                == legacy.bundle.entries
                and _bundle_snapshot(
                    v1.bundle.bytes, contract=v1.bundle.contract
                ).entries
                == v1.bundle.entries
                and mandatory.issubset(legacy.bundle.entry_names)
                and mandatory.issubset(v1.bundle.entry_names)
                and legacy.canonical_ledger_json == legacy.source_bytes
                and v1.canonical_ledger_json != v1.source_bytes
                and not bundle_drift
            )
        except (ValueError, zipfile.BadZipFile):
            bundle_explained = False
        differences.append(_difference("bundle", "evidence-bundle", legacy.bundle.entries, v1.bundle.entries, explained=bundle_explained, explanation="The strict-v1 bundle preserves canonical ledger, lineage, and integrity metadata."))
    lineage_drift = (
        expected_legacy is not None
        and expected_v1 is not None
        and (
            legacy.artifact_lineage != expected_legacy.artifact_lineage
            or v1.artifact_lineage != expected_v1.artifact_lineage
        )
    )
    if legacy.artifact_lineage != v1.artifact_lineage or lineage_drift:
        lineage_explained = (
            roots_valid
            and expected_legacy.artifact_lineage[-1][-1]
            == expected_v1.artifact_lineage[-1][-1]
            and not lineage_drift
        )
        differences.append(_difference("artifact_lineage", "artifacts.lineage", legacy.artifact_lineage, v1.artifact_lineage, explained=lineage_explained, explanation="V1 adds exact importer lineage for the same raw legacy digest."))

    rows = tuple(differences)
    debt = tuple(_debt(row) for row in rows if not row.explained)
    return rows, debt


def dual_render_legacy_readiness(
    raw: bytes,
    *,
    source_relative_path: str,
    imported_at: str,
) -> DualRenderResult:
    imported = import_legacy_readiness_json(
        raw,
        source_relative_path=source_relative_path,
        imported_at=imported_at,
    )
    document = json.loads(raw.decode("utf-8"))
    if not isinstance(document, dict):
        raise ValueError("legacy readiness comparison requires an object")
    canonical_ids = tuple(finding.finding_id for finding in imported.ledger.findings)
    legacy_generated_at = imported_at.removesuffix("Z") + "+00:00"
    legacy = _legacy_side(
        raw, document, canonical_ids, legacy_generated_at
    )
    v1 = _v1_side(imported)
    codes = tuple(sorted({row.code for row in imported.mapping_debt}))
    differences, debt = compare_render_sides(legacy, v1, mapping_debt_codes=codes)
    return DualRenderResult(
        imported.source_schema_name,
        "comparison_only",
        False,
        codes,
        legacy,
        v1,
        _CATEGORIES,
        differences,
        debt,
    )
