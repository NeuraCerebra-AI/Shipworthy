"""Phase 0 migration and local rehearsal helpers.

These modules are internal comparison/rehearsal libraries.  Importing them does
not activate the optional core from any installed skill.
"""
