"""Deterministic Phase 0 compatibility, parity, and rollback receipts."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
from typing import Mapping

from shipworthy.adapters.importers.legacy_readiness import (
    import_legacy_readiness_json,
)
from shipworthy.adapters.reporting.projection import ReportingProjection
from shipworthy.migration.dual_render import RenderSide
from shipworthy.migration.dual_render import dual_render_legacy_readiness
from shipworthy.migration.installed_parity import validate_installed_copy_parity
from shipworthy.migration.lifecycle_rehearsal import (
    rehearse_uninstall,
    rehearse_upgrade,
)


IMPORTED_AT = "2026-07-12T12:34:56Z"
LEGACY_FIXTURE = "tests/fixtures/legacy/readiness-v0.json"
CONTRACT_PATHS = (
    "schemas/v1/readiness-ledger.schema.json",
    "schemas/v1/report-input.schema.json",
    LEGACY_FIXTURE,
    "tests/fixtures/v1/confirmed-blocker-ledger.json",
    "tests/fixtures/v1/hostile-path-ledger.json",
    "tests/fixtures/v1/incomplete-ledger.json",
    "tests/fixtures/v1/inconsistent-blocker-ledger.json",
    "tests/fixtures/v1/lying-green-ledger.json",
    "tests/fixtures/v1/mismatched-gate-ledger.json",
    "tests/fixtures/v1/missing-artifact-ledger.json",
    "tests/fixtures/v1/pure-action-first-report-input.json",
    "tests/fixtures/v1/unknown-enum-ledger.json",
)
SKILL_NAMES = (
    "ship-readiness-orchestrator",
    "ship-deep-review",
    "ship-product-workflows",
    "ship-workflow-clarity",
)
RECEIPT_NAMES = (
    "contract-hashes.json",
    "legacy-import.json",
    "dual-render.json",
    "installed-parity-codex.json",
    "installed-parity-claude.json",
    "upgrade-rollback.json",
    "uninstall-skill-only.json",
)
_MAX_CONTRACT_BYTES = 4 * 1024 * 1024
_MAX_SKILL_FILES = 10_000
_MAX_SKILL_ENTRIES = 20_000
_MAX_SKILL_DEPTH = 64
_MAX_SKILL_FILE_BYTES = 2 * 1024 * 1024
_MAX_SKILL_TOTAL_BYTES = 64 * 1024 * 1024
_MAX_SKILL_RELATIVE_PATH = 512
_MAX_RECEIPT_BYTES = 2 * 1024 * 1024
_MAX_TOTAL_RECEIPT_BYTES = 8 * 1024 * 1024
_READ_CHUNK_BYTES = 64 * 1024
_PARITY_MARKER = ".shipworthy-synthetic-fixture"
_PARITY_MARKER_VALUE = b"shipworthy-parity-fixture-v1\n"
_LIFECYCLE_MARKER = ".shipworthy-lifecycle-sandbox"
_LIFECYCLE_MARKER_VALUE = b"shipworthy-lifecycle-sandbox-v1\n"


class Phase0ReceiptError(ValueError):
    """A Phase 0 receipt could not be generated without overclaiming."""


@dataclass(frozen=True, slots=True)
class _SkillInventory:
    entries: tuple[tuple[str, bytes | None], ...]
    files: tuple[tuple[Path, os.stat_result], ...]
    directories: tuple[tuple[Path, os.stat_result], ...]


def _canonical(document: Mapping[str, object]) -> bytes:
    return (json.dumps(document, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _sha(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _stable_identity(row: os.stat_result) -> tuple[int, ...]:
    return (
        row.st_dev,
        row.st_ino,
        row.st_mode,
        row.st_nlink,
        row.st_size,
        row.st_mtime_ns,
        row.st_ctime_ns,
    )


def _read_stable_regular_file(
    path: Path,
    *,
    maximum_bytes: int,
    unavailable: str,
    invalid: str,
    unreadable: str,
    changed: str,
) -> bytes:
    try:
        before_path = path.lstat()
    except OSError as error:
        raise Phase0ReceiptError(unavailable) from error
    if (
        not stat.S_ISREG(before_path.st_mode)
        or before_path.st_nlink != 1
        or before_path.st_size > maximum_bytes
    ):
        raise Phase0ReceiptError(invalid)
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    flags |= getattr(os, "O_NONBLOCK", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError as error:
        raise Phase0ReceiptError(unreadable) from error
    try:
        before_fd = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before_fd.st_mode)
            or before_fd.st_nlink != 1
            or before_fd.st_size > maximum_bytes
            or _stable_identity(before_fd) != _stable_identity(before_path)
        ):
            raise Phase0ReceiptError(changed)
        chunks: list[bytes] = []
        observed = 0
        while True:
            chunk = os.read(
                descriptor,
                min(_READ_CHUNK_BYTES, maximum_bytes + 1 - observed),
            )
            if not chunk:
                break
            chunks.append(chunk)
            observed += len(chunk)
            if observed > maximum_bytes:
                raise Phase0ReceiptError(invalid)
        after_fd = os.fstat(descriptor)
    except Phase0ReceiptError:
        raise
    except OSError as error:
        raise Phase0ReceiptError(unreadable) from error
    finally:
        os.close(descriptor)
    try:
        after_path = path.lstat()
    except OSError as error:
        raise Phase0ReceiptError(changed) from error
    payload = b"".join(chunks)
    if (
        len(payload) != before_fd.st_size
        or _stable_identity(after_fd) != _stable_identity(before_fd)
        or _stable_identity(after_path) != _stable_identity(before_fd)
    ):
        raise Phase0ReceiptError(changed)
    return payload


def _read_contract_file(repository_root: Path, relative: str) -> bytes:
    return _read_stable_regular_file(
        repository_root / relative,
        maximum_bytes=_MAX_CONTRACT_BYTES,
        unavailable="allowlisted contract file is unavailable",
        invalid="allowlisted contract file is invalid",
        unreadable="allowlisted contract file is unreadable",
        changed="allowlisted contract file changed during read",
    )


def _contract_receipt(repository_root: Path) -> dict[str, object]:
    entries = []
    for relative in CONTRACT_PATHS:
        payload = _read_contract_file(repository_root, relative)
        entries.append(
            {
                "byte_size": len(payload),
                "kind": "schema" if relative.startswith("schemas/") else "fixture",
                "path": relative,
                "sha256": _sha(payload),
            }
        )
    return {
        "schema": "shipworthy-phase0-contract-hashes/v1",
        "scope": "repository_contract_fixtures",
        "git_commit_status": "not_asserted",
        "allowlist_policy": "explicit_paths_only",
        "entries": entries,
    }


def _legacy_receipts(
    repository_root: Path,
) -> tuple[dict[str, object], dict[str, object]]:
    raw = _read_contract_file(repository_root, LEGACY_FIXTURE)
    imported = import_legacy_readiness_json(
        raw,
        source_relative_path=LEGACY_FIXTURE,
        imported_at=IMPORTED_AT,
    )
    ledger = ReportingProjection.from_ledger(imported.ledger).ledger_json
    import_receipt: dict[str, object] = {
        "schema": "shipworthy-legacy-import-evidence/v1",
        "scope": "repository_fixture_comparison",
        "source": {
            "schema": imported.source_schema_name,
            "relative_path": imported.source_relative_path,
            "byte_size": imported.byte_size,
            "sha256": imported.sha256,
        },
        "imported_at": imported.imported_at,
        "canonical_ledger_sha256": _sha(ledger),
        "mapping_debt": [asdict(row) for row in imported.mapping_debt],
    }

    comparison = dual_render_legacy_readiness(
        raw,
        source_relative_path=LEGACY_FIXTURE,
        imported_at=IMPORTED_AT,
    )
    if comparison.unexplained_evidence_debt:
        raise Phase0ReceiptError(
            "selected dual-render fixture has unexplained evidence debt"
        )

    def side_receipt(side: RenderSide) -> dict[str, object]:
        # RenderSide is stable Phase 0 domain output; serialize only bounded
        # semantic snapshots and artifact digests, never the report bodies.
        return {
            "format": side.format_name,
            "ledger_sha256": _sha(side.canonical_ledger_json),
            "finding_identity": list(side.finding_identity),
            "actions": list(side.actions),
            "proofs": list(side.proofs),
            "gate": asdict(side.gate),
            "counts": asdict(side.counts),
            "html_sha256": _sha(side.html),
            "html_semantics": asdict(side.html_semantics),
            "sarif_sha256": _sha(side.sarif_bytes),
            "bundle_sha256": _sha(side.bundle.bytes),
            "bundle_entries": [
                asdict(entry) for entry in side.bundle.entries
            ],
            "artifact_lineage": [
                {
                    "artifact_id": row[0],
                    "producer": row[1],
                    "operation": row[2],
                    "sha256": row[3],
                }
                for row in side.artifact_lineage
            ],
        }

    dual_receipt: dict[str, object] = {
        "schema": "shipworthy-dual-render-evidence/v1",
        "scope": "repository_fixture_comparison",
        "source_schema": comparison.source_schema_name,
        "source_sha256": _sha(raw),
        "comparison_only": comparison.activation == "comparison_only",
        "skills_switched": comparison.skills_switched_to_core,
        "mapping_debt_codes": list(comparison.mapping_debt_codes),
        "compared_categories": list(comparison.compared_categories),
        "legacy": side_receipt(comparison.legacy),
        "v1": side_receipt(comparison.v1),
        "differences": [asdict(row) for row in comparison.differences],
        "unexplained_evidence_debt": [
            asdict(row) for row in comparison.unexplained_evidence_debt
        ],
    }
    if not dual_receipt["comparison_only"] or dual_receipt["skills_switched"]:
        raise Phase0ReceiptError("dual-render fixture violated comparison-only mode")
    return import_receipt, dual_receipt


def _skill_inventory(
    repository_skills: Path,
) -> _SkillInventory:
    snapshot: list[tuple[str, Path, os.stat_result | None]] = []
    directories: list[tuple[Path, os.stat_result]] = []
    entry_count = 0
    file_count = 0
    total_bytes = 0

    def visit(directory: Path, relative_directory: Path) -> None:
        nonlocal entry_count, file_count, total_bytes
        try:
            before = directory.lstat()
            if not stat.S_ISDIR(before.st_mode):
                raise Phase0ReceiptError("repository skill inventory is invalid")
            directories.append((directory, before))
            with os.scandir(directory) as iterator:
                entries = []
                for entry in iterator:
                    entries.append(entry)
                    if entry_count + len(entries) > _MAX_SKILL_ENTRIES:
                        raise Phase0ReceiptError(
                            "repository skill inventory exceeds resource limits"
                        )
                entries.sort(key=lambda row: row.name)
        except Phase0ReceiptError:
            raise
        except OSError as error:
            raise Phase0ReceiptError(
                "repository skill inventory is unreadable"
            ) from error
        for entry in entries:
            relative = relative_directory / entry.name
            rendered = relative.as_posix()
            entry_count += 1
            if (
                entry_count > _MAX_SKILL_ENTRIES
                or len(relative.parts) > _MAX_SKILL_DEPTH
                or len(rendered) > _MAX_SKILL_RELATIVE_PATH
            ):
                raise Phase0ReceiptError(
                    "repository skill inventory exceeds resource limits"
                )
            try:
                row = entry.stat(follow_symlinks=False)
            except OSError as error:
                raise Phase0ReceiptError(
                    "repository skill inventory is unreadable"
                ) from error
            if stat.S_ISLNK(row.st_mode):
                raise Phase0ReceiptError("repository skill inventory is invalid")
            if stat.S_ISDIR(row.st_mode):
                snapshot.append((rendered, Path(entry.path), None))
                visit(Path(entry.path), relative)
                continue
            if not stat.S_ISREG(row.st_mode) or row.st_nlink != 1:
                raise Phase0ReceiptError("repository skill inventory is invalid")
            file_count += 1
            if file_count > _MAX_SKILL_FILES:
                raise Phase0ReceiptError(
                    "repository skill inventory exceeds resource limits"
                )
            if row.st_size > _MAX_SKILL_FILE_BYTES:
                raise Phase0ReceiptError(
                    "repository skill inventory exceeds resource limits"
                )
            total_bytes += row.st_size
            if total_bytes > _MAX_SKILL_TOTAL_BYTES:
                raise Phase0ReceiptError(
                    "repository skill inventory exceeds resource limits"
                )
            snapshot.append((rendered, Path(entry.path), row))
        try:
            after = directory.lstat()
        except OSError as error:
            raise Phase0ReceiptError(
                "repository skill source changed during inventory"
            ) from error
        if _stable_identity(after) != _stable_identity(before):
            raise Phase0ReceiptError(
                "repository skill source changed during inventory"
            )

    try:
        root = repository_skills.lstat()
    except OSError as error:
        raise Phase0ReceiptError("repository skill copy is incomplete") from error
    if not stat.S_ISDIR(root.st_mode):
        raise Phase0ReceiptError("repository skill copy is incomplete")
    directories.append((repository_skills, root))
    for skill in SKILL_NAMES:
        entry_count += 1
        if entry_count > _MAX_SKILL_ENTRIES:
            raise Phase0ReceiptError(
                "repository skill inventory exceeds resource limits"
            )
        source = repository_skills / skill
        try:
            row = source.lstat()
        except OSError as error:
            raise Phase0ReceiptError("repository skill copy is incomplete") from error
        if not stat.S_ISDIR(row.st_mode):
            raise Phase0ReceiptError("repository skill copy is incomplete")
        snapshot.append((skill, source, None))
        visit(source, Path(skill))
    try:
        after_root = repository_skills.lstat()
    except OSError as error:
        raise Phase0ReceiptError(
            "repository skill source changed during inventory"
        ) from error
    if _stable_identity(after_root) != _stable_identity(root):
        raise Phase0ReceiptError("repository skill source changed during inventory")

    inventory: list[tuple[str, bytes | None]] = []
    for rendered, path, expected in snapshot:
        if expected is None:
            inventory.append((rendered, None))
            continue
        try:
            current = path.lstat()
        except OSError as error:
            raise Phase0ReceiptError(
                "repository skill source changed before read"
            ) from error
        if _stable_identity(current) != _stable_identity(expected):
            raise Phase0ReceiptError("repository skill source changed before read")
        payload = _read_stable_regular_file(
            path,
            maximum_bytes=_MAX_SKILL_FILE_BYTES,
            unavailable="repository skill inventory is unavailable",
            invalid="repository skill inventory is invalid",
            unreadable="repository skill inventory is unreadable",
            changed="repository skill source changed during read",
        )
        inventory.append((rendered, payload))
    result = _SkillInventory(
        entries=tuple(inventory),
        files=tuple(
            (path, expected)
            for _rendered, path, expected in snapshot
            if expected is not None
        ),
        directories=tuple(directories),
    )
    _validate_skill_source_snapshot(result)
    return result


def _validate_skill_source_snapshot(inventory: _SkillInventory) -> None:
    for path, expected in (*inventory.files, *inventory.directories):
        try:
            current = path.lstat()
        except OSError as error:
            raise Phase0ReceiptError(
                "repository skill source changed during read"
            ) from error
        if _stable_identity(current) != _stable_identity(expected):
            raise Phase0ReceiptError("repository skill source changed during read")


def _copy_repository_skills(repository_skills: Path, destination: Path) -> None:
    inventory = _skill_inventory(repository_skills)
    try:
        destination.mkdir(parents=True, mode=0o700)
        for relative, payload in inventory.entries:
            target = destination / relative
            if payload is None:
                target.mkdir(mode=0o700)
                continue
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
            flags |= getattr(os, "O_CLOEXEC", 0)
            flags |= getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(target, flags, 0o600)
            try:
                view = memoryview(payload)
                offset = 0
                while offset < len(view):
                    count = os.write(descriptor, view[offset:])
                    if count <= 0:
                        raise OSError("repository skill copy write failed")
                    offset += count
            finally:
                os.close(descriptor)
        _validate_skill_source_snapshot(inventory)
    except Phase0ReceiptError:
        raise
    except OSError as error:
        raise Phase0ReceiptError("repository skill copy failed") from error


def _parity_receipt(
    repository_skills: Path,
    *,
    temporary_root: Path,
    client: str,
) -> dict[str, object]:
    fixture = temporary_root / f"parity-{client}"
    fixture.mkdir()
    (fixture / _PARITY_MARKER).write_bytes(_PARITY_MARKER_VALUE)
    installed = fixture / f".{client}" / "skills"
    installed.parent.mkdir()
    _copy_repository_skills(repository_skills, installed)
    report = validate_installed_copy_parity(
        repository_skills_root=repository_skills,
        installed_skills_root=installed,
        synthetic_fixture_root=fixture,
        client=client,
    )
    document = json.loads(report.to_json_bytes())
    document.update(
        {
            "scope": "synthetic_temporary_fixture",
            "real_installed_copy_checked": False,
        }
    )
    if (
        report.status != "exact"
        or not report.exact
        or report.issues
        or report.repository_tree_sha256 != report.installed_tree_sha256
    ):
        raise Phase0ReceiptError("synthetic installed-copy parity is not exact")
    return document


def _lifecycle_root(temporary_root: Path, name: str, repository_skills: Path) -> Path:
    root = temporary_root / name
    root.mkdir()
    (root / _LIFECYCLE_MARKER).write_bytes(_LIFECYCLE_MARKER_VALUE)
    (root / "core/package").mkdir(parents=True)
    (root / "core/data").mkdir()
    (root / "core/metadata.json").write_bytes(b'{"package_version":"0.1.0"}\n')
    (root / "core/package/module.py").write_bytes(b"VERSION = '0.1.0'\n")
    (root / "core/data/local-state.bin").write_bytes(b"core-local-state-v1\n")
    _copy_repository_skills(repository_skills, root / "skills")
    (root / "evidence/canonical/artifacts").mkdir(parents=True)
    (root / "evidence/canonical/ledger.json").write_bytes(
        b'{"evidence":"canonical"}\n'
    )
    (root / "evidence/canonical/artifacts/proof.txt").write_bytes(b"proof bytes\n")
    return root


def _lifecycle_receipts(
    repository_skills: Path, *, temporary_root: Path
) -> tuple[dict[str, object], dict[str, object]]:
    upgrade_root = _lifecycle_root(
        temporary_root, "upgrade-rollback", repository_skills
    )
    upgrade = rehearse_upgrade(
        sandbox_root=upgrade_root,
        target_metadata={
            "package_version": "0.2.0",
            "compatible_upgrade_from": ">=0.1.0,<0.2.0",
        },
        target_core_files={"package/module.py": b"VERSION = '0.2.0'\n"},
        inject_failure_after_writes=2,
    )
    rollback = json.loads(upgrade.to_json_bytes())
    rollback.update(
        {
            "scope": "synthetic_temporary_fixture",
            "failure_injected": True,
        }
    )
    if not (
        upgrade.status == "rolled_back"
        and upgrade.backup_created
        and upgrade.rollback_attempted
        and upgrade.rollback_exact
        and upgrade.state_before_sha256 == upgrade.state_after_sha256
        and upgrade.canonical_evidence_preserved
        and upgrade.skills_preserved
    ):
        raise Phase0ReceiptError("synthetic upgrade rollback was not exact")

    incompatible_root = _lifecycle_root(
        temporary_root, "incompatible-upgrade", repository_skills
    )
    incompatible_result = rehearse_upgrade(
        sandbox_root=incompatible_root,
        target_metadata={
            "package_version": "0.2.0",
            "compatible_upgrade_from": ">=0.2.0,<0.3.0",
        },
        target_core_files={"package/module.py": b"VERSION = '0.2.0'\n"},
    )
    if not (
        incompatible_result.status == "incompatible"
        and incompatible_result.backup_created
        and not incompatible_result.rollback_attempted
        and incompatible_result.state_before_sha256
        == incompatible_result.state_after_sha256
    ):
        raise Phase0ReceiptError("synthetic incompatible upgrade was not rejected")
    rollback["incompatible_upgrade_check"] = json.loads(
        incompatible_result.to_json_bytes()
    )

    uninstall_root = _lifecycle_root(
        temporary_root, "uninstall-skill-only", repository_skills
    )
    uninstall_result = rehearse_uninstall(
        sandbox_root=uninstall_root,
        authorize_destructive_delete=True,
        repository_skills_root=repository_skills,
    )
    uninstall = json.loads(uninstall_result.to_json_bytes())
    uninstall.update(
        {
            "scope": "synthetic_temporary_fixture",
            "authorization": {
                "explicit": True,
                "scope": "temporary_fixture_optional_core_only",
            },
        }
    )
    if not (
        uninstall_result.status == "skill_only"
        and uninstall_result.removed_roots == ("core",)
        and uninstall_result.canonical_evidence_preserved
        and uninstall_result.skill_only_operational
    ):
        raise Phase0ReceiptError("synthetic uninstall did not preserve skill-only mode")
    return rollback, uninstall


def _validate_output(output_dir: Path) -> Path:
    if output_dir.name != "phase0" or output_dir.parent.parent.name != ".staging":
        raise Phase0ReceiptError("receipt output must be a Phase 0 staging path")
    parent = output_dir.parent
    if not parent.is_dir() or parent.is_symlink():
        raise Phase0ReceiptError("receipt staging parent is invalid")
    if output_dir.exists() or output_dir.is_symlink():
        raise Phase0ReceiptError("Phase 0 receipt directory already exists")
    return output_dir


def _write_receipts(
    output_dir: Path, documents: Mapping[str, Mapping[str, object]]
) -> dict[str, Path]:
    if set(documents) != set(RECEIPT_NAMES):
        raise Phase0ReceiptError("Phase 0 receipt set is incomplete")
    payloads = {name: _canonical(documents[name]) for name in RECEIPT_NAMES}
    if any(len(payload) > _MAX_RECEIPT_BYTES for payload in payloads.values()):
        raise Phase0ReceiptError("Phase 0 receipt exceeds per-file limit")
    if sum(map(len, payloads.values())) > _MAX_TOTAL_RECEIPT_BYTES:
        raise Phase0ReceiptError("Phase 0 receipts exceed aggregate limit")
    try:
        os.mkdir(output_dir, mode=0o700)
        directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        directory_flags |= getattr(os, "O_NOFOLLOW", 0)
        directory_fd = os.open(output_dir, directory_flags)
    except OSError as error:
        raise Phase0ReceiptError("Phase 0 receipt directory creation failed") from error
    written: dict[str, Path] = {}
    try:
        for name in RECEIPT_NAMES:
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
            flags |= getattr(os, "O_NOFOLLOW", 0)
            file_descriptor = os.open(name, flags, 0o600, dir_fd=directory_fd)
            try:
                payload = payloads[name]
                view = memoryview(payload)
                offset = 0
                while offset < len(view):
                    count = os.write(file_descriptor, view[offset:])
                    if count <= 0:
                        raise OSError("receipt write failed")
                    offset += count
                os.fsync(file_descriptor)
            finally:
                os.close(file_descriptor)
            written[name] = output_dir / name
        os.fsync(directory_fd)
    except OSError as error:
        raise Phase0ReceiptError("Phase 0 receipt write failed") from error
    finally:
        os.close(directory_fd)
    return written


def generate_phase0_receipts(
    *, repository_root: Path, output_dir: Path
) -> dict[str, Path]:
    """Generate all receipts, then create an exclusive Phase 0 evidence directory."""

    repository = repository_root.resolve()
    if not repository.is_dir():
        raise Phase0ReceiptError("repository root is invalid")
    destination = _validate_output(output_dir)
    repository_skills = repository / "plugins/shipworthy/skills"
    contract = _contract_receipt(repository)
    imported, dual = _legacy_receipts(repository)
    try:
        with tempfile.TemporaryDirectory(prefix="shipworthy-phase0-") as temporary:
            temporary_root = Path(temporary)
            codex = _parity_receipt(
                repository_skills, temporary_root=temporary_root, client="codex"
            )
            claude = _parity_receipt(
                repository_skills, temporary_root=temporary_root, client="claude"
            )
            rollback, uninstall = _lifecycle_receipts(
                repository_skills, temporary_root=temporary_root
            )
    except Phase0ReceiptError:
        raise
    except Exception as error:
        raise Phase0ReceiptError("synthetic Phase 0 rehearsal failed") from error
    return _write_receipts(
        destination,
        {
            "contract-hashes.json": contract,
            "legacy-import.json": imported,
            "dual-render.json": dual,
            "installed-parity-codex.json": codex,
            "installed-parity-claude.json": claude,
            "upgrade-rollback.json": rollback,
            "uninstall-skill-only.json": uninstall,
        },
    )


__all__ = [
    "CONTRACT_PATHS",
    "Phase0ReceiptError",
    "generate_phase0_receipts",
]
