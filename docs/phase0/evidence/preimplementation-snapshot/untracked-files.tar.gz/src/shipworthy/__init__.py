"""Shipworthy's local, evidence-backed product core."""

__version__ = "0.1.0"
