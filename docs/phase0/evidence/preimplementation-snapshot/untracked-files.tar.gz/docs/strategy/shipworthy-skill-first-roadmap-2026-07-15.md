# Shipworthy skill-first roadmap

**Status:** Active product direction. Tasks 1-6 of the lean host-native plan are
implemented and locally verified in the feature worktree. Independent
specification and quality reviews are approved. This document does not
claim publication, merge, or availability in `origin/main`.

## Product direction

Shipworthy stays a skill-first evidence and judgment system for Codex and
Claude. The four existing skills remain the visible workflow. The optional core
accepts bounded evidence, preserves provenance and uncertainty, and renders one
canonical v1 ledger to the mandatory HTML report, SARIF, and evidence bundle.

The host owns browser and process execution:

- Codex/Claude native browser or computer-use capabilities are the default for
  adaptive exploration, discovery, state interpretation, and human-style path
  walking.
- A target repository's existing Playwright setup is optional deterministic
  evidence for exact replay, assertions, isolated contexts, traces,
  cross-browser checks, and CI regression proof.
- Shipworthy imports evidence from either route. It does not install
  Playwright, launch a browser, provide a browser DSL, or silently modify the
  target application to manufacture evidence.
- A screenshot proves the visible state at capture time, not an entire
  workflow. Neither native nor Playwright evidence may inflate proof, promote a
  finding to confirmed, or approve an independent-verifier gate by itself.

## Lean milestone delivered locally

The current feature worktree contains the following implementation. These
statements describe local source and test coverage, not publication.

1. **Native-browser-first routing.** The orchestrator and product-workflow
   contracts explain when to use adaptive host-native browsing and when to
   reuse deterministic Playwright evidence. Existing skill names, triggers,
   skill-only operation, and the mandatory HTML-report contract remain in
   place.
2. **Bounded browser-evidence envelope.** A strict v1 model and JSON Schema
   cover producer, host, driver, mode, target, ordered observations, local
   artifact descriptors, unavailable channels, limitations, `not_proven`, and
   optional existing finding IDs. Parsing is bounded and side-effect free.
3. **Conservative evidence adapters.** Native browser envelopes and supplied
   Playwright JSON reporter output normalize into one immutable evidence
   result. Raw inputs and supplied attachments are sealed; corrupt, absent, or
   undeclared attachments remain explicit evidence debt. The adapters do not
   invent findings or readiness dispositions.
4. **Canonical attachment and reporting.** A pure attachment transform connects
   normalized evidence only to existing finding IDs, rejects collisions and
   forged provenance, and preserves canonical finding and gate fields. HTML,
   SARIF, and the bundle manifest expose mode, driver, producer, lineage,
   attachment availability, digest, limitations, and debt.
5. **Host-owned execution recipes.** The skills first discover target-owned
   tests, then use host-native browsing for adaptive paths, then reuse existing
   Playwright for deterministic replay when useful. Proposing a new
   target-owned Playwright test requires explicit authorization. Unsupported
   execution becomes evidence debt.
6. **Release evidence and documentation.** The focused suite, complete core
   suite, four legacy suites, compatibility/preflight, dual-render, installed
   parity, rollback/uninstall rehearsal, compile, hygiene, offline wheel, and
   lock-held offline SBOM checks are recorded in
   `docs/phase0/evidence/lean-host-native-red-green-ledger.md`.

## Source-template repair

`plugins/shipworthy/skills/ship-product-workflows/templates/audit-ledger.md` is
referenced by the product-workflow skill and its living-ledger reference. The
repository's generated-output ignore rule, `**/audit-ledger.md`, also matched
that source template. The local repair adds the narrow exception
`!plugins/shipworthy/skills/ship-product-workflows/templates/audit-ledger.md`
and includes the template as source.

The repair must be present in the eventual reviewed commit and merged to
`origin/main`; until that integration occurs, **origin/main availability is
NOT_PROVEN**. No real installed skill directory is modified as part of this
repair.

## Mandatory proof contract

Every operational Shipworthy run still produces a self-contained
`readiness-report.html` from the final ledger, including downgraded or
skill-only runs. Failure to render the report is deliverable debt and prevents a
complete-run claim. HTML, SARIF, and the evidence bundle are projections of the
same canonical ledger, never parallel truth stores.

Proof ceilings remain explicit:

- exploratory evidence proves only what the supplied observation and artifacts
  show;
- deterministic replay proves only the target-owned test behavior represented
  by the supplied report and sealed attachments;
- missing channels, blocked paths, absent artifacts, and unresolved differences
  remain evidence debt or `NOT_PROVEN`;
- imported evidence cannot independently create a confirmed blocker or an
  approved verifier result.

## Exact stop and defer list

Stop after the lean Task 6 release gate. Do not add:

- a custom browser engine, browser DSL, Playwright wrapper, or Shipworthy
  browser-run command;
- SQLite, event sourcing, a general content-addressed store, persistence,
  backup service, or daemon;
- a public CLI product or general command runner;
- a portal, MCP server, provider abstraction, external-service integration, or cloud
  runner;
- accounts, billing, schedules, notifications, multi-tenant infrastructure,
  credential storage, or automatic dependency installation;
- network access, production changes, or writes to real Codex/Claude installed
  skill directories.

Historical provider and Phase 1-8 research remains historical evidence;
it is not the active build queue.

## Optional next adapters

No adapter follows automatically. A later SARIF, JUnit, API-contract, or other
brownfield adapter requires all of the following:

1. a real target repository already emits the format;
2. a small sanitized fixture from that repository demonstrates the need;
3. the adapter can translate into the existing normalized evidence result and
   canonical ledger without a new runner or truth store;
4. hostile-boundary, lineage, proof-ceiling, HTML, SARIF, and bundle tests are
   specified first;
5. the work receives separate approval.

## Current proof ceiling

Local Task 6 verification and independent review are complete. The following
remain **NOT_PROVEN**:

- Python 3.12-3.14 runtime execution across the complete matrix;
- locked-wheel reproduction;
- OS-level network containment;
- publication or merge to `origin/main`;
- parity with any real installed Codex or Claude skill copy.

SBOM execution is proven only for the current Python 3.13 environment. Exact
synthetic Codex/Claude installed-copy parity is proven; real installed-copy
parity remains deliberately untested because the approved boundary forbids
real installation reads or writes.

Phase 1-style platform work has not started because the active architecture
delegates execution to the host and keeps Shipworthy focused on evidence
normalization, canonical truth, and trustworthy reporting.
