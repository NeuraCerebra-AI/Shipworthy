from __future__ import annotations

import builtins
from dataclasses import FrozenInstanceError
import hashlib
import importlib
import json
from pathlib import Path
import socket
import subprocess

import pytest


FIXTURES = Path(__file__).resolve().parents[1] / "fixtures" / "browser_evidence"
SOURCE_PATH = "evidence/browser/session.json"


def _importer():
    return importlib.import_module("shipworthy.adapters.importers.browser_evidence")


def _envelope_with_real_seals() -> tuple[bytes, dict[str, bytes]]:
    payload = json.loads((FIXTURES / "valid-exploratory.json").read_bytes())
    attachments = {
        "evidence/browser/checkout.png": b"synthetic screenshot bytes",
        "evidence/browser/checkout-accessibility.json": b'{"role":"main"}\n',
    }
    for artifact in payload["artifacts"]:
        descriptor = artifact["descriptor"]
        supplied = attachments[descriptor["relative_path"]]
        descriptor["byte_size"] = len(supplied)
        descriptor["digest"] = hashlib.sha256(supplied).hexdigest()
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    return raw, attachments


def _import(raw: bytes, attachments: dict[str, bytes]):
    return _importer().import_browser_evidence_json(
        raw,
        source_relative_path=SOURCE_PATH,
        attachment_bytes=attachments,
    )


def test_import_retains_and_seals_source_and_exact_attachments() -> None:
    raw, attachments = _envelope_with_real_seals()

    result = _import(raw, attachments)

    assert result.raw_bytes is raw
    assert result.sha256 == hashlib.sha256(raw).hexdigest()
    assert result.byte_size == len(raw)
    assert result.source.schema_name == "shipworthy/browser-evidence-envelope"
    assert result.source.relative_path == SOURCE_PATH
    assert result.source.producer_name == "shipworthy-contract-tests"
    assert result.source.producer_version == "1.0.0"
    assert result.mode.value == "exploratory"
    assert result.driver == "in-app-browser"
    assert result.source_artifact.availability.value == "available"
    assert result.source_artifact.artifact_id.startswith("ART-BROWSER-SOURCE-")
    assert result.source_artifact.descriptor.digest == result.sha256
    assert result.source_artifact.descriptor.byte_size == len(raw)
    assert (
        result.source_artifact.lineage.producer
        == "shipworthy-browser-evidence-importer"
    )
    assert result.source_artifact.lineage.operation == "seal-supplied-browser-evidence"
    assert {item.artifact_id for item in result.artifacts} == {
        "ART-BROWSER-SCREENSHOT-001",
        "ART-BROWSER-DOM-001",
    }
    assert all(item.availability.value == "available" for item in result.artifacts)
    assert {item.lineage.producer for item in result.artifacts} == {
        "shipworthy-browser-evidence-importer"
    }
    assert len(result.observations) == 2
    assert all(item.artifact_ids == () for item in result.observations)
    assert result.finding_ids == ("FND-CHECKOUT-001",)
    assert result.evidence_debt == ()
    expected_paths = tuple(sorted(attachments))
    assert (
        tuple(item.relative_path for item in result.sealed_attachments)
        == expected_paths
    )
    assert tuple(item.raw_bytes for item in result.sealed_attachments) == tuple(
        attachments[path] for path in expected_paths
    )
    assert "synthetic screenshot bytes" not in repr(result)
    with pytest.raises(FrozenInstanceError):
        result.sealed_attachments[0].relative_path = "mutated"


def test_missing_corrupt_and_undeclared_attachments_become_named_debt() -> None:
    raw, attachments = _envelope_with_real_seals()
    supplied = {
        "evidence/browser/checkout.png": b"secret-token-should-not-leak",
        "evidence/browser/undeclared.txt": b"undeclared bytes",
    }

    result = _import(raw, supplied)

    assert {item.availability.value for item in result.artifacts} == {
        "corrupt",
        "missing",
    }
    codes = {item.code for item in result.evidence_debt}
    assert codes == {
        "ATTACHMENT_DIGEST_MISMATCH",
        "ATTACHMENT_MISSING",
        "ATTACHMENT_UNDECLARED",
    }
    diagnostics = repr(result.evidence_debt)
    assert "secret-token-should-not-leak" not in diagnostics
    assert all(len(item.reason) <= 1000 for item in result.evidence_debt)
    assert [item.relative_path for item in result.sealed_attachments] == [
        "evidence/browser/checkout.png",
        "evidence/browser/undeclared.txt",
    ]
    assert "secret-token-should-not-leak" not in repr(result)


def test_import_is_deterministic_frozen_and_has_no_read_or_execution_side_effects(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    raw, attachments = _envelope_with_real_seals()
    baseline = _import(raw, attachments)

    def forbidden(*_args, **_kwargs):
        raise AssertionError("import attempted an external side effect")

    monkeypatch.setattr(builtins, "open", forbidden)
    monkeypatch.setattr(socket, "socket", forbidden)
    monkeypatch.setattr(subprocess, "run", forbidden)
    monkeypatch.setattr(subprocess, "Popen", forbidden)
    repeated = _import(raw, attachments)

    assert repeated == baseline
    assert isinstance(repeated.artifacts, tuple)
    assert isinstance(repeated.observations, tuple)
    assert isinstance(repeated.limitations, tuple)
    with pytest.raises(FrozenInstanceError):
        repeated.driver = "mutated"


def test_import_result_has_no_finding_gate_or_proof_inflation_surface() -> None:
    raw, attachments = _envelope_with_real_seals()

    result = _import(raw, attachments)

    for forbidden in (
        "findings",
        "readiness_disposition",
        "gate",
        "proof",
        "confidence",
        "verifier_status",
    ):
        assert not hasattr(result, forbidden)
    assert not any(hasattr(item, "verifier_status") for item in result.observations)


def test_nested_result_is_frozen_and_attachment_secrets_are_not_represented() -> None:
    raw, attachments = _envelope_with_real_seals()
    secret = b"TASK3-SECRET-CANARY"
    payload = json.loads(raw)
    descriptor = payload["artifacts"][0]["descriptor"]
    descriptor["digest"] = hashlib.sha256(secret).hexdigest()
    descriptor["byte_size"] = len(secret)
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    attachments[descriptor["relative_path"]] = secret

    result = _import(raw, attachments)

    assert "raw_bytes=" not in repr(result)
    assert secret.decode() not in repr(result)
    with pytest.raises(FrozenInstanceError):
        result.source.producer_name = "mutated"
    with pytest.raises(FrozenInstanceError):
        result.observations[0].action = "mutated"


@pytest.mark.parametrize(
    ("raw", "attachments"),
    [
        (b"", {}),
        (b"{", {}),
        (b"[]", {}),
        (b"{" + b" " * 1_048_576 + b"}", {}),
        (b'<?xml version="1.0"?><x/>', {}),
    ],
)
def test_invalid_envelope_is_rejected_with_one_sanitized_error(
    raw: bytes, attachments: dict[str, bytes]
) -> None:
    importer = _importer()

    with pytest.raises(
        importer.BrowserEvidenceImportError,
        match="browser evidence failed safe import validation",
    ) as captured:
        _import(raw, attachments)

    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None
