from __future__ import annotations

from dataclasses import FrozenInstanceError
import builtins
import hashlib
import importlib
import json
from pathlib import Path
import socket
import subprocess

import pytest


FIXTURES = Path(__file__).resolve().parents[1] / "fixtures" / "playwright"
SOURCE_PATH = "test-results/playwright-report.json"


def _importer():
    return importlib.import_module("shipworthy.adapters.importers.playwright_report")


def _import(
    raw: bytes,
    attachments: dict[str, bytes] | None = None,
    *,
    finding_ids: tuple[str, ...] = (),
):
    return _importer().import_playwright_json_report(
        raw,
        source_relative_path=SOURCE_PATH,
        attachment_bytes=attachments or {},
        finding_ids=finding_ids,
    )


def _payload() -> dict[str, object]:
    return json.loads((FIXTURES / "basic-report.json").read_bytes())


def _raw(payload: object) -> bytes:
    return (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()


def test_report_normalizes_status_retry_flaky_screenshot_and_trace() -> None:
    raw = (FIXTURES / "basic-report.json").read_bytes()
    attachments = {
        "test-results/checkout/screenshot.png": (
            FIXTURES / "screenshot.png"
        ).read_bytes(),
        "test-results/expired/trace.zip": (FIXTURES / "trace.zip").read_bytes(),
    }

    result = _import(raw, attachments)

    assert result.raw_bytes is raw
    assert result.sha256 == hashlib.sha256(raw).hexdigest()
    assert result.byte_size == len(raw)
    assert result.source.schema_name == "playwright/json-reporter"
    assert result.source.relative_path == SOURCE_PATH
    assert result.source.producer_name == "playwright"
    assert result.source.producer_version == "1.54.0"
    assert result.mode.value == "deterministic_replay"
    assert result.driver == "existing-playwright-json-reporter"
    assert result.source_artifact.artifact_id.startswith("ART-PLAYWRIGHT-SOURCE-")
    assert (
        result.source_artifact.lineage.producer
        == "shipworthy-playwright-report-importer"
    )
    assert result.source_artifact.lineage.operation == "seal-supplied-playwright-report"
    observations = {item.official_id: item for item in result.observations}
    assert observations["checkout-valid-card"].outcome == "passed"
    assert observations["checkout-expired-card"].outcome == "failed"
    assert observations["checkout-bank-redirect"].outcome == "skipped"
    flaky = observations["checkout-receipt"]
    assert flaky.outcome == "passed"
    assert flaky.retry_count == 1
    assert flaky.flaky is True
    assert flaky.project_id == "chromium-default"
    assert "checkout > tests/checkout.spec.ts:40:3" in flaky.subject
    assert "aggregate status flaky" in flaky.observed_outcome
    assert "attempts: failed, passed" in flaky.observed_outcome
    assert {item.descriptor.declared_media_type for item in result.artifacts} == {
        "image/png",
        "application/zip",
    }
    assert all(item.availability.value == "available" for item in result.artifacts)
    assert {item.lineage.producer for item in result.artifacts} == {
        "shipworthy-playwright-report-importer"
    }
    assert {item.lineage.operation for item in result.artifacts} == {
        "seal-supplied-playwright-attachment"
    }
    assert all(
        item.artifact_id.startswith("ART-PLAYWRIGHT-") for item in result.artifacts
    )
    assert all(
        item.lineage.source_ids == (result.source_artifact.artifact_id,)
        for item in result.artifacts
    )
    for observation in result.observations:
        assert observation.action == "Import existing target-owned Playwright result"
        assert "replay" not in observation.action.lower()
        assert "run" not in observation.action.lower()
    assert result.evidence_debt == ()
    assert result.finding_ids == ()
    expected_paths = tuple(sorted(attachments))
    assert (
        tuple(item.relative_path for item in result.sealed_attachments)
        == expected_paths
    )
    assert tuple(item.raw_bytes for item in result.sealed_attachments) == tuple(
        attachments[path] for path in expected_paths
    )
    assert "PNG synthetic screenshot" not in repr(result)
    with pytest.raises(FrozenInstanceError):
        result.sealed_attachments[0].relative_path = "mutated"


def test_optional_finding_ids_are_validated_without_ledger_access() -> None:
    raw = (FIXTURES / "basic-report.json").read_bytes()

    associated = _import(raw, finding_ids=("FND-CHECKOUT-001",))

    assert associated.finding_ids == ("FND-CHECKOUT-001",)

    invalid_values: tuple[object, ...] = (
        ["FND-CHECKOUT-001"],
        ("not-a-finding",),
        ("FND-CHECKOUT-001", "FND-CHECKOUT-001"),
        tuple(f"FND-BOUND-{index:03d}" for index in range(129)),
    )
    for invalid in invalid_values:
        with pytest.raises(
            _importer().PlaywrightReportImportError,
            match="playwright report failed safe import validation",
        ) as captured:
            _importer().import_playwright_json_report(
                raw,
                source_relative_path=SOURCE_PATH,
                attachment_bytes={},
                finding_ids=invalid,
            )
        assert captured.value.__cause__ is None
        assert captured.value.__context__ is None


def test_missing_report_attachment_is_preserved_as_named_debt() -> None:
    raw = (FIXTURES / "basic-report.json").read_bytes()

    result = _import(raw)

    assert {item.availability.value for item in result.artifacts} == {"missing"}
    assert {item.code for item in result.evidence_debt} == {"ATTACHMENT_MISSING"}
    assert all(
        item.artifact_id.startswith("ART-PLAYWRIGHT-") for item in result.artifacts
    )
    assert {item.lineage.producer for item in result.artifacts} == {
        "shipworthy-playwright-report-importer"
    }
    assert {item.lineage.operation for item in result.artifacts} == {
        "declare-missing-supplied-playwright-attachment"
    }
    assert all(
        item.lineage.source_ids == (result.source_artifact.artifact_id,)
        for item in result.artifacts
    )


def test_absolute_attachment_path_is_rejected() -> None:
    payload = _payload()
    payload["suites"][0]["specs"][0]["tests"][0]["results"][0]["attachments"][0][
        "path"
    ] = "/tmp/screenshot.png"

    with pytest.raises(
        _importer().PlaywrightReportImportError,
        match="playwright report failed safe import validation",
    ):
        _import(_raw(payload))


def test_duplicate_test_identity_is_rejected() -> None:
    payload = _payload()
    duplicate = payload["suites"][0]["specs"][0]
    payload["suites"][0]["specs"].append(duplicate)

    with pytest.raises(
        _importer().PlaywrightReportImportError,
        match="playwright report failed safe import validation",
    ):
        _import(_raw(payload))


@pytest.mark.parametrize(
    "raw",
    [
        b"",
        b"{",
        b"[]",
        b'{"suites":[],"suites":[]}',
        b'{"config":{"version":"1"},"suites":"wrong"}',
        b"{" + b" " * 1_048_576 + b"}",
    ],
)
def test_malformed_or_oversized_report_fails_with_sanitized_error(raw: bytes) -> None:
    importer = _importer()

    with pytest.raises(
        importer.PlaywrightReportImportError,
        match="playwright report failed safe import validation",
    ) as captured:
        _import(raw)

    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_result_is_frozen_and_cannot_express_findings_or_readiness() -> None:
    result = _import((FIXTURES / "basic-report.json").read_bytes())

    with pytest.raises(FrozenInstanceError):
        result.driver = "mutated"
    for forbidden in (
        "findings",
        "readiness_disposition",
        "gate",
        "proof",
        "confidence",
        "verifier_status",
    ):
        assert not hasattr(result, forbidden)


def test_aggregate_status_controls_outcome_and_expected_failure_is_not_product_failure() -> (
    None
):
    payload = _payload()
    specs = payload["suites"][0]["specs"]
    specs[0]["tests"][0]["status"] = "expected"
    specs[0]["tests"][0]["expectedStatus"] = "failed"
    specs[0]["tests"][0]["results"][0]["status"] = "failed"

    result = _import(_raw(payload))
    by_id = {item.official_id: item for item in result.observations}

    expected_failure = by_id["checkout-valid-card"]
    assert expected_failure.outcome == "passed"
    assert expected_failure.flaky is False
    assert "expected status failed" in expected_failure.observed_outcome
    assert by_id["checkout-expired-card"].outcome == "failed"
    assert by_id["checkout-receipt"].flaky is True
    assert by_id["checkout-bank-redirect"].outcome == "skipped"


def test_empty_results_use_aggregate_status_and_body_attachment_becomes_debt() -> None:
    payload = _payload()
    test = payload["suites"][0]["specs"][0]["tests"][0]
    test["results"] = []
    test["status"] = "expected"
    test["expectedStatus"] = "passed"
    payload["suites"][0]["specs"][1]["tests"][0]["results"][0]["attachments"] = [
        {
            "name": "embedded screenshot",
            "contentType": "image/png",
            "body": "VEFTSzMtU0VDUkVULUNBTkFSWQ==",
        }
    ]

    result = _import(_raw(payload))

    observation = next(
        item
        for item in result.observations
        if item.official_id == "checkout-valid-card"
    )
    assert observation.outcome == "passed"
    assert observation.artifact_ids == ()
    assert "TASK3-SECRET-CANARY" not in repr(result)
    assert "raw_bytes=" not in repr(result)
    body_debt = next(
        item
        for item in result.evidence_debt
        if item.code == "ATTACHMENT_BODY_UNIMPORTED"
    )
    assert body_debt.artifact_ids == ()
    assert not any(
        item.descriptor.relative_path.endswith("embedded-screenshot")
        for item in result.artifacts
    )


def test_official_id_plus_project_is_stable_and_same_title_distinct_ids_are_allowed() -> (
    None
):
    payload = _payload()
    first = payload["suites"][0]["specs"][0]
    distinct = json.loads(json.dumps(first))
    distinct["id"] = "checkout-valid-card-variant"
    distinct["line"] = 11
    distinct["tests"][0]["results"][0]["attachments"] = []
    payload["suites"][0]["specs"].append(distinct)

    original = _import(_raw(payload))
    ids_before = {
        (item.official_id, item.project_id): item.observation_id
        for item in original.observations
    }
    payload["suites"][0]["specs"].reverse()
    reordered = _import(_raw(payload))
    ids_after = {
        (item.official_id, item.project_id): item.observation_id
        for item in reordered.observations
    }

    assert ids_after == ids_before
    assert ("checkout-valid-card", "chromium-default") in ids_before
    assert ("checkout-valid-card-variant", "chromium-default") in ids_before


def test_duplicate_official_id_and_project_is_rejected_even_with_different_title() -> (
    None
):
    payload = _payload()
    duplicate = json.loads(json.dumps(payload["suites"][0]["specs"][0]))
    duplicate["title"] = "different display title"
    payload["suites"][0]["specs"].append(duplicate)

    with pytest.raises(_importer().PlaywrightReportImportError):
        _import(_raw(payload))


def test_empty_project_name_uses_default_display_but_project_id_controls_identity() -> (
    None
):
    raw = (FIXTURES / "unnamed-project-report.json").read_bytes()

    result = _import(raw)

    observation = result.observations[0]
    assert observation.project == "default"
    assert observation.project_id == ""
    assert observation.subject.endswith("uses unnamed project [default]")
    expected_hash = hashlib.sha256(b"default-project-test\0").hexdigest()[:24]
    assert observation.observation_id == f"playwright-{expected_hash}"


def test_same_display_project_name_with_distinct_project_ids_is_accepted() -> None:
    payload = _payload()
    spec = payload["suites"][0]["specs"][0]
    second_project = json.loads(json.dumps(spec["tests"][0]))
    second_project["projectId"] = "chromium-secondary"
    second_project["results"][0]["attachments"] = []
    spec["tests"].append(second_project)

    result = _import(_raw(payload))
    matching = [
        item
        for item in result.observations
        if item.official_id == "checkout-valid-card"
    ]

    assert len(matching) == 2
    assert {item.project for item in matching} == {"chromium"}
    assert {item.project_id for item in matching} == {
        "chromium-default",
        "chromium-secondary",
    }
    assert len({item.observation_id for item in matching}) == 2


@pytest.mark.parametrize("project_id", [None, 7, "x" * 201])
def test_missing_or_invalid_project_id_fails_with_sanitized_error(
    project_id: object,
) -> None:
    payload = _payload()
    test = payload["suites"][0]["specs"][0]["tests"][0]
    if project_id is None:
        del test["projectId"]
    else:
        test["projectId"] = project_id
    importer = _importer()

    with pytest.raises(importer.PlaywrightReportImportError) as captured:
        _import(_raw(payload))

    assert str(captured.value) == "playwright report failed safe import validation"
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_import_has_no_io_browser_socket_or_subprocess_side_effects(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    raw = (FIXTURES / "basic-report.json").read_bytes()
    baseline = _import(raw)

    def forbidden(*_args, **_kwargs):
        raise AssertionError("Playwright import attempted an external side effect")

    monkeypatch.setattr(builtins, "open", forbidden)
    monkeypatch.setattr(socket, "socket", forbidden)
    monkeypatch.setattr(subprocess, "run", forbidden)
    monkeypatch.setattr(subprocess, "Popen", forbidden)

    assert _import(raw) == baseline


def test_nested_result_is_frozen_and_raw_secret_is_not_represented() -> None:
    payload = _payload()
    payload["ignoredReporterMetadata"] = "TASK3-SECRET-CANARY"
    result = _import(_raw(payload))

    assert "raw_bytes=" not in repr(result)
    assert "TASK3-SECRET-CANARY" not in repr(result)
    with pytest.raises(FrozenInstanceError):
        result.source.producer_name = "mutated"
    with pytest.raises(FrozenInstanceError):
        result.observations[0].action = "mutated"


def test_report_and_attachment_resource_limits_are_named_and_enforced() -> None:
    importer = _importer()
    assert importer.MAX_REPORT_BYTES == 16 * 1_048_576
    assert importer.MAX_ATTACHMENTS == 128
    assert importer.MAX_SINGLE_ATTACHMENT_BYTES == 16 * 1_048_576
    assert importer.MAX_TOTAL_ATTACHMENT_BYTES == 64 * 1_048_576

    too_many = {
        f"evidence/attachment-{index}.bin": b""
        for index in range(importer.MAX_ATTACHMENTS + 1)
    }
    with pytest.raises(importer.PlaywrightReportImportError):
        _import((FIXTURES / "basic-report.json").read_bytes(), too_many)

    oversized = b"x" * (importer.MAX_SINGLE_ATTACHMENT_BYTES + 1)
    with pytest.raises(importer.PlaywrightReportImportError):
        _import(
            (FIXTURES / "basic-report.json").read_bytes(),
            {"evidence/oversized.bin": oversized},
        )

    shared_chunk = b"x" * importer.MAX_SINGLE_ATTACHMENT_BYTES
    over_total = {
        f"evidence/chunk-{index}.bin": shared_chunk
        for index in range(
            importer.MAX_TOTAL_ATTACHMENT_BYTES // importer.MAX_SINGLE_ATTACHMENT_BYTES
            + 1
        )
    }
    with pytest.raises(importer.PlaywrightReportImportError):
        _import((FIXTURES / "basic-report.json").read_bytes(), over_total)


def test_valid_report_larger_than_one_mib_is_accepted_but_limit_is_enforced() -> None:
    importer = _importer()
    payload = _payload()
    payload["boundedReporterMetadata"] = ["x" * 9_000 for _ in range(120)]
    raw = _raw(payload)
    assert 1_048_576 < len(raw) < importer.MAX_REPORT_BYTES

    result = _import(raw)

    assert result.byte_size == len(raw)
    assert result.sha256 == hashlib.sha256(raw).hexdigest()
    oversized = b"{" + b" " * importer.MAX_REPORT_BYTES + b"}"
    with pytest.raises(importer.PlaywrightReportImportError):
        _import(oversized)


def test_multiple_embedded_bodies_create_distinct_validated_debt_without_decoding() -> (
    None
):
    payload = _payload()
    attachments = payload["suites"][0]["specs"][1]["tests"][0]["results"][0][
        "attachments"
    ]
    attachments[:] = [
        {
            "name": "screenshot",
            "contentType": "image/png",
            "body": "TASK3-BODY-SECRET-CANARY-ONE",
        },
        {
            "name": "trace",
            "contentType": "application/zip",
            "body": "TASK3-BODY-SECRET-CANARY-TWO",
        },
    ]

    result = _import(_raw(payload))
    body_debts = [
        item
        for item in result.evidence_debt
        if item.code == "ATTACHMENT_BODY_UNIMPORTED"
    ]

    assert len(body_debts) == 2
    assert len({item.subject for item in body_debts}) == 2
    assert "screenshot" in body_debts[0].subject
    assert "trace" in body_debts[1].subject
    assert all(item.artifact_ids == () for item in body_debts)
    assert "TASK3-BODY-SECRET-CANARY" not in repr(result)


@pytest.mark.parametrize(
    "attachment",
    [
        {"name": "", "contentType": "image/png", "body": "abc"},
        {"name": "x" * 201, "contentType": "image/png", "body": "abc"},
        {"name": "shot", "contentType": "not-a-media-type", "body": "abc"},
        {"name": "shot", "contentType": "image/png", "body": 7},
    ],
)
def test_invalid_embedded_attachment_shape_fails_closed(attachment: object) -> None:
    payload = _payload()
    payload["suites"][0]["specs"][1]["tests"][0]["results"][0]["attachments"] = [
        attachment
    ]

    with pytest.raises(_importer().PlaywrightReportImportError):
        _import(_raw(payload))


@pytest.mark.parametrize(
    "body",
    [
        "",
        "QUJD" * 3_000,
    ],
    ids=["empty", "base64-like-over-10000-chars"],
)
def test_bounded_body_strings_are_retained_raw_only_without_decoding(
    body: str,
) -> None:
    payload = _payload()
    payload["suites"][0]["specs"][1]["tests"][0]["results"][0]["attachments"] = [
        {
            "name": "embedded result",
            "contentType": "application/octet-stream",
            "body": body,
        }
    ]
    raw = _raw(payload)
    assert len(raw) < _importer().MAX_REPORT_BYTES

    result = _import(raw)

    debt = next(
        item
        for item in result.evidence_debt
        if item.code == "ATTACHMENT_BODY_UNIMPORTED"
    )
    assert debt.artifact_ids == ()
    assert "embedded result" in debt.subject
    assert body not in repr(result) if body else "raw_bytes=" not in repr(result)
