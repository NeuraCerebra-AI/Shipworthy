from __future__ import annotations

import builtins
import codecs
from dataclasses import FrozenInstanceError
import hashlib
import importlib
import json
from pathlib import Path
import socket
import traceback

import pytest
from pydantic import ValidationError as PydanticValidationError


FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"
LEGACY_FIXTURE = FIXTURES / "legacy" / "readiness-v0.json"
SOURCE_PATH = "evidence/legacy/readiness-v0.json"
IMPORTED_AT = "2026-07-12T12:34:56Z"
LEGACY_FIXTURE_SHA256 = (
    "37cfe1e5dcc37780d758fe0c800a86f931bf347926c96ef45aa01cfd6515a5cc"
)


def _importer():
    return importlib.import_module(
        "shipworthy.adapters.importers.legacy_readiness"
    )


def _contracts():
    return importlib.import_module("shipworthy.domain.contracts")


def _import(raw: bytes, **overrides):
    options = {
        "source_relative_path": SOURCE_PATH,
        "imported_at": IMPORTED_AT,
    }
    options.update(overrides)
    return _importer().import_legacy_readiness_json(raw, **options)


def _raw(payload: object) -> bytes:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()


def _escaped_raw(payload: object) -> bytes:
    return json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode()


def _recognized_findings(count: int) -> list[dict[str, str]]:
    return [
        {
            "title": f"Legacy finding {index}",
            "action": "Prove",
            "section": "not_proven_not_tested",
            "severity": "Unscored",
            "proof": "Not tested",
            "confidence": "Hypothesis",
        }
        for index in range(count)
    ]


def _nested_arrays(depth: int) -> list[object]:
    value: list[object] = []
    for _ in range(depth - 1):
        value = [value]
    return value


def _array_tree_with_nodes(node_count: int) -> list[object]:
    """Build exactly node_count list/scalar nodes with each list <= 4096 items."""

    if node_count < 1:
        raise ValueError("node_count must include the root list")
    root: list[object] = []
    remaining = node_count - 1
    while remaining:
        child_items = min(4_096, remaining - 1)
        root.append([0] * child_items)
        remaining -= child_items + 1
    return root


def _debt_codes(result) -> set[str]:
    return {row.code for row in result.mapping_debt}


def _all_projected_ids(result) -> tuple[str, ...]:
    ledger = result.ledger
    return (
        ledger.ledger_id,
        *(artifact.artifact_id for artifact in ledger.artifacts),
        *(finding.finding_id for finding in ledger.findings),
        *(debt.debt_id for debt in ledger.evidence_debt),
    )


def test_current_legacy_fixture_imports_raw_first_and_round_trips_v1() -> None:
    raw = LEGACY_FIXTURE.read_bytes()

    result = _import(raw)

    assert result.source_schema_name == "legacy/readiness-v0"
    assert result.raw_bytes is raw
    assert result.raw_bytes == raw
    assert result.sha256 == LEGACY_FIXTURE_SHA256
    assert result.sha256 == hashlib.sha256(raw).hexdigest()
    assert result.byte_size == len(raw)
    assert result.source_relative_path == SOURCE_PATH
    assert result.imported_at == IMPORTED_AT
    assert isinstance(result.mapping_debt, tuple)
    assert result.mapping_debt

    ledger = result.ledger
    assert ledger.generated_at == IMPORTED_AT
    assert ledger.producer.name == "shipworthy-legacy-readiness-importer"
    assert ledger.producer.version == "0.1.0"
    assert ledger.completion_status.value == "incomplete"
    assert ledger.readiness_disposition.value == "cannot_determine"
    assert ledger.gate.outcome.value == "incomplete"
    assert ledger.gate.blocking_finding_ids == ()

    assert len(ledger.artifacts) == 1
    artifact = ledger.artifacts[0]
    assert artifact.availability.value == "available"
    assert artifact.custody_state.value == "LOCAL_CONTENT_INTEGRITY"
    assert artifact.descriptor.relative_path == SOURCE_PATH
    assert artifact.descriptor.digest_algorithm == "sha256"
    assert artifact.descriptor.digest == result.sha256
    assert artifact.descriptor.byte_size == len(raw)
    assert artifact.lineage.producer == "shipworthy-legacy-readiness-importer"
    assert artifact.lineage.operation == "import legacy/readiness-v0"

    assert len(ledger.findings) == 1
    finding = ledger.findings[0]
    assert finding.subject.title == "Legacy unversioned finding"
    assert finding.summary == "Legacy unversioned finding"
    assert finding.subject.location is None
    assert finding.verifier_status.value == "needs-proof"
    assert finding.artifact_ids == (artifact.artifact_id,)
    assert all(debt.artifact_ids == (artifact.artifact_id,) for debt in ledger.evidence_debt)
    assert tuple(row.debt_id for row in result.mapping_debt) == tuple(
        debt.debt_id for debt in ledger.evidence_debt
    )
    assert tuple(row.reason for row in result.mapping_debt) == tuple(
        debt.reason for debt in ledger.evidence_debt
    )
    assert (
        "LEGACY_FIELD_RAW_ONLY",
        "$.generated_at",
    ) in {(row.code, row.source_path) for row in result.mapping_debt}

    serialized = _contracts().serialize_readiness_ledger_json(ledger)
    assert _contracts().parse_readiness_ledger_json(serialized) == ledger
    assert _contracts().serialize_readiness_ledger_json(
        _contracts().parse_readiness_ledger_json(serialized)
    ) == serialized


def test_import_result_and_mapping_debt_are_deeply_immutable() -> None:
    result = _import(LEGACY_FIXTURE.read_bytes())

    with pytest.raises(FrozenInstanceError):
        result.sha256 = "0" * 64
    with pytest.raises(FrozenInstanceError):
        result.mapping_debt[0].reason = "changed"
    with pytest.raises(TypeError):
        result.mapping_debt[0] = result.mapping_debt[0]
    with pytest.raises(PydanticValidationError):
        result.ledger.revision = 2


def test_same_inputs_are_identical_and_changed_raw_changes_all_derived_ids() -> None:
    raw = LEGACY_FIXTURE.read_bytes()

    first = _import(raw)
    second = _import(raw)
    changed = _import(raw.replace(b"Legacy unversioned finding", b"Legacy revised finding"))

    assert first == second
    assert _contracts().serialize_readiness_ledger_json(first.ledger) == (
        _contracts().serialize_readiness_ledger_json(second.ledger)
    )
    assert first.sha256 != changed.sha256
    assert set(_all_projected_ids(first)).isdisjoint(_all_projected_ids(changed))


def test_legacy_confirmed_blocker_is_downgraded_and_cannot_fail_gate() -> None:
    result = _import(LEGACY_FIXTURE.read_bytes())

    finding = result.ledger.findings[0]
    assert finding.action.value == "Fix"
    assert finding.section.value == "clear_before_ship"
    assert finding.severity.value == "P0 Blocker"
    assert finding.proof.value == "Partial"
    assert finding.confidence.value == "Provisional"
    assert finding.verifier_status.value == "needs-proof"
    assert result.ledger.gate.outcome.value == "incomplete"
    assert result.ledger.gate.blocking_finding_ids == ()
    assert {
        "LEGACY_CONFIRMED_PROOF_DOWNGRADED",
        "LEGACY_CONFIRMED_CONFIDENCE_DOWNGRADED",
        "LEGACY_FINDING_NEEDS_PROOF",
    }.issubset(_debt_codes(result))


def test_unknown_action_first_values_default_conservatively_with_named_debt() -> None:
    result = _import(
        _raw(
            {
                "target": "legacy-api",
                "findings": [
                    {
                        "title": "Unknown legacy vocabulary",
                        "action": "Launch",
                        "section": "magic",
                        "severity": "catastrophic-ish",
                        "proof": "Verified elsewhere",
                        "confidence": "Certain",
                    }
                ],
            }
        )
    )

    finding = result.ledger.findings[0]
    assert finding.action.value == "Prove"
    assert finding.section.value == "not_proven_not_tested"
    assert finding.severity.value == "Unscored"
    assert finding.proof.value == "Not tested"
    assert finding.confidence.value == "Hypothesis"
    assert finding.verifier_status.value == "needs-proof"
    assert {
        "LEGACY_ACTION_DEFAULTED",
        "LEGACY_SECTION_DEFAULTED",
        "LEGACY_SEVERITY_DEFAULTED",
        "LEGACY_PROOF_DEFAULTED",
        "LEGACY_CONFIDENCE_DEFAULTED",
    }.issubset(_debt_codes(result))


@pytest.mark.parametrize(
    ("title", "expected_code"),
    [
        (None, "LEGACY_FINDING_TITLE_MISSING"),
        ("", "LEGACY_FINDING_TITLE_UNUSABLE"),
        ("   ", "LEGACY_FINDING_TITLE_UNUSABLE"),
        (42, "LEGACY_FINDING_TITLE_UNUSABLE"),
    ],
)
def test_missing_or_unusable_title_stays_raw_only_without_invented_finding(
    title: object,
    expected_code: str,
) -> None:
    finding = {"severity": "blocker", "action": "Fix"}
    if title is not None:
        finding["title"] = title

    result = _import(_raw({"findings": [finding]}))

    assert result.ledger.findings == ()
    rows = [
        row
        for row in result.mapping_debt
        if row.code == expected_code
    ]
    assert len(rows) == 1
    assert rows[0].source_path == "$.findings[0].title"
    assert result.raw_bytes == _raw({"findings": [finding]})


UNSAFE_DISPLAY_TEXT = [
    pytest.param("visible\x00text", id="nul"),
    pytest.param("visible\x1btext", id="ansi-esc"),
    pytest.param("visible\x85text", id="c1-control"),
    pytest.param("visible\u202etext", id="bidi-rlo"),
    pytest.param("visible\u2066text", id="bidi-isolate"),
    pytest.param("visible\u2028text", id="line-separator"),
    pytest.param("visible\u2029text", id="paragraph-separator"),
    pytest.param("visible\u00a0text", id="nonbreaking-separator-space"),
    pytest.param("visible\u115ftext", id="u115f-blank-filler"),
    pytest.param("visible\u1160text", id="u1160-blank-filler"),
    pytest.param("visible\u2800text", id="u2800-blank-filler"),
    pytest.param("visible\u3164text", id="u3164-blank-filler"),
    pytest.param("visible\uffa0text", id="uffa0-blank-filler"),
    pytest.param("\u200b", id="zwsp-only"),
    pytest.param("\u200c", id="zwnj-only"),
    pytest.param("\u200d", id="zwj-only"),
    pytest.param("\u0301", id="combining-only"),
    pytest.param("\ud800", id="unpaired-high-surrogate"),
    pytest.param("\udc00", id="unpaired-low-surrogate"),
]


@pytest.mark.parametrize("unsafe_text", UNSAFE_DISPLAY_TEXT)
def test_unsafe_title_remains_raw_only_with_no_invented_finding(
    unsafe_text: str,
) -> None:
    raw = _escaped_raw(
        {
            "target": "safe-target",
            "findings": [{"title": unsafe_text}],
        }
    )

    result = _import(raw)

    assert result.raw_bytes == raw
    assert result.ledger.findings == ()
    assert (
        "LEGACY_FINDING_TITLE_UNUSABLE",
        "$.findings[0].title",
    ) in {(row.code, row.source_path) for row in result.mapping_debt}


@pytest.mark.parametrize("unsafe_text", UNSAFE_DISPLAY_TEXT)
def test_unsafe_target_defaults_to_position_and_never_enters_subject_ref(
    unsafe_text: str,
) -> None:
    raw = _escaped_raw(
        {
            "target": unsafe_text,
            "findings": [{"title": "Safe title"}],
        }
    )

    result = _import(raw)

    assert result.raw_bytes == raw
    assert result.ledger.findings[0].subject.ref == "legacy/findings/0"
    assert unsafe_text not in result.ledger.findings[0].subject.ref
    assert (
        "LEGACY_TARGET_DEFAULTED",
        "$.target",
    ) in {(row.code, row.source_path) for row in result.mapping_debt}


@pytest.mark.parametrize(
    "display_text",
    [
        pytest.param("😀 Ready", id="emoji"),
        pytest.param("发布就绪", id="cjk"),
        pytest.param("جاهز", id="rtl-letters"),
        pytest.param("Café", id="composed-accent"),
        pytest.param("Cafe\u0301", id="decomposed-accent"),
        pytest.param("❤️ ready", id="emoji-variation-selector"),
    ],
)
def test_valid_multilingual_display_text_projects_and_round_trips(
    display_text: str,
) -> None:
    raw = _raw(
        {
            "target": display_text,
            "findings": [{"title": display_text}],
        }
    )

    result = _import(raw)

    finding = result.ledger.findings[0]
    assert finding.subject.ref == display_text
    assert finding.subject.title == display_text
    assert finding.summary == display_text
    serialized = _contracts().serialize_readiness_ledger_json(result.ledger)
    assert _contracts().parse_readiness_ledger_json(serialized) == result.ledger


def test_valid_json_surrogate_pair_projects_as_one_astral_unicode_scalar() -> None:
    raw = (
        b'{"target":"\\ud83d\\ude00","findings":['
        b'{"title":"\\ud83d\\ude00"}]}'
    )

    result = _import(raw)

    finding = result.ledger.findings[0]
    assert finding.subject.ref == "😀"
    assert finding.subject.title == "😀"
    assert finding.summary == "😀"
    serialized = _contracts().serialize_readiness_ledger_json(result.ledger)
    assert _contracts().parse_readiness_ledger_json(serialized) == result.ledger


def test_unknown_and_unrepresentable_fields_are_named_as_raw_only_debt() -> None:
    result = _import(
        _raw(
            {
                "target": "legacy-api",
                "verdict": "MAYBE",
                "release_narrative": "free text retained only in raw bytes",
                "findings": [
                    {
                        "title": "Legacy note",
                        "action": "Prove",
                        "section": "not_proven_not_tested",
                        "severity": "minor",
                        "proof": "Not tested",
                        "confidence": "hypothesis",
                        "evidence": "legacy evidence prose",
                        "notes": "unmodeled prose",
                    }
                ],
            }
        )
    )

    raw_only_paths = {
        row.source_path
        for row in result.mapping_debt
        if row.code == "LEGACY_FIELD_RAW_ONLY"
    }
    assert {
        "$.verdict",
        "$.release_narrative",
        "$.findings[0].evidence",
        "$.findings[0].notes",
    }.issubset(raw_only_paths)
    assert result.ledger.findings[0].summary == "Legacy note"


def test_optional_legacy_location_is_never_projected_and_records_debt() -> None:
    result = _import(
        _raw(
            {
                "findings": [
                    {
                        "title": "Hostile location",
                        "location": {"file": "../../private/secret.txt"},
                    }
                ]
            }
        )
    )

    assert result.ledger.findings[0].subject.location is None
    location_rows = [
        row for row in result.mapping_debt if row.code == "LEGACY_LOCATION_RAW_ONLY"
    ]
    assert len(location_rows) == 1
    assert location_rows[0].source_path == "$.findings[0].location"


@pytest.mark.parametrize(
    ("location", "has_title"),
    [
        (None, True),
        ({}, True),
        ("", True),
        ({"file": "src/safe-looking.py"}, True),
        ({"file": "../../private/secret.txt"}, True),
        (None, False),
    ],
    ids=[
        "null",
        "empty-object",
        "empty-string",
        "safe-looking",
        "hostile",
        "titleless-null",
    ],
)
def test_every_present_location_key_records_exactly_one_raw_only_debt(
    location: object,
    has_title: bool,
) -> None:
    finding = {"location": location}
    if has_title:
        finding["title"] = "Location is untrusted"

    result = _import(_raw({"findings": [finding]}))

    rows = [
        row for row in result.mapping_debt if row.code == "LEGACY_LOCATION_RAW_ONLY"
    ]
    assert len(rows) == 1
    assert rows[0].source_path == "$.findings[0].location"
    assert all(item.subject.location is None for item in result.ledger.findings)
    assert bool(result.ledger.findings) is has_title


def test_hostile_location_records_debt_even_when_missing_title_prevents_projection() -> None:
    result = _import(
        _raw(
            {
                "findings": [
                    {"location": {"file": "../../private/secret.txt"}}
                ]
            }
        )
    )

    assert result.ledger.findings == ()
    assert {
        (row.code, row.source_path)
        for row in result.mapping_debt
    }.issuperset(
        {
            ("LEGACY_FINDING_TITLE_MISSING", "$.findings[0].title"),
            ("LEGACY_LOCATION_RAW_ONLY", "$.findings[0].location"),
        }
    )


def test_usable_target_with_no_projected_findings_is_named_raw_only() -> None:
    result = _import(_raw({"target": "legacy-api", "findings": []}))

    assert result.ledger.findings == ()
    assert (
        "LEGACY_TARGET_RAW_ONLY",
        "$.target",
    ) in {
        (row.code, row.source_path) for row in result.mapping_debt
    }


@pytest.mark.parametrize(
    "source_relative_path",
    [
        "../readiness.json",
        "/tmp/readiness.json",
        "evidence//readiness.json",
        "evidence/./readiness.json",
        "evidence/../readiness.json",
        "evidence\\readiness.json",
        "https://example.test/readiness.json",
        " evidence/readiness.json",
    ],
)
def test_required_source_path_fails_closed(source_relative_path: str) -> None:
    importer = _importer()

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="source path failed safe validation",
    ):
        _import(
            LEGACY_FIXTURE.read_bytes(),
            source_relative_path=source_relative_path,
        )


@pytest.mark.parametrize(
    "raw",
    [
        "not-bytes",
        b"",
        b"{",
        b"[]",
        b"null",
        b'{"findings": [], "score": NaN}',
        b"\xff",
        b'{"findings": [], "findings": [{"title": "shadow"}]}',
        b'{"findings": [{"title": "shadow"}], "findings": []}',
        b'{"findings": [{"title": "first", "title": "shadow"}]}',
        b'{"findings": [{"title": "shadow", "title": "first"}]}',
        b"{" + (b" " * 1_048_576) + b"}",
    ],
    ids=[
        "non-bytes",
        "empty",
        "malformed",
        "array",
        "null",
        "nonstandard-number",
        "invalid-utf8",
        "duplicate-top-first",
        "duplicate-top-last",
        "duplicate-nested-first",
        "duplicate-nested-last",
        "oversized",
    ],
)
def test_invalid_boundary_inputs_fail_with_sanitized_importer_error(raw) -> None:
    importer = _importer()

    with pytest.raises(importer.LegacyReadinessImportError):
        _import(raw)


@pytest.mark.parametrize(
    "raw",
    [
        '{"findings":[]}'.encode("utf-16-le"),
        codecs.BOM_UTF16_LE + '{"findings":[]}'.encode("utf-16-le"),
        '{"findings":[]}'.encode("utf-16-be"),
        codecs.BOM_UTF16_BE + '{"findings":[]}'.encode("utf-16-be"),
        '{"findings":[]}'.encode("utf-32-le"),
        codecs.BOM_UTF32_LE + '{"findings":[]}'.encode("utf-32-le"),
        '{"findings":[]}'.encode("utf-32-be"),
        codecs.BOM_UTF32_BE + '{"findings":[]}'.encode("utf-32-be"),
    ],
    ids=[
        "utf16-le",
        "utf16-le-bom",
        "utf16-be",
        "utf16-be-bom",
        "utf32-le",
        "utf32-le-bom",
        "utf32-be",
        "utf32-be-bom",
    ],
)
def test_non_utf8_json_encodings_are_rejected_without_exception_context(
    raw: bytes,
) -> None:
    importer = _importer()

    with pytest.raises(importer.LegacyReadinessImportError) as captured:
        _import(raw)

    error = captured.value
    assert str(error) == "legacy readiness JSON failed safe import validation"
    assert error.__cause__ is None
    assert error.__context__ is None


def test_too_many_findings_fails_closed() -> None:
    importer = _importer()
    raw = _raw({"findings": [{"title": "x"}] * 513})

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="legacy readiness shape exceeds safe bounds",
    ):
        _import(raw)


def test_mapping_debt_accepts_exactly_512_rows() -> None:
    result = _import(
        _raw(
            {
                "target": "legacy-api",
                "findings": _recognized_findings(511),
            }
        )
    )

    assert len(result.mapping_debt) == 512
    assert len(result.ledger.evidence_debt) == 512
    assert len(result.ledger.findings) == 511


def test_mapping_debt_rejects_row_513_before_constructing_it(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    importer = _importer()
    original_debt_draft = importer._DebtDraft
    constructed = 0

    def tracked_debt_draft(*args, **kwargs):
        nonlocal constructed
        constructed += 1
        return original_debt_draft(*args, **kwargs)

    monkeypatch.setattr(importer, "_DebtDraft", tracked_debt_draft)
    raw = _raw(
        {
            "target": "legacy-api",
            "findings": _recognized_findings(512),
        }
    )

    with pytest.raises(importer.LegacyReadinessImportError) as captured:
        _import(raw)

    error = captured.value
    assert str(error) == "legacy readiness shape exceeds safe bounds"
    assert error.__cause__ is None
    assert error.__context__ is None
    assert constructed == 512


@pytest.mark.parametrize("member_count", [511, 512])
def test_nested_raw_only_object_accepts_member_count_through_512(
    member_count: int,
) -> None:
    nested = {f"key-{index}": 0 for index in range(member_count)}

    result = _import(_raw({"findings": [], "raw_object": nested}))

    assert result.raw_bytes
    assert result.ledger.completion_status.value == "incomplete"


def test_nested_raw_only_object_rejects_member_count_513() -> None:
    importer = _importer()
    nested = {f"key-{index}": 0 for index in range(513)}

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="legacy readiness shape exceeds safe bounds",
    ):
        _import(_raw({"findings": [], "raw_object": nested}))


@pytest.mark.parametrize("item_count", [4_095, 4_096])
def test_nested_raw_only_array_accepts_item_count_through_4096(
    item_count: int,
) -> None:
    result = _import(
        _raw({"findings": [], "raw_array": [0] * item_count})
    )

    assert result.raw_bytes
    assert result.ledger.completion_status.value == "incomplete"


def test_nested_raw_only_array_rejects_item_count_4097() -> None:
    importer = _importer()

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="legacy readiness shape exceeds safe bounds",
    ):
        _import(_raw({"findings": [], "raw_array": [0] * 4_097}))


@pytest.mark.parametrize("total_node_count", [99_999, 100_000])
def test_json_shape_accepts_effective_node_count_through_100000(
    total_node_count: int,
) -> None:
    document_overhead_nodes = 2  # root object plus the empty findings array
    tree = _array_tree_with_nodes(total_node_count - document_overhead_nodes)

    result = _import(_raw({"findings": [], "raw_tree": tree}))

    assert result.raw_bytes
    assert result.ledger.completion_status.value == "incomplete"


def test_json_shape_rejects_effective_node_count_100001() -> None:
    importer = _importer()
    document_overhead_nodes = 2
    tree = _array_tree_with_nodes(100_001 - document_overhead_nodes)

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="legacy readiness shape exceeds safe bounds",
    ):
        _import(_raw({"findings": [], "raw_tree": tree}))


@pytest.mark.parametrize("effective_depth", [31, 32])
def test_json_shape_accepts_effective_depth_through_32(
    effective_depth: int,
) -> None:
    result = _import(
        _raw(
            {
                "findings": [],
                "raw_nested_arrays": _nested_arrays(effective_depth),
            }
        )
    )

    assert result.raw_bytes


def test_json_shape_rejects_effective_depth_33() -> None:
    importer = _importer()

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="legacy readiness shape exceeds safe bounds",
    ):
        _import(
            _raw(
                {
                    "findings": [],
                    "raw_nested_arrays": _nested_arrays(33),
                }
            )
        )


@pytest.mark.parametrize("key_length", [63, 64])
def test_json_shape_accepts_key_length_through_64(key_length: int) -> None:
    result = _import(_raw({"findings": [], "k" * key_length: 0}))

    assert result.raw_bytes


def test_json_shape_rejects_key_length_65() -> None:
    importer = _importer()

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="legacy readiness shape exceeds safe bounds",
    ):
        _import(_raw({"findings": [], "k" * 65: 0}))


@pytest.mark.parametrize(
    "payload",
    [
        {"target": "x" * 201, "findings": []},
        {"findings": [{"title": "x" * 201}]},
        {"findings": [{"title": "x", "notes": "y" * 1001}]},
        {"findings": [{"title": "x", "action": "z" * 65}]},
    ],
    ids=["target", "title", "free-text", "enum"],
)
def test_overlong_legacy_fields_fail_closed(payload: object) -> None:
    importer = _importer()

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="legacy readiness shape exceeds safe bounds",
    ):
        _import(_raw(payload))


@pytest.mark.parametrize(
    "imported_at",
    [
        "2026-07-12",
        "2026-07-12T12:34:56.123Z",
        "2026-07-12T05:34:56-07:00",
        "2026-02-30T12:34:56Z",
        b"2026-07-12T12:34:56Z",
    ],
)
def test_import_timestamp_must_be_an_explicit_canonical_utc_second(
    imported_at: object,
) -> None:
    importer = _importer()

    with pytest.raises(
        importer.LegacyReadinessImportError,
        match="import timestamp failed canonical validation",
    ):
        _import(LEGACY_FIXTURE.read_bytes(), imported_at=imported_at)


def test_changing_safe_source_path_changes_every_content_derived_id() -> None:
    raw = LEGACY_FIXTURE.read_bytes()

    first = _import(raw, source_relative_path="evidence/legacy/first.json")
    second = _import(raw, source_relative_path="evidence/legacy/second.json")

    assert first.raw_bytes == second.raw_bytes == raw
    assert first.sha256 == second.sha256 == LEGACY_FIXTURE_SHA256
    assert set(_all_projected_ids(first)).isdisjoint(_all_projected_ids(second))


def test_changing_only_import_timestamp_preserves_content_derived_identity() -> None:
    raw = LEGACY_FIXTURE.read_bytes()

    first = _import(raw, imported_at="2026-07-12T12:34:56Z")
    second = _import(raw, imported_at="2026-07-12T12:34:57Z")

    assert first.sha256 == second.sha256 == LEGACY_FIXTURE_SHA256
    assert _all_projected_ids(first) == _all_projected_ids(second)
    assert first.mapping_debt == second.mapping_debt
    assert first.ledger.generated_at != second.ledger.generated_at

    first_json = json.loads(
        _contracts().serialize_readiness_ledger_json(first.ledger)
    )
    second_json = json.loads(
        _contracts().serialize_readiness_ledger_json(second.ledger)
    )
    assert first_json.pop("generated_at") == "2026-07-12T12:34:56Z"
    assert second_json.pop("generated_at") == "2026-07-12T12:34:57Z"
    assert first_json == second_json


def test_missing_action_first_values_use_conservative_defaults_with_debt() -> None:
    result = _import(_raw({"findings": [{"title": "Unclassified legacy row"}]}))

    finding = result.ledger.findings[0]
    assert (
        finding.action.value,
        finding.section.value,
        finding.severity.value,
        finding.proof.value,
        finding.confidence.value,
    ) == (
        "Prove",
        "not_proven_not_tested",
        "Unscored",
        "Not tested",
        "Hypothesis",
    )
    assert {
        "LEGACY_ACTION_DEFAULTED",
        "LEGACY_SECTION_DEFAULTED",
        "LEGACY_SEVERITY_DEFAULTED",
        "LEGACY_PROOF_DEFAULTED",
        "LEGACY_CONFIDENCE_DEFAULTED",
    }.issubset(_debt_codes(result))


def test_boundary_error_does_not_retain_raw_secret_or_exception_context() -> None:
    importer = _importer()
    marker = "SECRET-CANARY-LEGACY-5bd2"

    with pytest.raises(importer.LegacyReadinessImportError) as captured:
        _import(_raw({"findings": [{"title": marker * 20}]}))

    error = captured.value
    formatted = "".join(
        traceback.format_exception(type(error), error, error.__traceback__)
    )
    assert marker not in str(error)
    assert error.__cause__ is None
    assert error.__context__ is None
    assert marker not in formatted


def test_import_is_side_effect_free_without_filesystem_or_network_access(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    importer = _importer()
    raw = LEGACY_FIXTURE.read_bytes()

    def denied(*_args, **_kwargs):
        raise AssertionError("ambient filesystem or network access attempted")

    monkeypatch.setattr(builtins, "open", denied)
    monkeypatch.setattr(socket, "socket", denied)
    monkeypatch.setattr(socket, "create_connection", denied)

    result = importer.import_legacy_readiness_json(
        raw,
        source_relative_path=SOURCE_PATH,
        imported_at=IMPORTED_AT,
    )

    assert result.raw_bytes == raw
    assert result.ledger.artifacts[0].descriptor.digest == hashlib.sha256(raw).hexdigest()
