from __future__ import annotations

import builtins
import copy
from collections.abc import Mapping
import hashlib
import io
import json
from pathlib import Path
import sys
import traceback
from types import ModuleType, SimpleNamespace
import zipfile

import pytest

from shipworthy.adapters.importers.legacy_readiness import import_legacy_readiness_json
from shipworthy.domain.contracts import (
    ContractValidationError,
    parse_readiness_ledger_json,
    serialize_readiness_ledger_json,
)


ROOT = Path(__file__).resolve().parents[2]
FIXTURES = ROOT / "tests" / "fixtures"
LEGACY_SOURCE_PATH = "evidence/legacy/readiness-v0.json"
IMPORTED_AT = "2026-07-12T12:34:56Z"


def _reporting():
    from shipworthy.adapters import reporting

    return reporting


def _ledger(name: str):
    return parse_readiness_ledger_json((FIXTURES / "v1" / name).read_bytes())


def _candidate(name: str) -> dict[str, object]:
    return json.loads((FIXTURES / "v1" / name).read_bytes())


def _zip(bundle: bytes) -> tuple[zipfile.ZipFile, dict[str, object]]:
    archive = zipfile.ZipFile(io.BytesIO(bundle))
    return archive, json.loads(archive.read("manifest.json"))


def _render_custom_html(
    document: str, monkeypatch: pytest.MonkeyPatch
) -> bytes:
    reporting = _reporting()
    from shipworthy.adapters.reporting import html as html_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )

    class CustomRenderer:
        @staticmethod
        def render(_data, interactive=False):
            return document

    monkeypatch.setattr(
        html_adapter, "load_legacy_renderer", lambda: CustomRenderer
    )
    return reporting.render_readiness_html(projection)


def _legacy_sarif_document(projection) -> dict[str, object]:
    from shipworthy.adapters.reporting.compat_loader import load_legacy_sarif

    return load_legacy_sarif().to_sarif(projection.legacy_report_data())


def _two_finding_projection():
    reporting = _reporting()
    candidate = _candidate("confirmed-blocker-ledger.json")
    second_artifact = copy.deepcopy(candidate["artifacts"][0])
    second_artifact["artifact_id"] = "ART-CHECKOUT-501"
    second_artifact["descriptor"]["digest"] = "d" * 64
    second_artifact["descriptor"]["relative_path"] = "evidence/checkout-501.json"
    second_finding = copy.deepcopy(candidate["findings"][0])
    second_finding["artifact_ids"] = ["ART-CHECKOUT-501"]
    second_finding["finding_id"] = "FND-CHECKOUT-002"
    second_finding["subject"]["ref"] = "checkout.payment-second-error"
    second_finding["subject"]["title"] = "Second payment failure advances"
    candidate["artifacts"].append(second_artifact)
    candidate["findings"].append(second_finding)
    ledger = parse_readiness_ledger_json(json.dumps(candidate).encode())
    return reporting.ReportingProjection.from_ledger(ledger)


def _artifact_budget_projection(count: int, payload: bytes):
    reporting = _reporting()
    candidate = _candidate("confirmed-blocker-ledger.json")
    base_artifact = candidate["artifacts"][0]
    candidate["artifacts"] = []
    candidate["findings"] = []
    candidate["ledger_id"] = f"LED-BUDGET-{count:03d}"
    candidate["readiness_disposition"] = "ready"
    digest = hashlib.sha256(payload).hexdigest()
    artifact_bytes = {}
    for index in range(count):
        artifact = copy.deepcopy(base_artifact)
        artifact_id = f"ART-BUDGET-{index:03d}"
        artifact["artifact_id"] = artifact_id
        artifact["descriptor"]["byte_size"] = len(payload)
        artifact["descriptor"]["declared_media_type"] = "application/octet-stream"
        artifact["descriptor"]["digest"] = digest
        artifact["descriptor"]["relative_path"] = f"evidence/budget-{index:03d}.bin"
        candidate["artifacts"].append(artifact)
        artifact_bytes[artifact_id] = payload
    ledger = parse_readiness_ledger_json(json.dumps(candidate).encode())
    return reporting.ReportingProjection.from_ledger(ledger), artifact_bytes


def test_action_first_ledger_projects_one_to_one_with_exact_counts_and_stable_bytes() -> None:
    reporting = _reporting()
    ledger = parse_readiness_ledger_json(
        json.dumps(
            _candidate("pure-action-first-report-input.json")["source_ledger"]
        ).encode()
    )

    first = reporting.ReportingProjection.from_ledger(ledger)
    second = reporting.ReportingProjection.from_ledger(ledger)

    assert first == second
    assert first.ledger_json == serialize_readiness_ledger_json(ledger)
    assert first.canonical_finding_count == 1
    assert first.evidence_debt_count == 0
    assert first.total_report_row_count == 1
    assert first.record_ids == ("FND-COUPON-001",)
    assert dict(first.section_counts) == {"fix_next": 1}
    assert dict(first.action_counts) == {"Fix": 1}
    assert dict(first.compatibility_severity_counts) == {"strong": 1}
    row = first.rows[0]
    assert row.record_kind == "finding"
    assert row.record_id == "FND-COUPON-001"
    assert row.action == "Fix"
    assert row.proof == "Partial"
    assert row.section == "fix_next"
    assert row.severity == "P1 Major"
    assert row.compatibility_severity == "strong"
    assert row.confidence == "Strong"
    assert row.location == "src/checkout/coupon.py"
    assert first.gate_outcome == "passed"
    assert first.gate_blocking_finding_ids == ()
    artifact = first.artifacts[0]
    assert artifact.declared_media_type == "application/json"
    assert artifact.digest_algorithm == "sha256"
    assert artifact.digest == "a" * 64
    assert artifact.byte_size == 128


def test_confirmed_blocker_reconciles_html_sarif_manifest_and_canonical_gate() -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )

    html_bytes = reporting.render_readiness_html(projection)
    sarif = reporting.render_readiness_sarif(projection)
    bundle = reporting.build_evidence_bundle(projection)
    archive, manifest = _zip(bundle)

    assert b"Clear Before Ship" in html_bytes
    assert b"FND-CHECKOUT-001" in html_bytes
    assert b"confirmed_only gate outcome: failed" in html_bytes
    assert b"confirmed blocker IDs: FND-CHECKOUT-001" in html_bytes
    assert b'<span class="n">1</span><span class="l">Required Fixes</span>' in html_bytes
    result = sarif["runs"][0]["results"][0]
    assert result["level"] == "error"
    assert result["properties"]["record_id"] == "FND-CHECKOUT-001"
    assert manifest["gate"] == {
        "blocking_finding_ids": ["FND-CHECKOUT-001"],
        "outcome": "failed",
        "policy": "confirmed_only",
    }
    assert manifest["counts"]["canonical_findings"] == 1
    assert manifest["counts"]["total_report_rows"] == 1
    assert manifest["schema_name"] == projection.ledger.schema_name
    assert manifest["schema_version"] == projection.ledger.schema_version
    assert manifest["generated_at"] == projection.ledger.generated_at
    assert manifest["producer"] == {
        "name": projection.ledger.producer.name,
        "version": projection.ledger.producer.version,
    }
    assert manifest["records"][0]["record_id"] == result["properties"]["record_id"]
    assert manifest["records"][0]["title"] in result["message"]["text"]
    assert json.loads(archive.read("readiness.sarif")) == sarif
    assert archive.read("readiness-report.html") == html_bytes


def test_nonconfirmed_p0_is_error_level_without_failing_confirmed_only_gate() -> None:
    reporting = _reporting()
    candidate = _candidate("pure-action-first-report-input.json")["source_ledger"]
    candidate["findings"][0]["severity"] = "P0 Blocker"
    ledger = parse_readiness_ledger_json(json.dumps(candidate).encode())
    projection = reporting.ReportingProjection.from_ledger(ledger)

    result = reporting.render_readiness_sarif(projection)["runs"][0]["results"][0]
    _, manifest = _zip(reporting.build_evidence_bundle(projection))

    assert result["level"] == "error"
    assert result["properties"]["canonical_severity"] == "P0 Blocker"
    assert projection.gate_outcome == "passed"
    assert projection.gate_blocking_finding_ids == ()
    assert manifest["gate"]["outcome"] == "passed"
    assert manifest["gate"]["blocking_finding_ids"] == []
    assert manifest["counts"]["compatibility_severity"] == {"blocker": 1}


def test_disposition_labels_are_explicit_without_upgrading_uncertainty() -> None:
    reporting = _reporting()
    conditional = parse_readiness_ledger_json(
        json.dumps(
            _candidate("pure-action-first-report-input.json")["source_ledger"]
        ).encode()
    )
    not_ready = _ledger("confirmed-blocker-ledger.json")
    cannot_determine = _ledger("incomplete-ledger.json")
    ready_candidate = _candidate("confirmed-blocker-ledger.json")
    ready_candidate["artifacts"] = []
    ready_candidate["findings"] = []
    ready_candidate["readiness_disposition"] = "ready"
    ready = parse_readiness_ledger_json(json.dumps(ready_candidate).encode())

    labels = {
        ledger.readiness_disposition.value: reporting.ReportingProjection.from_ledger(
            ledger
        ).renderer_verdict
        for ledger in (ready, conditional, not_ready, cannot_determine)
    }

    assert labels == {
        "ready": "READY",
        "conditionally_ready": "CONDITIONALLY READY",
        "not_ready": "NOT READY",
        "cannot_determine": "CANNOT DETERMINE",
    }


def test_incomplete_zero_finding_ledger_emits_explicit_debt_row_everywhere() -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )

    assert projection.canonical_finding_count == 0
    assert projection.evidence_debt_count == 1
    assert projection.total_report_row_count == 1
    row = projection.rows[0]
    assert row.record_kind == "evidence_debt"
    assert row.record_id == "ED-LOAD-001"
    assert row.action == "Prove"
    assert row.proof == "Not tested"
    assert row.section == "not_proven_not_tested"
    assert row.compatibility_severity == "info"

    html_bytes = reporting.render_readiness_html(projection)
    sarif = reporting.render_readiness_sarif(projection)
    archive, manifest = _zip(reporting.build_evidence_bundle(projection))

    assert b"Cannot Determine" in html_bytes
    assert b"ED-LOAD-001" in html_bytes
    assert b"Not tested" in html_bytes
    assert b"No blocking or open findings were recorded" not in html_bytes
    assert b"Ready</span>" not in html_bytes
    assert sarif["runs"][0]["results"][0]["properties"]["record_kind"] == "evidence_debt"
    assert manifest["completion_status"] == "incomplete"
    assert manifest["readiness_disposition"] == "cannot_determine"
    assert manifest["gate"]["outcome"] == "incomplete"
    assert manifest["counts"]["evidence_debt"] == 1
    assert archive.read("readiness-report.html") == html_bytes


def test_missing_artifact_keeps_mandatory_report_and_explicit_manifest_status() -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("missing-artifact-ledger.json")
    )

    archive, manifest = _zip(reporting.build_evidence_bundle(projection))

    assert "readiness-report.html" in archive.namelist()
    assert b"ART-MISSING-001" in archive.read("readiness-report.html")
    assert manifest["artifacts"] == [
        {
            "artifact_id": "ART-MISSING-001",
            "availability": "missing",
            "byte_size": None,
            "bundle_path": None,
            "declared_media_type": "application/json",
            "digest": None,
            "digest_algorithm": "sha256",
            "inclusion_status": "not_includable",
            "relative_path": "evidence/missing-result.json",
        }
    ]


def test_legacy_import_renders_neutrally_and_bundle_includes_exact_raw_bytes() -> None:
    reporting = _reporting()
    raw = (FIXTURES / "legacy" / "readiness-v0.json").read_bytes()
    imported = import_legacy_readiness_json(
        raw,
        source_relative_path=LEGACY_SOURCE_PATH,
        imported_at=IMPORTED_AT,
    )
    projection = reporting.ReportingProjection.from_ledger(imported.ledger)
    raw_artifact_id = imported.ledger.artifacts[0].artifact_id

    archive, manifest = _zip(
        reporting.build_evidence_bundle(
            projection, artifact_bytes={raw_artifact_id: imported.raw_bytes}
        )
    )
    artifact_status = manifest["artifacts"][0]

    assert b"Cannot Determine" in archive.read("readiness-report.html")
    assert b"Ready</span>" not in archive.read("readiness-report.html")
    assert artifact_status["inclusion_status"] == "included"
    assert artifact_status["declared_media_type"] == "application/json"
    assert artifact_status["digest_algorithm"] == "sha256"
    assert artifact_status["digest"] == imported.sha256
    assert artifact_status["byte_size"] == len(raw)
    assert archive.read(artifact_status["bundle_path"]) == raw
    optional_entry = next(
        item
        for item in manifest["entries"]
        if item["name"] == artifact_status["bundle_path"]
    )
    assert optional_entry["media_type"] == "application/json"
    assert hashlib.sha256(raw).hexdigest() == imported.sha256


def test_html_escapes_hostile_text_and_has_no_active_or_remote_content() -> None:
    reporting = _reporting()
    candidate = _candidate("pure-action-first-report-input.json")["source_ledger"]
    marker = '<script src="https://evil.invalid/x.js">alert(1)</script>'
    candidate["findings"][0]["subject"]["title"] = marker
    candidate["findings"][0]["summary"] = marker
    ledger = parse_readiness_ledger_json(json.dumps(candidate).encode())

    html_text = reporting.render_readiness_html(
        reporting.ReportingProjection.from_ledger(ledger)
    ).decode()

    assert marker not in html_text
    assert "&lt;script src=&quot;https://evil.invalid/x.js&quot;&gt;" in html_text
    assert "<script" not in html_text.lower()
    assert "@import" not in html_text.lower()
    assert "url(http" not in html_text.lower()
    assert "<link" not in html_text.lower()
    assert "src=\"http" not in html_text.lower()


def test_html_safety_validation_distinguishes_safe_prose_from_markup(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import html as html_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )
    safe = """<!doctype html>
<html><head><meta charset="utf-8"><style>body { color: #111; }</style></head>
<body><div><p id="details">
Safe prose: @import url(https://example.invalid/a.css), javascript:, data:,
&lt;script&gt;alert(1)&lt;/script&gt; and &lt;svg onload=alert(1)&gt;.
</p></div></body></html>"""

    class SafeRenderer:
        @staticmethod
        def render(_data, interactive=False):
            return safe

    monkeypatch.setattr(html_adapter, "load_legacy_renderer", lambda: SafeRenderer)

    assert reporting.render_readiness_html(projection) == safe.encode()


@pytest.mark.parametrize(
    "active_markup",
    [
        "<script>alert(1)</script>",
        "<iframe></iframe>",
        "<object></object>",
        "<embed>",
        "<form></form>",
        '<link rel="stylesheet" href="#local">',
        '<base href="#local">',
        "<frame>",
        "<frameset></frameset>",
        "<applet></applet>",
        '<svg onload="alert(1)"></svg>',
        "<math><mi>x</mi></math>",
        '<div onclick="alert(1)">x</div>',
        '<DIV ONFOCUS="alert(1)">x</DIV>',
        '<meta http-equiv="refresh" content="0;url=/next">',
        '<a href="javascript:alert(1)">x</a>',
        '<a href="java&#x09;script:alert(1)">x</a>',
        '<a href="data:text/html,boom">x</a>',
        '<a href="vbscript:boom">x</a>',
        '<a href="file:///tmp/secret">x</a>',
        '<a href="https://example.invalid">x</a>',
        '<a href="HTTP://example.invalid">x</a>',
        '<a href="//example.invalid">x</a>',
        '<a href="&#x2f;&#x2f;example.invalid">x</a>',
        '<a href="relative/page.html">x</a>',
        '<img src="relative/image.png">',
        '<video poster="relative/poster.png"></video>',
        '<button formaction="relative/submit">x</button>',
        '<div data="https://example.invalid/x">x</div>',
        '<div style="background:url(https://example.invalid/a.png)">x</div>',
        '<div style="background:u/**/rl(relative.png)">x</div>',
        '<div style="background:image(relative.png)">x</div>',
        '<div style="width:expression(alert(1))">x</div>',
        '<div style="behavior:url(x.htc)">x</div>',
        '<div style="-moz-binding:url(x.xml#x)">x</div>',
        "<style>@import 'https://example.invalid/a.css';</style>",
        "<style>@im/**/port 'relative.css';</style>",
        r"<style>body{background:u\72l(relative.png)}</style>",
        "<style>body{background:url(relative.png)}</style>",
        "<style>body{width:expression(alert(1))}</style>",
    ],
)
def test_html_safety_validation_rejects_active_markup_sanitized(
    active_markup: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import html as html_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )
    marker = "SECRET-CANARY-structural-html"
    document = (
        "<!doctype html><html><head><meta charset=\"utf-8\"></head>"
        f"<body>{active_markup}<p>{marker}</p></body></html>"
    )

    class UnsafeRenderer:
        @staticmethod
        def render(_data, interactive=False):
            return document

    monkeypatch.setattr(
        html_adapter, "load_legacy_renderer", lambda: UnsafeRenderer
    )
    with pytest.raises(
        reporting.ReportingTransformError,
        match="readiness HTML safety validation failed",
    ) as captured:
        reporting.render_readiness_html(projection)

    formatted = "".join(
        traceback.format_exception(
            type(captured.value), captured.value, captured.value.__traceback__
        )
    )
    assert marker not in str(captured.value)
    assert marker not in formatted
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


@pytest.mark.parametrize(
    "malformed",
    [
        "<html><head></head><body><div></body></html>",
        "<html><head></head><body><div></div>",
        "<html><head></head><body></body></html><p>after root</p>",
        "<html><head><body></body></head></html>",
        "<html><head></head><div></div><body></body></html>",
        "<html><head/><body></body></html>",
    ],
)
def test_html_safety_validation_rejects_unbalanced_documents(
    malformed: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import html as html_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )

    class MalformedRenderer:
        @staticmethod
        def render(_data, interactive=False):
            return "<!doctype html>" + malformed

    monkeypatch.setattr(
        html_adapter, "load_legacy_renderer", lambda: MalformedRenderer
    )
    with pytest.raises(
        reporting.ReportingTransformError,
        match="readiness HTML safety validation failed",
    ):
        reporting.render_readiness_html(projection)


@pytest.mark.parametrize(
    "forbidden_element",
    [
        "plaintext",
        "xmp",
        "listing",
        "noembed",
        "noframes",
        "noscript",
        "template",
        "a",
        "table",
        "caption",
        "colgroup",
        "thead",
        "tbody",
        "tfoot",
        "tr",
        "th",
        "td",
        "img",
        "input",
        "source",
        "textarea",
        "select",
        "button",
        "video",
        "audio",
        "custom-element",
    ],
)
def test_noninteractive_html_grammar_rejects_every_unemitted_element(
    forbidden_element: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    document = (
        "<!doctype html><html><head><meta charset=\"utf-8\"><title>x</title>"
        "<style>body{color:#111}</style></head><body><div>"
        f"<{forbidden_element}>safe text</{forbidden_element}>"
        "</div></body></html>"
    )

    with pytest.raises(
        reporting.ReportingTransformError,
        match="readiness HTML safety validation failed",
    ):
        _render_custom_html(document, monkeypatch)


@pytest.mark.parametrize(
    "invalid_body",
    [
        "<h1>x</h1>",
        "<article><h3>x</h3></article>",
        "<details><summary>x</summary></details>",
        "<footer><b>x</b></footer>",
        "<title>x</title>",
        "<style>body{color:#111}</style>",
        '<meta charset="utf-8">',
        "<div><article><h3>x</h3></article></div>",
        "<section><footer><b>x</b></footer></section>",
        "<p><div>x</div></p>",
        "<span><p>x</p></span>",
        "<table><div>x</div></table>",
        '<a href="#x"><a href="#y">nested</a></a>',
    ],
)
def test_noninteractive_html_grammar_rejects_invalid_body_pairs_and_head_tags(
    invalid_body: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    document = (
        "<!doctype html><html><head><meta charset=\"utf-8\"><title>x</title>"
        "<style>body{color:#111}</style></head>"
        f"<body>{invalid_body}</body></html>"
    )

    with pytest.raises(
        reporting.ReportingTransformError,
        match="readiness HTML safety validation failed",
    ):
        _render_custom_html(document, monkeypatch)


@pytest.mark.parametrize(
    "invalid_document",
    [
        (
            '<!doctype html><html><head><meta charset="utf-8"><div>x</div>'
            "</head><body><div></div></body></html>"
        ),
        (
            '<!doctype html><html><head><meta charset="utf-8"><title>x</title>'
            "<style>body{color:#111}</style><body><div></div></body></head></html>"
        ),
        (
            '<!doctype html><html><head><meta charset="utf-8"></head>'
            "<head><title>x</title></head><body><div></div></body></html>"
        ),
        (
            '<!doctype html><html><body><div></div></body><head>'
            '<meta charset="utf-8"><title>x</title></head></html>'
        ),
        (
            '<!doctype html><html><head><meta charset="utf-8"><title>x</title>'
            "<style>body{color:#111}</style></head><body><div></div></body>"
            "<body><div></div></body></html>"
        ),
    ],
)
def test_noninteractive_html_grammar_rejects_head_body_misplacement(
    invalid_document: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()

    with pytest.raises(
        reporting.ReportingTransformError,
        match="readiness HTML safety validation failed",
    ):
        _render_custom_html(invalid_document, monkeypatch)


@pytest.mark.parametrize(
    "parser_differential",
    [
        "<plaintext><script>alert(1)</script>",
        "<xmp><script>alert(1)</script></xmp>",
        "<listing><script>alert(1)</script></listing>",
        "<noembed><script>alert(1)</script></noembed>",
        "<noframes><script>alert(1)</script></noframes>",
        "<noscript><script>alert(1)</script></noscript>",
        "<template><script>alert(1)</script></template>",
    ],
)
def test_noninteractive_html_grammar_rejects_obsolete_raw_text_differentials(
    parser_differential: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    document = (
        "<!doctype html><html><head><meta charset=\"utf-8\"><title>x</title>"
        "<style>body{color:#111}</style></head><body><div>"
        f"{parser_differential}</div></body></html>"
    )

    with pytest.raises(
        reporting.ReportingTransformError,
        match="readiness HTML safety validation failed",
    ):
        _render_custom_html(document, monkeypatch)


@pytest.mark.parametrize(
    "forbidden_syntax",
    [
        "<!-- ordinary comment -->",
        "<!--[if IE]><script>alert(1)</script><![endif]-->",
        "<?processing instruction?>",
        "<![CDATA[raw declaration]]>",
    ],
)
def test_noninteractive_html_grammar_rejects_comments_and_declarations(
    forbidden_syntax: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    document = (
        "<!doctype html><html><head><meta charset=\"utf-8\"><title>x</title>"
        "<style>body{color:#111}</style></head><body><div>"
        f"{forbidden_syntax}</div></body></html>"
    )

    with pytest.raises(
        reporting.ReportingTransformError,
        match="readiness HTML safety validation failed",
    ):
        _render_custom_html(document, monkeypatch)


def test_all_default_noninteractive_renderer_variants_match_frozen_grammar() -> None:
    reporting = _reporting()
    ledgers = [
        _ledger("confirmed-blocker-ledger.json"),
        _ledger("incomplete-ledger.json"),
        _ledger("missing-artifact-ledger.json"),
    ]
    action_first = _candidate("pure-action-first-report-input.json")[
        "source_ledger"
    ]
    ledgers.append(
        parse_readiness_ledger_json(json.dumps(action_first).encode())
    )
    legacy_raw = (FIXTURES / "legacy" / "readiness-v0.json").read_bytes()
    ledgers.append(
        import_legacy_readiness_json(
            legacy_raw,
            source_relative_path=LEGACY_SOURCE_PATH,
            imported_at=IMPORTED_AT,
        ).ledger
    )
    clean = _candidate("confirmed-blocker-ledger.json")
    clean["artifacts"] = []
    clean["findings"] = []
    clean["ledger_id"] = "LED-CLEAN-001"
    clean["readiness_disposition"] = "ready"
    ledgers.append(parse_readiness_ledger_json(json.dumps(clean).encode()))

    rendered = [
        reporting.render_readiness_html(
            reporting.ReportingProjection.from_ledger(ledger)
        )
        for ledger in ledgers
    ]

    assert len(rendered) == 6
    assert all(document.startswith(b"<!doctype html>") for document in rendered)


def test_bundle_is_byte_deterministic_and_every_payload_digest_reconciles() -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )
    html_bytes = reporting.render_readiness_html(projection)
    sarif_bytes = reporting.render_readiness_sarif_bytes(projection)

    first = reporting.build_evidence_bundle(projection)
    second = reporting.build_evidence_bundle(projection)
    archive, manifest = _zip(first)

    assert first == second
    assert archive.namelist() == [
        "ledger.json",
        "readiness-report.html",
        "readiness.sarif",
        "manifest.json",
        "README.txt",
    ]
    assert archive.read("ledger.json") == projection.ledger_json
    assert archive.read("readiness-report.html") == html_bytes
    assert archive.read("readiness.sarif") == sarif_bytes
    assert set(item["name"] for item in manifest["entries"]) == (
        set(archive.namelist()) - {"manifest.json"}
    )
    for item in manifest["entries"]:
        payload = archive.read(item["name"])
        assert item["bytes"] == len(payload)
        assert item["sha256"] == hashlib.sha256(payload).hexdigest()
        assert isinstance(item["media_type"], str)
    media_types = {
        item["name"]: item["media_type"] for item in manifest["entries"]
    }
    assert media_types == {
        "README.txt": "text/plain; charset=utf-8",
        "ledger.json": "application/json",
        "readiness-report.html": "text/html; charset=utf-8",
        "readiness.sarif": "application/sarif+json",
    }
    assert "not signed" in archive.read("README.txt").decode().lower()
    assert "not attested" in archive.read("README.txt").decode().lower()
    assert "not tamper-proof" in archive.read("README.txt").decode().lower()


@pytest.mark.parametrize(
    ("artifact_bytes", "match"),
    [
        ({"ART-UNKNOWN-001": b"raw"}, "artifact bytes failed validation"),
        ({"ART-MISSING-001": b"raw"}, "artifact bytes failed validation"),
        ({"ART-X": "not bytes"}, "artifact bytes failed validation"),
    ],
)
def test_invalid_artifact_inputs_fail_sanitized_without_filesystem_or_partial_output(
    artifact_bytes: dict[str, object], match: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("missing-artifact-ledger.json")
    )
    marker = "SECRET-CANARY-invalid-artifact"
    artifact_bytes = {
        (marker if key == "ART-X" else key): value
        for key, value in artifact_bytes.items()
    }
    original_open = builtins.open
    calls: list[tuple[object, ...]] = []

    def guarded_open(*args, **kwargs):
        calls.append(args)
        return original_open(*args, **kwargs)

    monkeypatch.setattr(builtins, "open", guarded_open)
    with pytest.raises(reporting.ReportingArtifactError, match=match) as captured:
        reporting.build_evidence_bundle(projection, artifact_bytes=artifact_bytes)

    assert marker not in str(captured.value)
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None
    assert calls == []


@pytest.mark.parametrize("failure", ["digest", "size"])
def test_artifact_digest_or_size_mismatch_fails_sanitized(failure: str) -> None:
    reporting = _reporting()
    raw = (FIXTURES / "legacy" / "readiness-v0.json").read_bytes()
    imported = import_legacy_readiness_json(
        raw,
        source_relative_path=LEGACY_SOURCE_PATH,
        imported_at=IMPORTED_AT,
    )
    projection = reporting.ReportingProjection.from_ledger(imported.ledger)
    artifact_id = imported.ledger.artifacts[0].artifact_id
    wrong = (
        bytes((raw[0] ^ 1,)) + raw[1:]
        if failure == "digest"
        else raw + b"x"
    )

    with pytest.raises(
        reporting.ReportingArtifactError, match="artifact bytes failed validation"
    ) as captured:
        reporting.build_evidence_bundle(
            projection, artifact_bytes={artifact_id: wrong}
        )

    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_available_artifact_without_bytes_is_honestly_referenced_only() -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )

    _, manifest = _zip(reporting.build_evidence_bundle(projection))

    assert manifest["artifacts"][0]["inclusion_status"] == "referenced_only"
    assert manifest["artifacts"][0]["bundle_path"] is None


def test_known_available_artifact_rejects_nonbytes_without_exposing_value() -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )
    artifact_id = projection.artifacts[0].artifact_id
    marker = "SECRET-CANARY-nonbytes"

    with pytest.raises(
        reporting.ReportingArtifactError, match="artifact bytes failed validation"
    ) as captured:
        reporting.build_evidence_bundle(
            projection, artifact_bytes={artifact_id: marker}
        )

    assert marker not in str(captured.value)
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_artifact_mapping_stops_at_first_invalid_streamed_entry() -> None:
    reporting = _reporting()
    projection, _ = _artifact_budget_projection(1, b"x")

    class HostileMapping(Mapping):
        def __init__(self):
            self.consumed = 0

        def __len__(self):
            return 100_000

        def __iter__(self):
            return iter(())

        def __getitem__(self, _key):
            raise KeyError

        def items(self):
            for _ in range(100_000):
                self.consumed += 1
                yield ("ART-UNKNOWN-STREAM", b"x")

    hostile = HostileMapping()

    with pytest.raises(
        reporting.ReportingArtifactError, match="artifact bytes failed validation"
    ) as captured:
        reporting.build_evidence_bundle(projection, artifact_bytes=hostile)

    assert hostile.consumed == 1
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_artifact_mapping_rejects_duplicate_yielded_ids_incrementally() -> None:
    reporting = _reporting()
    projection, artifacts = _artifact_budget_projection(2, b"x")
    first_id = projection.artifacts[0].artifact_id

    class DuplicateMapping(Mapping):
        def __len__(self):
            return 2

        def __iter__(self):
            return iter((first_id,))

        def __getitem__(self, key):
            return artifacts[key]

        def items(self):
            yield (first_id, artifacts[first_id])
            yield (first_id, artifacts[first_id])

    with pytest.raises(
        reporting.ReportingArtifactError, match="artifact bytes failed validation"
    ):
        reporting.build_evidence_bundle(
            projection, artifact_bytes=DuplicateMapping()
        )


def test_phase0_artifact_entry_cap_accepts_at_limit_and_rejects_over() -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import bundle as bundle_adapter

    cap = bundle_adapter.PHASE0_MAX_INCLUDED_ARTIFACT_COUNT
    at_projection, at_payloads = _artifact_budget_projection(cap, b"x")
    over_projection, over_payloads = _artifact_budget_projection(cap + 1, b"x")

    at_bundle = reporting.build_evidence_bundle(
        at_projection, artifact_bytes=at_payloads
    )
    with pytest.raises(
        reporting.ReportingArtifactError, match="artifact bytes failed validation"
    ):
        reporting.build_evidence_bundle(
            over_projection, artifact_bytes=over_payloads
        )

    at_archive, at_manifest = _zip(at_bundle)
    included = [
        row
        for row in at_manifest["artifacts"]
        if row["inclusion_status"] == "included"
    ]
    assert len(included) == cap
    assert len(at_archive.namelist()) == cap + 5


def test_phase0_per_artifact_budget_accepts_at_limit_and_rejects_over() -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import bundle as bundle_adapter

    limit = bundle_adapter.PHASE0_MAX_ARTIFACT_BYTES
    at_payload = b"0" * limit
    over_payload = b"0" * (limit + 1)
    at_projection, at_payloads = _artifact_budget_projection(1, at_payload)
    over_projection, over_payloads = _artifact_budget_projection(1, over_payload)

    reporting.build_evidence_bundle(at_projection, artifact_bytes=at_payloads)
    with pytest.raises(
        reporting.ReportingArtifactError, match="artifact bytes failed validation"
    ):
        reporting.build_evidence_bundle(
            over_projection, artifact_bytes=over_payloads
        )


def test_phase0_aggregate_artifact_budget_accepts_at_limit_and_rejects_over() -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import bundle as bundle_adapter

    per_artifact = bundle_adapter.PHASE0_MAX_ARTIFACT_BYTES
    at_count = (
        bundle_adapter.PHASE0_MAX_AGGREGATE_ARTIFACT_BYTES // per_artifact
    )
    assert at_count * per_artifact == (
        bundle_adapter.PHASE0_MAX_AGGREGATE_ARTIFACT_BYTES
    )
    payload = b"0" * per_artifact
    at_projection, at_payloads = _artifact_budget_projection(at_count, payload)
    over_projection, over_payloads = _artifact_budget_projection(
        at_count + 1, payload
    )

    reporting.build_evidence_bundle(at_projection, artifact_bytes=at_payloads)
    with pytest.raises(
        reporting.ReportingArtifactError, match="artifact bytes failed validation"
    ):
        reporting.build_evidence_bundle(
            over_projection, artifact_bytes=over_payloads
        )


def test_phase0_total_uncompressed_budget_accepts_at_limit_and_rejects_over(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import bundle as bundle_adapter

    projection, _ = _artifact_budget_projection(0, b"")
    baseline = reporting.build_evidence_bundle(projection)
    candidate_limit = sum(info.file_size for info in _zip(baseline)[0].infolist())

    for _ in range(4):
        monkeypatch.setattr(
            bundle_adapter,
            "PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES",
            candidate_limit,
        )
        at_bundle = reporting.build_evidence_bundle(projection)
        actual = sum(info.file_size for info in _zip(at_bundle)[0].infolist())
        if actual == candidate_limit:
            break
        candidate_limit = actual

    assert actual == candidate_limit
    monkeypatch.setattr(
        bundle_adapter,
        "PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES",
        actual - 1,
    )
    with pytest.raises(
        reporting.ReportingArtifactError,
        match="evidence bundle exceeds Phase 0 budget",
    ):
        reporting.build_evidence_bundle(projection)


def test_total_budget_fails_before_zip_compression(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import bundle as bundle_adapter

    projection, _ = _artifact_budget_projection(0, b"")
    marker = "SECRET-CANARY-zip-must-not-start"
    monkeypatch.setattr(
        bundle_adapter, "PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES", 1
    )

    class ForbiddenZip:
        def __init__(self, *_args, **_kwargs):
            raise AssertionError(marker)

    monkeypatch.setattr(bundle_adapter.zipfile, "ZipFile", ForbiddenZip)
    with pytest.raises(
        reporting.ReportingArtifactError,
        match="evidence bundle exceeds Phase 0 budget",
    ) as captured:
        reporting.build_evidence_bundle(projection)

    assert marker not in str(captured.value)
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_manifest_exposes_phase0_bundle_budget_policy() -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import bundle as bundle_adapter

    projection, _ = _artifact_budget_projection(0, b"")
    _, manifest = _zip(reporting.build_evidence_bundle(projection))

    assert manifest["phase0_bundle_policy"] == {
        "applies_to": "Phase 0 local reporting bundles only",
        "max_aggregate_artifact_bytes": (
            bundle_adapter.PHASE0_MAX_AGGREGATE_ARTIFACT_BYTES
        ),
        "max_artifact_bytes": bundle_adapter.PHASE0_MAX_ARTIFACT_BYTES,
        "max_included_artifact_count": (
            bundle_adapter.PHASE0_MAX_INCLUDED_ARTIFACT_COUNT
        ),
        "max_total_uncompressed_bundle_bytes": (
            bundle_adapter.PHASE0_MAX_TOTAL_UNCOMPRESSED_BUNDLE_BYTES
        ),
    }


def test_projection_revalidates_and_rejects_invalid_model_copy() -> None:
    reporting = _reporting()
    invalid = _ledger("confirmed-blocker-ledger.json").model_copy(
        update={"schema_version": "9.9"}
    )

    with pytest.raises(ContractValidationError):
        reporting.ReportingProjection.from_ledger(invalid)


def test_sarif_has_one_result_per_row_stable_ids_properties_and_honest_location() -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )

    first = reporting.render_readiness_sarif(projection)
    second = reporting.render_readiness_sarif(projection)
    result = first["runs"][0]["results"][0]

    assert first == second
    assert len(first["runs"][0]["results"]) == projection.total_report_row_count
    assert result["partialFingerprints"] == {
        "shipworthyRecordHash/v1": hashlib.sha256(
            b"finding\x00FND-CHECKOUT-001"
        ).hexdigest()
    }
    assert result["properties"] == {
        "action": "Fix",
        "canonical_confidence": "Confirmed",
        "canonical_severity": "P0 Blocker",
        "proof": "Confirmed",
        "record_id": "FND-CHECKOUT-001",
        "record_kind": "finding",
        "section": "clear_before_ship",
    }
    physical = result["locations"][0]["physicalLocation"]
    assert physical["artifactLocation"]["uri"] == "src/checkout/payment.py"
    assert "region" not in physical
    assert first["runs"][0]["properties"]["gate"]["outcome"] == "failed"


def test_sarif_never_mutates_shared_transform_output_or_reuses_caller_mutation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )
    shared = _legacy_sarif_document(projection)
    pristine = copy.deepcopy(shared)

    class SharedTransform:
        @staticmethod
        def to_sarif(_data):
            return shared

    monkeypatch.setattr(
        sarif_adapter, "load_legacy_sarif", lambda: SharedTransform
    )

    first = reporting.render_readiness_sarif(projection)
    assert shared == pristine
    first["runs"][0]["results"][0]["message"]["text"] = "caller mutation"
    second = reporting.render_readiness_sarif(projection)

    assert shared == pristine
    assert second["runs"][0]["results"][0]["message"]["text"] != (
        "caller mutation"
    )
    assert first is not second


def test_sarif_rejects_reordered_results_instead_of_mislabeling_them(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = _two_finding_projection()
    reordered = _legacy_sarif_document(projection)
    reordered["runs"][0]["results"].reverse()

    class ReorderedTransform:
        @staticmethod
        def to_sarif(_data):
            return reordered

    monkeypatch.setattr(
        sarif_adapter, "load_legacy_sarif", lambda: ReorderedTransform
    )

    with pytest.raises(
        reporting.ReportingTransformError, match="readiness SARIF rendering failed"
    ):
        reporting.render_readiness_sarif(projection)


@pytest.mark.parametrize(
    "malformation",
    [
        "schema",
        "version",
        "runs_type",
        "runs_count",
        "driver_name",
        "rules_type",
        "rules_undeclared",
        "rule_default_level",
        "result_rule_id",
        "result_level",
        "message_type",
        "message_identity",
        "location_missing",
        "location_wrong_uri",
        "location_invented_line",
        "non_json",
        "nan",
    ],
)
def test_sarif_rejects_malformed_or_non_json_transform_output_sanitized(
    malformation: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )
    document = _legacy_sarif_document(projection)
    run = document["runs"][0]
    driver = run["tool"]["driver"]
    result = run["results"][0]
    marker = f"SECRET-CANARY-sarif-{malformation}"

    if malformation == "schema":
        document["$schema"] = marker
    elif malformation == "version":
        document["version"] = "2.0.0"
    elif malformation == "runs_type":
        document["runs"] = {"unexpected": marker}
    elif malformation == "runs_count":
        document["runs"].append(copy.deepcopy(run))
    elif malformation == "driver_name":
        driver["name"] = marker
    elif malformation == "rules_type":
        driver["rules"] = {"unexpected": marker}
    elif malformation == "rules_undeclared":
        driver["rules"] = []
    elif malformation == "rule_default_level":
        driver["rules"][0]["defaultConfiguration"]["level"] = "warning"
    elif malformation == "result_rule_id":
        result["ruleId"] = "shipworthy/unrelated"
    elif malformation == "result_level":
        result["level"] = "note"
    elif malformation == "message_type":
        result["message"]["text"] = {"unexpected": marker}
    elif malformation == "message_identity":
        result["message"]["text"] = marker
    elif malformation == "location_missing":
        del result["locations"]
    elif malformation == "location_wrong_uri":
        result["locations"][0]["physicalLocation"]["artifactLocation"][
            "uri"
        ] = "src/unrelated.py"
    elif malformation == "location_invented_line":
        result["locations"][0]["physicalLocation"]["region"] = {
            "startLine": 99
        }
    elif malformation == "non_json":
        document["unexpected"] = {marker}
    elif malformation == "nan":
        document["unexpected"] = float("nan")

    class MalformedTransform:
        @staticmethod
        def to_sarif(_data):
            return document

    monkeypatch.setattr(
        sarif_adapter, "load_legacy_sarif", lambda: MalformedTransform
    )
    with pytest.raises(
        reporting.ReportingTransformError, match="readiness SARIF rendering failed"
    ) as captured:
        reporting.render_readiness_sarif(projection)

    formatted = "".join(
        traceback.format_exception(
            type(captured.value), captured.value, captured.value.__traceback__
        )
    )
    assert marker not in str(captured.value)
    assert marker not in formatted
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_sarif_rejects_invented_location_for_unlocated_row(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )
    document = _legacy_sarif_document(projection)
    document["runs"][0]["results"][0]["locations"] = [
        {
            "physicalLocation": {
                "artifactLocation": {"uri": "src/invented.py"}
            }
        }
    ]

    class LocatedTransform:
        @staticmethod
        def to_sarif(_data):
            return document

    monkeypatch.setattr(
        sarif_adapter, "load_legacy_sarif", lambda: LocatedTransform
    )
    with pytest.raises(
        reporting.ReportingTransformError, match="readiness SARIF rendering failed"
    ):
        reporting.render_readiness_sarif(projection)


def test_sarif_deep_copy_failure_is_sanitized(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )
    marker = "SECRET-CANARY-sarif-deepcopy"

    class ExplodingDocument(dict):
        def __deepcopy__(self, _memo):
            raise RuntimeError(marker)

    document = ExplodingDocument(_legacy_sarif_document(projection))

    class ExplodingTransform:
        @staticmethod
        def to_sarif(_data):
            return document

    monkeypatch.setattr(
        sarif_adapter, "load_legacy_sarif", lambda: ExplodingTransform
    )
    with pytest.raises(
        reporting.ReportingTransformError, match="readiness SARIF rendering failed"
    ) as captured:
        reporting.render_readiness_sarif(projection)

    assert marker not in str(captured.value)
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_sarif_bytes_serialization_failure_is_sanitized(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )
    marker = "SECRET-CANARY-sarif-bytes"
    monkeypatch.setattr(
        sarif_adapter.json,
        "dumps",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError(marker)),
    )

    with pytest.raises(
        reporting.ReportingTransformError, match="readiness SARIF rendering failed"
    ) as captured:
        reporting.render_readiness_sarif_bytes(projection)

    assert marker not in str(captured.value)
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


@pytest.mark.parametrize(
    "invalid_metadata",
    ["driver_version", "information_uri", "automation_id"],
)
def test_sarif_rejects_unapproved_driver_and_automation_metadata(
    invalid_metadata: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )
    document = _legacy_sarif_document(projection)
    marker = f"SECRET-CANARY-sarif-metadata-{invalid_metadata}"
    run = document["runs"][0]
    driver = run["tool"]["driver"]
    if invalid_metadata == "driver_version":
        driver["version"] = "unrelated-version"
    elif invalid_metadata == "information_uri":
        driver["informationUri"] = "https://example.invalid/unapproved"
    else:
        run["automationDetails"]["id"] = 42

    class InvalidMetadataTransform:
        @staticmethod
        def to_sarif(_data):
            return document

    monkeypatch.setattr(
        sarif_adapter,
        "load_legacy_sarif",
        lambda: InvalidMetadataTransform,
    )
    with pytest.raises(
        reporting.ReportingTransformError, match="readiness SARIF rendering failed"
    ) as captured:
        reporting.render_readiness_sarif(projection)

    formatted = "".join(
        traceback.format_exception(
            type(captured.value), captured.value, captured.value.__traceback__
        )
    )
    assert marker not in formatted
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_sarif_reconstructs_allowlisted_document_and_omits_extension_metadata(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("confirmed-blocker-ledger.json")
    )
    document = _legacy_sarif_document(projection)
    run = document["runs"][0]
    driver = run["tool"]["driver"]
    rule = driver["rules"][0]
    result = run["results"][0]
    document["extension"] = "drop-top"
    run["extension"] = "drop-run"
    driver["extension"] = "drop-driver"
    rule["helpUri"] = 42
    rule["extension"] = "drop-rule"
    result["extension"] = "drop-result"

    class ExtendedTransform:
        @staticmethod
        def to_sarif(_data):
            return document

    monkeypatch.setattr(
        sarif_adapter, "load_legacy_sarif", lambda: ExtendedTransform
    )
    rendered = reporting.render_readiness_sarif(projection)
    rendered_run = rendered["runs"][0]
    rendered_driver = rendered_run["tool"]["driver"]
    rendered_rule = rendered_driver["rules"][0]
    rendered_result = rendered_run["results"][0]

    assert set(rendered) == {"$schema", "runs", "version"}
    assert set(rendered_run) == {
        "automationDetails",
        "properties",
        "results",
        "tool",
    }
    assert rendered_run["automationDetails"] == {
        "id": "shipworthy-readiness"
    }
    assert set(rendered_driver) == {
        "informationUri",
        "name",
        "rules",
        "version",
    }
    assert rendered_driver["version"] == projection.ledger.producer.version
    assert rendered_driver["informationUri"] == (
        "https://github.com/NeuraCerebra-AI/shipworthy"
    )
    assert set(rendered_rule) == {
        "defaultConfiguration",
        "id",
        "name",
        "shortDescription",
    }
    assert "helpUri" not in rendered_rule
    assert set(rendered_result) == {
        "level",
        "locations",
        "message",
        "partialFingerprints",
        "properties",
        "ruleId",
    }
    assert document["runs"][0]["tool"]["driver"]["rules"][0]["helpUri"] == 42


def test_compatibility_loader_never_mutates_sys_path() -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )
    before = tuple(sys.path)

    reporting.render_readiness_html(projection)
    reporting.render_readiness_sarif(projection)

    assert tuple(sys.path) == before


def test_bundle_builder_does_not_read_or_write_artifact_paths(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )
    reporting.render_readiness_html(projection)
    reporting.render_readiness_sarif(projection)
    calls: list[tuple[object, ...]] = []

    def forbidden_open(*args, **kwargs):
        calls.append(args)
        raise AssertionError("bundle builder must not use filesystem paths")

    monkeypatch.setattr(builtins, "open", forbidden_open)

    bundle = reporting.build_evidence_bundle(projection)

    assert zipfile.is_zipfile(io.BytesIO(bundle))
    assert calls == []


def test_transform_unavailable_or_failure_is_loud_and_sanitized(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import html as html_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )
    marker = "SECRET-CANARY-render"

    def unavailable():
        raise reporting.ReportingTransformError("legacy reporting transform unavailable")

    monkeypatch.setattr(html_adapter, "load_legacy_renderer", unavailable)
    with pytest.raises(
        reporting.ReportingTransformError,
        match="legacy reporting transform unavailable",
    ):
        reporting.render_readiness_html(projection)

    class BrokenRenderer:
        @staticmethod
        def render(_data, interactive=False):
            raise RuntimeError(marker)

    monkeypatch.setattr(html_adapter, "load_legacy_renderer", lambda: BrokenRenderer)
    with pytest.raises(
        reporting.ReportingTransformError, match="readiness HTML rendering failed"
    ) as captured:
        reporting.render_readiness_html(projection)

    assert marker not in str(captured.value)
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_sarif_transform_failure_is_loud_and_sanitized(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import sarif as sarif_adapter

    projection = reporting.ReportingProjection.from_ledger(
        _ledger("incomplete-ledger.json")
    )
    marker = "SECRET-CANARY-sarif"

    class BrokenSarif:
        @staticmethod
        def to_sarif(_data):
            raise RuntimeError(marker)

    monkeypatch.setattr(sarif_adapter, "load_legacy_sarif", lambda: BrokenSarif)
    with pytest.raises(
        reporting.ReportingTransformError, match="readiness SARIF rendering failed"
    ) as captured:
        reporting.render_readiness_sarif(projection)

    assert marker not in str(captured.value)
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


_LOADER_STAGES = (
    "repository_resolution",
    "path_construction",
    "is_file",
    "spec_creation",
    "module_creation",
    "exec_module",
)


def _configure_loader_stage_failure(
    compat_loader,
    monkeypatch: pytest.MonkeyPatch,
    stage: str,
    error_type: type[BaseException],
    marker: str,
) -> None:
    class GoodPath:
        def is_file(self):
            return True

    class ExplodingJoin:
        def __truediv__(self, _other):
            raise error_type(marker)

    class ExplodingPath:
        def is_file(self):
            raise error_type(marker)

    class ExplodingLoader:
        def exec_module(self, _module):
            raise error_type(marker)

    class GoodLoader:
        def exec_module(self, _module):
            return None

    if stage == "repository_resolution":
        monkeypatch.setattr(
            compat_loader,
            "_repository_root",
            lambda: (_ for _ in ()).throw(error_type(marker)),
        )
        return
    if stage == "path_construction":
        monkeypatch.setattr(
            compat_loader, "_repository_root", lambda: ExplodingJoin()
        )
        return
    if stage == "is_file":
        monkeypatch.setattr(
            compat_loader, "_legacy_script_path", lambda _name: ExplodingPath()
        )
        return

    monkeypatch.setattr(
        compat_loader, "_legacy_script_path", lambda _name: GoodPath()
    )
    if stage == "spec_creation":
        monkeypatch.setattr(
            compat_loader.importlib.util,
            "spec_from_file_location",
            lambda *_args: (_ for _ in ()).throw(error_type(marker)),
        )
        return

    loader = ExplodingLoader() if stage == "exec_module" else GoodLoader()
    spec = SimpleNamespace(loader=loader)
    monkeypatch.setattr(
        compat_loader.importlib.util,
        "spec_from_file_location",
        lambda *_args: spec,
    )
    if stage == "module_creation":
        monkeypatch.setattr(
            compat_loader.importlib.util,
            "module_from_spec",
            lambda _spec: (_ for _ in ()).throw(error_type(marker)),
        )
    else:
        monkeypatch.setattr(
            compat_loader.importlib.util,
            "module_from_spec",
            lambda _spec: ModuleType("test_legacy_transform"),
        )


@pytest.mark.parametrize("stage", _LOADER_STAGES)
def test_compat_loader_sanitizes_every_loading_stage(
    stage: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    reporting = _reporting()
    from shipworthy.adapters.reporting import compat_loader

    marker = f"SECRET-CANARY-loader-{stage}"
    compat_loader._load_legacy_script.cache_clear()
    _configure_loader_stage_failure(
        compat_loader, monkeypatch, stage, RuntimeError, marker
    )

    with pytest.raises(reporting.ReportingTransformError) as captured:
        compat_loader.load_legacy_renderer()

    formatted = "".join(
        traceback.format_exception(
            type(captured.value), captured.value, captured.value.__traceback__
        )
    )
    assert str(captured.value) == "legacy reporting transform unavailable"
    assert marker not in formatted
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None
    compat_loader._load_legacy_script.cache_clear()


@pytest.mark.parametrize(
    "stage",
    _LOADER_STAGES,
)
@pytest.mark.parametrize("control_flow", [KeyboardInterrupt, SystemExit])
def test_compat_loader_propagates_control_flow_from_every_loading_stage(
    stage: str,
    control_flow: type[BaseException],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _reporting()
    from shipworthy.adapters.reporting import compat_loader

    marker = f"CONTROL-FLOW-{stage}-{control_flow.__name__}"

    compat_loader._load_legacy_script.cache_clear()
    _configure_loader_stage_failure(
        compat_loader, monkeypatch, stage, control_flow, marker
    )

    with pytest.raises(control_flow, match=marker):
        compat_loader.load_legacy_renderer()
    compat_loader._load_legacy_script.cache_clear()


def test_non_projection_inputs_fail_closed() -> None:
    reporting = _reporting()

    with pytest.raises(TypeError, match="ReportingProjection"):
        reporting.render_readiness_html(object())
    with pytest.raises(TypeError, match="ReportingProjection"):
        reporting.render_readiness_sarif(object())
    with pytest.raises(TypeError, match="ReportingProjection"):
        reporting.build_evidence_bundle(object())
