from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import zipfile

import pytest

from shipworthy.adapters.importers.browser_evidence import import_browser_evidence_json
from shipworthy.adapters.importers.playwright_report import (
    import_playwright_json_report,
)
from shipworthy.adapters.reporting import (
    ReportingProjection,
    build_evidence_bundle,
    render_readiness_html,
    render_readiness_sarif,
)
from shipworthy.domain.contracts import parse_readiness_ledger_json
from shipworthy.domain.evidence_attachment import attach_evidence


ROOT = Path(__file__).resolve().parents[2]


def _attached_projection() -> ReportingProjection:
    candidate = json.loads(
        (ROOT / "tests/fixtures/v1/confirmed-blocker-ledger.json").read_bytes()
    )
    ledger = parse_readiness_ledger_json(json.dumps(candidate).encode())
    envelope = json.loads(
        (ROOT / "tests/fixtures/browser_evidence/valid-exploratory.json").read_bytes()
    )
    envelope["finding_ids"] = ["FND-CHECKOUT-001"]
    envelope["producer"] = {"name": "codex-native-browser", "version": "1.2.3"}
    envelope["host"]["driver"] = "in-app-browser"
    screenshot_bytes = b"synthetic checkout screenshot"
    screenshot_descriptor = envelope["artifacts"][0]["descriptor"]
    screenshot_descriptor["byte_size"] = len(screenshot_bytes)
    screenshot_descriptor["digest"] = hashlib.sha256(screenshot_bytes).hexdigest()
    envelope["unavailable_channels"] = ["network"]
    envelope["limitations"] = ["A screenshot proves only the captured state."]
    envelope["not_proven"] = ["The complete checkout workflow is not proven."]
    raw = (json.dumps(envelope, indent=2, sort_keys=True) + "\n").encode()
    normalized = import_browser_evidence_json(
        raw,
        source_relative_path="evidence/browser/session.json",
        attachment_bytes={screenshot_descriptor["relative_path"]: screenshot_bytes},
    )
    return ReportingProjection.from_ledger(attach_evidence(ledger, normalized))


def test_html_sarif_and_bundle_expose_browser_lineage_without_gate_drift() -> None:
    projection = _attached_projection()

    html = render_readiness_html(projection)
    sarif = render_readiness_sarif(projection)
    bundle = build_evidence_bundle(projection)
    with zipfile.ZipFile(io.BytesIO(bundle)) as archive:
        manifest = json.loads(archive.read("manifest.json"))

    for expected in (
        b"exploratory",
        b"in-app-browser",
        b"codex-native-browser",
        b"browser-evidence/v1",
        b"A screenshot proves only the captured state.",
        b"Evidence channel unavailable: network.",
        b"FND-CHECKOUT-001",
        b"confirmed_only gate outcome: failed",
    ):
        assert expected in html

    browser_source = sarif["runs"][0]["properties"]["browser_evidence"][0]
    assert browser_source["mode"] == "exploratory"
    assert browser_source["driver"] == "in-app-browser"
    assert browser_source["source_producer"] == {
        "name": "codex-native-browser",
        "version": "1.2.3",
    }
    assert browser_source["lineage_operation"].startswith("browser-evidence/v1?")
    assert [item["availability"] for item in browser_source["attachments"]] == [
        "available",
        "missing",
    ]
    assert len(browser_source["attachments"][0]["digest"]) == 64
    assert browser_source["attachments"][1]["digest"] is None
    assert sarif["runs"][0]["properties"]["gate"] == {
        "blocking_finding_ids": ["FND-CHECKOUT-001"],
        "outcome": "failed",
        "policy": "confirmed_only",
    }
    assert (
        sarif["runs"][0]["results"][0]["properties"]["record_id"] == "FND-CHECKOUT-001"
    )

    assert (
        manifest["browser_evidence"]
        == sarif["runs"][0]["properties"]["browser_evidence"]
    )
    source_status = next(
        item
        for item in manifest["artifacts"]
        if item["artifact_id"].startswith("ART-BROWSER-SOURCE-")
    )
    assert source_status["availability"] == "available"
    assert len(source_status["digest"]) == 64
    assert source_status["lineage"]["operation"].startswith("browser-evidence/v1?")
    assert manifest["gate"]["outcome"] == "failed"
    assert manifest["records"][0]["record_id"] == "FND-CHECKOUT-001"
    debt_records = [
        record
        for record in manifest["records"]
        if record["record_kind"] == "evidence_debt"
    ]
    limitation_record = next(
        record
        for record in debt_records
        if record["reason"]
        == "LIMITATION: A screenshot proves only the captured state."
    )
    missing_channel_record = next(
        record
        for record in debt_records
        if record["reason"] == "LIMITATION: Evidence channel unavailable: network."
    )
    assert limitation_record["record_id"].startswith("ED-BROWSER-")
    assert missing_channel_record["record_id"].startswith("ED-BROWSER-")
    assert limitation_record["record_id"] != missing_channel_record["record_id"]
    for record in (limitation_record, missing_channel_record):
        assert record["subject"] == "browser-evidence limitation"
        assert record["proof_needed"] == (
            "Obtain evidence that closes or explicitly scopes this limitation."
        )
        assert record["debt_status"] == "scoped-out"


def test_projection_and_bundle_are_byte_deterministic_from_ledger_alone() -> None:
    first = _attached_projection()
    second = ReportingProjection.from_ledger(first.ledger)

    assert first == second
    assert render_readiness_html(first) == render_readiness_html(second)
    assert render_readiness_sarif(first) == render_readiness_sarif(second)
    assert build_evidence_bundle(first) == build_evidence_bundle(second)


def test_playwright_association_attaches_and_reports_without_limitation_gate_drift() -> (
    None
):
    ledger = parse_readiness_ledger_json(
        (ROOT / "tests/fixtures/v1/confirmed-blocker-ledger.json").read_bytes()
    )
    raw = (ROOT / "tests/fixtures/playwright/basic-report.json").read_bytes()
    normalized = import_playwright_json_report(
        raw,
        source_relative_path="test-results/playwright-report.json",
        attachment_bytes={
            "test-results/checkout/screenshot.png": (
                ROOT / "tests/fixtures/playwright/screenshot.png"
            ).read_bytes(),
            "test-results/expired/trace.zip": (
                ROOT / "tests/fixtures/playwright/trace.zip"
            ).read_bytes(),
        },
        finding_ids=("FND-CHECKOUT-001",),
    )

    attached = attach_evidence(ledger, normalized)
    projection = ReportingProjection.from_ledger(attached)
    html = render_readiness_html(projection)
    sarif = render_readiness_sarif(projection)
    with zipfile.ZipFile(io.BytesIO(build_evidence_bundle(projection))) as archive:
        manifest = json.loads(archive.read("manifest.json"))

    assert attached.completion_status == ledger.completion_status
    assert attached.readiness_disposition == ledger.readiness_disposition
    assert attached.gate == ledger.gate
    assert b"deterministic_replay" in html
    assert b"existing-playwright-json-reporter" in html
    browser = sarif["runs"][0]["properties"]["browser_evidence"][0]
    assert browser["mode"] == "deterministic_replay"
    assert browser["finding_ids"] == ["FND-CHECKOUT-001"]
    assert {item["availability"] for item in browser["attachments"]} == {"available"}
    limitation_records = [
        record
        for record in manifest["records"]
        if record["record_kind"] == "evidence_debt"
    ]
    assert [record["debt_status"] for record in limitation_records] == [
        "scoped-out",
        "scoped-out",
    ]
    assert [record["reason"] for record in limitation_records] == [
        "LIMITATION: Imported reporter output does not prove unconfigured browsers or paths.",
        "LIMITATION: Shipworthy did not run Playwright and did not independently verify assertions.",
    ]
    assert manifest["gate"]["outcome"] == "failed"
    assert manifest["gate"]["blocking_finding_ids"] == ["FND-CHECKOUT-001"]


def test_genuine_native_import_limitations_are_scoped_without_gate_drift() -> None:
    report_input = json.loads(
        (ROOT / "tests/fixtures/v1/pure-action-first-report-input.json").read_bytes()
    )
    ledger = parse_readiness_ledger_json(
        json.dumps(report_input["source_ledger"]).encode()
    )
    envelope = json.loads(
        (ROOT / "tests/fixtures/browser_evidence/valid-exploratory.json").read_bytes()
    )
    envelope["finding_ids"] = ["FND-COUPON-001"]
    attachment_bytes = {
        "evidence/browser/checkout.png": b"genuine native screenshot fixture",
        "evidence/browser/checkout-accessibility.json": b'{"role":"main"}\n',
    }
    for artifact in envelope["artifacts"]:
        descriptor = artifact["descriptor"]
        supplied = attachment_bytes[descriptor["relative_path"]]
        descriptor["byte_size"] = len(supplied)
        descriptor["digest"] = hashlib.sha256(supplied).hexdigest()
    raw = (json.dumps(envelope, indent=2, sort_keys=True) + "\n").encode()
    normalized = import_browser_evidence_json(
        raw,
        source_relative_path="evidence/browser/native-session.json",
        attachment_bytes=attachment_bytes,
    )

    attached = attach_evidence(ledger, normalized)
    projection = ReportingProjection.from_ledger(attached)
    with zipfile.ZipFile(io.BytesIO(build_evidence_bundle(projection))) as archive:
        manifest = json.loads(archive.read("manifest.json"))

    assert normalized.evidence_debt == ()
    assert attached.completion_status == ledger.completion_status
    assert attached.readiness_disposition == ledger.readiness_disposition
    assert attached.gate == ledger.gate
    scoped = [
        record
        for record in manifest["records"]
        if record["record_kind"] == "evidence_debt"
    ]
    assert len(scoped) == len(normalized.limitations)
    assert all(record["debt_status"] == "scoped-out" for record in scoped)
    assert any(
        record["reason"] == "LIMITATION: Evidence channel unavailable: network."
        for record in scoped
    )


@pytest.mark.parametrize(
    "mutate",
    (
        lambda operation: operation + "&extra=spoofed",
        lambda operation: operation + "&driver=duplicate",
        lambda operation: operation.replace("in-app-browser", "%69n-app-browser"),
        lambda operation: operation.replace("mode=exploratory", "mode=spoofed"),
        lambda operation: operation.replace("&producer_version=1.2.3", ""),
    ),
)
def test_noncanonical_or_spoofed_lineage_operation_is_not_classified(mutate) -> None:
    ledger = _attached_projection().ledger
    source_index = next(
        index
        for index, artifact in enumerate(ledger.artifacts)
        if artifact.lineage.operation.startswith("browser-evidence/v1?")
    )
    source = ledger.artifacts[source_index]
    artifacts = list(ledger.artifacts)
    artifacts[source_index] = source.model_copy(
        update={
            "lineage": source.lineage.model_copy(
                update={"operation": mutate(source.lineage.operation)}
            )
        }
    )
    forged = ledger.model_copy(update={"artifacts": tuple(artifacts)})

    projection = ReportingProjection.from_ledger(forged)

    assert projection.browser_evidence == ()
