from __future__ import annotations

import base64
import json
import hashlib
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import tomllib
import zipfile

import pytest


ROOT = Path(__file__).resolve().parents[2]
LEGACY_SCRIPTS = Path(
    "plugins/shipworthy/skills/ship-readiness-orchestrator/scripts"
)

PHASE0_RECEIPT_SCHEMAS = {
    "contract-hashes.json": "shipworthy-phase0-contract-hashes/v1",
    "legacy-import.json": "shipworthy-legacy-import-evidence/v1",
    "dual-render.json": "shipworthy-dual-render-evidence/v1",
    "installed-parity-codex.json": "shipworthy-installed-parity/v1",
    "installed-parity-claude.json": "shipworthy-installed-parity/v1",
    "upgrade-rollback.json": "shipworthy-lifecycle-upgrade-rehearsal/v1",
    "uninstall-skill-only.json": "shipworthy-lifecycle-uninstall-rehearsal/v1",
}


def _write_phase0_receipts(root: Path) -> Path:
    root.mkdir()
    for name, schema in PHASE0_RECEIPT_SCHEMAS.items():
        (root / name).write_text(
            json.dumps({"schema": schema}) + "\n", encoding="utf-8"
        )
    return root


def test_wheel_metadata_pins_the_phase0_runtime_and_hatchling_contract() -> None:
    metadata = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))

    assert metadata["project"]["requires-python"] == ">=3.12,<3.15"
    assert metadata["project"]["dependencies"] == ["pydantic>=2.13,<3"]
    assert metadata["build-system"] == {
        "build-backend": "hatchling.build",
        "requires": ["hatchling>=1.31,<2"],
    }
    assert "cyclonedx-python-lib[json-validation]>=11.11,<12" in metadata[
        "dependency-groups"
    ]["build"]
    assert not any(
        dependency == "cyclonedx-python-lib[json-validation]"
        or dependency.startswith("cyclonedx-python-lib[json-validation]>=12")
        for dependency in metadata["dependency-groups"]["build"]
    )
    assert (ROOT / ".python-version").read_text(encoding="utf-8") == "3.13\n"


def test_wheel_force_includes_schemas_and_legacy_reporting_transforms() -> None:
    metadata = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    force_include = metadata["tool"]["hatch"]["build"]["targets"]["wheel"][
        "force-include"
    ]

    assert force_include["schemas"] == "shipworthy/schemas"
    legacy_root = "plugins/shipworthy/skills/ship-readiness-orchestrator/scripts"
    assert force_include[f"{legacy_root}/render_report.py"] == (
        "shipworthy/_legacy_reporting/render_report.py"
    )
    assert force_include[f"{legacy_root}/to_sarif.py"] == (
        "shipworthy/_legacy_reporting/to_sarif.py"
    )
    assert force_include[f"{legacy_root}/make_bundle.py"] == (
        "shipworthy/_legacy_reporting/make_bundle.py"
    )
    ignored = (ROOT / ".gitignore").read_text(encoding="utf-8").splitlines()
    assert "artifacts/" in ignored
    assert "dist/" in ignored
    assert "build/" in ignored


def test_compat_loader_prefers_packaged_transform_bytes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from shipworthy.adapters.reporting import compat_loader

    source = (
        ROOT
        / LEGACY_SCRIPTS
        / "render_report.py"
    ).read_bytes()

    monkeypatch.setattr(
        compat_loader,
        "_packaged_legacy_bytes",
        lambda filename: source if filename == "render_report.py" else None,
    )

    def source_tree_forbidden(_filename: str) -> Path:
        raise AssertionError("packaged wheel must not resolve a repository root")

    monkeypatch.setattr(compat_loader, "_legacy_script_path", source_tree_forbidden)
    compat_loader._load_legacy_script.cache_clear()
    try:
        renderer = compat_loader.load_legacy_renderer()
        assert callable(renderer.render)
    finally:
        compat_loader._load_legacy_script.cache_clear()


def test_unreadable_packaged_transform_fails_closed_without_source_fallback(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from shipworthy.adapters.reporting import compat_loader

    class UnreadableResource:
        def joinpath(self, *_parts: str):
            return self

        def is_file(self) -> bool:
            return True

        def read_bytes(self) -> bytes:
            raise OSError("sensitive resource detail")

    source_fallback_called = False

    def source_fallback(_filename: str) -> Path:
        nonlocal source_fallback_called
        source_fallback_called = True
        return ROOT / "not-used.py"

    monkeypatch.setattr(
        compat_loader.resources, "files", lambda _name: UnreadableResource()
    )
    monkeypatch.setattr(compat_loader, "_legacy_script_path", source_fallback)
    compat_loader._load_legacy_script.cache_clear()
    try:
        with pytest.raises(
            compat_loader.ReportingTransformError,
            match="legacy reporting transform unavailable",
        ) as exc_info:
            compat_loader.load_legacy_renderer()
        assert not source_fallback_called
        assert "sensitive" not in str(exc_info.value)
    finally:
        compat_loader._load_legacy_script.cache_clear()


def test_missing_transform_in_present_packaged_directory_fails_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from shipworthy.adapters.reporting import compat_loader

    class MissingTransform:
        def is_file(self) -> bool:
            return False

    class PresentDirectory:
        def is_dir(self) -> bool:
            return True

        def joinpath(self, _filename: str) -> MissingTransform:
            return MissingTransform()

    class PackageRoot:
        def joinpath(self, *parts: str):
            assert parts[0] == "_legacy_reporting"
            if len(parts) == 1:
                return PresentDirectory()
            assert parts == ("_legacy_reporting", "render_report.py")
            return MissingTransform()

    source_fallback_called = False

    def source_fallback(_filename: str) -> Path:
        nonlocal source_fallback_called
        source_fallback_called = True
        return ROOT / "not-used.py"

    monkeypatch.setattr(compat_loader.resources, "files", lambda _name: PackageRoot())
    monkeypatch.setattr(compat_loader, "_legacy_script_path", source_fallback)
    compat_loader._load_legacy_script.cache_clear()
    try:
        with pytest.raises(
            compat_loader.ReportingTransformError,
            match="legacy reporting transform unavailable",
        ):
            compat_loader.load_legacy_renderer()
        assert not source_fallback_called
    finally:
        compat_loader._load_legacy_script.cache_clear()


def test_absent_packaged_directory_in_installed_layout_fails_closed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from shipworthy.adapters.reporting import compat_loader

    class AbsentDirectory:
        def is_dir(self) -> bool:
            return False

    class PackageRoot:
        def joinpath(self, directory: str) -> AbsentDirectory:
            assert directory == "_legacy_reporting"
            return AbsentDirectory()

    source_fallback_called = False

    def source_fallback(_filename: str) -> Path:
        nonlocal source_fallback_called
        source_fallback_called = True
        return ROOT / "not-used.py"

    monkeypatch.setattr(compat_loader.resources, "files", lambda _name: PackageRoot())
    monkeypatch.setattr(compat_loader, "_is_source_checkout", lambda: False)
    monkeypatch.setattr(compat_loader, "_legacy_script_path", source_fallback)
    compat_loader._load_legacy_script.cache_clear()
    try:
        with pytest.raises(
            compat_loader.ReportingTransformError,
            match="legacy reporting transform unavailable",
        ):
            compat_loader.load_legacy_renderer()
        assert not source_fallback_called
    finally:
        compat_loader._load_legacy_script.cache_clear()


def test_one_command_gate_lists_new_and_all_four_legacy_suites() -> None:
    result = subprocess.run(
        [sys.executable, "scripts/validate_local.py", "--list"],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0, result.stderr
    stages = json.loads(result.stdout)
    assert stages == [
        [sys.executable, "-m", "pytest", "tests"],
        [
            sys.executable,
            str(LEGACY_SCRIPTS / "test_skill_contract.py"),
        ],
        [
            sys.executable,
            str(LEGACY_SCRIPTS / "test_render_report.py"),
        ],
        [
            sys.executable,
            str(LEGACY_SCRIPTS / "test_to_sarif.py"),
        ],
        [
            sys.executable,
            str(LEGACY_SCRIPTS / "test_make_bundle.py"),
        ],
    ]


def test_local_gate_labels_out_of_range_python_as_compatibility_only() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from validate_local import _runtime_notice
    finally:
        sys.path.pop(0)

    assert _runtime_notice((3, 13)) is None
    assert _runtime_notice((3, 11)) == (
        "local validation: Python 3.11 is outside >=3.12,<3.15; "
        "result is compatibility-only and target runtime remains NOT_PROVEN"
    )


def test_release_gate_handles_missing_uv_with_bounded_diagnostic(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    (tmp_path / "uv.lock").write_bytes(b"lock")
    monkeypatch.setattr(validate_local, "ROOT", tmp_path)
    monkeypatch.setattr(validate_local.shutil, "which", lambda _name: None)

    assert not validate_local._strict_release_prerequisites()
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == "release validation: uv is unavailable\n"


def test_release_gate_accepts_only_exact_uv_semantic_version() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from validate_local import _uv_version_is_expected
    finally:
        sys.path.pop(0)

    assert _uv_version_is_expected(b"uv 0.11.28\n")
    assert _uv_version_is_expected(
        b"uv 0.11.28 (ebf0f43d7 2026-07-07 aarch64-apple-darwin)\n"
    )
    assert not _uv_version_is_expected(b"uv 0.11.29\n")
    assert not _uv_version_is_expected(b"uv 0.11.28-hostile\n")
    assert not _uv_version_is_expected(b"uv 0.11.28\nextra\n")


def test_release_gate_includes_git_diff_check() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from validate_local import _release_commands
    finally:
        sys.path.pop(0)

    commands = _release_commands()
    assert ["git", "diff", "--check"] in commands
    assert any(
        command[-5:] == [
            "--locked",
            "--no-dev",
            "--no-emit-project",
            "--output-file",
            "artifacts/.staging/TEST/runtime-requirements.txt",
        ]
        for command in commands
    )
    for command in commands:
        if command[0] == "uv":
            assert command[1:4] == [
                "--no-config",
                "--offline",
                "--no-python-downloads",
            ]


def test_release_environment_strips_indexes_proxies_credentials_and_venvs() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from validate_local import _release_environment
    finally:
        sys.path.pop(0)

    sanitized = _release_environment(
        {
            "PATH": "/safe/bin",
            "HOME": "/safe/home",
            "UV_INDEX_URL": "https://example.invalid",
            "PIP_INDEX_URL": "https://example.invalid",
            "HTTPS_PROXY": "https://proxy.invalid",
            "API_TOKEN": "secret",
            "AWS_SECRET_ACCESS_KEY": "secret",
            "GIT_DIR": "/hostile/repo",
            "GIT_WORK_TREE": "/hostile/tree",
            "VIRTUAL_ENV": "/ambient/venv",
        }
    )
    assert sanitized == {
        "HOME": "/safe/home",
        "PATH": "/safe/bin",
        "UV_NO_CONFIG": "1",
        "UV_OFFLINE": "1",
        "UV_PYTHON_DOWNLOADS": "never",
    }


def test_release_runner_bounds_timeout_with_sanitized_message(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    monkeypatch.setattr(
        validate_local, "RELEASE_SUBPROCESS_TIMEOUT_SECONDS", 0.01
    )
    staging = tmp_path / "staging"
    staging.mkdir()
    assert not validate_local._run(
        [
            sys.executable,
            "-c",
            "import time; time.sleep(10)",
            "sensitive command",
        ],
        release=True,
        log_path=staging / "logs/01-lock-check.log",
    )
    captured = capsys.readouterr()
    retained = (staging / "logs/01-lock-check.log").read_text(encoding="utf-8")
    assert "sensitive" not in captured.out
    assert "sensitive" not in captured.err
    assert "sensitive" not in retained
    assert captured.err == "release validation: subprocess timed out\n"


@pytest.mark.skipif(os.name != "posix", reason="requires POSIX process groups")
def test_release_timeout_kills_pipe_inheriting_descendant_without_late_return(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    monkeypatch.setattr(
        validate_local, "RELEASE_SUBPROCESS_TIMEOUT_SECONDS", 0.3
    )
    staging = tmp_path / "staging"
    staging.mkdir()
    started = time.monotonic()

    assert not validate_local._run(
        [
            sys.executable,
            "-c",
            (
                "import subprocess, sys, time; "
                "subprocess.Popen([sys.executable, '-c', "
                "'import time; time.sleep(2)']); "
                "print('descendant started', flush=True); "
                "time.sleep(2)"
            ),
        ],
        release=True,
        log_path=staging / "logs/04-tests.log",
    )

    assert time.monotonic() - started < 1.0
    captured = capsys.readouterr()
    assert captured.err == "release validation: subprocess timed out\n"


@pytest.mark.skipif(os.name != "posix", reason="requires POSIX sessions")
def test_release_timeout_kills_descendant_that_detaches_with_setsid(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    monkeypatch.setattr(
        validate_local, "RELEASE_SUBPROCESS_TIMEOUT_SECONDS", 0.3
    )
    staging = tmp_path / "staging"
    staging.mkdir()
    started = time.monotonic()

    assert not validate_local._run(
        [
            sys.executable,
            "-c",
            (
                "import subprocess, sys, time; "
                "subprocess.Popen([sys.executable, '-c', "
                "'import os, time; os.setsid(); "
                "print(\"detached descendant\", os.getpid(), flush=True); "
                "time.sleep(2)']); "
                "time.sleep(2)"
            ),
        ],
        release=True,
        log_path=staging / "logs/04-tests.log",
    )

    assert time.monotonic() - started < 1.0
    retained = (staging / "logs/04-tests.log").read_text(encoding="utf-8")
    detached_pid = int(retained.split("detached descendant ", 1)[1].split()[0])
    deadline = time.monotonic() + 0.5
    detached_alive = True
    while detached_alive and time.monotonic() < deadline:
        try:
            os.kill(detached_pid, 0)
        except ProcessLookupError:
            detached_alive = False
        else:
            time.sleep(0.01)
    if detached_alive:
        os.kill(detached_pid, signal.SIGKILL)
    assert not detached_alive
    captured = capsys.readouterr()
    assert captured.err == "release validation: subprocess timed out\n"


def test_release_runner_retains_combined_output_for_success_and_failure(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    staging = tmp_path / "staging"
    staging.mkdir()
    success_log = staging / "logs/04-tests.log"
    failure_log = staging / "logs/10-build-wheel.log"

    assert validate_local._run(
        [
            sys.executable,
            "-c",
            (
                "import sys; "
                "print('retained stdout', flush=True); "
                "print('retained stderr', file=sys.stderr, flush=True)"
            ),
            "raw credential=must-not-log",
        ],
        release=True,
        log_path=success_log,
    )
    assert not validate_local._run(
        [
            sys.executable,
            "-c",
            (
                "import sys; "
                "print('failed stdout', flush=True); "
                "print('failed stderr', file=sys.stderr, flush=True); "
                "raise SystemExit(7)"
            ),
        ],
        release=True,
        log_path=failure_log,
    )

    assert success_log.read_text(encoding="utf-8") == (
        "retained stdout\nretained stderr\n"
    )
    assert "raw credential" not in success_log.read_text(encoding="utf-8")
    assert failure_log.read_text(encoding="utf-8") == (
        "failed stdout\nfailed stderr\n"
    )
    assert success_log.is_file()
    assert failure_log.is_file()


def test_release_runner_refuses_preexisting_log_symlink(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    staging = tmp_path / "staging"
    logs = staging / "logs"
    logs.mkdir(parents=True)
    outside = tmp_path / "outside.log"
    outside.write_text("unchanged\n", encoding="utf-8")
    log_path = logs / "04-tests.log"
    log_path.symlink_to(outside)

    assert not validate_local._run(
        [sys.executable, "-c", "print('must not escape')"],
        release=True,
        log_path=log_path,
    )
    assert outside.read_text(encoding="utf-8") == "unchanged\n"
    captured = capsys.readouterr()
    assert captured.err == "release validation: log creation failed\n"


def test_release_runner_fails_closed_when_log_exceeds_bound(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    monkeypatch.setattr(validate_local, "RELEASE_LOG_MAX_BYTES", 32)
    staging = tmp_path / "staging"
    staging.mkdir()
    log_path = staging / "logs/04-tests.log"

    assert not validate_local._run(
        [
            sys.executable,
            "-c",
            "import os; os.write(1, b'x' * 64)",
        ],
        release=True,
        log_path=log_path,
    )
    assert log_path.stat().st_size <= 32
    captured = capsys.readouterr()
    assert captured.err == "release validation: subprocess log exceeded limit\n"


def test_failed_release_retains_staging_log_without_promoting_current(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    artifacts = tmp_path / "artifacts"
    artifacts.mkdir()
    paths = validate_local._new_release_paths(artifacts, run_id="failed-log")
    log_path = paths.staging / "logs/04-tests.log"

    assert not validate_local._run(
        [sys.executable, "-c", "print('failure evidence'); raise SystemExit(2)"],
        release=True,
        log_path=log_path,
    )
    validate_local._fail_release(paths)

    assert paths.staging.is_dir()
    assert log_path.read_text(encoding="utf-8") == "failure evidence\n"
    assert not paths.release.exists()
    assert json.loads(paths.current.read_text(encoding="utf-8")) == {
        "run_id": "failed-log",
        "status": "not_current",
    }


def test_release_log_stage_names_cover_every_release_subprocess() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from validate_local import RELEASE_LOG_STAGE_NAMES
    finally:
        sys.path.pop(0)

    assert RELEASE_LOG_STAGE_NAMES == (
        "01-lock-check",
        "02-runtime-export",
        "03-sync",
        "04-tests",
        "05-legacy-skill-contract",
        "06-legacy-render-report",
        "07-legacy-to-sarif",
        "08-legacy-make-bundle",
        "09-git-diff-check",
        "10-build-wheel",
        "11-python-3.12",
        "12-python-3.13",
        "13-python-3.14",
        "14-sbom",
        "15-clean-wheel-3.12",
        "16-clean-wheel-3.13",
        "17-clean-wheel-3.14",
        "18-phase0-receipts",
        "19-python-target-matrix",
        "20-uv-toolchain",
        "21-build-manifest",
    )


def test_successful_release_promotes_logs_for_all_release_subprocesses(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    monkeypatch.setattr(validate_local, "ROOT", tmp_path)
    monkeypatch.setattr(
        validate_local, "_strict_release_prerequisites", lambda: True
    )
    monkeypatch.setattr(
        validate_local,
        "_release_commands",
        lambda _staging: [["stage", str(index)] for index in range(10)],
    )
    (tmp_path / ".python-version").write_text("3.13\n", encoding="utf-8")
    (tmp_path / "uv.lock").write_text("locked\n", encoding="utf-8")
    observed_logs: list[str] = []

    def run_stage(
        _command: list[str],
        *,
        release: bool = False,
        log_path: Path | None = None,
    ) -> bool:
        assert release
        assert log_path is not None
        observed_logs.append(log_path.name)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text("retained\n", encoding="utf-8")
        if log_path.name == "10-build-wheel.log":
            (log_path.parent.parent / "dist/shipworthy_core-0.1.0.whl").write_bytes(
                b"wheel"
            )
        return True

    monkeypatch.setattr(validate_local, "_run", run_stage)

    assert validate_local._release() == 0
    assert observed_logs == [
        f"{stage_name}.log"
        for stage_name in validate_local.RELEASE_LOG_STAGE_NAMES
    ]
    current = json.loads(
        (tmp_path / "artifacts/current.json").read_text(encoding="utf-8")
    )
    promoted_logs = tmp_path / "artifacts" / current["path"] / "logs"
    assert sorted(path.name for path in promoted_logs.iterdir()) == observed_logs
    assert all(path.is_file() for path in promoted_logs.iterdir())


def test_release_status_invalidates_old_pointer_until_atomic_promotion(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from validate_local import (
            _fail_release,
            _new_release_paths,
            _promote_release,
        )
    finally:
        sys.path.pop(0)

    artifacts = tmp_path / "artifacts"
    artifacts.mkdir()
    (artifacts / "current.json").write_text(
        '{"run_id":"old","status":"passed"}\n', encoding="utf-8"
    )

    paths = _new_release_paths(artifacts, run_id="new")
    assert json.loads((artifacts / "release-status.json").read_text()) == {
        "run_id": "new",
        "status": "running",
    }
    assert json.loads((artifacts / "current.json").read_text()) == {
        "run_id": "new",
        "status": "not_current",
    }
    (paths.staging / "build-manifest.json").write_text("{}\n", encoding="utf-8")
    _promote_release(paths)
    assert not paths.staging.exists()
    assert (paths.release / "build-manifest.json").is_file()
    assert json.loads((artifacts / "current.json").read_text()) == {
        "path": "releases/new",
        "run_id": "new",
        "status": "passed",
    }

    failed = _new_release_paths(artifacts, run_id="failed")
    _fail_release(failed)
    assert json.loads((artifacts / "release-status.json").read_text()) == {
        "run_id": "failed",
        "status": "failed",
    }
    assert json.loads((artifacts / "current.json").read_text()) == {
        "run_id": "failed",
        "status": "not_current",
    }


@pytest.mark.parametrize("failed_boundary", ["move", "status", "current"])
def test_promotion_failure_never_leaves_current_passed(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    failed_boundary: str,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    artifacts = tmp_path / "artifacts"
    artifacts.mkdir()
    paths = validate_local._new_release_paths(artifacts, run_id="fault")
    real_replace = validate_local.os.replace
    real_atomic_json = validate_local._atomic_json
    injected = False

    def replace(source, destination) -> None:
        nonlocal injected
        if failed_boundary == "move" and Path(source) == paths.staging:
            injected = True
            raise OSError("injected move failure")
        real_replace(source, destination)

    def atomic_json(path: Path, document: dict[str, object]) -> None:
        nonlocal injected
        if (
            not injected
            and document.get("status") == "passed"
            and (
                (failed_boundary == "status" and path == paths.status)
                or (failed_boundary == "current" and path == paths.current)
            )
        ):
            injected = True
            raise OSError("injected pointer failure")
        real_atomic_json(path, document)

    monkeypatch.setattr(validate_local.os, "replace", replace)
    monkeypatch.setattr(validate_local, "_atomic_json", atomic_json)

    with pytest.raises(OSError):
        validate_local._promote_release(paths)
    validate_local._fail_release(paths)

    assert injected
    assert json.loads(paths.current.read_text(encoding="utf-8"))["status"] != (
        "passed"
    )
    assert json.loads(paths.status.read_text(encoding="utf-8")) == {
        "run_id": "fault",
        "status": "failed",
    }


def test_clean_wheel_smoke_command_requires_an_existing_wheel() -> None:
    result = subprocess.run(
        [
            sys.executable,
            "scripts/clean_wheel_smoke.py",
            "--wheel",
            "missing.whl",
            "--fixture",
            "tests/fixtures/v1/incomplete-ledger.json",
            "--runtime-requirements",
            "pyproject.toml",
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert result.stdout == ""
    assert result.stderr == "clean-wheel smoke: wheel does not exist\n"


def test_clean_wheel_smoke_requires_lock_derived_runtime_requirements(
    tmp_path: Path,
) -> None:
    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    _write_fake_wheel(wheel)
    result = subprocess.run(
        [
            sys.executable,
            "scripts/clean_wheel_smoke.py",
            "--wheel",
            str(wheel),
            "--fixture",
            "tests/fixtures/v1/incomplete-ledger.json",
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 2
    assert "--runtime-requirements" in result.stderr


def test_clean_wheel_origin_must_be_inside_the_temporary_environment(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _installed_origin_is_clean
    finally:
        sys.path.pop(0)

    environment = tmp_path / "venv"
    installed = environment / "lib/python3.14/site-packages/shipworthy/__init__.py"
    source_tree = ROOT / "src/shipworthy/__init__.py"

    assert _installed_origin_is_clean(installed, environment)
    assert not _installed_origin_is_clean(source_tree, environment)


def test_clean_wheel_syncs_the_exact_lock_before_installing_the_wheel(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _offline_install_commands
    finally:
        sys.path.pop(0)

    python = tmp_path / "venv/bin/python"
    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    requirements = tmp_path / "runtime-requirements.txt"

    assert _offline_install_commands(python, wheel, requirements) == (
        [
            "uv",
            "--no-config",
            "--offline",
            "--no-python-downloads",
            "sync",
            "--locked",
            "--no-default-groups",
            "--no-install-project",
            "--python",
            str(python),
            "--project",
            str(ROOT),
        ],
        [
            "uv",
            "--no-config",
            "--offline",
            "--no-python-downloads",
            "pip",
            "install",
            "--no-managed-python",
            "--python",
            str(python),
            "--no-deps",
            str(wheel),
        ],
    )


def test_venv_python_path_is_portable(tmp_path: Path) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _venv_python
    finally:
        sys.path.pop(0)

    assert _venv_python(tmp_path / "venv", windows=False) == (
        tmp_path / "venv/bin/python"
    )
    assert _venv_python(tmp_path / "venv", windows=True) == (
        tmp_path / "venv/Scripts/python.exe"
    )


def test_uv_venv_command_and_environment_are_offline_and_config_free(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _uv_environment, _uv_venv_command
    finally:
        sys.path.pop(0)

    environment = tmp_path / "venv"
    assert _uv_venv_command("3.13", environment) == [
        "uv",
        "--no-config",
        "--offline",
        "--no-python-downloads",
        "venv",
        "--no-project",
        "--no-managed-python",
        "--python",
        "3.13",
        str(environment),
    ]
    sanitized = _uv_environment(
        {
            "PATH": "/safe/bin",
            "UV_PROJECT": "/hostile/project",
            "UV_CONFIG_FILE": "/hostile/uv.toml",
            "UV_INDEX_URL": "https://example.invalid",
            "HTTPS_PROXY": "https://proxy.invalid",
            "API_TOKEN": "secret",
            "GIT_CONFIG_GLOBAL": "/hostile/gitconfig",
            "VIRTUAL_ENV": "/ambient/venv",
        }
    )
    assert sanitized == {
        "PATH": "/safe/bin",
        "UV_NO_CONFIG": "1",
        "UV_NO_MANAGED_PYTHON": "1",
        "UV_OFFLINE": "1",
        "UV_PYTHON_DOWNLOADS": "never",
    }


def test_clean_wheel_defaults_to_the_current_runtime_base_interpreter(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import clean_wheel_smoke
    finally:
        sys.path.pop(0)

    monkeypatch.setattr(
        clean_wheel_smoke.sys,
        "_base_executable",
        "/managed/cpython-3.12/bin/python3.12",
        raising=False,
    )
    monkeypatch.setattr(
        clean_wheel_smoke.sys,
        "executable",
        "/isolated/temporary/venv/bin/python",
    )

    assert clean_wheel_smoke._target_python(None) == (
        "/managed/cpython-3.12/bin/python3.12"
    )
    assert clean_wheel_smoke._target_python("/explicit/python") == (
        "/explicit/python"
    )


def test_clean_wheel_lock_snapshot_rejects_mutation(tmp_path: Path) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import (
            _close_lock_snapshot,
            _open_lock_snapshot,
        )
    finally:
        sys.path.pop(0)

    lock = tmp_path / "uv.lock"
    lock.write_bytes(b"locked snapshot")
    snapshot = _open_lock_snapshot(lock)
    lock.write_bytes(b"mutated snapshot")

    assert _close_lock_snapshot(snapshot, 0) == 2


def test_uv_toolchain_closes_lock_when_binary_acquisition_fails(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_uv_toolchain as toolchain
    finally:
        sys.path.pop(0)
    lock = tmp_path / "uv.lock"
    lock.write_bytes(b"locked")
    before = {int(name) for name in os.listdir("/dev/fd") if name.isdigit()}
    original_open = toolchain._open_held_input
    calls = 0

    def fail_second(path: Path, maximum: int):
        nonlocal calls
        calls += 1
        if calls == 2:
            raise ValueError("injected binary acquisition failure")
        return original_open(path, maximum)

    monkeypatch.setattr(toolchain, "_open_held_input", fail_second)
    monkeypatch.setattr(toolchain.shutil, "which", lambda _name: "/usr/bin/true")
    monkeypatch.setattr(
        toolchain.sys if hasattr(toolchain, "sys") else sys,
        "argv",
        [
            "write_uv_toolchain.py",
            "--lock",
            str(lock),
            "--output",
            str(tmp_path / "toolchain.json"),
        ],
    )
    with pytest.raises(ValueError, match="injected binary"):
        toolchain.main()
    assert {
        int(name) for name in os.listdir("/dev/fd") if name.isdigit()
    } == before


def test_strict_macos_containment_fails_when_sandbox_is_unavailable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import clean_wheel_smoke
    finally:
        sys.path.pop(0)

    monkeypatch.setattr(clean_wheel_smoke.sys, "platform", "darwin")
    monkeypatch.setattr(
        clean_wheel_smoke, "SANDBOX_EXEC", tmp_path / "missing-sandbox"
    )
    with pytest.raises(ValueError, match="containment"):
        clean_wheel_smoke._prepare_macos_containment(tmp_path, {})


def test_strict_macos_containment_rejects_an_allowed_probe(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import clean_wheel_smoke
    finally:
        sys.path.pop(0)

    sandbox = tmp_path / "sandbox-exec"
    sandbox.write_bytes(b"sandbox binary")
    monkeypatch.setattr(clean_wheel_smoke.sys, "platform", "darwin")
    monkeypatch.setattr(clean_wheel_smoke, "SANDBOX_EXEC", sandbox)
    observed: list[list[str]] = []

    def allowed(
        command: list[str], *, cwd: Path, environment: object
    ) -> subprocess.CompletedProcess[bytes]:
        observed.append(command)
        return subprocess.CompletedProcess(command, 3)

    monkeypatch.setattr(clean_wheel_smoke, "_run_quiet", allowed)
    with pytest.raises(ValueError, match="containment"):
        clean_wheel_smoke._prepare_macos_containment(tmp_path, {})
    assert observed
    assert observed[0][:3] == [
        str(sandbox),
        "-f",
        str(tmp_path / "deny-network.sb"),
    ]


def test_strict_macos_containment_prefixes_every_child_command(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import clean_wheel_smoke
    finally:
        sys.path.pop(0)

    sandbox = tmp_path / "sandbox-exec"
    sandbox.write_bytes(b"sandbox binary")
    monkeypatch.setattr(clean_wheel_smoke.sys, "platform", "darwin")
    monkeypatch.setattr(clean_wheel_smoke, "SANDBOX_EXEC", sandbox)
    observed: list[list[str]] = []

    def denied(
        command: list[str], *, cwd: Path, environment: object
    ) -> subprocess.CompletedProcess[bytes]:
        observed.append(command)
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(clean_wheel_smoke, "_run_quiet", denied)
    containment = clean_wheel_smoke._prepare_macos_containment(tmp_path, {})
    profile = tmp_path / "deny-network.sb"
    assert profile.read_bytes() == b"(version 1)(allow default)(deny network*)"
    assert len(observed) == 2
    assert containment.prefix == (str(sandbox), "-f", str(profile))
    assert containment.evidence["bind_probe"] == "EPERM"
    assert containment.evidence["connect_probe"] == "EPERM"

    environment = tmp_path / "venv"
    python = environment / "bin/python"
    wheel = tmp_path / "core.whl"
    requirements = tmp_path / "requirements.txt"
    venv = clean_wheel_smoke._uv_venv_command(
        "3.12", environment, prefix=containment.prefix
    )
    installs = clean_wheel_smoke._offline_install_commands(
        python, wheel, requirements, prefix=containment.prefix
    )
    runtime = clean_wheel_smoke._child_command(
        [str(python), "-I", "-c", "pass"], containment.prefix
    )
    for command in (venv, *installs, runtime):
        assert command[:3] == list(containment.prefix)


def test_expected_python_runtime_requires_exact_cpython_minor() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _validate_expected_runtime
    finally:
        sys.path.pop(0)

    runtime = {
        "implementation": "CPython",
        "major": 3,
        "minor": 12,
        "patch": 11,
    }
    assert _validate_expected_runtime(runtime, "3.12") == runtime
    with pytest.raises(ValueError, match="runtime target"):
        _validate_expected_runtime(runtime, "3.13")
    with pytest.raises(ValueError, match="runtime target"):
        _validate_expected_runtime({**runtime, "implementation": "PyPy"}, "3.12")


def _record_digest(payload: bytes) -> str:
    encoded = base64.urlsafe_b64encode(hashlib.sha256(payload).digest())
    return "sha256=" + encoded.rstrip(b"=").decode("ascii")


def _write_fake_wheel(
    path: Path,
    *,
    extra_member: tuple[str, bytes] | None = None,
    compression: int = zipfile.ZIP_STORED,
) -> tuple[str, ...]:
    files = (
        "shipworthy/__init__.py",
        "shipworthy_core-0.1.0.dist-info/METADATA",
        "shipworthy_core-0.1.0.dist-info/RECORD",
        "shipworthy_core-0.1.0.dist-info/WHEEL",
    )
    payloads = {
        "shipworthy/__init__.py": b'__version__ = "0.1.0"\n',
        "shipworthy_core-0.1.0.dist-info/METADATA": (
            b"Metadata-Version: 2.4\nName: shipworthy-core\nVersion: 0.1.0\n"
        ),
        "shipworthy_core-0.1.0.dist-info/WHEEL": (
            b"Wheel-Version: 1.0\nTag: py3-none-any\n"
        ),
    }
    if extra_member is not None:
        payloads[extra_member[0]] = extra_member[1]
        files = (*files, extra_member[0])
    rows = []
    for name in files:
        if name.endswith(".dist-info/RECORD"):
            rows.append((name, "", ""))
        else:
            payload = payloads[name]
            rows.append((name, _record_digest(payload), str(len(payload))))
    record = "".join(",".join(row) + "\n" for row in rows).encode("utf-8")
    payloads["shipworthy_core-0.1.0.dist-info/RECORD"] = record
    with zipfile.ZipFile(path, "w", compression=compression) as archive:
        for name in files:
            archive.writestr(name, payloads[name])
    return files


def test_built_wheel_identity_is_read_from_metadata_and_record(tmp_path: Path) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _wheel_identity
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    files = _write_fake_wheel(wheel)

    identity = _wheel_identity(wheel)

    assert identity["name"] == "shipworthy-core"
    assert identity["version"] == "0.1.0"
    assert identity["record_files"] == list(files)
    assert identity["record_file_count"] == 4
    assert identity["record_files_sha256"] == hashlib.sha256(
        "\n".join(files).encode("utf-8")
    ).hexdigest()
    assert identity["wheel_sha256"] == hashlib.sha256(wheel.read_bytes()).hexdigest()
    assert identity["record_entries"][0]["size"] == 22


def test_parent_verifies_installed_wheel_before_and_after_child_execution(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import (
            _verify_installed_distribution,
            _wheel_identity,
        )
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    _write_fake_wheel(wheel)
    environment = tmp_path / "venv"
    site_packages = environment / "lib/python3.13/site-packages"
    site_packages.mkdir(parents=True)
    with zipfile.ZipFile(wheel) as archive:
        archive.extractall(site_packages)
    built = _wheel_identity(wheel)

    before = _verify_installed_distribution(environment, built)
    assert before["name"] == "shipworthy-core"
    assert before["version"] == "0.1.0"
    assert before["wheel_record_entries_verified"] is True

    (site_packages / "shipworthy/__init__.py").write_bytes(b"mutated")
    with pytest.raises(
        ValueError, match="installed distribution failed trusted verification"
    ):
        _verify_installed_distribution(environment, built)


def test_wheel_rejects_member_mutation_without_record_update(tmp_path: Path) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _wheel_identity
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    _write_fake_wheel(wheel)
    with zipfile.ZipFile(wheel) as source:
        members = {name: source.read(name) for name in source.namelist()}
    members["shipworthy/__init__.py"] = b'__version__ = "9.9.9"\n'
    with zipfile.ZipFile(wheel, "w") as archive:
        for name, payload in members.items():
            archive.writestr(name, payload)

    with pytest.raises(ValueError, match="built wheel identity failed validation"):
        _wheel_identity(wheel)


def test_wheel_hash_is_streamed_without_path_read_bytes(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _wheel_identity
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    _write_fake_wheel(wheel)
    original = Path.read_bytes

    def reject_wheel_read_bytes(path: Path) -> bytes:
        if path == wheel:
            raise AssertionError("wheel hash must stream")
        return original(path)

    monkeypatch.setattr(Path, "read_bytes", reject_wheel_read_bytes)
    assert _wheel_identity(wheel)["wheel_sha256"] == hashlib.sha256(
        original(wheel)
    ).hexdigest()


def test_build_manifest_entry_hash_is_streamed_without_read_bytes(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_build_manifest import _entry
    finally:
        sys.path.pop(0)

    artifact = tmp_path / "artifact.bin"
    artifact.write_bytes(b"stream me")

    def reject_read_bytes(_path: Path) -> bytes:
        raise AssertionError("manifest hashes must stream")

    monkeypatch.setattr(Path, "read_bytes", reject_read_bytes)
    assert _entry("artifact", artifact) == {
        "bytes": 9,
        "name": "artifact",
        "sha256": hashlib.sha256(b"stream me").hexdigest(),
    }


def test_build_manifest_binds_exact_phase0_receipt_allowlist(tmp_path: Path) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_build_manifest import _phase0_receipt_entries
    finally:
        sys.path.pop(0)

    receipt_dir = _write_phase0_receipts(tmp_path / "phase0")
    entries = _phase0_receipt_entries(receipt_dir)

    assert [row["name"] for row in entries] == [
        f"phase0/{name}" for name in PHASE0_RECEIPT_SCHEMAS
    ]
    assert entries == [
        {
            "bytes": len((receipt_dir / name).read_bytes()),
            "name": f"phase0/{name}",
            "sha256": hashlib.sha256((receipt_dir / name).read_bytes()).hexdigest(),
        }
        for name in PHASE0_RECEIPT_SCHEMAS
    ]


@pytest.mark.parametrize("mutation", ("missing", "extra", "symlink", "oversize"))
def test_build_manifest_rejects_invalid_phase0_receipt_set(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, mutation: str
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_build_manifest
    finally:
        sys.path.pop(0)

    receipt_dir = _write_phase0_receipts(tmp_path / "phase0")
    selected = receipt_dir / "contract-hashes.json"
    if mutation == "missing":
        selected.unlink()
    elif mutation == "extra":
        (receipt_dir / "extra.json").write_text("{}\n", encoding="utf-8")
    elif mutation == "symlink":
        selected.unlink()
        selected.symlink_to("legacy-import.json")
    else:
        monkeypatch.setattr(write_build_manifest, "MAX_PHASE0_RECEIPT_BYTES", 8)
    with pytest.raises(ValueError, match="Phase 0 receipts failed validation"):
        write_build_manifest._phase0_receipt_entries(receipt_dir)


def test_build_manifest_detects_phase0_receipt_mutation_during_read(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_build_manifest
    finally:
        sys.path.pop(0)

    receipt_dir = _write_phase0_receipts(tmp_path / "phase0")
    selected = receipt_dir / "contract-hashes.json"
    original_read = write_build_manifest.os.read
    changed = False

    def mutate_then_read(fd: int, count: int) -> bytes:
        nonlocal changed
        if not changed:
            changed = True
            selected.write_bytes(selected.read_bytes() + b" ")
        return original_read(fd, count)

    monkeypatch.setattr(write_build_manifest.os, "read", mutate_then_read)
    with pytest.raises(ValueError, match="Phase 0 receipts failed validation"):
        write_build_manifest._phase0_receipt_entries(receipt_dir)


def test_build_manifest_detects_earlier_receipt_mutation_during_later_read(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_build_manifest
    finally:
        sys.path.pop(0)

    receipt_dir = _write_phase0_receipts(tmp_path / "phase0")
    first = receipt_dir / "contract-hashes.json"
    later = receipt_dir / "legacy-import.json"
    later_inode = later.stat().st_ino
    original_read = write_build_manifest.os.read
    changed = False

    def mutate_first_during_later_read(fd: int, count: int) -> bytes:
        nonlocal changed
        if not changed and os.fstat(fd).st_ino == later_inode:
            changed = True
            payload = first.read_bytes()
            first.write_bytes(payload[:-1] + b" ")
        return original_read(fd, count)

    monkeypatch.setattr(
        write_build_manifest.os, "read", mutate_first_during_later_read
    )
    with pytest.raises(ValueError, match="Phase 0 receipts failed validation"):
        write_build_manifest._phase0_receipt_entries(receipt_dir)


def test_smoke_result_file_must_be_regular_bounded_and_not_symlinked(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import clean_wheel_smoke
    finally:
        sys.path.pop(0)

    result = tmp_path / "smoke-result.json"
    result.write_text('{"ok":true}\n', encoding="utf-8")
    assert clean_wheel_smoke._read_smoke_result(result) == {"ok": True}

    result.unlink()
    target = tmp_path / "target.json"
    target.write_text('{"ok":true}\n', encoding="utf-8")
    result.symlink_to(target)
    with pytest.raises(ValueError, match="smoke result failed validation"):
        clean_wheel_smoke._read_smoke_result(result)

    result.unlink()
    result.write_bytes(b"12345")
    monkeypatch.setattr(clean_wheel_smoke, "MAX_SMOKE_BYTES", 4)
    with pytest.raises(ValueError, match="smoke result failed validation"):
        clean_wheel_smoke._read_smoke_result(result)


def test_quiet_subprocess_discards_output_and_keeps_timeout(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import clean_wheel_smoke
    finally:
        sys.path.pop(0)

    observed = {}

    def completed(command, **kwargs):
        observed["command"] = command
        observed.update(kwargs)
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(clean_wheel_smoke.subprocess, "run", completed)
    result = clean_wheel_smoke._run_quiet(
        ["uv", "example"], cwd=tmp_path, environment={"PATH": "/bin"}
    )

    assert result.returncode == 0
    assert observed["stdout"] is subprocess.DEVNULL
    assert observed["stderr"] is subprocess.DEVNULL
    assert observed["timeout"] == clean_wheel_smoke.SUBPROCESS_TIMEOUT_SECONDS
    assert "capture_output" not in observed


@pytest.mark.parametrize(
    "member",
    (
        "../escape.py",
        "/absolute.py",
        "C:/drive.py",
        r"folder\windows.py",
        "folder/./dot.py",
        "//server/share.py",
    ),
)
def test_wheel_rejects_noncanonical_member_paths(
    tmp_path: Path, member: str
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _wheel_identity
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    _write_fake_wheel(wheel, extra_member=(member, b"payload"))

    with pytest.raises(ValueError, match="built wheel identity failed validation"):
        _wheel_identity(wheel)


def test_wheel_rejects_excessive_member_count_and_compression_ratio(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import clean_wheel_smoke
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    _write_fake_wheel(wheel)
    monkeypatch.setattr(clean_wheel_smoke, "MAX_WHEEL_MEMBER_COUNT", 3)
    with pytest.raises(ValueError, match="built wheel identity failed validation"):
        clean_wheel_smoke._wheel_identity(wheel)

    monkeypatch.setattr(clean_wheel_smoke, "MAX_WHEEL_MEMBER_COUNT", 128)
    _write_fake_wheel(
        wheel,
        extra_member=("shipworthy/compressed.txt", b"a" * 1_000_000),
        compression=zipfile.ZIP_DEFLATED,
    )
    with pytest.raises(ValueError, match="built wheel identity failed validation"):
        clean_wheel_smoke._wheel_identity(wheel)


@pytest.mark.parametrize(
    "raw",
    (
        b'{"bomFormat":"CycloneDX","specVersion":"nonsense","version":1,"components":[]}',
        b'{"bomFormat":"CycloneDX","specVersion":"1.6","version":1,"components":[42]}',
        b'{"bomFormat":"CycloneDX","specVersion":"1.6","version":1,"components":[{}]}',
        b'{"bomFormat":"CycloneDX","specVersion":"1.6","version":1,"components":[],"version":2}',
        b'{"bomFormat":"CycloneDX","specVersion":"1.6","version":NaN,"components":[]}',
        b'{"bomFormat":"CycloneDX",',
    ),
)
def test_build_manifest_rejects_non_cyclonedx_and_ambiguous_json(
    tmp_path: Path, raw: bytes
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_build_manifest import build_manifest
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    lock = tmp_path / "uv.lock"
    sbom = tmp_path / "sbom.cdx.json"
    smoke = tmp_path / "clean-wheel-smoke.json"
    requirements = tmp_path / "runtime-requirements.txt"
    _write_fake_wheel(wheel)
    lock.write_bytes(b"lock")
    sbom.write_bytes(raw)
    smoke.write_text("{}", encoding="utf-8")
    requirements.write_text("pydantic==2.13.4\n", encoding="utf-8")

    with pytest.raises(ValueError, match="SBOM failed CycloneDX validation"):
        build_manifest(
            wheel=wheel,
            lock=lock,
            sbom=sbom,
            smoke=smoke,
            runtime_requirements=requirements,
        )


def test_build_manifest_binds_wheel_lock_and_valid_cyclonedx_bytes(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_build_manifest import build_manifest
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    lock = tmp_path / "uv.lock"
    sbom = tmp_path / "sbom.cdx.json"
    smoke = tmp_path / "clean-wheel-smoke.json"
    requirements = tmp_path / "runtime-requirements.txt"
    wheel_files = _write_fake_wheel(wheel)
    lock.write_bytes(b"lock")
    requirements.write_text("pydantic==2.13.4\n", encoding="utf-8")
    sbom.write_text(
        json.dumps(
            {
                "bomFormat": "CycloneDX",
                "specVersion": "1.6",
                "version": 1,
                "components": [
                    {
                        "type": "application",
                        "name": "shipworthy-core",
                        "version": "0.1.0",
                    },
                    {
                        "type": "library",
                        "name": "pydantic",
                        "version": "2.13.4",
                    },
                ],
            }
        ),
        encoding="utf-8",
    )
    record_files_sha256 = hashlib.sha256(
        "\n".join(wheel_files).encode("utf-8")
    ).hexdigest()
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _wheel_identity
    finally:
        sys.path.pop(0)
    wheel_identity = _wheel_identity(wheel)
    smoke.write_text(
        json.dumps(
            {
                "schema": "shipworthy-clean-wheel-smoke/v1",
                "identity_match": True,
                "built_wheel": wheel_identity,
                "installed_distribution": {
                    "name": "shipworthy-core",
                    "version": "0.1.0",
                    "missing_wheel_files": [],
                    "wheel_record_entries_verified": True,
                },
                "network_containment": {
                    "dependency_installation": "offline_enforced",
                    "installed_code_runtime": "NOT_PROVEN",
                },
                "runtime_distributions": [
                    {"name": "pydantic", "version": "2.13.4"},
                    {"name": "shipworthy-core", "version": "0.1.0"},
                ],
                "runtime_requirements_sha256": hashlib.sha256(
                    requirements.read_bytes()
                ).hexdigest(),
            }
        ),
        encoding="utf-8",
    )

    manifest = build_manifest(
        wheel=wheel,
        lock=lock,
        sbom=sbom,
        smoke=smoke,
        runtime_requirements=requirements,
    )

    assert manifest["schema"] == "shipworthy-build-manifest/v1"
    assert manifest["artifacts"] == [
        {
            "bytes": len(path.read_bytes()),
            "name": name,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for name, path in (
            ("wheel", wheel),
            ("uv.lock", lock),
            ("sbom.cdx.json", sbom),
            ("clean-wheel-smoke.json", smoke),
            ("runtime-requirements.txt", requirements),
        )
    ]
    assert manifest["sbom"] == {
        "bomFormat": "CycloneDX",
        "generated_inventory_scope": "locked_all_groups_environment",
        "specVersion": "1.6",
        "surrounding_all_groups_completeness": "NOT_PROVEN",
        "version": 1,
        "verified_inventory_scope": "clean_wheel_runtime_closure_subset",
    }
    assert manifest["package_identity"] == {
        "identity_match": True,
        "name": "shipworthy-core",
        "record_files_sha256": record_files_sha256,
        "version": "0.1.0",
        "wheel_sha256": wheel_identity["wheel_sha256"],
    }
    assert manifest["network_containment"] == {
        "dependency_installation": "offline_enforced",
        "installed_code_runtime": "NOT_PROVEN",
    }
    assert manifest["python_target_matrix"] == {
        "requires_python": ">=3.12,<3.15",
        "status": "NOT_PROVEN",
        "targets": ["3.12", "3.13", "3.14"],
    }


@pytest.mark.parametrize(
    "components",
    (
        [],
        [{"type": "library", "name": "unrelated", "version": "1.0"}],
        [
            {
                "type": "application",
                "name": "shipworthy-core",
                "version": "0.1.0",
            }
        ],
    ),
)
def test_build_manifest_rejects_empty_unrelated_or_incomplete_sbom_scope(
    tmp_path: Path, components: list[dict[str, object]]
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _wheel_identity
        from write_build_manifest import build_manifest
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    lock = tmp_path / "uv.lock"
    sbom = tmp_path / "sbom.cdx.json"
    smoke = tmp_path / "clean-wheel-smoke.json"
    requirements = tmp_path / "runtime-requirements.txt"
    _write_fake_wheel(wheel)
    lock.write_bytes(b"lock")
    requirements.write_text("pydantic==2.13.4\n", encoding="utf-8")
    sbom.write_text(
        json.dumps(
            {
                "bomFormat": "CycloneDX",
                "specVersion": "1.6",
                "version": 1,
                "components": components,
            }
        ),
        encoding="utf-8",
    )
    identity = _wheel_identity(wheel)
    smoke.write_text(
        json.dumps(
            {
                "schema": "shipworthy-clean-wheel-smoke/v1",
                "identity_match": True,
                "built_wheel": identity,
                "installed_distribution": {
                    "name": "shipworthy-core",
                    "version": "0.1.0",
                    "missing_wheel_files": [],
                    "wheel_record_entries_verified": True,
                },
                "network_containment": {
                    "dependency_installation": "offline_enforced",
                    "installed_code_runtime": "NOT_PROVEN",
                },
                "runtime_distributions": [
                    {"name": "pydantic", "version": "2.13.4"},
                    {"name": "shipworthy-core", "version": "0.1.0"},
                ],
                "runtime_requirements_sha256": hashlib.sha256(
                    requirements.read_bytes()
                ).hexdigest(),
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="SBOM inventory scope failed validation"):
        build_manifest(
            wheel=wheel,
            lock=lock,
            sbom=sbom,
            smoke=smoke,
            runtime_requirements=requirements,
        )


def test_build_manifest_rejects_smoke_with_wrong_exact_wheel_digest(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from clean_wheel_smoke import _wheel_identity
        from write_build_manifest import _validated_smoke
    finally:
        sys.path.pop(0)

    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    _write_fake_wheel(wheel)
    identity = _wheel_identity(wheel)
    identity["wheel_sha256"] = "0" * 64
    smoke = {
        "schema": "shipworthy-clean-wheel-smoke/v1",
        "identity_match": True,
        "built_wheel": identity,
        "installed_distribution": {
            "name": "shipworthy-core",
            "version": "0.1.0",
            "missing_wheel_files": [],
            "wheel_record_entries_verified": True,
        },
        "network_containment": {
            "dependency_installation": "offline_enforced",
            "installed_code_runtime": "NOT_PROVEN",
        },
        "runtime_distributions": [
            {"name": "shipworthy-core", "version": "0.1.0"}
        ],
        "runtime_requirements_sha256": "1" * 64,
    }

    with pytest.raises(
        ValueError, match="clean-wheel identity evidence failed validation"
    ):
        _validated_smoke(
            json.dumps(smoke).encode("utf-8"),
            wheel,
            runtime_requirements_sha256="1" * 64,
        )
