from __future__ import annotations

import ast
from pathlib import Path
import tomllib
from typing import Any

import pytest


ROOT = Path(__file__).resolve().parents[2]
RECIPES = (
    ROOT
    / "plugins"
    / "shipworthy"
    / "skills"
    / "ship-readiness-orchestrator"
    / "references"
    / "host-execution-recipes.md"
)


def _recipe_text() -> str:
    assert RECIPES.is_file(), "host execution recipe is missing"
    return RECIPES.read_text(encoding="utf-8")


FORBIDDEN_MODULES: dict[str, tuple[str, ...]] = {
    "network": (
        "urllib.request",
        "http.client",
        "socket",
        "ftplib",
        "smtplib",
        "requests",
        "httpx",
        "httpcore",
        "aiohttp",
        "urllib3",
        "websocket",
        "websockets",
    ),
    "process": ("subprocess", "multiprocessing"),
    "browser": ("playwright", "selenium", "pyppeteer", "webbrowser"),
    "package-installer": ("pip", "ensurepip"),
    "database-storage": (
        "sqlite3",
        "dbm",
        "shelve",
        "sqlalchemy",
        "psycopg",
        "psycopg2",
        "pymongo",
        "redis",
    ),
    "server-daemon": (
        "http.server",
        "socketserver",
        "wsgiref",
        "fastapi",
        "flask",
        "django",
        "uvicorn",
        "gunicorn",
        "daemon",
        "celery",
    ),
    "mcp-portal": ("mcp", "streamlit", "gradio", "dash"),
    "scheduler": ("apscheduler", "schedule"),
    "credential-store": ("keyring", "secretstorage"),
    "provider": (
        "anthropic",
        "openai",
        "boto3",
        "botocore",
        "cohere",
        "mistralai",
        "google.generativeai",
        "google.genai",
    ),
}
SAFE_MODULES = {"urllib.parse"}


def _module_category(module: str) -> str | None:
    if any(module == safe or module.startswith(f"{safe}.") for safe in SAFE_MODULES):
        return None
    for category, prefixes in FORBIDDEN_MODULES.items():
        if any(
            module == prefix or module.startswith(f"{prefix}.") for prefix in prefixes
        ):
            return category
    return None


def _call_category(qualified: str) -> str | None:
    if qualified.startswith("os."):
        member = qualified.removeprefix("os.").split(".", 1)[0]
        if member in {"system", "popen", "fork", "forkpty", "startfile"} or (
            member.startswith(("spawn", "exec", "posix_spawn"))
        ):
            return "process"
    if qualified in {
        "asyncio.create_subprocess_exec",
        "asyncio.create_subprocess_shell",
    }:
        return "process"
    return _module_category(qualified)


def _constant_string(node: ast.expr) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _constant_string(node.left)
        right = _constant_string(node.right)
        return left + right if left is not None and right is not None else None
    if isinstance(node, ast.JoinedStr):
        parts: list[str] = []
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append(value.value)
            elif isinstance(value, ast.FormattedValue):
                formatted = _constant_string(value.value)
                if formatted is None:
                    return None
                parts.append(formatted)
            else:
                return None
        return "".join(parts)
    return None


class _ReviewedSurfaceVisitor(ast.NodeVisitor):
    """Small policy visitor; not a sandbox or a general security analyzer."""

    def __init__(self) -> None:
        self.module_aliases: list[dict[str, str]] = [{}]
        self.direct_aliases: list[dict[str, str]] = [{}]
        self.shadowed: list[set[str]] = [set()]
        self.scope_kinds: list[str] = ["module"]
        self.class_lexical_bases: list[
            tuple[dict[str, str], dict[str, str], set[str]]
        ] = []
        self.findings: list[str] = []

    def _bind_assignment(self, name: str, qualified: str | None) -> None:
        if qualified:
            self.direct_aliases[-1][name] = qualified
            self.module_aliases[-1].pop(name, None)
            self.shadowed[-1].discard(name)
            return
        self.direct_aliases[-1].pop(name, None)
        self.module_aliases[-1].pop(name, None)
        self.shadowed[-1].add(name)

    def _bind_definition(self, name: str) -> None:
        self.direct_aliases[-1].pop(name, None)
        self.module_aliases[-1].pop(name, None)
        self.shadowed[-1].add(name)

    def _qualified(self, node: ast.expr) -> str | None:
        if isinstance(node, ast.Name):
            if node.id in self.shadowed[-1]:
                return None
            return self.direct_aliases[-1].get(
                node.id, self.module_aliases[-1].get(node.id, node.id)
            )
        if isinstance(node, ast.Attribute):
            parent = self._qualified(node.value)
            return f"{parent}.{node.attr}" if parent else None
        if isinstance(node, ast.Call):
            called = self._qualified(node.func)
            if called in {"getattr", "builtins.getattr"} and len(node.args) >= 2:
                parent = self._qualified(node.args[0])
                member = _constant_string(node.args[1])
                return f"{parent}.{member}" if parent and member else None
        return None

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            local_name = alias.asname or alias.name.split(".", 1)[0]
            self.module_aliases[-1][local_name] = alias.name
            self.shadowed[-1].discard(local_name)
            if category := _module_category(alias.name):
                self.findings.append(f"{category}:import:{alias.name}@{node.lineno}")

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if not node.module:
            return
        for alias in node.names:
            local_name = alias.asname or alias.name
            self.direct_aliases[-1][local_name] = f"{node.module}.{alias.name}"
            self.shadowed[-1].discard(local_name)
        if category := _module_category(node.module):
            self.findings.append(f"{category}:import:{node.module}@{node.lineno}")

    def visit_Assign(self, node: ast.Assign) -> None:
        self.visit(node.value)
        qualified = self._qualified(node.value)
        for target in node.targets:
            if not isinstance(target, ast.Name):
                continue
            self._bind_assignment(target.id, qualified)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        self.visit(node.annotation)
        if node.value is not None:
            self.visit(node.value)
        if isinstance(node.target, ast.Name):
            qualified = self._qualified(node.value) if node.value is not None else None
            self._bind_assignment(node.target.id, qualified)

    def visit_Call(self, node: ast.Call) -> None:
        qualified = self._qualified(node.func)
        if qualified in {
            "__import__",
            "builtins.__import__",
            "importlib.import_module",
        }:
            module_name = _constant_string(node.args[0]) if node.args else None
            if module_name is None:
                self.findings.append(f"dynamic-import:call:<nonconstant>@{node.lineno}")
            elif _module_category(module_name):
                self.findings.append(f"dynamic-import:call:{module_name}@{node.lineno}")
        elif qualified and (category := _call_category(qualified)):
            self.findings.append(f"{category}:call:{qualified}@{node.lineno}")
        self.generic_visit(node)

    def _visit_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        for decorator in node.decorator_list:
            self.visit(decorator)
        for default in [*node.args.defaults, *node.args.kw_defaults]:
            if default is not None:
                self.visit(default)
        self._bind_definition(node.name)
        if self.scope_kinds[-1] == "class":
            lexical_base = self.class_lexical_bases[-1]
            module_aliases = lexical_base[0].copy()
            direct_aliases = lexical_base[1].copy()
            shadowed = lexical_base[2].copy()
        else:
            module_aliases = self.module_aliases[-1].copy()
            direct_aliases = self.direct_aliases[-1].copy()
            shadowed = self.shadowed[-1].copy()
        parameters = {
            argument.arg
            for argument in [
                *node.args.posonlyargs,
                *node.args.args,
                *node.args.kwonlyargs,
            ]
        }
        if node.args.vararg:
            parameters.add(node.args.vararg.arg)
        if node.args.kwarg:
            parameters.add(node.args.kwarg.arg)
        for parameter in parameters:
            module_aliases.pop(parameter, None)
            direct_aliases.pop(parameter, None)
        shadowed.update(parameters)
        self.module_aliases.append(module_aliases)
        self.direct_aliases.append(direct_aliases)
        self.shadowed.append(shadowed)
        self.scope_kinds.append("function")
        for statement in node.body:
            self.visit(statement)
        self.scope_kinds.pop()
        self.shadowed.pop()
        self.direct_aliases.pop()
        self.module_aliases.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._visit_function(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._visit_function(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        for decorator in node.decorator_list:
            self.visit(decorator)
        for base in node.bases:
            self.visit(base)
        for keyword in node.keywords:
            self.visit(keyword.value)
        if self.scope_kinds[-1] == "class":
            lexical_base = self.class_lexical_bases[-1]
        else:
            lexical_base = (
                self.module_aliases[-1].copy(),
                self.direct_aliases[-1].copy(),
                self.shadowed[-1].copy(),
            )
        module_aliases = lexical_base[0].copy()
        direct_aliases = lexical_base[1].copy()
        self.module_aliases.append(module_aliases)
        self.direct_aliases.append(direct_aliases)
        self.shadowed.append(lexical_base[2].copy())
        self.scope_kinds.append("class")
        self.class_lexical_bases.append(lexical_base)
        for statement in node.body:
            self.visit(statement)
        self.class_lexical_bases.pop()
        self.scope_kinds.pop()
        self.shadowed.pop()
        self.direct_aliases.pop()
        self.module_aliases.pop()
        self._bind_definition(node.name)


def _review_source_policy(source: str) -> list[str]:
    visitor = _ReviewedSurfaceVisitor()
    visitor.visit(ast.parse(source))
    return sorted(set(visitor.findings))


ALLOWED_RUNTIME_DEPENDENCIES = {"pydantic>=2.13,<3"}
FORBIDDEN_DYNAMIC_FIELDS = {
    "dependencies",
    "optional-dependencies",
    "scripts",
    "gui-scripts",
    "entry-points",
}
MAX_DYNAMIC_FIELDS = 32
MAX_DYNAMIC_FIELD_LENGTH = 64


def _packaged_python_sources(
    root: Path, config: dict[str, Any]
) -> tuple[set[Path], list[str]]:
    wheel = (
        config.get("tool", {})
        .get("hatch", {})
        .get("build", {})
        .get("targets", {})
        .get("wheel", {})
    )
    sources: set[Path] = set()
    findings: list[str] = []
    for package in wheel.get("packages", []):
        package_path = (root / package).resolve()
        if package_path.is_dir():
            sources.update(package_path.rglob("*.py"))
        elif package_path.suffix == ".py" and package_path.is_file():
            sources.add(package_path)
        else:
            findings.append(f"packaging:missing:{package}")
    for source_name in wheel.get("force-include", {}):
        source_path = (root / source_name).resolve()
        try:
            source_path.relative_to(root.resolve())
        except ValueError:
            findings.append(f"packaging:outside-root:{source_name}")
            continue
        if source_path.is_dir():
            sources.update(source_path.rglob("*.py"))
        elif source_path.suffix == ".py" and source_path.is_file():
            sources.add(source_path)
        elif not source_path.exists():
            findings.append(f"packaging:missing:{source_name}")
    return sources, findings


def _review_packaged_surface(root: Path) -> list[str]:
    config = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    project = config.get("project", {})
    findings: list[str] = []
    for dependency in project.get("dependencies", []):
        if dependency not in ALLOWED_RUNTIME_DEPENDENCIES:
            findings.append(f"dependency:{dependency}")
    optional_dependencies = project.get("optional-dependencies", {})
    if not isinstance(optional_dependencies, dict):
        findings.append("optional-dependency:invalid")
    else:
        for group, dependencies in optional_dependencies.items():
            if dependencies:
                findings.append(f"optional-dependency:{group}")
    for entrypoint_key in ("scripts", "gui-scripts", "entry-points"):
        if project.get(entrypoint_key):
            findings.append(f"entrypoint:{entrypoint_key}")
    dynamic = project.get("dynamic", [])
    if not isinstance(dynamic, list):
        findings.append("dynamic-metadata:invalid:type")
    elif len(dynamic) > MAX_DYNAMIC_FIELDS:
        findings.append("dynamic-metadata:invalid:count")
    elif any(not isinstance(field, str) for field in dynamic):
        findings.append("dynamic-metadata:invalid:member-type")
    else:
        if len(dynamic) != len(set(dynamic)):
            findings.append("dynamic-metadata:invalid:duplicate")
        for field in dynamic:
            if not field or len(field) > MAX_DYNAMIC_FIELD_LENGTH:
                findings.append("dynamic-metadata:invalid:name")
            if field in FORBIDDEN_DYNAMIC_FIELDS:
                findings.append(f"dynamic-metadata:forbidden:{field}")
    sources, packaging_findings = _packaged_python_sources(root, config)
    findings.extend(packaging_findings)
    for path in sorted(sources):
        for finding in _review_source_policy(path.read_text(encoding="utf-8")):
            findings.append(f"{path.relative_to(root)}:{finding}")
    return sorted(findings)


def _write_metadata_fixture(root: Path, dynamic_declaration: str) -> None:
    (root / "src" / "shipworthy").mkdir(parents=True)
    (root / "src" / "shipworthy" / "safe.py").write_text("VALUE = 1\n")
    (root / "pyproject.toml").write_text(
        '[project]\nname = "fixture"\nversion = "0.0.1"\n'
        'dependencies = ["pydantic>=2.13,<3"]\n'
        f"{dynamic_declaration}\n"
        '[tool.hatch.build.targets.wheel]\npackages = ["src/shipworthy"]\n'
    )


def test_recipe_preserves_the_host_execution_decision_order() -> None:
    text = _recipe_text()
    ordered_markers = [
        "1. **Discover and run target-owned tests.**",
        "2. **Use native browser or computer-use for adaptive discovery.**",
        "3. **Reuse an existing target-owned Playwright setup for deterministic replay.**",
        "4. **Propose a minimal target-owned Playwright test only with explicit user authorization.**",
        "5. **Record unavailable execution as evidence debt.**",
    ]
    positions = [text.index(marker) for marker in ordered_markers]
    assert positions == sorted(positions)


def test_recipe_runs_every_applicable_safe_path_for_each_material_claim() -> None:
    text = _recipe_text().lower()
    for required in (
        "for each material claim or evidence need",
        "every applicable safe path",
        "supporting evidence and never replace",
        "required native frontend path-walk",
        "only for that specific claim",
        "flagship frontend gate remains satisfied",
    ):
        assert required in text
    assert "stop at the first sufficient, safe capability" not in text


def test_recipe_keeps_execution_target_owned_bounded_and_local() -> None:
    text = _recipe_text().lower()
    for required in (
        "target-repository instructions",
        "read-only by default",
        "safe fixture",
        "explicit authorization",
        "destructive",
        "local-only artifacts",
        "pytest",
        "npm test",
        "playwright test",
        "sarif",
        "junit",
        "not a general command runner",
    ):
        assert required in text


def test_recipe_does_not_install_or_launch_an_execution_platform() -> None:
    text = _recipe_text().lower()
    for forbidden in (
        "pip install",
        "npm install",
        "npx playwright install",
        "shipworthy run",
        "general-purpose shell runner",
    ):
        assert forbidden not in text


def test_recipe_states_the_reviewed_policy_limit_honestly() -> None:
    text = _recipe_text()
    assert "defense-in-depth reviewed packaged-surface policy" in text
    assert "OS-level containment remains `NOT_PROVEN`" in text
    assert "review and forbidden-behavior `rg` scans are still required" in text


@pytest.mark.parametrize(
    ("category", "source"),
    [
        ("network", "import urllib.request as transport\ntransport.urlopen('x')"),
        ("network", "from http.client import HTTPConnection as Conn\nConn('x')"),
        ("network", "import socket as s\ns.create_connection(('x', 1))"),
        ("network", "import httpcore as transport\ntransport.ConnectionPool()"),
        ("process", "import os as operating\noperating.spawnv(0, 'x', ['x'])"),
        ("process", "import os as operating\noperating.posix_spawn('x', ['x'], {})"),
        ("process", "from os import system as execute\nexecute('x')"),
        ("process", "import os\nexecute = os.system\nexecute('x')"),
        ("process", "import os\nexecute = getattr(os, 'system')\nexecute('x')"),
        ("process", "import asyncio as aio\naio.create_subprocess_shell('x')"),
        ("browser", "import playwright.sync_api as browser\nbrowser.sync_playwright()"),
        ("package-installer", "from ensurepip import bootstrap as setup\nsetup()"),
        ("database-storage", "import sqlite3 as store\nstore.connect(':memory:')"),
        (
            "server-daemon",
            "from http.server import HTTPServer as Server\nServer(('', 1), object)",
        ),
        ("mcp-portal", "import mcp as protocol\nprotocol.run()"),
        ("scheduler", "import apscheduler as jobs\njobs.start()"),
        ("credential-store", "import keyring as vault\nvault.get_password('a', 'b')"),
        ("provider", "import anthropic as provider\nprovider.Anthropic()"),
        (
            "dynamic-import",
            "import importlib as loader\nloader.import_module('requests')",
        ),
        (
            "dynamic-import",
            "from importlib import import_module as load\nload('playwright')",
        ),
        ("dynamic-import", "__import__('sqlite3')"),
        ("dynamic-import", "import builtins as b\nb.__import__('http' + 'x')"),
        (
            "dynamic-import",
            "import importlib\nimportlib.import_module(f\"{'request'}s\")",
        ),
        ("dynamic-import", "import importlib\nimportlib.import_module(module_name)"),
    ],
)
def test_reviewed_scanner_flags_practical_alias_and_dynamic_import_cases(
    category: str, source: str
) -> None:
    findings = _review_source_policy(source)
    assert findings, f"reviewed {category} case was missed"
    assert any(finding.startswith(f"{category}:") for finding in findings)


def test_reviewed_scanner_explicitly_allows_safe_urllib_parse_usage() -> None:
    source = (
        "from urllib.parse import parse_qsl, quote\nquote('safe')\nparse_qsl('a=b')"
    )
    assert _review_source_policy(source) == []


def test_reviewed_scanner_respects_parameter_shadowing() -> None:
    source = "def inspect(os):\n    return os.system()"
    assert _review_source_policy(source) == []


def test_reviewed_scanner_class_attributes_shadow_only_inside_class_body() -> None:
    source = (
        "import os\n"
        "class C:\n"
        "    os = SafeAdapter()\n"
        "    os.system('local')\n"
        "os.system('module')"
    )
    assert _review_source_policy(source) == ["process:call:os.system@5"]


def test_reviewed_scanner_does_not_leak_class_local_imports_outward() -> None:
    source = (
        "class C:\n"
        "    import os as class_os\n"
        "    class_os.system('inside')\n"
        "class_os.system('outside')"
    )
    assert _review_source_policy(source) == ["process:call:os.system@3"]


def test_reviewed_scanner_function_name_shadows_imported_alias() -> None:
    source = (
        "import os as execute\ndef execute():\n    return None\nexecute.system('x')"
    )
    assert _review_source_policy(source) == []


def test_reviewed_scanner_annotated_assignment_shadows_imported_alias() -> None:
    source = "import os\nos: object = object()\nos.system('x')"
    assert _review_source_policy(source) == []


def test_reviewed_scanner_class_methods_use_lexical_outer_scope_and_parameters() -> (
    None
):
    source = (
        "import os\n"
        "class C:\n"
        "    os = object()\n"
        "    def risky(self):\n"
        "        os.system('x')\n"
        "    def safe(self, os):\n"
        "        os.system('x')\n"
        "    def safe_local(self):\n"
        "        os = SafeAdapter()\n"
        "        os.system('x')"
    )
    assert _review_source_policy(source) == ["process:call:os.system@5"]


def test_reviewed_scanner_restores_bindings_across_nested_class_and_function_scopes() -> (
    None
):
    source = (
        "import os\n"
        "def outer():\n"
        "    class C:\n"
        "        os = object()\n"
        "        def risky(self):\n"
        "            os.system('nested')\n"
        "    def os():\n"
        "        return None\n"
        "    os.system('shadowed')\n"
        "os.system('module')"
    )
    assert _review_source_policy(source) == [
        "process:call:os.system@10",
        "process:call:os.system@6",
    ]


def test_reviewed_packaged_surface_includes_every_force_included_python_source(
    tmp_path: Path,
) -> None:
    (tmp_path / "src" / "shipworthy").mkdir(parents=True)
    (tmp_path / "src" / "shipworthy" / "safe.py").write_text("VALUE = 1\n")
    (tmp_path / "extra.py").write_text("import requests as client\n")
    (tmp_path / "pyproject.toml").write_text(
        """
[project]
name = "fixture"
version = "0.0.1"
dependencies = ["pydantic>=2.13,<3"]

[tool.hatch.build.targets.wheel]
packages = ["src/shipworthy"]

[tool.hatch.build.targets.wheel.force-include]
"extra.py" = "shipworthy/extra.py"
""".strip()
        + "\n"
    )

    findings = _review_packaged_surface(tmp_path)
    assert any("extra.py:network:" in finding for finding in findings)


@pytest.mark.parametrize(
    ("addition", "expected"),
    [
        ('dependencies = ["pydantic>=2.13,<3", "requests>=2"]', "dependency:"),
        (
            'dependencies = ["pydantic>=2.13,<3"]\n[project.scripts]\nrun = "x:y"',
            "entrypoint:",
        ),
        (
            'dependencies = ["pydantic>=2.13,<3"]\n[project.gui-scripts]\nrun = "x:y"',
            "entrypoint:",
        ),
    ],
)
def test_reviewed_packaged_surface_rejects_dependency_and_runner_expansion(
    tmp_path: Path, addition: str, expected: str
) -> None:
    (tmp_path / "src" / "shipworthy").mkdir(parents=True)
    (tmp_path / "src" / "shipworthy" / "safe.py").write_text("VALUE = 1\n")
    (tmp_path / "pyproject.toml").write_text(
        f'[project]\nname = "fixture"\nversion = "0.0.1"\n{addition}\n'
        '[tool.hatch.build.targets.wheel]\npackages = ["src/shipworthy"]\n'
    )
    assert any(
        finding.startswith(expected) for finding in _review_packaged_surface(tmp_path)
    )


@pytest.mark.parametrize(
    "addition",
    [
        '[project.optional-dependencies]\nbrowser = ["requests>=2"]',
        '[project.optional-dependencies]\ndocs = ["mkdocs>=1"]',
    ],
)
def test_reviewed_packaged_surface_rejects_unreviewed_optional_dependencies(
    tmp_path: Path, addition: str
) -> None:
    (tmp_path / "src" / "shipworthy").mkdir(parents=True)
    (tmp_path / "src" / "shipworthy" / "safe.py").write_text("VALUE = 1\n")
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "fixture"\nversion = "0.0.1"\n'
        'dependencies = ["pydantic>=2.13,<3"]\n'
        f"{addition}\n"
        '[tool.hatch.build.targets.wheel]\npackages = ["src/shipworthy"]\n'
    )
    assert any(
        finding.startswith("optional-dependency:")
        for finding in _review_packaged_surface(tmp_path)
    )


@pytest.mark.parametrize(
    "dynamic_field",
    [
        "dependencies",
        "optional-dependencies",
        "scripts",
        "gui-scripts",
        "entry-points",
    ],
)
def test_reviewed_packaged_surface_rejects_dynamic_runtime_or_runner_metadata(
    tmp_path: Path, dynamic_field: str
) -> None:
    _write_metadata_fixture(tmp_path, f'dynamic = ["{dynamic_field}"]')
    assert any(
        finding.startswith("dynamic-metadata:forbidden:")
        for finding in _review_packaged_surface(tmp_path)
    )


@pytest.mark.parametrize(
    "dynamic_declaration",
    [
        'dynamic = "readme"',
        'dynamic = ["readme", "readme"]',
        'dynamic = ["readme", 7]',
        "dynamic = [" + ", ".join(f'"field-{index}"' for index in range(33)) + "]",
        f'dynamic = ["{"x" * 65}"]',
    ],
)
def test_reviewed_packaged_surface_fails_closed_on_invalid_dynamic_metadata(
    tmp_path: Path, dynamic_declaration: str
) -> None:
    _write_metadata_fixture(tmp_path, dynamic_declaration)
    assert any(
        finding.startswith("dynamic-metadata:invalid:")
        for finding in _review_packaged_surface(tmp_path)
    )


def test_reviewed_packaged_surface_allows_bounded_nonruntime_dynamic_metadata(
    tmp_path: Path,
) -> None:
    _write_metadata_fixture(tmp_path, 'dynamic = ["readme"]')
    assert _review_packaged_surface(tmp_path) == []


def test_repository_packaged_surface_matches_reviewed_policy() -> None:
    config = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert config["project"]["dependencies"] == ["pydantic>=2.13,<3"]
    assert "scripts" not in config["project"]
    assert "gui-scripts" not in config["project"]
    assert _review_packaged_surface(ROOT) == []
