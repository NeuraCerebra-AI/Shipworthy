from __future__ import annotations

import re
import subprocess
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
SKILL_ROOT = REPO_ROOT / "plugins/shipworthy/skills/ship-product-workflows"
TEMPLATE = SKILL_ROOT / "templates/audit-ledger.md"
REFERENCE = SKILL_ROOT / "references/living-audit-ledger.md"

def _check_ignore(path: Path, *, verbose: bool = False) -> subprocess.CompletedProcess[str]:
    flags = ["-v", "--no-index"] if verbose else ["-q"]
    return subprocess.run(
        ["git", "check-ignore", *flags, "--", str(path.relative_to(REPO_ROOT))],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )


def test_each_audit_ledger_template_reference_resolves_skill_relative() -> None:
    referencers = (
        SKILL_ROOT / "SKILL.md",
        REFERENCE,
    )

    for referencer in referencers:
        references = re.findall(r"`(templates/audit-ledger\.md)`", referencer.read_text())
        assert references == ["templates/audit-ledger.md"]
        assert (SKILL_ROOT / references[0]).is_file()


def test_audit_ledger_template_covers_the_living_ledger_required_sections() -> None:
    reference_text = REFERENCE.read_text()
    required_block = reference_text.split("## Required Sections", 1)[1].split(
        "## Agent And Wave Packets", 1
    )[0]
    required_bullets = re.findall(r"^- (.+)$", required_block, flags=re.MULTILINE)
    canonical_sections = re.findall(
        r"^- `([^`]+)`: .+$", required_block, flags=re.MULTILINE
    )
    assert len(canonical_sections) == len(required_bullets)

    template_text = TEMPLATE.read_text()
    headings = tuple(re.findall(r"^## (.+)$", template_text, flags=re.MULTILINE))
    assert headings == tuple(canonical_sections)
    assert "<!-- Shipworthy source template; copy it before recording runtime evidence. -->" in template_text


def test_only_the_source_template_is_exempt_from_runtime_ledger_ignore_rule() -> None:
    assert _check_ignore(TEMPLATE).returncode == 1

    source_relative = str(TEMPLATE.relative_to(REPO_ROOT))
    source_rule = _check_ignore(TEMPLATE, verbose=True)
    assert source_rule.stdout.rstrip().endswith(f"\t{source_relative}")
    assert source_rule.stdout.split("\t", 1)[0].endswith(f":!{source_relative}")

    alternate_template = REPO_ROOT / "plugins/shipworthy/skills/other-skill/templates/audit-ledger.md"
    alternate_relative = str(alternate_template.relative_to(REPO_ROOT))
    alternate_rule = _check_ignore(alternate_template, verbose=True)
    assert alternate_rule.stdout.rstrip().endswith(f"\t{alternate_relative}")
    assert alternate_rule.stdout.split("\t", 1)[0].endswith(":**/audit-ledger.md")
    assert _check_ignore(alternate_template).returncode == 0

    runtime_ledgers = (
        REPO_ROOT / "audit-ledger.md",
        REPO_ROOT / "outputs/audit-ledger.md",
        REPO_ROOT / "some-product/audit-ledger.md",
    )
    assert all(_check_ignore(path).returncode == 0 for path in runtime_ledgers)
