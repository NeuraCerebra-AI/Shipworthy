from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import os

import pytest


ROOT = Path(__file__).resolve().parents[2]
CONTRACT_PATHS = (
    "schemas/v1/readiness-ledger.schema.json",
    "schemas/v1/report-input.schema.json",
    "tests/fixtures/legacy/readiness-v0.json",
    "tests/fixtures/v1/confirmed-blocker-ledger.json",
    "tests/fixtures/v1/hostile-path-ledger.json",
    "tests/fixtures/v1/incomplete-ledger.json",
    "tests/fixtures/v1/inconsistent-blocker-ledger.json",
    "tests/fixtures/v1/lying-green-ledger.json",
    "tests/fixtures/v1/mismatched-gate-ledger.json",
    "tests/fixtures/v1/missing-artifact-ledger.json",
    "tests/fixtures/v1/pure-action-first-report-input.json",
    "tests/fixtures/v1/unknown-enum-ledger.json",
)


def _output(tmp_path: Path, run_id: str = "proof") -> Path:
    parent = tmp_path / "artifacts" / ".staging" / run_id
    parent.mkdir(parents=True)
    return parent / "phase0"


def _documents(output: Path) -> dict[str, dict[str, object]]:
    return {
        path.name: json.loads(path.read_text(encoding="utf-8"))
        for path in sorted(output.iterdir())
    }


def test_phase0_receipts_are_deterministic_bounded_and_complete(tmp_path: Path) -> None:
    from shipworthy.phase0_receipts import generate_phase0_receipts

    first = _output(tmp_path, "first")
    second = _output(tmp_path, "second")
    first_result = generate_phase0_receipts(repository_root=ROOT, output_dir=first)
    second_result = generate_phase0_receipts(repository_root=ROOT, output_dir=second)

    expected = {
        "contract-hashes.json",
        "legacy-import.json",
        "dual-render.json",
        "installed-parity-codex.json",
        "installed-parity-claude.json",
        "upgrade-rollback.json",
        "uninstall-skill-only.json",
    }
    assert set(first_result) == expected
    assert set(second_result) == expected
    assert all(path.parent == first for path in first_result.values())
    assert sum(path.stat().st_size for path in first.iterdir()) < 8 * 1024 * 1024
    assert {
        path.name: path.read_bytes() for path in first.iterdir()
    } == {
        path.name: path.read_bytes() for path in second.iterdir()
    }


def test_contract_receipt_uses_only_explicit_allowlisted_files(tmp_path: Path) -> None:
    from shipworthy.phase0_receipts import generate_phase0_receipts

    output = _output(tmp_path)
    generate_phase0_receipts(repository_root=ROOT, output_dir=output)
    document = _documents(output)["contract-hashes.json"]

    assert document["schema"] == "shipworthy-phase0-contract-hashes/v1"
    assert document["scope"] == "repository_contract_fixtures"
    assert document["git_commit_status"] == "not_asserted"
    assert document["allowlist_policy"] == "explicit_paths_only"
    entries = document["entries"]
    assert [row["path"] for row in entries] == list(CONTRACT_PATHS)
    assert {row["kind"] for row in entries} == {"schema", "fixture"}
    for row in entries:
        payload = (ROOT / row["path"]).read_bytes()
        assert row["byte_size"] == len(payload)
        assert row["sha256"] == hashlib.sha256(payload).hexdigest()


def test_import_and_dual_render_receipts_preserve_required_evidence(tmp_path: Path) -> None:
    from shipworthy.phase0_receipts import generate_phase0_receipts

    output = _output(tmp_path)
    generate_phase0_receipts(repository_root=ROOT, output_dir=output)
    documents = _documents(output)
    imported = documents["legacy-import.json"]
    dual = documents["dual-render.json"]
    raw = (ROOT / "tests/fixtures/legacy/readiness-v0.json").read_bytes()

    assert imported["schema"] == "shipworthy-legacy-import-evidence/v1"
    assert imported["scope"] == "repository_fixture_comparison"
    assert imported["source"] == {
        "schema": "legacy/readiness-v0",
        "relative_path": "tests/fixtures/legacy/readiness-v0.json",
        "byte_size": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }
    assert imported["imported_at"] == "2026-07-12T12:34:56Z"
    assert len(imported["canonical_ledger_sha256"]) == 64
    assert imported["mapping_debt"]
    assert "raw_bytes" not in imported

    assert dual["schema"] == "shipworthy-dual-render-evidence/v1"
    assert dual["scope"] == "repository_fixture_comparison"
    assert dual["comparison_only"] is True
    assert dual["skills_switched"] is False
    assert dual["source_sha256"] == hashlib.sha256(raw).hexdigest()
    assert dual["compared_categories"] == [
        "finding_identity",
        "action",
        "proof",
        "gate",
        "counts",
        "html",
        "sarif",
        "bundle",
        "artifact_lineage",
    ]
    assert dual["unexplained_evidence_debt"] == []
    assert dual["differences"]
    assert all(row["explained"] is True for row in dual["differences"])
    for side in ("legacy", "v1"):
        snapshot = dual[side]
        assert len(snapshot["ledger_sha256"]) == 64
        assert len(snapshot["html_sha256"]) == 64
        assert len(snapshot["sarif_sha256"]) == 64
        assert len(snapshot["bundle_sha256"]) == 64
        assert snapshot["bundle_entries"]
        assert snapshot["finding_identity"]
        assert snapshot["actions"]
        assert snapshot["proofs"]
        assert snapshot["gate"]
        assert snapshot["counts"]
        assert snapshot["artifact_lineage"]


def test_synthetic_parity_and_lifecycle_receipts_prove_exact_invariants(
    tmp_path: Path,
) -> None:
    from shipworthy.phase0_receipts import generate_phase0_receipts

    output = _output(tmp_path)
    generate_phase0_receipts(repository_root=ROOT, output_dir=output)
    documents = _documents(output)

    for client in ("codex", "claude"):
        parity = documents[f"installed-parity-{client}.json"]
        assert parity["schema"] == "shipworthy-installed-parity/v1"
        assert parity["scope"] == "synthetic_temporary_fixture"
        assert parity["real_installed_copy_checked"] is False
        assert parity["client"] == client
        assert parity["status"] == "exact"
        assert parity["exact"] is True
        assert parity["issues"] == []
        assert parity["repository_tree_sha256"] == parity["installed_tree_sha256"]

    rollback = documents["upgrade-rollback.json"]
    assert rollback["schema"] == "shipworthy-lifecycle-upgrade-rehearsal/v1"
    assert rollback["scope"] == "synthetic_temporary_fixture"
    assert rollback["failure_injected"] is True
    assert rollback["status"] == "rolled_back"
    assert rollback["backup_created"] is True
    assert rollback["rollback_attempted"] is True
    assert rollback["rollback_exact"] is True
    assert rollback["state_before_sha256"] == rollback["state_after_sha256"]
    assert rollback["canonical_evidence_preserved"] is True
    assert rollback["skills_preserved"] is True
    assert {
        row["relative_path"] for row in rollback["backup_entries"]
    } == {"core/data/local-state.bin", "core/metadata.json"}
    incompatible = rollback["incompatible_upgrade_check"]
    assert incompatible["status"] == "incompatible"
    assert incompatible["backup_created"] is True
    assert incompatible["rollback_attempted"] is False
    assert incompatible["state_before_sha256"] == incompatible["state_after_sha256"]

    uninstall = documents["uninstall-skill-only.json"]
    assert uninstall["schema"] == "shipworthy-lifecycle-uninstall-rehearsal/v1"
    assert uninstall["scope"] == "synthetic_temporary_fixture"
    assert uninstall["authorization"] == {
        "explicit": True,
        "scope": "temporary_fixture_optional_core_only",
    }
    assert uninstall["status"] == "skill_only"
    assert uninstall["removed_roots"] == ["core"]
    assert uninstall["canonical_evidence_preserved"] is True
    assert uninstall["skill_only_operational"] is True


def test_receipt_generation_rejects_collision_and_invalid_staging_path(
    tmp_path: Path,
) -> None:
    from shipworthy.phase0_receipts import Phase0ReceiptError
    from shipworthy.phase0_receipts import generate_phase0_receipts

    output = _output(tmp_path)
    generate_phase0_receipts(repository_root=ROOT, output_dir=output)
    before = {path.name: path.read_bytes() for path in output.iterdir()}
    with pytest.raises(Phase0ReceiptError, match="already exists"):
        generate_phase0_receipts(repository_root=ROOT, output_dir=output)
    assert {path.name: path.read_bytes() for path in output.iterdir()} == before

    with pytest.raises(Phase0ReceiptError, match="staging"):
        generate_phase0_receipts(
            repository_root=ROOT,
            output_dir=tmp_path / "not-staging" / "phase0",
        )


def test_phase0_receipt_script_generates_receipts_without_network(tmp_path: Path) -> None:
    output = _output(tmp_path)
    result = subprocess.run(
        [
            sys.executable,
            "scripts/write_phase0_receipts.py",
            "--output",
            str(output),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
        env={"PATH": "/usr/bin:/bin", "PYTHONPATH": str(ROOT / "src")},
        timeout=30,
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout == ""
    assert result.stderr == ""
    assert len(list(output.glob("*.json"))) == 7


def test_release_gate_places_receipts_before_the_final_manifest() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    assert validate_local.RELEASE_LOG_STAGE_NAMES[-4:] == (
        "18-phase0-receipts",
        "19-python-target-matrix",
        "20-uv-toolchain",
        "21-build-manifest",
    )
    command = validate_local._phase0_receipt_command(
        ROOT / "artifacts/.staging/proof"
    )
    assert command[-3:] == [
        "scripts/write_phase0_receipts.py",
        "--output",
        str(ROOT / "artifacts/.staging/proof/phase0"),
    ]
    manifest = validate_local._build_manifest_command(
        ROOT / "artifacts/.staging/proof",
        ROOT / "artifacts/.staging/proof/dist/core.whl",
        ROOT / "artifacts/.staging/proof/sbom.cdx.json",
        ROOT / "artifacts/.staging/proof/clean-wheel-smoke.json",
        ROOT / "artifacts/.staging/proof/runtime-requirements.txt",
    )
    receipt_index = manifest.index("--phase0-receipts")
    assert manifest[receipt_index + 1] == str(
        ROOT / "artifacts/.staging/proof/phase0"
    )


def _minimal_skills(root: Path) -> Path:
    skills = root / "skills"
    for name in (
        "ship-readiness-orchestrator",
        "ship-deep-review",
        "ship-product-workflows",
        "ship-workflow-clarity",
    ):
        path = skills / name
        path.mkdir(parents=True)
        (path / "SKILL.md").write_text(f"# {name}\n", encoding="utf-8")
    return skills


def test_contract_reader_detects_growth_and_same_size_mutation(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import shipworthy.phase0_receipts as receipts

    path = tmp_path / "contract.json"
    original_read = receipts.os.read
    for replacement in (b"longer payload", b"changed"):
        path.write_bytes(b"initial")
        changed = False

        def mutate_then_read(fd: int, count: int) -> bytes:
            nonlocal changed
            if not changed:
                changed = True
                path.write_bytes(replacement)
            return original_read(fd, count)

        monkeypatch.setattr(receipts.os, "read", mutate_then_read)
        with pytest.raises(receipts.Phase0ReceiptError, match="changed"):
            receipts._read_contract_file(tmp_path, "contract.json")
        monkeypatch.setattr(receipts.os, "read", original_read)


def test_skill_copy_rejects_resource_overflow_symlink_and_special_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import shipworthy.phase0_receipts as receipts

    source = _minimal_skills(tmp_path / "source")
    monkeypatch.setattr(receipts, "_MAX_SKILL_FILES", 3, raising=False)
    with pytest.raises(receipts.Phase0ReceiptError, match="resource"):
        receipts._copy_repository_skills(source, tmp_path / "count-copy")

    monkeypatch.setattr(receipts, "_MAX_SKILL_FILES", 10_000, raising=False)
    (source / "ship-deep-review" / "link").symlink_to("SKILL.md")
    with pytest.raises(receipts.Phase0ReceiptError, match="invalid"):
        receipts._copy_repository_skills(source, tmp_path / "link-copy")
    (source / "ship-deep-review" / "link").unlink()

    special = source / "ship-deep-review" / "special.fifo"
    os.mkfifo(special)
    with pytest.raises(receipts.Phase0ReceiptError, match="invalid"):
        receipts._copy_repository_skills(source, tmp_path / "special-copy")


def test_skill_copy_detects_source_replacement_during_descriptor_read(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import shipworthy.phase0_receipts as receipts

    source = _minimal_skills(tmp_path / "source")
    target = source / "ship-deep-review" / "SKILL.md"
    original_read = receipts.os.read
    changed = False

    def replace_then_read(fd: int, count: int) -> bytes:
        nonlocal changed
        if not changed:
            changed = True
            replacement = target.with_suffix(".replacement")
            replacement.write_bytes(b"replacement bytes\n")
            replacement.replace(target)
        return original_read(fd, count)

    monkeypatch.setattr(receipts.os, "read", replace_then_read)
    with pytest.raises(receipts.Phase0ReceiptError, match="changed"):
        receipts._copy_repository_skills(source, tmp_path / "copy")


def test_skill_copy_detects_earlier_file_mutation_during_later_read(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import shipworthy.phase0_receipts as receipts

    source = _minimal_skills(tmp_path / "source")
    first = source / "ship-readiness-orchestrator" / "SKILL.md"
    later = source / "ship-deep-review" / "SKILL.md"
    later_inode = later.stat().st_ino
    original_read = receipts.os.read
    changed = False

    def mutate_first_during_later_read(fd: int, count: int) -> bytes:
        nonlocal changed
        if not changed and os.fstat(fd).st_ino == later_inode:
            changed = True
            payload = first.read_bytes()
            first.write_bytes(b"X" + payload[1:])
        return original_read(fd, count)

    monkeypatch.setattr(receipts.os, "read", mutate_first_during_later_read)
    with pytest.raises(receipts.Phase0ReceiptError, match="changed"):
        receipts._copy_repository_skills(source, tmp_path / "copy")


def test_skill_copy_rechecks_source_after_writing_snapshot(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import shipworthy.phase0_receipts as receipts

    source = _minimal_skills(tmp_path / "source")
    first = source / "ship-readiness-orchestrator" / "SKILL.md"
    original_write = receipts.os.write
    changed = False

    def mutate_source_during_copy(fd: int, payload: bytes) -> int:
        nonlocal changed
        if not changed:
            changed = True
            original = first.read_bytes()
            first.write_bytes(b"X" + original[1:])
        return original_write(fd, payload)

    monkeypatch.setattr(receipts.os, "write", mutate_source_during_copy)
    with pytest.raises(receipts.Phase0ReceiptError, match="changed"):
        receipts._copy_repository_skills(source, tmp_path / "copy")


@pytest.mark.parametrize("shape", ("broad", "deep"))
def test_skill_copy_bounds_empty_directory_entries_and_depth(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, shape: str
) -> None:
    import shipworthy.phase0_receipts as receipts

    source = _minimal_skills(tmp_path / "source")
    root = source / "ship-deep-review"
    if shape == "broad":
        for index in range(8):
            (root / f"empty-{index}").mkdir()
        monkeypatch.setattr(receipts, "_MAX_SKILL_ENTRIES", 8, raising=False)
    else:
        current = root
        for index in range(8):
            current = current / f"level-{index}"
            current.mkdir()
        monkeypatch.setattr(receipts, "_MAX_SKILL_DEPTH", 4, raising=False)

    with pytest.raises(receipts.Phase0ReceiptError, match="resource"):
        receipts._copy_repository_skills(source, tmp_path / "copy")
