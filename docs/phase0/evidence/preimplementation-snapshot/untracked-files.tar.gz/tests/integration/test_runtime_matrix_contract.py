from __future__ import annotations

import json
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tomllib

import pytest


ROOT = Path(__file__).resolve().parents[2]
TARGETS = ("3.12", "3.13", "3.14")


def _open_fd_numbers() -> set[int]:
    return {int(name) for name in os.listdir("/dev/fd") if name.isdigit()}


def test_locked_matrix_test_group_has_json_validation_without_bom_cli() -> None:
    metadata = tomllib.loads(
        (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    )

    dependencies = metadata["dependency-groups"]["test"]
    assert "cyclonedx-python-lib[json-validation]>=11.11,<12" in dependencies
    assert not any(
        dependency.startswith(("cyclonedx-bom", "lxml"))
        for dependency in dependencies
    )


def test_target_runner_rejects_wrong_runtime_without_writing_proof(
    tmp_path: Path,
) -> None:
    output = tmp_path / "target.json"
    result = subprocess.run(
        [
            sys.executable,
            "scripts/run_python_target.py",
            "--expected-python",
            "0.0",
            "--output",
            str(output),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
        env={"PATH": os.environ["PATH"]},
        timeout=30,
    )

    assert result.returncode == 2
    assert not output.exists()
    assert result.stdout == ""
    assert result.stderr == "python target proof: runtime target mismatch\n"


def test_release_target_commands_use_exact_locked_isolated_test_group() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    staging = ROOT / "artifacts/.staging/proof"
    commands = validate_local._python_target_commands(staging)
    assert len(commands) == 3
    for target, command in zip(("3.12", "3.13", "3.14"), commands, strict=True):
        assert command == [
            "uv",
            "--no-config",
            "--offline",
            "--no-python-downloads",
            "run",
            "--isolated",
            "--locked",
            "--no-default-groups",
            "--group",
            "test",
            "--python",
            target,
            "python",
            "scripts/run_python_target.py",
            "--expected-python",
            target,
            "--output",
            str(staging / f"python-target-{target}.json"),
        ]


def test_target_proof_schema_is_bounded_and_exact_for_current_runtime(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import run_python_target
    finally:
        sys.path.pop(0)

    observed = (sys.version_info.major, sys.version_info.minor, sys.version_info.micro)
    expected = f"{observed[0]}.{observed[1]}"
    monkeypatch.setattr(run_python_target, "_run_compile_gate", lambda: True)
    monkeypatch.setattr(run_python_target, "_run_validation_gate", lambda: True)
    output = tmp_path / "proof.json"

    assert run_python_target.run_target(expected, output) == 0
    document = json.loads(output.read_text(encoding="utf-8"))
    assert document == {
        "compile": {
            "paths": list(run_python_target.COMPILE_PATHS),
            "status": "passed",
        },
        "implementation": "CPython",
        "observed_python": {
            "major": observed[0],
            "minor": observed[1],
            "patch": observed[2],
        },
        "schema": "shipworthy-python-target-proof/v1",
        "status": "passed",
        "target": expected,
        "validation": {"command": "scripts/validate_local.py", "status": "passed"},
    }
    assert output.stat().st_size < 64 * 1024


def test_target_runner_redirects_its_own_bytecode_outside_repository(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import run_python_target
    finally:
        sys.path.pop(0)

    observed: list[str | None] = []

    def gate() -> bool:
        observed.append(sys.pycache_prefix)
        return True

    monkeypatch.setattr(run_python_target, "_run_compile_gate", gate)
    monkeypatch.setattr(run_python_target, "_run_validation_gate", gate)
    target = f"{sys.version_info.major}.{sys.version_info.minor}"

    assert run_python_target.run_target(target, tmp_path / "proof.json") == 0
    assert len(observed) == 2
    assert all(value is not None for value in observed)
    assert all(not str(value).startswith(str(ROOT)) for value in observed)


def _write_matrix_inputs(tmp_path: Path) -> tuple[Path, Path, dict[str, Path], dict[str, Path], dict[str, Path]]:
    tmp_path.mkdir(parents=True, exist_ok=True)
    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    lock = tmp_path / "uv.lock"
    wheel.write_bytes(b"bounded wheel identity")
    lock.write_bytes(b"version = 1\n")
    wheel_sha256 = hashlib.sha256(wheel.read_bytes()).hexdigest()
    lock_sha256 = hashlib.sha256(lock.read_bytes()).hexdigest()
    proofs: dict[str, Path] = {}
    logs: dict[str, Path] = {}
    smokes: dict[str, Path] = {}
    for target in TARGETS:
        major, minor = map(int, target.split("."))
        proof = tmp_path / f"proof-{target}.json"
        proof.write_text(
            json.dumps(
                {
                    "compile": {
                        "paths": [
                            "src",
                            "scripts",
                            "tests",
                            "plugins/shipworthy/skills/ship-readiness-orchestrator/scripts",
                        ],
                        "status": "passed",
                    },
                    "implementation": "CPython",
                    "observed_python": {"major": major, "minor": minor, "patch": 1},
                    "schema": "shipworthy-python-target-proof/v1",
                    "status": "passed",
                    "target": target,
                    "validation": {
                        "command": "scripts/validate_local.py",
                        "status": "passed",
                    },
                }
            )
            + "\n",
            encoding="utf-8",
        )
        log = tmp_path / f"target-{target}.log"
        log.write_text(f"target {target} passed\n", encoding="utf-8")
        smoke = tmp_path / f"smoke-{target}.json"
        smoke.write_text(
            json.dumps(
                {
                    "built_wheel": {
                        "name": "shipworthy-core",
                        "record_files_sha256": "1" * 64,
                        "version": "0.1.0",
                        "wheel_sha256": wheel_sha256,
                    },
                    "identity_match": True,
                    "network_containment": {
                        "bind_probe": "EPERM",
                        "connect_probe": "EPERM",
                        "dependency_installation": (
                            "offline_locked_os_network_contained"
                        ),
                        "dependency_source": "uv_sync_locked",
                        "installed_code_runtime": "os_network_contained",
                        "mechanism": "macos_sandbox_exec_deny_network",
                        "profile_sha256": "2" * 64,
                        "sandbox_exec_sha256": "3" * 64,
                        "scope": "clean_wheel_child_operations_only",
                        "uv_lock_sha256": lock_sha256,
                    },
                    "python_runtime": {
                        "implementation": "CPython",
                        "major": major,
                        "minor": minor,
                        "patch": 1,
                    },
                    "schema": "shipworthy-clean-wheel-smoke/v1",
                    "uv_lock_sha256": lock_sha256,
                }
            )
            + "\n",
            encoding="utf-8",
        )
        proofs[target] = proof
        logs[target] = log
        smokes[target] = smoke
    return wheel, lock, proofs, logs, smokes


def test_matrix_receipt_proves_exact_three_targets_and_scoped_limitations(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_python_target_matrix import build_target_matrix
    finally:
        sys.path.pop(0)

    wheel, lock, proofs, logs, smokes = _write_matrix_inputs(tmp_path)
    receipt = build_target_matrix(
        wheel=wheel, lock=lock, proofs=proofs, logs=logs, smokes=smokes
    )

    assert receipt["schema"] == "shipworthy-python-target-matrix/v1"
    assert receipt["status"] == "PROVEN"
    assert [row["target"] for row in receipt["targets"]] == list(TARGETS)
    assert receipt["limitations"] == {
        "all_groups_on_every_target": "NOT_PROVEN",
        "other_os_architectures": "NOT_PROVEN",
        "other_patch_releases": "NOT_PROVEN",
        "outer_release_and_test_containment": "NOT_PROVEN",
    }
    for row in receipt["targets"]:
        assert set(row) == {"log", "proof", "smoke", "target"}
        for kind in ("log", "proof", "smoke"):
            assert row[kind]["bytes"] > 0
            assert len(row[kind]["sha256"]) == 64


@pytest.mark.parametrize("kind", ("proofs", "logs", "smokes"))
def test_matrix_receipt_rejects_missing_or_duplicate_targets(
    tmp_path: Path, kind: str
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_python_target_matrix import MatrixEvidenceError, _parse_target_paths
    finally:
        sys.path.pop(0)

    values = [f"{target}={tmp_path / (kind + target)}" for target in TARGETS]
    with pytest.raises(MatrixEvidenceError, match="exact targets"):
        _parse_target_paths(values[:-1], kind)
    with pytest.raises(MatrixEvidenceError, match="exact targets"):
        _parse_target_paths([*values, values[0]], kind)


def test_matrix_receipt_rejects_wrong_target_and_cross_input_mutation(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_python_target_matrix as matrix
    finally:
        sys.path.pop(0)

    wheel, lock, proofs, logs, smokes = _write_matrix_inputs(tmp_path)
    wrong = json.loads(proofs["3.12"].read_text(encoding="utf-8"))
    wrong["observed_python"]["minor"] = 13
    proofs["3.12"].write_text(json.dumps(wrong) + "\n", encoding="utf-8")
    with pytest.raises(matrix.MatrixEvidenceError, match="target proof"):
        matrix.build_target_matrix(
            wheel=wheel, lock=lock, proofs=proofs, logs=logs, smokes=smokes
        )

    wheel, lock, proofs, logs, smokes = _write_matrix_inputs(tmp_path / "fresh")
    first = proofs["3.12"]
    later_inode = smokes["3.14"].stat().st_ino
    original_read = matrix.os.read
    changed = False

    def mutate_first_during_later_read(fd: int, count: int) -> bytes:
        nonlocal changed
        if not changed and os.fstat(fd).st_ino == later_inode:
            changed = True
            payload = first.read_bytes()
            first.write_bytes(payload[:-1] + b" ")
        return original_read(fd, count)

    monkeypatch.setattr(matrix.os, "read", mutate_first_during_later_read)
    with pytest.raises(matrix.MatrixEvidenceError, match="changed"):
        matrix.build_target_matrix(
            wheel=wheel, lock=lock, proofs=proofs, logs=logs, smokes=smokes
        )


def test_matrix_receipt_rejects_smoke_bound_to_a_different_lock(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_python_target_matrix as matrix
    finally:
        sys.path.pop(0)

    wheel, lock, proofs, logs, smokes = _write_matrix_inputs(tmp_path)
    smoke = json.loads(smokes["3.12"].read_text(encoding="utf-8"))
    smoke["uv_lock_sha256"] = "0" * 64
    smoke["network_containment"]["uv_lock_sha256"] = "0" * 64
    smokes["3.12"].write_text(json.dumps(smoke) + "\n", encoding="utf-8")

    with pytest.raises(matrix.MatrixEvidenceError, match="target smoke"):
        matrix.build_target_matrix(
            wheel=wheel, lock=lock, proofs=proofs, logs=logs, smokes=smokes
        )

def test_build_manifest_validates_matrix_hashes_and_rejects_mismatch(
    tmp_path: Path,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_build_manifest import _validated_target_matrix
        from write_python_target_matrix import build_target_matrix
    finally:
        sys.path.pop(0)

    wheel, lock, proofs, logs, smokes = _write_matrix_inputs(tmp_path)
    receipt = build_target_matrix(
        wheel=wheel, lock=lock, proofs=proofs, logs=logs, smokes=smokes
    )
    raw = (json.dumps(receipt, sort_keys=True) + "\n").encode("utf-8")
    validated = _validated_target_matrix(
        raw, wheel=wheel, lock=lock, smokes=smokes
    )
    assert validated["status"] == "PROVEN"
    assert validated["targets"] == list(TARGETS)
    assert validated["limitations"]["outer_release_and_test_containment"] == (
        "NOT_PROVEN"
    )

    original = smokes["3.12"].read_bytes()
    smokes["3.12"].write_bytes(original + b" ")
    with pytest.raises(ValueError, match="matrix evidence mismatch"):
        _validated_target_matrix(raw, wheel=wheel, lock=lock, smokes=smokes)


@pytest.mark.parametrize("mutation", ("missing", "duplicate"))
def test_build_manifest_rejects_incomplete_or_duplicate_matrix_targets(
    tmp_path: Path, mutation: str
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_build_manifest import _validated_target_matrix
        from write_python_target_matrix import build_target_matrix
    finally:
        sys.path.pop(0)

    wheel, lock, proofs, logs, smokes = _write_matrix_inputs(tmp_path)
    receipt = build_target_matrix(
        wheel=wheel, lock=lock, proofs=proofs, logs=logs, smokes=smokes
    )
    rows = receipt["targets"]
    assert isinstance(rows, list)
    if mutation == "missing":
        rows.pop()
    else:
        rows[-1] = rows[0]
    raw = (json.dumps(receipt, sort_keys=True) + "\n").encode("utf-8")
    with pytest.raises(ValueError, match="matrix evidence mismatch"):
        _validated_target_matrix(raw, wheel=wheel, lock=lock, smokes=smokes)


def test_build_manifest_promotes_only_exact_matrix_to_proven(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_build_manifest as manifest
        from write_python_target_matrix import build_target_matrix
    finally:
        sys.path.pop(0)

    wheel, lock, proofs, logs, smokes = _write_matrix_inputs(tmp_path)
    toolchain = tmp_path / "uv-toolchain.json"
    toolchain.write_text(
        json.dumps(
            {
                "binary": {
                    "bytes": 1,
                    "name": "uv",
                    "path": "/usr/local/bin/uv",
                    "sha256": "1" * 64,
                },
                "schema": "shipworthy-uv-toolchain/v1",
                "source_lock_sha256": hashlib.sha256(
                    lock.read_bytes()
                ).hexdigest(),
                "uv_version": "uv 0.11.28",
            }
        )
        + "\n",
        encoding="utf-8",
    )
    matrix_path = tmp_path / "python-target-matrix.json"
    matrix_path.write_text(
        json.dumps(
            build_target_matrix(
                wheel=wheel,
                lock=lock,
                proofs=proofs,
                logs=logs,
                smokes=smokes,
            ),
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    sbom = tmp_path / "sbom.json"
    requirements = tmp_path / "runtime-requirements.txt"
    sbom.write_text("{}\n", encoding="utf-8")
    requirements.write_text("pydantic==2.13.4\n", encoding="utf-8")
    built = {
        "name": "shipworthy-core",
        "record_files_sha256": "1" * 64,
        "version": "0.1.0",
        "wheel_sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
    }

    def validated_smoke(
        raw: bytes,
        selected_wheel: Path | dict[str, object],
        *,
        runtime_requirements_sha256: str,
        expected_python: str | None = None,
        require_os_containment: bool = False,
        lock_sha256: str | None = None,
    ) -> dict[str, object]:
        assert selected_wheel == built
        assert expected_python in TARGETS
        assert require_os_containment is True
        assert lock_sha256 == hashlib.sha256(lock.read_bytes()).hexdigest()
        return {
            "built_wheel": built,
            "network_containment": {
                "dependency_installation": "os_network_contained",
                "installed_code_runtime": "os_network_contained",
                "scope": "clean_wheel_child_operations_only",
            },
            "runtime_distributions": [
                {"name": "shipworthy-core", "version": "0.1.0"}
            ],
        }

    monkeypatch.setattr(manifest, "_validated_smoke", validated_smoke)
    monkeypatch.setattr(
        manifest, "_wheel_identity_bytes", lambda *_args: built
    )
    monkeypatch.setattr(
        manifest,
        "_validated_cyclonedx",
        lambda _raw: {"specVersion": "1.6", "version": 1},
    )
    monkeypatch.setattr(manifest, "_validate_sbom_scope", lambda *_args: None)

    document = manifest.build_manifest(
        wheel=wheel,
        lock=lock,
        sbom=sbom,
        smoke=smokes["3.13"],
        runtime_requirements=requirements,
        smokes=smokes,
        target_matrix=matrix_path,
        source_lock=lock,
        toolchain=toolchain,
        proofs=proofs,
        logs=logs,
    )

    assert document["python_target_matrix"]["status"] == "PROVEN"
    assert document["python_target_matrix"]["targets"] == list(TARGETS)
    assert document["network_containment"] == {
        "clean_wheel_dependency_installation": "os_network_contained",
        "clean_wheel_installed_code_runtime": "os_network_contained",
        "outer_release_and_test_execution": "NOT_PROVEN",
        "scope": "clean_wheel_child_operations_only",
    }
    artifact_names = [row["name"] for row in document["artifacts"]]
    assert artifact_names[-4:] == [
        "clean-wheel-smoke-3.12.json",
        "clean-wheel-smoke-3.13.json",
        "clean-wheel-smoke-3.14.json",
        "python-target-matrix.json",
    ]


@pytest.mark.parametrize("selected_name", ["wheel", "sbom", "smoke"])
def test_manifest_rejects_input_mutated_after_semantic_snapshot(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    selected_name: str,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_build_manifest as manifest
    finally:
        sys.path.pop(0)
    paths = {
        "wheel": tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl",
        "lock": tmp_path / "uv.lock",
        "sbom": tmp_path / "sbom.json",
        "smoke": tmp_path / "smoke.json",
        "requirements": tmp_path / "requirements.txt",
    }
    for path in paths.values():
        path.write_bytes(b"snapshot")
    built = {
        "name": "shipworthy-core",
        "record_files_sha256": "1" * 64,
        "version": "0.1.0",
        "wheel_sha256": hashlib.sha256(b"snapshot").hexdigest(),
    }
    monkeypatch.setattr(manifest, "_wheel_identity_bytes", lambda *_args: built)
    monkeypatch.setattr(
        manifest,
        "_validated_smoke",
        lambda *_args, **_kwargs: {
            "built_wheel": built,
            "network_containment": {},
            "runtime_distributions": [
                {"name": "shipworthy-core", "version": "0.1.0"}
            ],
        },
    )
    monkeypatch.setattr(manifest, "_validate_sbom_scope", lambda *_args: None)

    def mutate_after_validation(_raw: bytes) -> dict[str, object]:
        paths[selected_name].write_bytes(b"mutated")
        return {"specVersion": "1.6", "version": 1}

    monkeypatch.setattr(manifest, "_validated_cyclonedx", mutate_after_validation)
    with pytest.raises(ValueError, match="snapshot changed"):
        manifest.build_manifest(
            wheel=paths["wheel"],
            lock=paths["lock"],
            sbom=paths["sbom"],
            smoke=paths["smoke"],
            runtime_requirements=paths["requirements"],
        )


@pytest.mark.parametrize("selected_kind", ["matrix", "proof"])
def test_manifest_rejects_post_matrix_exact_input_mutation(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    selected_kind: str,
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_build_manifest as manifest
    finally:
        sys.path.pop(0)
    wheel = tmp_path / "shipworthy_core-0.1.0-py3-none-any.whl"
    lock = tmp_path / "staged-uv.lock"
    source_lock = tmp_path / "source-uv.lock"
    sbom = tmp_path / "sbom.json"
    requirements = tmp_path / "requirements.txt"
    toolchain = tmp_path / "uv-toolchain.json"
    for path in (wheel, lock, source_lock, sbom, requirements, toolchain):
        path.write_bytes(b"snapshot")
    smokes: dict[str, Path] = {}
    proofs: dict[str, Path] = {}
    logs: dict[str, Path] = {}
    for target in TARGETS:
        smokes[target] = tmp_path / f"smoke-{target}.json"
        proofs[target] = tmp_path / f"proof-{target}.json"
        logs[target] = tmp_path / f"log-{target}.txt"
        smokes[target].write_bytes(b"snapshot")
        proofs[target].write_bytes(b"snapshot")
        logs[target].write_bytes(b"snapshot")
    built = {
        "name": "shipworthy-core",
        "record_files_sha256": "1" * 64,
        "version": "0.1.0",
        "wheel_sha256": hashlib.sha256(b"snapshot").hexdigest(),
    }
    matrix = tmp_path / "matrix.json"
    matrix.write_text(json.dumps({"wheel_identity": built}), encoding="utf-8")
    monkeypatch.setattr(manifest, "_wheel_identity_bytes", lambda *_args: built)
    monkeypatch.setattr(
        manifest,
        "_validated_cyclonedx",
        lambda _raw: {"specVersion": "1.6", "version": 1},
    )
    monkeypatch.setattr(
        manifest, "_validated_toolchain", lambda *_args, **_kwargs: {}
    )
    monkeypatch.setattr(manifest, "_validate_proof", lambda *_args: {})
    monkeypatch.setattr(manifest, "_validate_sbom_scope", lambda *_args: None)
    monkeypatch.setattr(
        manifest,
        "_validated_smoke",
        lambda *_args, **_kwargs: {
            "built_wheel": built,
            "network_containment": {},
            "runtime_distributions": [
                {"name": "shipworthy-core", "version": "0.1.0"}
            ],
        },
    )

    def mutate_after_matrix(*_args: object, **_kwargs: object) -> dict[str, object]:
        selected = matrix if selected_kind == "matrix" else proofs["3.12"]
        selected.write_bytes(b"mutated")
        return {
            "limitations": {},
            "requires_python": ">=3.12,<3.15",
            "status": "PROVEN",
            "targets": list(TARGETS),
        }

    monkeypatch.setattr(manifest, "_validated_target_matrix", mutate_after_matrix)
    with pytest.raises(ValueError, match="snapshot changed"):
        manifest.build_manifest(
            wheel=wheel,
            lock=lock,
            source_lock=source_lock,
            sbom=sbom,
            smoke=smokes["3.13"],
            runtime_requirements=requirements,
            smokes=smokes,
            target_matrix=matrix,
            toolchain=toolchain,
            proofs=proofs,
            logs=logs,
        )


def test_release_matrix_smoke_receipt_and_manifest_commands_are_atomic_stages() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import validate_local
    finally:
        sys.path.pop(0)

    staging = ROOT / "artifacts/.staging/proof"
    wheel = staging / "dist/shipworthy_core-0.1.0-py3-none-any.whl"
    requirements = staging / "runtime-requirements.txt"
    assert validate_local.RELEASE_LOG_STAGE_NAMES[-11:] == (
        "11-python-3.12",
        "12-python-3.13",
        "13-python-3.14",
        "14-sbom",
        "15-clean-wheel-3.12",
        "16-clean-wheel-3.13",
        "17-clean-wheel-3.14",
        "18-phase0-receipts",
        "19-python-target-matrix",
        "20-uv-toolchain",
        "21-build-manifest",
    )
    smoke_commands = validate_local._clean_wheel_smoke_commands(
        staging, wheel, requirements
    )
    assert len(smoke_commands) == 3
    for target, command in zip(TARGETS, smoke_commands, strict=True):
        assert "--isolated" in command
        assert "--locked" in command
        assert command[command.index("--python") + 1] == target
        assert command[command.index("--expected-python") + 1] == target
        assert "--require-os-network-containment" in command
        assert command[command.index("--output") + 1] == str(
            staging / f"clean-wheel-smoke-{target}.json"
        )

    matrix = validate_local._python_matrix_receipt_command(staging, wheel)
    for target, log_stage in zip(TARGETS, (11, 12, 13), strict=True):
        assert f"{target}={staging / f'python-target-{target}.json'}" in matrix
        assert (
            f"{target}={staging / 'logs' / f'{log_stage:02d}-python-{target}.log'}"
            in matrix
        )
        assert f"{target}={staging / f'clean-wheel-smoke-{target}.json'}" in matrix

    manifest = validate_local._build_manifest_command(
        staging,
        wheel,
        staging / "sbom.cdx.json",
        staging / "clean-wheel-smoke-3.13.json",
        requirements,
    )
    assert manifest[manifest.index("--target-matrix") + 1] == str(
        staging / "python-target-matrix.json"
    )
    assert sum(item == "--target-smoke" for item in manifest) == 3


@pytest.mark.parametrize(
    "mutation", ["missing_path", "extra_field", "wrong_command"]
)
def test_matrix_receipt_requires_exact_target_proof_semantics(
    tmp_path: Path, mutation: str
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        from write_python_target_matrix import (
            MatrixEvidenceError,
            build_target_matrix,
        )
    finally:
        sys.path.pop(0)
    wheel, lock, proofs, logs, smokes = _write_matrix_inputs(tmp_path)
    proof = json.loads(proofs["3.12"].read_text(encoding="utf-8"))
    if mutation == "missing_path":
        proof["compile"]["paths"].pop()
    elif mutation == "extra_field":
        proof["unexpected"] = True
    else:
        proof["validation"]["command"] = "other.py"
    proofs["3.12"].write_text(json.dumps(proof) + "\n", encoding="utf-8")
    with pytest.raises(MatrixEvidenceError, match="target proof"):
        build_target_matrix(
            wheel=wheel,
            lock=lock,
            proofs=proofs,
            logs=logs,
            smokes=smokes,
        )


def test_matrix_open_file_closes_descriptor_when_fstat_fails(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        import write_python_target_matrix as matrix
    finally:
        sys.path.pop(0)
    evidence = tmp_path / "evidence.json"
    evidence.write_bytes(b"evidence")
    before = _open_fd_numbers()
    original_fstat = matrix.os.fstat

    def fail_fstat(_descriptor: int) -> os.stat_result:
        raise OSError("injected fstat failure")

    monkeypatch.setattr(matrix.os, "fstat", fail_fstat)
    try:
        with pytest.raises(matrix.MatrixEvidenceError, match="unavailable"):
            matrix._open_file("proof", evidence, 1024)
        assert _open_fd_numbers() == before
    finally:
        monkeypatch.setattr(matrix.os, "fstat", original_fstat)
