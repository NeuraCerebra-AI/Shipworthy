from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[2]
SKILLS = (
    "ship-readiness-orchestrator",
    "ship-deep-review",
    "ship-product-workflows",
    "ship-workflow-clarity",
)
COMPATIBILITY_FILENAME = "shipworthy-compatibility.json"
FEATURE_MODULE_RESOURCES = (
    "domain/__init__.py",
    "domain/browser_evidence.py",
    "domain/contracts.py",
    "domain/entities.py",
    "domain/enums.py",
    "domain/evidence_attachment.py",
    "domain/ids.py",
    "adapters/__init__.py",
    "adapters/importers/__init__.py",
    "adapters/importers/_evidence_normalization.py",
    "adapters/importers/browser_evidence.py",
    "adapters/importers/legacy_readiness.py",
    "adapters/importers/playwright_report.py",
    "adapters/reporting/__init__.py",
    "adapters/reporting/bundle.py",
    "adapters/reporting/compat_loader.py",
    "adapters/reporting/html.py",
    "adapters/reporting/html_safety.py",
    "adapters/reporting/projection.py",
    "adapters/reporting/sarif.py",
)
REQUIRED_CORE_RESOURCES = (
    "__init__.py",
    *FEATURE_MODULE_RESOURCES,
    "schemas/v1/readiness-ledger.schema.json",
    "schemas/v1/report-input.schema.json",
    "schemas/v1/browser-evidence-envelope.schema.json",
    "_legacy_reporting/render_report.py",
    "_legacy_reporting/to_sarif.py",
    "_legacy_reporting/make_bundle.py",
)


def _load_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, document: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document) + "\n", encoding="utf-8")


def _install_skills(skills_dir: Path) -> None:
    metadata = _load_json(ROOT / "src/shipworthy" / COMPATIBILITY_FILENAME)
    for skill in SKILLS:
        root = skills_dir / skill
        root.mkdir(parents=True)
        (root / "SKILL.md").write_text("---\nname: fixture\n---\n", encoding="utf-8")
        (root / "README.md").write_text("fixture\n", encoding="utf-8")
        _write_json(root / COMPATIBILITY_FILENAME, metadata)


def _install_core(site_packages: Path) -> None:
    metadata = _load_json(ROOT / "src/shipworthy" / COMPATIBILITY_FILENAME)
    package = site_packages / "shipworthy"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text(
        'raise RuntimeError("installed core code must not execute")\n',
        encoding="utf-8",
    )
    _write_json(package / COMPATIBILITY_FILENAME, metadata)
    for resource in REQUIRED_CORE_RESOURCES[1:]:
        target = package / resource
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("fixture\n", encoding="utf-8")
    dist_info = site_packages / "shipworthy_core-0.1.0.dist-info"
    dist_info.mkdir()
    (dist_info / "METADATA").write_text(
        "Metadata-Version: 2.4\nName: shipworthy-core\nVersion: 0.1.0\n",
        encoding="utf-8",
    )


def _run_preflight(
    site_packages: Path,
    skills_dir: Path,
    *,
    python_version: str = "3.13",
    output_format: str = "json",
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            sys.executable,
            "scripts/preflight_install.py",
            "--site-packages",
            str(site_packages),
            "--skills-dir",
            str(skills_dir),
            "--python-version",
            python_version,
            "--format",
            output_format,
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )


def test_core_and_all_skill_clients_publish_identical_compatibility_metadata() -> None:
    core = _load_json(ROOT / "src/shipworthy" / COMPATIBILITY_FILENAME)

    assert core == {
        "metadata_schema": "shipworthy-compatibility/v1",
        "core": {
            "package": "shipworthy-core",
            "package_version": "0.1.0",
            "requires_python": ">=3.12,<3.15",
            "compatible_skill_clients": ">=0.1.0,<0.2.0",
            "required_resources": list(REQUIRED_CORE_RESOURCES),
        },
        "schema": {
            "name": "shipworthy/readiness-ledger",
            "version": "1.0",
        },
        "skill_client": {
            "version": "0.1.0",
            "supported_core": ">=0.1.0,<0.2.0",
        },
        "producer": {
            "expected_name": "shipworthy-core",
            "supported_versions": ">=0.1.0,<0.2.0",
        },
        "features": {
            "browser_evidence_intake": True,
            "evidence_attachment": True,
            "core_contracts": True,
            "core_reporting": True,
            "mandatory_html_report": True,
            "playwright_report_import": True,
            "skill_only": True,
        },
        "skills": list(SKILLS),
    }
    for skill in SKILLS:
        skill_metadata = _load_json(
            ROOT / "plugins/shipworthy/skills" / skill / COMPATIBILITY_FILENAME
        )
        assert skill_metadata == core


def test_plugin_manifests_expose_compatibility_without_changing_identity() -> None:
    marketplace = _load_json(ROOT / ".claude-plugin/marketplace.json")
    plugin = _load_json(
        ROOT / "plugins/shipworthy/.claude-plugin/plugin.json"
    )

    entry = marketplace["plugins"][0]
    assert (marketplace["name"], entry["name"], entry["version"]) == (
        "shipworthy",
        "shipworthy",
        "0.1.0",
    )
    assert (plugin["name"], plugin["version"]) == ("shipworthy", "0.1.0")
    expected = {
        "metadata_schema": "shipworthy-compatibility/v1",
        "core": ">=0.1.0,<0.2.0",
        "skill_client": ">=0.1.0,<0.2.0",
        "schema": "1.0",
        "skill_only": True,
    }
    assert entry["compatibility"] == {
        **expected,
        "metadata_file": "../plugins/shipworthy/shipworthy-compatibility.json",
    }
    assert plugin["compatibility"] == {
        **expected,
        "metadata_file": "../shipworthy-compatibility.json",
    }
    marketplace_metadata = (
        ROOT
        / ".claude-plugin"
        / entry["compatibility"]["metadata_file"]
    ).resolve()
    plugin_metadata = (
        ROOT
        / "plugins/shipworthy/.claude-plugin"
        / plugin["compatibility"]["metadata_file"]
    ).resolve()
    assert marketplace_metadata == plugin_metadata
    assert _load_json(plugin_metadata) == _load_json(
        ROOT / "src/shipworthy" / COMPATIBILITY_FILENAME
    )


def test_repo_skill_copies_are_readable_and_independently_usable() -> None:
    for skill in SKILLS:
        root = ROOT / "plugins/shipworthy/skills" / skill
        assert root.is_dir()
        assert (root / "SKILL.md").read_text(encoding="utf-8").startswith("---\n")
        assert _load_json(root / COMPATIBILITY_FILENAME)["features"][
            "skill_only"
        ] is True


def test_advertised_core_resource_manifest_matches_source_feature_closure() -> None:
    metadata = _load_json(ROOT / "src/shipworthy" / COMPATIBILITY_FILENAME)

    assert metadata["core"]["required_resources"] == list(
        REQUIRED_CORE_RESOURCES
    )
    for resource in REQUIRED_CORE_RESOURCES:
        if resource.startswith("schemas/"):
            source = ROOT / resource
        elif resource.startswith("_legacy_reporting/"):
            source = (
                ROOT
                / "plugins/shipworthy/skills/ship-readiness-orchestrator/scripts"
                / Path(resource).name
            )
        else:
            source = ROOT / "src/shipworthy" / resource
        assert source.is_file()


def test_preflight_help_is_available_without_importing_shipworthy() -> None:
    result = subprocess.run(
        [sys.executable, "scripts/preflight_install.py", "--help"],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0
    assert result.stderr == ""
    assert "--site-packages" in result.stdout
    assert "--skills-dir" in result.stdout
    assert "--format" in result.stdout


def test_preflight_enables_complete_compatible_core_and_skills(tmp_path: Path) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 0
    assert result.stderr == ""
    status = json.loads(result.stdout)
    assert status["schema"] == "shipworthy-install-preflight/v1"
    assert status["status"] == "ready"
    assert status["core"] == {
        "features": {
            "browser_evidence_intake": True,
            "evidence_attachment": True,
            "core_contracts": True,
            "core_reporting": True,
            "mandatory_html_report": True,
            "playwright_report_import": True,
        },
        "observed_version": "0.1.0",
        "python_version": "3.13",
        "schema_version": "1.0",
        "status": "enabled",
        "usable": True,
    }
    assert status["skills"] == {
        "client_version": "0.1.0",
        "expected": 4,
        "found": 4,
        "status": "usable",
        "usable": True,
    }
    assert [item["code"] for item in status["diagnostics"]] == [
        "PREFLIGHT_READY"
    ]
    assert str(tmp_path) not in result.stdout


@pytest.mark.parametrize("agent_dir", [".codex/skills", ".claude/skills"])
def test_preflight_preserves_skill_only_mode_for_absent_core(
    tmp_path: Path, agent_dir: str
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / agent_dir
    site_packages.mkdir(parents=True)
    _install_skills(skills_dir)

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 0
    assert result.stderr == ""
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["status"] == "absent"
    assert status["core"]["usable"] is False
    assert status["skills"]["status"] == "usable"
    assert status["skills"]["usable"] is True
    assert [item["code"] for item in status["diagnostics"]] == ["CORE_ABSENT"]
    assert "core is absent" in status["diagnostics"][0]["message"].lower()
    assert "skills remain usable" in status["diagnostics"][0]["message"].lower()
    assert str(tmp_path) not in result.stdout


def test_wrong_python_disables_core_but_keeps_skills_usable(tmp_path: Path) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)

    result = _run_preflight(site_packages, skills_dir, python_version="3.11")

    assert result.returncode == 0
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["status"] == "disabled"
    assert status["core"]["usable"] is False
    assert status["skills"]["usable"] is True
    assert status["diagnostics"][0]["code"] == "PYTHON_INCOMPATIBLE"


def test_incompatible_core_is_not_silently_used_or_upgraded(tmp_path: Path) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".claude/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    metadata_path = site_packages / "shipworthy" / COMPATIBILITY_FILENAME
    metadata = _load_json(metadata_path)
    metadata["core"]["package_version"] = "0.2.0"
    metadata["core"]["compatible_skill_clients"] = ">=0.2.0,<0.3.0"
    metadata["skill_client"] = {
        "version": "0.2.0",
        "supported_core": ">=0.2.0,<0.3.0",
    }
    metadata["producer"]["supported_versions"] = ">=0.2.0,<0.3.0"
    _write_json(metadata_path, metadata)
    old_dist = site_packages / "shipworthy_core-0.1.0.dist-info"
    new_dist = site_packages / "shipworthy_core-0.2.0.dist-info"
    old_dist.rename(new_dist)
    (new_dist / "METADATA").write_text(
        "Metadata-Version: 2.4\nName: shipworthy-core\nVersion: 0.2.0\n",
        encoding="utf-8",
    )

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 0
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["status"] == "disabled"
    assert status["core"]["observed_version"] == "0.2.0"
    assert status["diagnostics"][0]["code"] == "CORE_INCOMPATIBLE"
    assert "upgrade" not in result.stdout.lower()


@pytest.mark.parametrize(
    "missing_resource",
    [
        "shipworthy/__init__.py",
        "shipworthy/schemas/v1/readiness-ledger.schema.json",
        "shipworthy/schemas/v1/browser-evidence-envelope.schema.json",
        "shipworthy/_legacy_reporting/to_sarif.py",
        "shipworthy_core-0.1.0.dist-info/METADATA",
    ],
)
def test_partial_core_resources_are_detected_without_breaking_skills(
    tmp_path: Path, missing_resource: str
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    (site_packages / missing_resource).unlink()

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 0
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["status"] == "invalid"
    assert status["skills"]["usable"] is True
    assert status["diagnostics"][0]["code"] == "CORE_PARTIAL"


@pytest.mark.parametrize("missing_module", FEATURE_MODULE_RESOURCES)
def test_missing_feature_implementation_module_disables_core_only(
    tmp_path: Path, missing_module: str
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    (site_packages / "shipworthy" / missing_module).unlink()

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 0
    assert result.stderr == ""
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["status"] == "invalid"
    assert status["core"]["usable"] is False
    assert status["skills"]["usable"] is True
    assert status["diagnostics"][0]["code"] == "CORE_PARTIAL"


@pytest.mark.parametrize(
    "malformation",
    ["malformed", "duplicate", "oversized", "incompatible", "hostile_producer"],
)
def test_invalid_skill_metadata_fails_closed_with_bounded_sanitized_json(
    tmp_path: Path, malformation: str
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".claude/skills"
    site_packages.mkdir(parents=True)
    _install_skills(skills_dir)
    target = skills_dir / "ship-deep-review" / COMPATIBILITY_FILENAME
    canary = "SECRET-CANARY-" + malformation
    if malformation == "malformed":
        target.write_text("{" + canary, encoding="utf-8")
    elif malformation == "duplicate":
        target.write_text(
            '{"metadata_schema":"%s","metadata_schema":"%s"}'
            % (canary, canary),
            encoding="utf-8",
        )
    elif malformation == "oversized":
        target.write_text(canary + ("x" * (65 * 1024)), encoding="utf-8")
    else:
        metadata = _load_json(target)
        if malformation == "incompatible":
            metadata["skill_client"]["supported_core"] = ">=9.0.0,<10.0.0"
        else:
            metadata["producer"]["expected_name"] = canary
        _write_json(target, metadata)

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 2
    assert result.stderr == ""
    assert len(result.stdout) < 2_048
    assert canary not in result.stdout
    assert str(tmp_path) not in result.stdout
    status = json.loads(result.stdout)
    assert status["status"] == "invalid"
    assert status["skills"]["status"] == "invalid"
    assert status["diagnostics"] == [
        {
            "code": "SKILLS_INVALID",
            "level": "error",
            "message": (
                "The four-skill installation is missing or incompatible and is "
                "not usable."
            ),
        }
    ]


def test_symlinked_core_and_skill_directories_are_not_followed(tmp_path: Path) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    external_core = tmp_path / "external-core"
    (site_packages / "shipworthy").rename(external_core)
    (site_packages / "shipworthy").symlink_to(external_core, target_is_directory=True)

    core_result = _run_preflight(site_packages, skills_dir)
    core_status = json.loads(core_result.stdout)

    assert core_result.returncode == 0
    assert core_status["core"]["status"] == "invalid"
    assert core_status["diagnostics"][0]["code"] == "CORE_PARTIAL"

    external_skill = tmp_path / "external-skill"
    selected = skills_dir / "ship-deep-review"
    selected.rename(external_skill)
    selected.symlink_to(external_skill, target_is_directory=True)
    skill_result = _run_preflight(site_packages, skills_dir)
    skill_status = json.loads(skill_result.stdout)

    assert skill_result.returncode == 2
    assert skill_status["skills"]["status"] == "invalid"


def test_path_traversal_arguments_are_rejected_even_when_target_exists(
    tmp_path: Path,
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    actual_skills = tmp_path / "actual/skills"
    traversal_parent = tmp_path / "traversal"
    site_packages.mkdir(parents=True)
    traversal_parent.mkdir()
    _install_skills(actual_skills)
    traversal_skills = traversal_parent / ".." / "actual" / "skills"

    result = _run_preflight(site_packages, traversal_skills)

    assert result.returncode == 2
    assert result.stderr == ""
    status = json.loads(result.stdout)
    assert status["status"] == "invalid"
    assert status["skills"]["status"] == "invalid"
    assert str(tmp_path) not in result.stdout


def test_missing_skill_and_duplicate_core_install_are_detected(tmp_path: Path) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    duplicate = site_packages / "shipworthy_core-0.1.1.dist-info"
    duplicate.mkdir()
    (duplicate / "METADATA").write_text("fixture\n", encoding="utf-8")
    missing_skill = skills_dir / "ship-product-workflows" / "SKILL.md"
    missing_skill.unlink()

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 2
    status = json.loads(result.stdout)
    assert status["status"] == "invalid"
    assert status["skills"]["found"] == 3
    assert status["core"]["status"] == "invalid"


@pytest.mark.parametrize("skill_failure", ["missing", "malformed"])
def test_invalid_skill_set_disables_core_and_discards_partial_client_metadata(
    tmp_path: Path, skill_failure: str
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    target = skills_dir / "ship-workflow-clarity"
    if skill_failure == "missing":
        (target / "SKILL.md").unlink()
    else:
        (target / COMPATIBILITY_FILENAME).write_text("{", encoding="utf-8")

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 2
    assert result.stderr == ""
    status = json.loads(result.stdout)
    assert status["status"] == "invalid"
    assert status["skills"]["status"] == "invalid"
    assert status["skills"]["usable"] is False
    assert status["skills"]["client_version"] is None
    assert status["core"]["status"] == "disabled"
    assert status["core"]["usable"] is False
    assert not any(status["core"]["features"].values())
    assert status["core"]["observed_version"] == "0.1.0"


def test_dangling_core_package_symlink_is_partial_not_absent(tmp_path: Path) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".claude/skills"
    site_packages.mkdir(parents=True)
    _install_skills(skills_dir)
    (site_packages / "shipworthy").symlink_to(
        tmp_path / "does-not-exist", target_is_directory=True
    )

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 0
    assert result.stderr == ""
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["status"] == "invalid"
    assert status["core"]["usable"] is False
    assert status["skills"]["usable"] is True
    assert status["diagnostics"][0]["code"] == "CORE_PARTIAL"


def test_symlinked_ancestor_arguments_are_rejected_without_following(
    tmp_path: Path,
) -> None:
    actual = tmp_path / "actual"
    site_packages = actual / "site-packages"
    skills_dir = actual / "skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    alias = tmp_path / "alias"
    alias.symlink_to(actual, target_is_directory=True)

    core_result = _run_preflight(alias / "site-packages", skills_dir)
    core_status = json.loads(core_result.stdout)

    assert core_result.returncode == 0
    assert core_status["status"] == "skills_only"
    assert core_status["core"]["status"] == "invalid"
    assert core_status["core"]["usable"] is False
    assert core_status["diagnostics"][0]["code"] == "CORE_PATH_INVALID"

    skills_result = _run_preflight(site_packages, alias / "skills")
    skills_status = json.loads(skills_result.stdout)

    assert skills_result.returncode == 2
    assert skills_status["status"] == "invalid"
    assert skills_status["skills"]["status"] == "invalid"
    assert skills_status["skills"]["usable"] is False
    assert skills_status["core"]["status"] == "disabled"
    assert skills_status["core"]["usable"] is False


def test_human_output_is_bounded_and_reports_skill_only_semantics(
    tmp_path: Path,
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".claude/skills"
    site_packages.mkdir(parents=True)
    _install_skills(skills_dir)

    result = _run_preflight(
        site_packages, skills_dir, output_format="human"
    )

    assert result.returncode == 0
    assert result.stderr == ""
    assert result.stdout == (
        "Shipworthy install preflight: skills_only\n"
        "Core: absent\n"
        "Skills: usable\n"
        "[CORE_ABSENT] Shipworthy core is absent; core is disabled and all four "
        "skills remain usable.\n"
    )
    assert str(tmp_path) not in result.stdout


@pytest.mark.parametrize(
    "metadata_text",
    [
        "Metadata-Version: 2.4\nName: wrong-core\nVersion: 0.1.0\n",
        "Metadata-Version: 2.4\nName: shipworthy-core\nVersion: 9.9.9\n",
        (
            "Metadata-Version: 2.4\nName: shipworthy-core\n"
            "Name: shipworthy-core\nVersion: 0.1.0\n"
        ),
        "SECRET-CANARY-DIST-INFO" + ("x" * (65 * 1024)),
    ],
)
def test_invalid_dist_info_metadata_disables_core_without_leaking_content(
    tmp_path: Path, metadata_text: str
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    (site_packages / "shipworthy_core-0.1.0.dist-info/METADATA").write_text(
        metadata_text, encoding="utf-8"
    )

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 0
    assert result.stderr == ""
    assert "SECRET-CANARY" not in result.stdout
    assert len(result.stdout) < 2_048
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["status"] == "invalid"
    assert status["diagnostics"][0]["code"] == "CORE_DISTRIBUTION_INVALID"


def test_symlinked_intermediate_resource_directory_is_not_followed(
    tmp_path: Path,
) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".claude/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    package = site_packages / "shipworthy"
    external = tmp_path / "external-schemas"
    (package / "schemas").rename(external)
    (package / "schemas").symlink_to(external, target_is_directory=True)

    result = _run_preflight(site_packages, skills_dir)

    assert result.returncode == 0
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["status"] == "invalid"
    assert status["diagnostics"][0]["code"] == "CORE_PARTIAL"


def test_invalid_runtime_probe_is_sanitized_and_bounded(tmp_path: Path) -> None:
    site_packages = tmp_path / "runtime/site-packages"
    skills_dir = tmp_path / ".codex/skills"
    site_packages.mkdir(parents=True)
    _install_core(site_packages)
    _install_skills(skills_dir)
    canary = "SECRET-CANARY-RUNTIME-" + ("x" * 4_096)

    result = _run_preflight(
        site_packages, skills_dir, python_version=canary
    )

    assert result.returncode == 0
    assert result.stderr == ""
    assert canary not in result.stdout
    assert "SECRET-CANARY" not in result.stdout
    assert len(result.stdout) < 2_048
    status = json.loads(result.stdout)
    assert status["status"] == "skills_only"
    assert status["core"]["python_version"] == "invalid"
    assert status["diagnostics"][0]["code"] == "PYTHON_INCOMPATIBLE"


def test_install_sh_copies_sidecars_and_preserves_timestamped_backup_behavior(
    tmp_path: Path,
) -> None:
    destination = tmp_path / ".codex/skills"
    environment = {
        "HOME": str(tmp_path / "home"),
        "PATH": os.environ.get("PATH", ""),
        "SKILLS_DIR": str(destination),
    }

    first = subprocess.run(
        ["bash", "install.sh"],
        cwd=ROOT,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
    )
    second = subprocess.run(
        ["bash", "install.sh"],
        cwd=ROOT,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
    )

    assert first.returncode == 0
    assert second.returncode == 0
    for skill in SKILLS:
        installed = destination / skill
        backups = list(destination.glob(skill + ".bak.*"))
        assert (installed / "SKILL.md").is_file()
        assert _load_json(installed / COMPATIBILITY_FILENAME)["features"][
            "skill_only"
        ] is True
        assert len(backups) == 1
        assert (backups[0] / "SKILL.md").is_file()
    assert "backing up" in second.stdout
    assert "No skills directory found" not in first.stdout
