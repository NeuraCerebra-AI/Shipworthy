from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

import pytest


SKILLS = (
    "ship-readiness-orchestrator",
    "ship-deep-review",
    "ship-product-workflows",
    "ship-workflow-clarity",
)
REPO_SKILLS = Path(__file__).resolve().parents[2] / "plugins" / "shipworthy" / "skills"


def _write(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)


def _sandbox(tmp_path: Path) -> Path:
    root = tmp_path / "shipworthy-lifecycle-fixture"
    root.mkdir()
    _write(root / ".shipworthy-lifecycle-sandbox", b"shipworthy-lifecycle-sandbox-v1\n")
    _write(
        root / "core" / "metadata.json",
        json.dumps({"package_version": "0.1.0"}, sort_keys=True).encode("utf-8"),
    )
    _write(root / "core" / "package" / "module.py", b"VERSION = '0.1.0'\n")
    _write(root / "core" / "data" / "local-state.bin", b"core-local-state-v1\n")
    (root / "core" / "data" / "empty-state-dir").mkdir()
    (root / "core" / "data" / "empty-state-dir").chmod(0o750)
    for skill in SKILLS:
        shutil.copytree(REPO_SKILLS / skill, root / "skills" / skill)
    _write(root / "evidence" / "canonical" / "ledger.json", b'{"evidence":"canonical"}\n')
    _write(root / "evidence" / "canonical" / "artifacts" / "proof.txt", b"proof bytes\n")
    return root


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _mode(path: Path) -> int:
    return stat.S_IMODE(path.stat().st_mode)


def _tree_state(root: Path) -> dict[str, tuple[bytes, int, bool]]:
    return {
        path.relative_to(root).as_posix(): (
            b"" if path.is_dir() else path.read_bytes(),
            path.stat().st_mode & 0o777,
            path.is_dir(),
        )
        for path in root.rglob("*")
    }


def _target_metadata(compatible_from: str = ">=0.1.0,<0.2.0") -> dict[str, str]:
    return {
        "package_version": "0.2.0",
        "compatible_upgrade_from": compatible_from,
    }


def test_successful_upgrade_backs_up_metadata_and_data_and_preserves_evidence(
    tmp_path: Path,
) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_upgrade

    root = _sandbox(tmp_path)
    evidence_before = _sha(root / "evidence" / "canonical" / "ledger.json")
    skill_before = {
        skill: _sha(root / "skills" / skill / "SKILL.md") for skill in SKILLS
    }

    result = rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(),
        target_core_files={"package/module.py": b"VERSION = '0.2.0'\n"},
    )

    assert result.status == "upgraded"
    assert result.backup_created is True
    assert {row.relative_path for row in result.backup_entries} == {
        "core/data/local-state.bin",
        "core/metadata.json",
    }
    assert result.from_version == "0.1.0"
    assert result.to_version == "0.2.0"
    assert result.state_before_sha256 != result.state_after_sha256
    assert result.canonical_evidence_preserved is True
    assert result.skills_preserved is True
    assert _sha(root / "evidence" / "canonical" / "ledger.json") == evidence_before
    assert {
        skill: _sha(root / "skills" / skill / "SKILL.md") for skill in SKILLS
    } == skill_before
    machine = json.loads(result.to_json_bytes())
    assert machine["schema"] == "shipworthy-lifecycle-upgrade-rehearsal/v1"
    assert {row["relative_path"] for row in machine["backup_entries"]} == {
        "core/data/local-state.bin",
        "core/metadata.json",
    }
    assert b"0.2.0" in (root / "core" / "package" / "module.py").read_bytes()


def test_successful_upgrade_preserves_full_root_mode(tmp_path: Path) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_upgrade

    root = _sandbox(tmp_path)
    root.chmod(0o1755)

    result = rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(),
        target_core_files={"package/module.py": b"VERSION = '0.2.0'\n"},
    )

    assert result.status == "upgraded"
    assert _mode(root) == 0o1755


def test_incompatible_upgrade_is_detected_without_changing_prior_state(tmp_path: Path) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_upgrade

    root = _sandbox(tmp_path)
    before = (root / "core" / "package" / "module.py").read_bytes()

    result = rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(">=0.2.0,<0.3.0"),
        target_core_files={"package/module.py": b"VERSION = '0.2.0'\n"},
    )

    assert result.status == "incompatible"
    assert result.backup_created is True
    assert result.state_before_sha256 == result.state_after_sha256
    assert result.rollback_attempted is False
    assert (root / "core" / "package" / "module.py").read_bytes() == before


@pytest.mark.parametrize("target_version", ["0.1.0", "0.0.9"])
def test_equal_or_lower_version_is_not_an_upgrade(
    tmp_path: Path, target_version: str
) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_upgrade

    root = _sandbox(tmp_path)
    before = {
        path.relative_to(root).as_posix(): path.read_bytes()
        for path in root.rglob("*")
        if path.is_file()
    }
    metadata = _target_metadata()
    metadata["package_version"] = target_version

    result = rehearse_upgrade(
        sandbox_root=root,
        target_metadata=metadata,
        target_core_files={"package/module.py": b"must not be written\n"},
    )

    after = {
        path.relative_to(root).as_posix(): path.read_bytes()
        for path in root.rglob("*")
        if path.is_file()
    }
    assert result.status == "not_upgrade"
    assert result.state_before_sha256 == result.state_after_sha256
    assert before == after


def test_oversized_target_metadata_fails_before_mutation(tmp_path: Path) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    root = _sandbox(tmp_path)
    before = lifecycle._snapshot(root)
    metadata = _target_metadata()
    metadata["oversized"] = "x" * (lifecycle._MAX_METADATA_BYTES + 1)

    with pytest.raises(lifecycle.LifecycleSandboxError, match="metadata"):
        lifecycle.rehearse_upgrade(
            sandbox_root=root,
            target_metadata=metadata,
            target_core_files={"package/module.py": b"must not be written\n"},
        )

    assert lifecycle._snapshot(root) == before


def test_malformed_installed_metadata_raises_bounded_error_without_mutation(
    tmp_path: Path,
) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    root = _sandbox(tmp_path)
    (root / "core" / "metadata.json").write_bytes(b"{not-json\n")
    before = _tree_state(root)

    with pytest.raises(lifecycle.LifecycleSandboxError, match="core metadata is invalid"):
        lifecycle.rehearse_upgrade(
            sandbox_root=root,
            target_metadata=_target_metadata(),
            target_core_files={"package/module.py": b"must not be written\n"},
        )

    assert _tree_state(root) == before


def test_core_symlink_swap_cannot_escape_and_restores_prior_state(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    root = _sandbox(tmp_path)
    before = lifecycle._snapshot(root)
    outside = tmp_path / "outside-core"
    outside.mkdir()
    sentinel = outside / "module.py"
    sentinel.write_bytes(b"outside sentinel\n")
    stolen = tmp_path / "stolen-original-core"
    original_metadata = lifecycle._metadata_from_state

    def swap_after_read(state):
        document = original_metadata(state)
        (root / "core").rename(stolen)
        (root / "core").symlink_to(outside, target_is_directory=True)
        return document

    monkeypatch.setattr(lifecycle, "_metadata_from_state", swap_after_read)

    result = lifecycle.rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(),
        target_core_files={"package/module.py": b"escaped write\n"},
    )

    assert result.status == "rolled_back"
    assert result.rollback_exact is True
    assert lifecycle._snapshot(root) == before
    assert sentinel.read_bytes() == b"outside sentinel\n"


def test_whole_root_swap_during_upgrade_never_rewrites_replacement(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    root = _sandbox(tmp_path)
    original_before = _tree_state(root)
    replacement = tmp_path / "replacement-sandbox"
    shutil.copytree(root, replacement)
    replacement_sentinel = replacement / "replacement-sentinel.txt"
    replacement_sentinel.write_bytes(b"replacement must remain untouched\n")
    stolen = tmp_path / "stolen-original-sandbox"
    original_metadata = lifecycle._metadata_from_state

    def swap_after_metadata(state):
        document = original_metadata(state)
        root.rename(stolen)
        replacement.rename(root)
        return document

    monkeypatch.setattr(lifecycle, "_metadata_from_state", swap_after_metadata)

    result = lifecycle.rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(),
        target_core_files={"package/module.py": b"must not escape\n"},
        inject_failure_after_writes=1,
    )

    assert result.status == "rolled_back"
    assert result.rollback_exact is True
    assert _tree_state(stolen) == original_before
    assert (root / replacement_sentinel.name).read_bytes() == (
        b"replacement must remain untouched\n"
    )
    assert (root / "core" / "package" / "module.py").read_bytes() == b"VERSION = '0.1.0'\n"


def test_hardlinked_core_file_is_rejected_before_any_mutation(
    tmp_path: Path,
) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    root = _sandbox(tmp_path)
    module = root / "core" / "package" / "module.py"
    outside = tmp_path / "outside-module.py"
    outside.write_bytes(b"outside sentinel\n")
    module.unlink()
    os.link(outside, module)
    before_root = _tree_state(root)
    outside_before = (outside.read_bytes(), outside.stat().st_mode & 0o777)

    with pytest.raises(lifecycle.LifecycleSandboxError, match="hard-linked"):
        lifecycle.rehearse_upgrade(
            sandbox_root=root,
            target_metadata=_target_metadata(),
            target_core_files={"package/module.py": b"escaped write\n"},
            inject_failure_after_writes=2,
        )

    assert _tree_state(root) == before_root
    assert (outside.read_bytes(), outside.stat().st_mode & 0o777) == outside_before


def test_core_rename_after_binding_check_cannot_mutate_relocated_tree(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    root = _sandbox(tmp_path)
    before_root = _tree_state(root)
    before_core = _tree_state(root / "core")
    root_mode = root.stat().st_mode & 0o777
    relocated = tmp_path / "relocated-core"
    original_binding_check = lifecycle._assert_directory_binding
    checks = 0

    def rename_after_second_check(parent_fd: int, name: str, directory_fd: int):
        nonlocal checks
        original_binding_check(parent_fd, name, directory_fd)
        checks += 1
        if checks == 2:
            (root / "core").rename(relocated)

    monkeypatch.setattr(
        lifecycle, "_assert_directory_binding", rename_after_second_check
    )

    result = lifecycle.rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(),
        target_core_files={"package/module.py": b"escaped write\n"},
    )

    assert result.status == "rolled_back"
    assert result.rollback_exact is True
    assert _tree_state(root) == before_root
    assert root.stat().st_mode & 0o777 == root_mode
    if relocated.exists():
        assert _tree_state(relocated) == before_core


def test_lifecycle_aggregate_budgets_enforce_boundary_and_over_limit(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    monkeypatch.setattr(lifecycle, "_MAX_TARGET_TOTAL_BYTES", 5)
    assert lifecycle._validated_target_files({"a": b"12", "b": b"345"})
    with pytest.raises(lifecycle.LifecycleSandboxError, match="aggregate"):
        lifecycle._validated_target_files({"a": b"12", "b": b"3456"})

    root = tmp_path / "snapshot-budget"
    root.mkdir()
    (root / "payload").write_bytes(b"12345")
    monkeypatch.setattr(lifecycle, "_MAX_SNAPSHOT_BYTES", 5)
    assert lifecycle._snapshot(root)
    (root / "extra").write_bytes(b"6")
    with pytest.raises(lifecycle.LifecycleSandboxError, match="aggregate"):
        lifecycle._snapshot(root)


def test_skill_inventory_aggregate_budget_boundary_and_over_limit(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    root = tmp_path / "skill-inventory"
    root.mkdir()
    (root / "one").write_bytes(b"12")
    (root / "two").write_bytes(b"345")
    monkeypatch.setattr(lifecycle, "_MAX_SKILL_INVENTORY_BYTES", 5)

    assert lifecycle._skill_inventory(root)
    (root / "three").write_bytes(b"6")
    assert lifecycle._skill_inventory(root) is None


def test_failed_upgrade_restores_exact_prior_state(tmp_path: Path) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_upgrade

    root = _sandbox(tmp_path)
    before_files = {
        path.relative_to(root).as_posix(): (path.read_bytes(), path.stat().st_mode & 0o777)
        for path in root.rglob("*")
        if path.is_file()
    }

    result = rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(),
        target_core_files={
            "package/module.py": b"VERSION = '0.2.0'\n",
            "package/new.py": b"new payload\n",
        },
        inject_failure_after_writes=1,
    )

    after_files = {
        path.relative_to(root).as_posix(): (path.read_bytes(), path.stat().st_mode & 0o777)
        for path in root.rglob("*")
        if path.is_file()
    }
    assert result.status == "rolled_back"
    assert result.rollback_attempted is True
    assert result.rollback_exact is True
    assert result.state_before_sha256 == result.state_after_sha256
    assert after_files == before_files
    assert (root / "core" / "data" / "empty-state-dir").is_dir()
    assert (root / "core" / "data" / "empty-state-dir").stat().st_mode & 0o777 == 0o750


def test_injected_rollback_preserves_full_root_mode(tmp_path: Path) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_upgrade

    root = _sandbox(tmp_path)
    root.chmod(0o1755)

    result = rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(),
        target_core_files={"package/module.py": b"VERSION = '0.2.0'\n"},
        inject_failure_after_writes=1,
    )

    assert result.status == "rolled_back"
    assert result.rollback_exact is True
    assert _mode(root) == 0o1755


def test_rollback_preserves_special_bits_on_files_and_directories(
    tmp_path: Path,
) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_upgrade

    root = _sandbox(tmp_path)
    special_directory = root / "core" / "data" / "empty-state-dir"
    special_file = root / "core" / "data" / "local-state.bin"
    special_directory.chmod(0o2750)
    special_file.chmod(0o4750)

    result = rehearse_upgrade(
        sandbox_root=root,
        target_metadata=_target_metadata(),
        target_core_files={"package/module.py": b"VERSION = '0.2.0'\n"},
        inject_failure_after_writes=1,
    )

    assert result.status == "rolled_back"
    assert result.rollback_exact is True
    assert _mode(special_directory) == 0o2750
    assert _mode(special_file) == 0o4750


def test_uninstall_requires_authorization_removes_only_optional_core(
    tmp_path: Path,
) -> None:
    from shipworthy.migration.lifecycle_rehearsal import LifecycleAuthorizationError
    from shipworthy.migration.lifecycle_rehearsal import rehearse_uninstall

    root = _sandbox(tmp_path)
    evidence_before = _sha(root / "evidence" / "canonical" / "ledger.json")

    with pytest.raises(LifecycleAuthorizationError, match="explicit authorization"):
        rehearse_uninstall(
            sandbox_root=root,
            authorize_destructive_delete=False,
            repository_skills_root=REPO_SKILLS,
        )
    assert (root / "core").is_dir()

    result = rehearse_uninstall(
        sandbox_root=root,
        authorize_destructive_delete=True,
        repository_skills_root=REPO_SKILLS,
    )
    assert result.status == "skill_only"
    assert result.removed_roots == ("core",)
    assert not (root / "core").exists()
    assert result.canonical_evidence_preserved is True
    assert result.skill_only_operational is True
    assert _sha(root / "evidence" / "canonical" / "ledger.json") == evidence_before
    assert all((root / "skills" / skill / "SKILL.md").is_file() for skill in SKILLS)
    machine = json.loads(result.to_json_bytes())
    assert machine["schema"] == "shipworthy-lifecycle-uninstall-rehearsal/v1"


def test_uninstall_preserves_full_root_mode(tmp_path: Path) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_uninstall

    root = _sandbox(tmp_path)
    root.chmod(0o1755)

    result = rehearse_uninstall(
        sandbox_root=root,
        authorize_destructive_delete=True,
        repository_skills_root=REPO_SKILLS,
    )

    assert result.status == "skill_only"
    assert _mode(root) == 0o1755


def test_whole_root_swap_during_uninstall_never_deletes_replacement_core(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.lifecycle_rehearsal as lifecycle

    root = _sandbox(tmp_path)
    original_before = _tree_state(root)
    replacement = tmp_path / "replacement-uninstall-sandbox"
    shutil.copytree(root, replacement)
    replacement_sentinel = replacement / "replacement-sentinel.txt"
    replacement_sentinel.write_bytes(b"replacement must remain untouched\n")
    stolen = tmp_path / "stolen-uninstall-sandbox"
    original_operational = lifecycle._skill_only_operational
    swapped = False

    def swap_after_skill_check(sandbox: Path, repository_skills_root: Path):
        nonlocal swapped
        result = original_operational(sandbox, repository_skills_root)
        if not swapped:
            swapped = True
            root.rename(stolen)
            replacement.rename(root)
        return result

    monkeypatch.setattr(lifecycle, "_skill_only_operational", swap_after_skill_check)

    with pytest.raises(lifecycle.LifecycleSandboxError, match="changed"):
        lifecycle.rehearse_uninstall(
            sandbox_root=root,
            authorize_destructive_delete=True,
            repository_skills_root=REPO_SKILLS,
        )

    assert _tree_state(stolen) == original_before
    assert (root / replacement_sentinel.name).read_bytes() == (
        b"replacement must remain untouched\n"
    )
    assert (root / "core").is_dir()


@pytest.mark.parametrize("invalid_kind", ["missing_skill", "skill_only_false"])
def test_skill_only_status_requires_all_four_valid_skill_sidecars(
    tmp_path: Path, invalid_kind: str
) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_uninstall

    root = _sandbox(tmp_path)
    if invalid_kind == "missing_skill":
        shutil.rmtree(root / "skills" / "ship-deep-review")
    else:
        (root / "skills" / "ship-workflow-clarity" / "shipworthy-compatibility.json").write_bytes(
            b'{"features":{"skill_only":false}}\n'
        )

    result = rehearse_uninstall(
        sandbox_root=root,
        authorize_destructive_delete=True,
        repository_skills_root=REPO_SKILLS,
    )
    assert result.status == "invalid_skills"
    assert result.skill_only_operational is False
    assert (root / "core").is_dir()


def test_four_garbage_skill_bodies_do_not_authorize_uninstall(tmp_path: Path) -> None:
    from shipworthy.migration.lifecycle_rehearsal import rehearse_uninstall

    root = _sandbox(tmp_path)
    shutil.rmtree(root / "skills")
    for skill in SKILLS:
        _write(root / "skills" / skill / "SKILL.md", b"garbage\n")
        _write(
            root / "skills" / skill / "shipworthy-compatibility.json",
            b'{"features":{"skill_only":true}}\n',
        )

    result = rehearse_uninstall(
        sandbox_root=root,
        authorize_destructive_delete=True,
        repository_skills_root=REPO_SKILLS,
    )

    assert result.status == "invalid_skills"
    assert result.removed_roots == ()
    assert result.skill_only_operational is False
    assert (root / "core").is_dir()


def test_rehearsals_reject_unmarked_roots_symlinks_and_path_escape(tmp_path: Path) -> None:
    from shipworthy.migration.lifecycle_rehearsal import LifecycleSandboxError
    from shipworthy.migration.lifecycle_rehearsal import rehearse_upgrade

    unmarked = tmp_path / "unmarked"
    unmarked.mkdir()
    with pytest.raises(LifecycleSandboxError, match="marked temporary sandbox"):
        rehearse_upgrade(
            sandbox_root=unmarked,
            target_metadata=_target_metadata(),
            target_core_files={},
        )

    root = _sandbox(tmp_path)
    with pytest.raises(LifecycleSandboxError, match="safe relative"):
        rehearse_upgrade(
            sandbox_root=root,
            target_metadata=_target_metadata(),
            target_core_files={"../evidence/canonical/ledger.json": b"delete me"},
        )

    symlink_root = tmp_path / "symlink-root"
    symlink_root.symlink_to(root, target_is_directory=True)
    with pytest.raises(LifecycleSandboxError, match="marked temporary sandbox"):
        rehearse_upgrade(
            sandbox_root=symlink_root,
            target_metadata=_target_metadata(),
            target_core_files={},
        )

    shutil_core = root / "core"
    for child in sorted(shutil_core.rglob("*"), reverse=True):
        if child.is_file():
            child.unlink()
        elif child.is_dir():
            child.rmdir()
    shutil_core.rmdir()
    shutil_core.symlink_to(root / "evidence", target_is_directory=True)
    with pytest.raises(LifecycleSandboxError, match="symlink"):
        rehearse_upgrade(
            sandbox_root=root,
            target_metadata=_target_metadata(),
            target_core_files={},
        )
