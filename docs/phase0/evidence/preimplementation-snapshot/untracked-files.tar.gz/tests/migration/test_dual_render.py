from __future__ import annotations

from dataclasses import replace
import datetime
import importlib.util
import io
import json
from pathlib import Path
import sys
import zipfile

import pytest


FIXTURE = (
    Path(__file__).resolve().parents[1]
    / "fixtures"
    / "legacy"
    / "readiness-v0.json"
)
LEGACY_SCRIPTS = (
    Path(__file__).resolve().parents[2]
    / "plugins"
    / "shipworthy"
    / "skills"
    / "ship-readiness-orchestrator"
    / "scripts"
)


def _render():
    from shipworthy.migration.dual_render import dual_render_legacy_readiness

    return dual_render_legacy_readiness(
        FIXTURE.read_bytes(),
        source_relative_path="evidence/legacy/readiness-v0.json",
        imported_at="2026-07-12T12:34:56Z",
    )


def test_dual_render_imports_and_retains_both_render_sides() -> None:
    result = _render()

    assert result.source_schema_name == "legacy/readiness-v0"
    assert result.legacy.source_bytes == FIXTURE.read_bytes()
    assert result.legacy.html.startswith(b"<!doctype html>")
    assert result.v1.html.startswith(b"<!doctype html>")
    assert result.legacy.sarif["version"] == "2.1.0"
    assert result.v1.sarif["version"] == "2.1.0"
    assert result.legacy.bundle.entries
    assert result.v1.bundle.entries
    assert result.legacy.bundle.contract == "legacy/make_bundle.py"
    assert result.v1.bundle.contract == "shipworthy/evidence-bundle-v1"
    assert "readiness-report.html" in result.legacy.bundle.entry_names
    assert "readiness-report.html" in result.v1.bundle.entry_names
    assert result.v1.canonical_ledger_json != result.legacy.source_bytes


def test_legacy_bundle_matches_actual_make_bundle_entry_contract(
    tmp_path: Path, monkeypatch
) -> None:
    result = _render()
    spec = importlib.util.spec_from_file_location(
        "shipworthy_actual_make_bundle_oracle", LEGACY_SCRIPTS / "make_bundle.py"
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    class FixedDateTime(datetime.datetime):
        @classmethod
        def now(cls, tz=None):
            return cls(2026, 7, 12, 12, 34, 56, tzinfo=tz)

    input_path = tmp_path / "legacy.json"
    output_path = tmp_path / "actual.zip"
    input_path.write_bytes(FIXTURE.read_bytes())
    monkeypatch.setattr(module.datetime, "datetime", FixedDateTime)
    monkeypatch.setattr(
        sys,
        "argv",
        ["make_bundle.py", str(input_path), str(output_path)],
    )
    with pytest.raises(SystemExit) as exit_info:
        module.main()
    assert exit_info.value.code == 0

    def entries(payload: bytes) -> dict[str, bytes]:
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            return {name: archive.read(name) for name in archive.namelist()}

    assert result.legacy.bundle.bytes == output_path.read_bytes()
    assert entries(result.legacy.bundle.bytes) == entries(output_path.read_bytes())
    assert result.legacy.bundle.contract == "legacy/make_bundle.py"


def test_structured_comparison_covers_every_required_surface() -> None:
    result = _render()

    assert {difference.category for difference in result.differences} == {
        "action",
        "artifact_lineage",
        "bundle",
        "counts",
        "gate",
        "html",
        "proof",
        "sarif",
    }
    assert result.compared_categories == (
        "finding_identity",
        "action",
        "proof",
        "gate",
        "counts",
        "html",
        "sarif",
        "bundle",
        "artifact_lineage",
    )
    assert all(difference.explained for difference in result.differences)
    assert result.unexplained_evidence_debt == ()

    assert result.legacy.finding_identity == result.v1.finding_identity
    assert result.legacy.finding_identity[0].startswith("FND-")
    assert result.legacy.actions == ("Fix",)
    assert result.v1.actions[:1] == ("Fix",)
    assert result.legacy.proofs == ("Confirmed",)
    assert result.v1.proofs[:1] == ("Partial",)
    assert result.legacy.counts.canonical_findings == 1
    assert result.v1.counts.canonical_findings == 1
    assert result.legacy.gate.outcome == "fail"
    assert result.v1.gate.outcome == "incomplete"
    assert result.legacy.html_semantics.canonical_finding_count == 1
    assert result.v1.html_semantics.canonical_finding_count == 1
    assert result.legacy.html_semantics.total_report_rows == 1
    assert result.v1.html_semantics.total_report_rows > 1
    assert result.legacy.html_semantics.finding_titles_present == (True,)
    assert result.v1.html_semantics.finding_titles_present == (True,)


def test_unexplained_structured_difference_becomes_deterministic_evidence_debt() -> None:
    from shipworthy.migration.dual_render import compare_render_sides

    result = _render()
    changed_v1 = replace(result.v1, actions=("Keep", *result.v1.actions[1:]))

    differences, debt = compare_render_sides(
        result.legacy,
        changed_v1,
        mapping_debt_codes=result.mapping_debt_codes,
    )

    action_difference = next(row for row in differences if row.category == "action")
    assert action_difference.explained is False
    assert action_difference.path == "findings[0].action"
    assert len(debt) == 1
    assert debt[0].category == "action"
    assert debt[0].difference_id.startswith("DDR-")
    assert debt[0].reason == "Unexplained dual-render difference requires review."
    assert debt == compare_render_sides(
        result.legacy,
        changed_v1,
        mapping_debt_codes=result.mapping_debt_codes,
    )[1]


def test_arbitrary_surface_tampering_is_never_excused_by_mapping_debt() -> None:
    from shipworthy.migration.dual_render import BundleEntry
    from shipworthy.migration.dual_render import compare_render_sides

    result = _render()
    tampered_sides = (
        replace(result.v1, html=result.v1.html + b"<!-- tampered -->"),
        replace(result.v1, sarif={"version": "2.1.0", "runs": []}),
        replace(
            result.v1,
            bundle=replace(
                result.v1.bundle,
                entries=(*result.v1.bundle.entries, BundleEntry("unexpected.txt", 1, "0" * 64)),
            ),
        ),
        replace(result.v1, counts=replace(result.v1.counts, total_report_rows=999)),
        replace(result.v1, gate=replace(result.v1.gate, outcome="pass")),
    )
    expected_categories = ("html", "sarif", "bundle", "counts", "gate")

    for changed, expected_category in zip(tampered_sides, expected_categories):
        differences, debt = compare_render_sides(
            result.legacy,
            changed,
            mapping_debt_codes=result.mapping_debt_codes,
        )
        changed_difference = next(
            row for row in differences if row.category == expected_category
        )
        assert changed_difference.explained is False
        assert any(row.category == expected_category for row in debt)


def test_internally_recomputed_companion_snapshots_cannot_launder_drift() -> None:
    from shipworthy.migration.dual_render import _bundle_snapshot
    from shipworthy.migration.dual_render import _canonical_json
    from shipworthy.migration.dual_render import _html_semantics
    from shipworthy.migration.dual_render import compare_render_sides

    result = _render()
    minimal_html = (
        "<!doctype html><html><body>"
        + " ".join(result.v1.finding_identity + result.v1.finding_titles)
        + "</body></html>"
    ).encode()
    forged_html = replace(
        result.v1,
        html=minimal_html,
        html_semantics=_html_semantics(
            minimal_html,
            finding_ids=result.v1.finding_identity,
            finding_titles=result.v1.finding_titles,
            canonical_finding_count=result.v1.counts.canonical_findings,
            total_report_rows=result.v1.counts.total_report_rows,
        ),
    )

    forged_sarif_doc = json.loads(json.dumps(result.v1.sarif))
    forged_sarif_doc["runs"][0]["results"][0]["level"] = "note"
    forged_sarif_doc["runs"][0]["results"][0]["message"]["text"] = "laundered"
    forged_sarif = replace(
        result.v1,
        sarif=forged_sarif_doc,
        sarif_bytes=_canonical_json(forged_sarif_doc),
    )

    with zipfile.ZipFile(io.BytesIO(result.v1.bundle.bytes)) as archive:
        payloads = {name: archive.read(name) for name in archive.namelist()}
    payloads["README.txt"] = b"compromised but internally consistent\n"
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(payloads):
            archive.writestr(name, payloads[name])
    forged_bundle_value = output.getvalue()
    forged_bundle = replace(
        result.v1,
        bundle=_bundle_snapshot(
            forged_bundle_value, contract=result.v1.bundle.contract
        ),
    )
    forged_lineage = replace(
        result.v1,
        artifact_lineage=(
            (
                result.v1.artifact_lineage[0][0],
                "untrusted-producer",
                "invent lineage",
                result.v1.artifact_lineage[0][3],
            ),
        ),
    )
    forged_counts = replace(
        result.v1,
        counts=replace(result.v1.counts, section=(("garbage", result.v1.counts.total_report_rows),)),
    )

    for changed, category in (
        (forged_html, "html"),
        (forged_sarif, "sarif"),
        (forged_bundle, "bundle"),
        (forged_lineage, "artifact_lineage"),
        (forged_counts, "counts"),
    ):
        differences, debt = compare_render_sides(
            result.legacy,
            changed,
            mapping_debt_codes=result.mapping_debt_codes,
        )
        assert next(row for row in differences if row.category == category).explained is False
        assert any(row.category == category for row in debt)


def test_equal_two_sided_tampering_is_compared_to_recomputed_roots() -> None:
    from shipworthy.migration.dual_render import BundleSnapshot
    from shipworthy.migration.dual_render import CountSnapshot
    from shipworthy.migration.dual_render import GateSnapshot
    from shipworthy.migration.dual_render import _canonical_json
    from shipworthy.migration.dual_render import _html_semantics
    from shipworthy.migration.dual_render import compare_render_sides

    result = _render()
    forged_html_bytes = b"<!doctype html><html><body>forged</body></html>"
    forged_html_semantics = _html_semantics(
        forged_html_bytes,
        finding_ids=("FND-FORGED",),
        finding_titles=("forged",),
        canonical_finding_count=1,
        total_report_rows=1,
    )
    forged_sarif_document = {"version": "2.1.0", "runs": []}
    forged_sarif_bytes = _canonical_json(forged_sarif_document)
    forged_bundle = BundleSnapshot("forged", b"not-a-zip", ())
    forged_gate = GateSnapshot("confirmed_only", "pass", ())
    forged_counts = CountSnapshot(1, 0, 1, (("garbage", 1),), (("Decide", 1),))
    forged_lineage = (("ART-FORGED", "forged", "forged", "0" * 64),)

    cases = (
        (
            replace(result.legacy, finding_identity=("FND-FORGED",)),
            replace(result.v1, finding_identity=("FND-FORGED",)),
            "finding_identity",
        ),
        (
            replace(result.legacy, actions=("Decide",)),
            replace(result.v1, actions=("Decide",)),
            "action",
        ),
        (
            replace(result.legacy, proofs=("Inferred",)),
            replace(result.v1, proofs=("Inferred",)),
            "proof",
        ),
        (
            replace(result.legacy, gate=forged_gate),
            replace(result.v1, gate=forged_gate),
            "gate",
        ),
        (
            replace(result.legacy, counts=forged_counts),
            replace(result.v1, counts=forged_counts),
            "counts",
        ),
        (
            replace(result.legacy, html=forged_html_bytes, html_semantics=forged_html_semantics),
            replace(result.v1, html=forged_html_bytes, html_semantics=forged_html_semantics),
            "html",
        ),
        (
            replace(result.legacy, sarif=forged_sarif_document, sarif_bytes=forged_sarif_bytes),
            replace(result.v1, sarif=forged_sarif_document, sarif_bytes=forged_sarif_bytes),
            "sarif",
        ),
        (
            replace(result.legacy, bundle=forged_bundle),
            replace(result.v1, bundle=forged_bundle),
            "bundle",
        ),
        (
            replace(result.legacy, artifact_lineage=forged_lineage),
            replace(result.v1, artifact_lineage=forged_lineage),
            "artifact_lineage",
        ),
    )

    for legacy, v1, category in cases:
        differences, debt = compare_render_sides(
            legacy,
            v1,
            mapping_debt_codes=result.mapping_debt_codes,
        )
        row = next(item for item in differences if item.category == category)
        assert row.explained is False
        assert any(item.category == category for item in debt)


def test_duplicate_legacy_titles_receive_distinct_canonical_identities() -> None:
    from shipworthy.migration.dual_render import dual_render_legacy_readiness

    raw = json.dumps(
        {
            "target": "duplicate-title-target",
            "findings": [
                {
                    "title": "Same title",
                    "action": "Prove",
                    "proof": "Not tested",
                    "section": "not_proven_not_tested",
                    "severity": "Unscored",
                    "confidence": "Hypothesis",
                },
                {
                    "title": "Same title",
                    "action": "Prove",
                    "proof": "Not tested",
                    "section": "not_proven_not_tested",
                    "severity": "Unscored",
                    "confidence": "Hypothesis",
                },
            ],
        },
        separators=(",", ":"),
    ).encode()

    result = dual_render_legacy_readiness(
        raw,
        source_relative_path="evidence/legacy/duplicate-titles.json",
        imported_at="2026-07-12T12:34:56Z",
    )

    assert len(result.legacy.finding_identity) == 2
    assert len(set(result.legacy.finding_identity)) == 2
    assert result.legacy.finding_identity == result.v1.finding_identity
    assert result.unexplained_evidence_debt == ()


def test_dual_render_is_deterministic_and_does_not_modify_skill_sources() -> None:
    skill = (
        Path(__file__).resolve().parents[2]
        / "plugins"
        / "shipworthy"
        / "skills"
        / "ship-readiness-orchestrator"
        / "SKILL.md"
    )
    before = skill.read_bytes()

    first = _render()
    second = _render()

    assert first == second
    assert skill.read_bytes() == before
    assert first.activation == "comparison_only"
    assert first.skills_switched_to_core is False


@pytest.mark.parametrize("malformed", [b"{}\n", b"{not-json\n"])
def test_invalid_v1_recomputation_roots_fail_closed_into_evidence_debt(
    malformed: bytes,
) -> None:
    from shipworthy.migration.dual_render import compare_render_sides

    result = _render()
    corrupted = replace(result.v1, canonical_ledger_json=malformed)

    differences, debt = compare_render_sides(
        result.legacy,
        corrupted,
        mapping_debt_codes=result.mapping_debt_codes,
    )

    assert differences
    assert all(row.explained is False for row in differences)
    assert len(debt) == len(differences)
    assert debt == compare_render_sides(
        result.legacy,
        corrupted,
        mapping_debt_codes=result.mapping_debt_codes,
    )[1]


def test_legacy_bundle_and_entire_result_ignore_wall_clock_zip_buckets(
    monkeypatch,
) -> None:
    import time

    with monkeypatch.context() as first_clock:
        first_clock.setattr(time, "time", lambda: 1_700_000_000.0)
        first = _render()
    with monkeypatch.context() as second_clock:
        second_clock.setattr(time, "time", lambda: 1_700_000_004.0)
        second = _render()

    assert first.legacy.bundle.bytes == second.legacy.bundle.bytes
    assert first == second
