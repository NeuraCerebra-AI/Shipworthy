from pathlib import Path


def test_legacy_transform_retirement_requires_all_non_negotiable_criteria() -> None:
    document = (
        Path(__file__).resolve().parents[2]
        / "docs"
        / "phase0"
        / "legacy-transform-retirement.md"
    ).read_text(encoding="utf-8")

    required = (
        "two supported releases",
        "zero unexplained dual-render differences",
        "successful export and restore",
        "installed-copy parity",
        "documented consumer migration",
        "raw legacy import remains supported or is explicitly version-gated",
    )
    lowered = document.lower()
    assert all(phrase in lowered for phrase in required)
    assert "all six criteria" in lowered
    assert "does not activate the optional core" in lowered
    assert "phase 1" in lowered and "not started" in lowered
