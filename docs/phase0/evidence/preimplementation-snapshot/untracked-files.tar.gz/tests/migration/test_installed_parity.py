from __future__ import annotations

import json
import os
from pathlib import Path
import shutil

import pytest


REPO_SKILLS = (
    Path(__file__).resolve().parents[2]
    / "plugins"
    / "shipworthy"
    / "skills"
)


def _synthetic_install(tmp_path: Path, client: str) -> tuple[Path, Path]:
    fixture_root = tmp_path / f"{client}-approval-fixture"
    fixture_root.mkdir()
    (fixture_root / ".shipworthy-synthetic-fixture").write_text(
        "shipworthy-parity-fixture-v1\n", encoding="utf-8"
    )
    installed = fixture_root / (".codex" if client == "codex" else ".claude") / "skills"
    installed.mkdir(parents=True)
    for skill in sorted(REPO_SKILLS.iterdir()):
        if skill.is_dir():
            shutil.copytree(skill, installed / skill.name)
    return fixture_root, installed


@pytest.mark.parametrize("client", ["codex", "claude"])
def test_exact_synthetic_installed_copy_parity_is_machine_readable(
    tmp_path: Path, client: str
) -> None:
    from shipworthy.migration.installed_parity import validate_installed_copy_parity

    fixture_root, installed = _synthetic_install(tmp_path, client)
    report = validate_installed_copy_parity(
        repository_skills_root=REPO_SKILLS,
        installed_skills_root=installed,
        synthetic_fixture_root=fixture_root,
        client=client,
    )

    assert report.status == "exact"
    assert report.exact is True
    assert report.issues == ()
    assert report.file_count > 20
    assert report.categories == (
        "skill_body",
        "script",
        "manifest",
        "metadata",
        "test",
        "reference_or_template",
    )
    assert all(count > 0 for _, count in report.category_counts)
    assert dict(report.category_counts)["manifest"] == 4
    assert dict(report.category_counts)["metadata"] == 4
    assert dict(report.category_counts)["test"] == 4
    document = json.loads(report.to_json_bytes())
    assert document["schema"] == "shipworthy-installed-parity/v1"
    assert document["client"] == client
    assert document["status"] == "exact"
    assert document["category_counts"]["manifest"] == 4
    assert "repository_skills_root" not in document
    assert "installed_skills_root" not in document


def test_reports_missing_modified_and_stale_files_deterministically(tmp_path: Path) -> None:
    from shipworthy.migration.installed_parity import validate_installed_copy_parity

    fixture_root, installed = _synthetic_install(tmp_path, "codex")
    missing = installed / "ship-readiness-orchestrator" / "scripts" / "test_to_sarif.py"
    modified = installed / "ship-product-workflows" / "SKILL.md"
    stale = installed / "ship-workflow-clarity" / "scripts" / "old_contract_test.py"
    missing.unlink()
    modified.write_text("stale skill body\n", encoding="utf-8")
    stale.parent.mkdir()
    stale.write_text("old copy\n", encoding="utf-8")

    report = validate_installed_copy_parity(
        repository_skills_root=REPO_SKILLS,
        installed_skills_root=installed,
        synthetic_fixture_root=fixture_root,
        client="codex",
    )

    assert report.status == "drift"
    assert report.exact is False
    assert tuple((issue.kind, issue.relative_path) for issue in report.issues) == (
        ("missing", "ship-readiness-orchestrator/scripts/test_to_sarif.py"),
        ("modified", "ship-product-workflows/SKILL.md"),
        ("stale", "ship-workflow-clarity/scripts/old_contract_test.py"),
    )
    assert all(issue.category in report.categories for issue in report.issues)
    assert report == validate_installed_copy_parity(
        repository_skills_root=REPO_SKILLS,
        installed_skills_root=installed,
        synthetic_fixture_root=fixture_root,
        client="codex",
    )


def test_known_contract_test_copy_drift_is_repaired_only_in_approval_fixture(
    tmp_path: Path,
) -> None:
    from shipworthy.migration.installed_parity import validate_installed_copy_parity

    fixture_root, installed = _synthetic_install(tmp_path, "claude")
    relative = "ship-readiness-orchestrator/scripts/test_skill_contract.py"
    installed_contract = installed / relative
    repository_contract = REPO_SKILLS / relative
    installed_contract.write_text("# deliberately old synthetic copy\n", encoding="utf-8")

    drift = validate_installed_copy_parity(
        repository_skills_root=REPO_SKILLS,
        installed_skills_root=installed,
        synthetic_fixture_root=fixture_root,
        client="claude",
    )
    assert [(issue.kind, issue.relative_path) for issue in drift.issues] == [
        ("modified", relative)
    ]

    installed_contract.write_bytes(repository_contract.read_bytes())
    repaired = validate_installed_copy_parity(
        repository_skills_root=REPO_SKILLS,
        installed_skills_root=installed,
        synthetic_fixture_root=fixture_root,
        client="claude",
    )
    assert repaired.status == "exact"
    assert repaired.issues == ()


@pytest.mark.parametrize(
    "client,installed_suffix",
    [("codex", ".codex/skills"), ("claude", ".claude/skills")],
)
def test_validator_rejects_non_fixture_and_real_home_shapes(
    tmp_path: Path, client: str, installed_suffix: str
) -> None:
    from shipworthy.migration.installed_parity import ParityFixtureError
    from shipworthy.migration.installed_parity import validate_installed_copy_parity

    fake_root = tmp_path / "unmarked"
    installed = fake_root / installed_suffix
    installed.mkdir(parents=True)
    with pytest.raises(ParityFixtureError, match="synthetic fixture"):
        validate_installed_copy_parity(
            repository_skills_root=REPO_SKILLS,
            installed_skills_root=installed,
            synthetic_fixture_root=fake_root,
            client=client,
        )


def test_parity_inventory_aggregate_budget_boundary_and_over_limit(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.installed_parity as parity

    root = tmp_path / "inventory"
    root.mkdir()
    (root / "one").write_bytes(b"12")
    (root / "two").write_bytes(b"345")
    monkeypatch.setattr(parity, "_MAX_TOTAL_BYTES", 5)

    assert parity._inventory(root)
    (root / "three").write_bytes(b"6")
    with pytest.raises(parity.ParityFixtureError, match="aggregate"):
        parity._inventory(root)


def test_oversized_generated_python_cache_still_hits_resource_limit(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.installed_parity as parity

    root = tmp_path / "inventory"
    cache = root / "__pycache__"
    cache.mkdir(parents=True)
    (cache / "test_contract.cpython-312.pyc").write_bytes(b"12345")
    monkeypatch.setattr(parity, "_MAX_FILE_BYTES", 4)

    with pytest.raises(parity.ParityFixtureError, match="resource limits"):
        parity._inventory(root)


def test_generated_python_cache_noise_is_excluded_from_parity(
    tmp_path: Path,
) -> None:
    from shipworthy.migration.installed_parity import validate_installed_copy_parity

    repository = tmp_path / "repository-skills"
    skill = repository / "example-skill"
    (skill / "scripts").mkdir(parents=True)
    (skill / "SKILL.md").write_text("# Example\n", encoding="utf-8")
    (skill / "scripts" / "test_contract.py").write_text(
        "def test_contract(): pass\n", encoding="utf-8"
    )
    fixture_root = tmp_path / "codex-approval-fixture"
    fixture_root.mkdir()
    (fixture_root / ".shipworthy-synthetic-fixture").write_text(
        "shipworthy-parity-fixture-v1\n", encoding="utf-8"
    )
    installed = fixture_root / ".codex" / "skills"
    shutil.copytree(repository, installed)

    baseline = validate_installed_copy_parity(
        repository_skills_root=repository,
        installed_skills_root=installed,
        synthetic_fixture_root=fixture_root,
        client="codex",
    )
    noisy_trees = ((repository, b"repository cache"), (installed, b"installed cache"))
    for root, payload in noisy_trees:
        cache = root / "example-skill" / "scripts" / "__pycache__"
        cache.mkdir()
        (cache / "test_contract.cpython-312.pyc").write_bytes(payload)
        (cache / "test_contract.pyo").write_bytes(payload)

    report = validate_installed_copy_parity(
        repository_skills_root=repository,
        installed_skills_root=installed,
        synthetic_fixture_root=fixture_root,
        client="codex",
    )

    assert report.status == "exact"
    assert report.file_count == baseline.file_count == 2
    assert dict(report.category_counts)["test"] == 1
    assert report.repository_tree_sha256 == baseline.repository_tree_sha256
    assert report.installed_tree_sha256 == baseline.installed_tree_sha256


def test_same_size_file_replacement_during_inventory_is_rejected(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.installed_parity as parity

    root = tmp_path / "inventory-race"
    root.mkdir()
    target = root / "SKILL.md"
    target.write_bytes(b"first")
    original_open = parity._open_inventory_file
    replaced = False

    def replace_before_open(parent_fd: int, name: str) -> int:
        nonlocal replaced
        if name == target.name and not replaced:
            replaced = True
            staged = root / "staged"
            staged.write_bytes(b"other")
            os.replace(staged, target)
        return original_open(parent_fd, name)

    monkeypatch.setattr(parity, "_open_inventory_file", replace_before_open)

    with pytest.raises(parity.ParityFixtureError, match="changed"):
        parity._inventory(root)


def test_repository_change_between_snapshots_cannot_report_exact(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.installed_parity as parity

    repository = tmp_path / "repository-skills"
    skill = repository / "example-skill"
    skill.mkdir(parents=True)
    source = skill / "SKILL.md"
    source.write_bytes(b"original\n")
    fixture_root = tmp_path / "codex-approval-fixture"
    fixture_root.mkdir()
    (fixture_root / ".shipworthy-synthetic-fixture").write_text(
        "shipworthy-parity-fixture-v1\n", encoding="utf-8"
    )
    installed = fixture_root / ".codex" / "skills"
    shutil.copytree(repository, installed)
    original_inventory = parity._inventory
    calls = 0

    def mutate_after_repository_snapshot(root: Path):
        nonlocal calls
        snapshot = original_inventory(root)
        calls += 1
        if calls == 1:
            source.write_bytes(b"changed!\n")
        return snapshot

    monkeypatch.setattr(parity, "_inventory", mutate_after_repository_snapshot)

    with pytest.raises(parity.ParityFixtureError, match="changed"):
        parity.validate_installed_copy_parity(
            repository_skills_root=repository,
            installed_skills_root=installed,
            synthetic_fixture_root=fixture_root,
            client="codex",
        )


def test_whole_fixture_replacement_after_marker_check_is_rejected(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.installed_parity as parity

    repository = tmp_path / "repository-skills"
    skill = repository / "example-skill"
    skill.mkdir(parents=True)
    (skill / "SKILL.md").write_bytes(b"exact\n")
    fixture_root = tmp_path / "codex-approval-fixture"
    fixture_root.mkdir()
    (fixture_root / ".shipworthy-synthetic-fixture").write_text(
        "shipworthy-parity-fixture-v1\n", encoding="utf-8"
    )
    installed = fixture_root / ".codex" / "skills"
    shutil.copytree(repository, installed)
    replacement = tmp_path / "unmarked-replacement"
    shutil.copytree(repository, replacement / ".codex" / "skills")
    (replacement / "replacement-sentinel.txt").write_bytes(b"untouched\n")
    stolen = tmp_path / "stolen-marked-fixture"
    original_inventory = parity._inventory
    swapped = False

    def swap_after_repository_inventory(root: Path):
        nonlocal swapped
        snapshot = original_inventory(root)
        if root == repository and not swapped:
            swapped = True
            fixture_root.rename(stolen)
            replacement.rename(fixture_root)
        return snapshot

    monkeypatch.setattr(parity, "_inventory", swap_after_repository_inventory)

    with pytest.raises(parity.ParityFixtureError, match="changed|marked"):
        parity.validate_installed_copy_parity(
            repository_skills_root=repository,
            installed_skills_root=installed,
            synthetic_fixture_root=fixture_root,
            client="codex",
        )

    assert (fixture_root / "replacement-sentinel.txt").read_bytes() == b"untouched\n"


def test_in_place_marker_rewrite_during_comparison_is_rejected(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.installed_parity as parity

    repository = tmp_path / "repository-skills"
    skill = repository / "example-skill"
    skill.mkdir(parents=True)
    (skill / "SKILL.md").write_bytes(b"exact\n")
    fixture_root = tmp_path / "codex-approval-fixture"
    fixture_root.mkdir()
    marker = fixture_root / ".shipworthy-synthetic-fixture"
    marker.write_bytes(b"shipworthy-parity-fixture-v1\n")
    installed = fixture_root / ".codex" / "skills"
    shutil.copytree(repository, installed)
    original_inventory = parity._inventory
    changed = False

    def rewrite_marker_after_repository_inventory(root: Path):
        nonlocal changed
        snapshot = original_inventory(root)
        if root == repository and not changed:
            changed = True
            marker.write_bytes(b"untrusted-parity-fixture-v1!\n")
        return snapshot

    monkeypatch.setattr(parity, "_inventory", rewrite_marker_after_repository_inventory)

    with pytest.raises(parity.ParityFixtureError, match="changed|marked"):
        parity.validate_installed_copy_parity(
            repository_skills_root=repository,
            installed_skills_root=installed,
            synthetic_fixture_root=fixture_root,
            client="codex",
        )


def test_initial_fixture_binding_failure_closes_every_opened_descriptor(
    tmp_path: Path, monkeypatch
) -> None:
    import shipworthy.migration.installed_parity as parity

    fixture_root, installed = _synthetic_install(tmp_path, "codex")
    original_open = parity.os.open
    original_close = parity.os.close
    held: list[int] = []

    def tracking_open(*args, **kwargs):
        descriptor = original_open(*args, **kwargs)
        held.append(descriptor)
        return descriptor

    def tracking_close(descriptor: int):
        try:
            return original_close(descriptor)
        finally:
            if descriptor in held:
                held.remove(descriptor)

    def fail_initial_assertion(_binding) -> None:
        raise parity.ParityFixtureError("synthetic fixture changed during comparison")

    monkeypatch.setattr(parity.os, "open", tracking_open)
    monkeypatch.setattr(parity.os, "close", tracking_close)
    monkeypatch.setattr(parity._FixtureBinding, "assert_current", fail_initial_assertion)

    with pytest.raises(parity.ParityFixtureError, match="changed"):
        parity._validate_fixture(fixture_root, installed, "codex")

    assert held == []


def test_fixture_binding_close_attempts_all_descriptors_after_one_close_error(
    monkeypatch,
) -> None:
    import shipworthy.migration.installed_parity as parity

    binding = parity._FixtureBinding(
        Path("fixture"), Path("installed"), 11, 12, 13, 1, 2, 3
    )
    attempted: list[int] = []

    def close_with_first_failure(descriptor: int) -> None:
        attempted.append(descriptor)
        if descriptor == 13:
            raise OSError("synthetic close failure")

    monkeypatch.setattr(parity.os, "close", close_with_first_failure)

    with pytest.raises(OSError, match="synthetic close failure"):
        binding.close()

    assert attempted == [13, 12, 11]
