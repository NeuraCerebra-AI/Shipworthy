from __future__ import annotations

import importlib
import json
import traceback
from datetime import datetime
from pathlib import Path
from types import ModuleType

import jsonschema
import pytest
from pydantic import ValidationError as PydanticValidationError


ROOT = Path(__file__).resolve().parents[2]
FIXTURES = ROOT / "tests" / "fixtures"
SCHEMAS = ROOT / "schemas" / "v1"
FORMAT_CHECKER = jsonschema.FormatChecker()


@FORMAT_CHECKER.checks("date-time", raises=ValueError)
def _is_valid_date_time(value: object) -> bool:
    if not isinstance(value, str):
        return True
    datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    return True


def _contract() -> ModuleType:
    try:
        return importlib.import_module("shipworthy.domain.contracts")
    except ModuleNotFoundError as exc:
        pytest.fail(f"strict v1 contract implementation is missing: {exc}")


def _fixture_bytes(relative_path: str) -> bytes:
    return (FIXTURES / relative_path).read_bytes()


def _fixture_json(relative_path: str) -> object:
    return json.loads(_fixture_bytes(relative_path))


def _schema(name: str) -> dict[str, object]:
    return json.loads((SCHEMAS / name).read_bytes())


def _assert_schema_accepts(schema: dict[str, object], instance: object) -> None:
    validator = jsonschema.Draft202012Validator(
        schema, format_checker=FORMAT_CHECKER
    )
    validator.check_schema(schema)
    validator.validate(instance)


def _assert_schema_rejects(schema: dict[str, object], instance: object) -> None:
    validator = jsonschema.Draft202012Validator(
        schema, format_checker=FORMAT_CHECKER
    )
    validator.check_schema(schema)
    with pytest.raises(jsonschema.ValidationError):
        validator.validate(instance)


def test_pure_action_first_report_input_matches_bytes_and_committed_schema() -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/pure-action-first-report-input.json")
    instance = json.loads(raw)

    model = contract.parse_report_input_json(raw)

    assert contract.serialize_report_input_json(model) == raw
    assert model.source_ledger.findings[0].action.value == "Fix"
    assert model.source_ledger.findings[0].proof.value == "Partial"
    assert model.source_ledger.findings[0].severity.value == "P1 Major"
    assert _schema("report-input.schema.json") == contract.report_input_json_schema()
    _assert_schema_accepts(_schema("report-input.schema.json"), instance)


def test_legacy_unversioned_readiness_json_fails_closed() -> None:
    contract = _contract()
    raw = _fixture_bytes("legacy/readiness-v0.json")

    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(raw)

    _assert_schema_rejects(
        _schema("readiness-ledger.schema.json"), json.loads(raw)
    )


def test_incomplete_ledger_round_trips_as_not_proven_evidence_debt() -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/incomplete-ledger.json")

    model = contract.parse_readiness_ledger_json(raw)

    assert contract.serialize_readiness_ledger_json(model) == raw
    assert model.completion_status.value == "incomplete"
    assert model.readiness_disposition.value == "cannot_determine"
    assert model.gate.outcome.value == "incomplete"
    assert model.evidence_debt[0].status.value == "needs-proof"
    _assert_schema_accepts(_schema("readiness-ledger.schema.json"), json.loads(raw))


def test_unknown_enum_is_rejected_by_model_and_schema() -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/unknown-enum-ledger.json")

    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(raw)

    _assert_schema_rejects(
        _schema("readiness-ledger.schema.json"), json.loads(raw)
    )


def test_confirmed_blocker_is_the_only_confirmed_only_gate_blocker() -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/confirmed-blocker-ledger.json")

    model = contract.parse_readiness_ledger_json(raw)

    assert contract.serialize_readiness_ledger_json(model) == raw
    assert model.gate.policy.value == "confirmed_only"
    assert model.gate.outcome.value == "failed"
    assert model.gate.blocking_finding_ids == ("FND-CHECKOUT-001",)
    assert json.loads(contract.serialize_confirmed_only_gate_json(model.gate)) == {
        "blocking_finding_ids": ["FND-CHECKOUT-001"],
        "outcome": "failed",
        "policy": "confirmed_only",
    }
    _assert_schema_accepts(_schema("readiness-ledger.schema.json"), json.loads(raw))

    mismatched = _fixture_bytes("v1/mismatched-gate-ledger.json")
    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(mismatched)
    _assert_schema_rejects(
        _schema("readiness-ledger.schema.json"), json.loads(mismatched)
    )


def test_confirmed_blocker_projection_is_order_independent_and_canonical() -> None:
    contract = _contract()
    candidate = _fixture_json("v1/confirmed-blocker-ledger.json")
    second_artifact = json.loads(json.dumps(candidate["artifacts"][0]))
    second_artifact["artifact_id"] = "ART-CHECKOUT-501"
    second_artifact["descriptor"]["digest"] = "d" * 64
    second_artifact["descriptor"]["relative_path"] = "evidence/checkout-501.json"
    second_finding = json.loads(json.dumps(candidate["findings"][0]))
    second_finding["artifact_ids"] = ["ART-CHECKOUT-501"]
    second_finding["finding_id"] = "FND-CHECKOUT-002"
    second_finding["subject"]["ref"] = "checkout.payment-second-error"
    candidate["artifacts"].append(second_artifact)
    candidate["findings"] = [second_finding, candidate["findings"][0]]

    model = contract.parse_readiness_ledger_json(json.dumps(candidate).encode())

    assert model.gate.blocking_finding_ids == (
        "FND-CHECKOUT-001",
        "FND-CHECKOUT-002",
    )
    projection = json.loads(contract.serialize_confirmed_only_gate_json(model.gate))
    assert projection["blocking_finding_ids"] == [
        "FND-CHECKOUT-001",
        "FND-CHECKOUT-002",
    ]


def test_confirmed_p0_cannot_hide_under_keep_or_passed_keep() -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/inconsistent-blocker-ledger.json")

    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(raw)
    _assert_schema_rejects(
        _schema("readiness-ledger.schema.json"), json.loads(raw)
    )


def test_missing_artifact_is_explicit_and_keeps_ledger_incomplete() -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/missing-artifact-ledger.json")

    model = contract.parse_readiness_ledger_json(raw)

    assert contract.serialize_readiness_ledger_json(model) == raw
    assert model.artifacts[0].availability.value == "missing"
    assert model.artifacts[0].descriptor.digest is None
    assert model.gate.outcome.value == "incomplete"
    _assert_schema_accepts(_schema("readiness-ledger.schema.json"), json.loads(raw))


def test_hostile_artifact_path_is_rejected_by_model_and_schema() -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/hostile-path-ledger.json")

    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(raw)

    _assert_schema_rejects(
        _schema("readiness-ledger.schema.json"), json.loads(raw)
    )


@pytest.mark.parametrize(
    ("label", "hostile_path"),
    [
        ("absolute-posix", "/etc/passwd"),
        ("drive-letter", "C:/Windows/system.ini"),
        ("unc", r"\\server\share\evidence.json"),
        ("remote-uri", "https://example.test/evidence.json"),
        ("active-uri", "javascript:alert(1)"),
        ("encoded-traversal", "%2e%2e/secret.json"),
        ("nul", "evidence/secret\x00.json"),
        ("parent-traversal", "evidence/../secret.json"),
    ],
)
def test_hostile_path_matrix_fails_closed_for_model_and_schema(
    label: str, hostile_path: str
) -> None:
    contract = _contract()
    candidate = _fixture_json("v1/confirmed-blocker-ledger.json")
    candidate["artifacts"][0]["descriptor"]["relative_path"] = hostile_path
    raw = json.dumps(candidate).encode()

    with pytest.raises(contract.ContractValidationError, match="strict v1"):
        contract.parse_readiness_ledger_json(raw)
    _assert_schema_rejects(_schema("readiness-ledger.schema.json"), candidate)


@pytest.mark.parametrize(
    ("label", "field", "value"),
    [
        ("mixed-id-prefix", "ledger_id", "ART-WRONG-001"),
        ("unknown-schema-version", "schema_version", "2.0"),
        ("extra-field", "unexpected", "forbidden"),
    ],
)
def test_boundary_identity_and_shape_fail_closed_for_model_and_schema(
    label: str, field: str, value: str
) -> None:
    contract = _contract()
    candidate = _fixture_json("v1/confirmed-blocker-ledger.json")
    candidate[field] = value
    raw = json.dumps(candidate).encode()

    with pytest.raises(contract.ContractValidationError, match="strict v1"):
        contract.parse_readiness_ledger_json(raw)
    _assert_schema_rejects(_schema("readiness-ledger.schema.json"), candidate)


@pytest.mark.parametrize(
    "duplicate_member",
    [
        '"schema_version": "2.0",\n  "schema_version": "1.0"',
        '"schema_version": "1.0",\n  "schema_version": "2.0"',
    ],
    ids=["hidden-unsupported-version-first", "unsupported-version-last"],
)
def test_top_level_duplicate_members_are_rejected_regardless_of_order(
    duplicate_member: str,
) -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/confirmed-blocker-ledger.json").replace(
        b'"schema_version": "1.0"', duplicate_member.encode(), 1
    )

    with pytest.raises(
        contract.ContractValidationError,
        match="contract JSON failed strict v1 validation",
    ):
        contract.parse_readiness_ledger_json(raw)


@pytest.mark.parametrize(
    "duplicate_member",
    [
        '"name": "attacker-controlled",\n    "name": "shipworthy-contract-tests"',
        '"name": "shipworthy-contract-tests",\n    "name": "attacker-controlled"',
    ],
    ids=["alternate-first", "alternate-last"],
)
def test_nested_duplicate_members_are_rejected_regardless_of_order(
    duplicate_member: str,
) -> None:
    contract = _contract()
    raw = _fixture_bytes("v1/confirmed-blocker-ledger.json").replace(
        b'"name": "shipworthy-contract-tests"', duplicate_member.encode(), 1
    )

    with pytest.raises(
        contract.ContractValidationError,
        match="contract JSON failed strict v1 validation",
    ):
        contract.parse_readiness_ledger_json(raw)


def test_hostile_validation_errors_do_not_retain_raw_exception_or_secret() -> None:
    contract = _contract()
    marker = "SECRET-CANARY-9fdd3d"
    candidate = _fixture_json("v1/confirmed-blocker-ledger.json")
    candidate["producer"]["name"] = marker * 20

    with pytest.raises(contract.ContractValidationError) as captured:
        contract.parse_readiness_ledger_json(json.dumps(candidate).encode())

    error = captured.value
    formatted = "".join(
        traceback.format_exception(type(error), error, error.__traceback__)
    )
    assert marker not in str(error)
    assert error.__cause__ is None
    assert error.__context__ is None
    assert marker not in formatted


@pytest.mark.parametrize(
    "generated_at",
    [
        "2026-07-09T12:00:00.123Z",
        "2026-07-09T05:00:00-07:00",
        "2026-07-09T12:00:00",
        "2026-02-30T12:00:00Z",
    ],
)
def test_timestamp_contract_rejects_noncanonical_or_invalid_values(
    generated_at: str,
) -> None:
    contract = _contract()
    candidate = _fixture_json("v1/confirmed-blocker-ledger.json")
    candidate["generated_at"] = generated_at
    raw = json.dumps(candidate).encode()

    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(raw)
    _assert_schema_rejects(_schema("readiness-ledger.schema.json"), candidate)


def test_parsed_contract_is_deeply_immutable() -> None:
    contract = _contract()
    model = contract.parse_readiness_ledger_json(
        _fixture_bytes("v1/confirmed-blocker-ledger.json")
    )

    with pytest.raises(PydanticValidationError):
        model.revision = 2
    with pytest.raises(AttributeError):
        model.findings.append(model.findings[0])
    with pytest.raises(AttributeError):
        model.findings[0].artifact_ids.append("ART-CHECKOUT-500")
    with pytest.raises(PydanticValidationError):
        model.findings[0].action = "Keep"


def _unresolved_finding_candidate(trigger: str, *, honest: bool) -> dict[str, object]:
    candidate = _fixture_json("v1/pure-action-first-report-input.json")[
        "source_ledger"
    ]
    finding = candidate["findings"][0]
    finding["action"] = "Prove"
    finding["section"] = "not_proven_not_tested"
    if trigger == "not-tested":
        finding["proof"] = "Not tested"
        finding["verifier_status"] = "approved"
    elif trigger == "needs-proof":
        finding["proof"] = "Partial"
        finding["verifier_status"] = "needs-proof"
    elif trigger == "blocked":
        finding["proof"] = "Partial"
        finding["verifier_status"] = "blocked"
    else:  # pragma: no cover - test helper guard
        raise AssertionError(f"unknown unresolved trigger: {trigger}")

    if honest:
        candidate["completion_status"] = "incomplete"
        candidate["readiness_disposition"] = "cannot_determine"
        candidate["evidence_debt"] = _fixture_json("v1/incomplete-ledger.json")[
            "evidence_debt"
        ]
    else:
        candidate["completion_status"] = "complete"
        candidate["readiness_disposition"] = "ready"
        candidate["evidence_debt"] = []
    return candidate


@pytest.mark.parametrize("trigger", ["not-tested", "needs-proof", "blocked"])
def test_each_unresolved_finding_trigger_rejects_a_lying_green_ledger(
    trigger: str,
) -> None:
    contract = _contract()
    candidate = _unresolved_finding_candidate(trigger, honest=False)

    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(json.dumps(candidate).encode())
    _assert_schema_rejects(_schema("readiness-ledger.schema.json"), candidate)


@pytest.mark.parametrize("trigger", ["not-tested", "needs-proof", "blocked"])
def test_each_unresolved_finding_trigger_accepts_explicit_incomplete_debt(
    trigger: str,
) -> None:
    contract = _contract()
    candidate = _unresolved_finding_candidate(trigger, honest=True)

    model = contract.parse_readiness_ledger_json(json.dumps(candidate).encode())

    assert model.completion_status.value == "incomplete"
    assert model.readiness_disposition.value == "cannot_determine"
    assert model.gate.outcome.value == "incomplete"
    _assert_schema_accepts(_schema("readiness-ledger.schema.json"), candidate)


def _semantic_invalid_candidate(case: str) -> dict[str, object]:
    if case == "incomplete-ready":
        candidate = _fixture_json("v1/incomplete-ledger.json")
        candidate["readiness_disposition"] = "ready"
    elif case == "confirmed-wrong-confidence":
        candidate = _fixture_json("v1/confirmed-blocker-ledger.json")
        candidate["findings"][0]["confidence"] = "Strong"
    elif case == "confirmed-wrong-verifier":
        candidate = _fixture_json("v1/confirmed-blocker-ledger.json")
        candidate["findings"][0]["verifier_status"] = "downgraded"
    elif case == "available-without-seal":
        candidate = _fixture_json("v1/confirmed-blocker-ledger.json")
        candidate["artifacts"][0]["descriptor"]["digest"] = None
        candidate["artifacts"][0]["descriptor"]["byte_size"] = None
    elif case == "missing-with-seal":
        candidate = _fixture_json("v1/missing-artifact-ledger.json")
        candidate["artifacts"][0]["descriptor"]["digest"] = "e" * 64
        candidate["artifacts"][0]["descriptor"]["byte_size"] = 64
    elif case == "complete-with-unresolved-debt":
        candidate = _fixture_json("v1/incomplete-ledger.json")
        candidate["completion_status"] = "complete"
        candidate["readiness_disposition"] = "ready"
    elif case == "complete-with-unavailable-artifact":
        candidate = _fixture_json("v1/missing-artifact-ledger.json")
        candidate["completion_status"] = "complete"
        candidate["readiness_disposition"] = "ready"
    else:  # pragma: no cover - test helper guard
        raise AssertionError(f"unknown semantic parity case: {case}")
    return candidate


@pytest.mark.parametrize(
    "case",
    [
        "incomplete-ready",
        "confirmed-wrong-confidence",
        "confirmed-wrong-verifier",
        "available-without-seal",
        "missing-with-seal",
        "complete-with-unresolved-debt",
        "complete-with-unavailable-artifact",
    ],
)
def test_model_and_schema_reject_the_same_expressible_semantic_invalid_states(
    case: str,
) -> None:
    contract = _contract()
    candidate = _semantic_invalid_candidate(case)

    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(json.dumps(candidate).encode())
    _assert_schema_rejects(_schema("readiness-ledger.schema.json"), candidate)


def test_readiness_ledger_committed_schema_matches_model_schema() -> None:
    contract = _contract()

    assert _schema("readiness-ledger.schema.json") == contract.readiness_ledger_json_schema()


@pytest.mark.parametrize(
    ("case", "fixture_name"),
    [
        ("lineage-source-ids", "v1/confirmed-blocker-ledger.json"),
        ("finding-artifact-ids", "v1/confirmed-blocker-ledger.json"),
        ("debt-artifact-ids", "v1/missing-artifact-ledger.json"),
    ],
)
@pytest.mark.parametrize(
    "schema_name",
    ["readiness-ledger.schema.json", "report-input.schema.json"],
)
def test_model_and_standalone_schemas_reject_duplicate_reference_arrays(
    case: str, fixture_name: str, schema_name: str
) -> None:
    contract = _contract()
    ledger = _fixture_json(fixture_name)
    if case == "lineage-source-ids":
        ledger["artifacts"][0]["lineage"]["source_ids"] = [
            "ART-CHECKOUT-500",
            "ART-CHECKOUT-500",
        ]
    elif case == "finding-artifact-ids":
        ledger["findings"][0]["artifact_ids"] = [
            "ART-CHECKOUT-500",
            "ART-CHECKOUT-500",
        ]
    elif case == "debt-artifact-ids":
        ledger["evidence_debt"][0]["artifact_ids"] = [
            "ART-MISSING-001",
            "ART-MISSING-001",
        ]
    else:  # pragma: no cover - parametrization guard
        raise AssertionError(f"unknown uniqueness case: {case}")

    with pytest.raises(contract.ContractValidationError):
        contract.parse_readiness_ledger_json(json.dumps(ledger).encode())

    if schema_name == "readiness-ledger.schema.json":
        instance = ledger
    else:
        instance = _fixture_json("v1/pure-action-first-report-input.json")
        instance["source_ledger"] = ledger
    _assert_schema_rejects(_schema(schema_name), instance)


def test_serializers_revalidate_copied_models_before_returning_bytes() -> None:
    contract = _contract()
    ledger = contract.parse_readiness_ledger_json(
        _fixture_bytes("v1/confirmed-blocker-ledger.json")
    )
    report_input = contract.parse_report_input_json(
        _fixture_bytes("v1/pure-action-first-report-input.json")
    )

    invalid_ledger = ledger.model_copy(update={"schema_version": "2.0"})
    with pytest.raises(contract.ContractValidationError):
        contract.serialize_readiness_ledger_json(invalid_ledger)

    invalid_finding = report_input.source_ledger.findings[0].model_copy(
        update={"artifact_ids": ("ART-UNKNOWN-001",)}
    )
    invalid_nested_ledger = report_input.source_ledger.model_copy(
        update={"findings": (invalid_finding,)}
    )
    invalid_report_input = report_input.model_copy(
        update={"source_ledger": invalid_nested_ledger}
    )
    with pytest.raises(contract.ContractValidationError):
        contract.serialize_report_input_json(invalid_report_input)

    assert contract.serialize_readiness_ledger_json(ledger) == _fixture_bytes(
        "v1/confirmed-blocker-ledger.json"
    )
    assert contract.serialize_report_input_json(report_input) == _fixture_bytes(
        "v1/pure-action-first-report-input.json"
    )


def test_gate_projection_requires_failed_if_and_only_if_blockers_exist() -> None:
    entities = importlib.import_module("shipworthy.domain.entities")
    enums = importlib.import_module("shipworthy.domain.enums")

    with pytest.raises(PydanticValidationError):
        entities.ConfirmedOnlyGateProjection(
            policy=enums.GatePolicy.CONFIRMED_ONLY,
            outcome=enums.GateOutcome.PASSED,
            blocking_finding_ids=("FND-CHECKOUT-001",),
        )
    with pytest.raises(PydanticValidationError):
        entities.ConfirmedOnlyGateProjection(
            policy=enums.GatePolicy.CONFIRMED_ONLY,
            outcome=enums.GateOutcome.FAILED,
            blocking_finding_ids=(),
        )


def test_gate_serializer_revalidates_an_invalid_copied_projection() -> None:
    contract = _contract()
    gate = contract.parse_readiness_ledger_json(
        _fixture_bytes("v1/confirmed-blocker-ledger.json")
    ).gate
    gate_outcome = importlib.import_module(
        "shipworthy.domain.enums"
    ).GateOutcome.PASSED
    invalid_gate = gate.model_copy(update={"outcome": gate_outcome})

    with pytest.raises(contract.ContractValidationError):
        contract.serialize_confirmed_only_gate_json(invalid_gate)


def test_generated_semantic_schema_fragments_are_mutation_isolated() -> None:
    contract = _contract()
    schema = contract.readiness_ledger_json_schema()
    first_clause = schema["allOf"][0]["if"]["properties"]["findings"]["contains"]
    peer_clause = schema["allOf"][3]["if"]["allOf"][0]["properties"][
        "findings"
    ]["not"]["contains"]

    assert first_clause is not peer_clause
    first_clause["canary"] = "mutated"
    assert "canary" not in peer_clause

    fresh_schema = contract.readiness_ledger_json_schema()
    fresh_first_clause = fresh_schema["allOf"][0]["if"]["properties"]["findings"][
        "contains"
    ]
    assert "canary" not in fresh_first_clause
