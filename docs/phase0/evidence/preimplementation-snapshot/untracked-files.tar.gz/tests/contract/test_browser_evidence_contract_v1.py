from __future__ import annotations

import builtins
import importlib
import json
import socket
import subprocess
from datetime import datetime
from pathlib import Path

import jsonschema
import pytest
from pydantic import ValidationError as PydanticValidationError


ROOT = Path(__file__).resolve().parents[2]
FIXTURES = ROOT / "tests" / "fixtures" / "browser_evidence"
SCHEMA_PATH = ROOT / "schemas" / "v1" / "browser-evidence-envelope.schema.json"
FORMAT_CHECKER = jsonschema.FormatChecker()


@FORMAT_CHECKER.checks("date-time", raises=ValueError)
def _is_valid_date_time(value: object) -> bool:
    if not isinstance(value, str):
        return True
    datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    return True


def _contract():
    return importlib.import_module("shipworthy.domain.contracts")


def _fixture_bytes(name: str = "valid-exploratory.json") -> bytes:
    return (FIXTURES / name).read_bytes()


def _fixture_json(name: str = "valid-exploratory.json") -> dict[str, object]:
    return json.loads(_fixture_bytes(name))


def _schema() -> dict[str, object]:
    return json.loads(SCHEMA_PATH.read_bytes())


def _assert_schema_accepts(instance: object) -> None:
    schema = _schema()
    validator = jsonschema.Draft202012Validator(
        schema, format_checker=FORMAT_CHECKER
    )
    validator.check_schema(schema)
    validator.validate(instance)


def _assert_schema_rejects(instance: object) -> None:
    schema = _schema()
    validator = jsonschema.Draft202012Validator(
        schema, format_checker=FORMAT_CHECKER
    )
    validator.check_schema(schema)
    with pytest.raises(jsonschema.ValidationError):
        validator.validate(instance)


@pytest.mark.parametrize(
    ("fixture_name", "family", "mode"),
    [
        ("valid-exploratory.json", "codex", "exploratory"),
        (
            "valid-deterministic-replay.json",
            "claude_code",
            "deterministic_replay",
        ),
    ],
)
def test_valid_envelopes_round_trip_canonically_and_match_committed_schema(
    fixture_name: str, family: str, mode: str
) -> None:
    contract = _contract()
    raw = _fixture_bytes(fixture_name)
    model = contract.parse_browser_evidence_json(raw)

    assert model.host.family.value == family
    assert model.mode.value == mode
    assert contract.serialize_browser_evidence_json(model) == raw
    assert _schema() == contract.browser_evidence_json_schema()
    _assert_schema_accepts(json.loads(raw))


def test_parse_requires_bounded_nonempty_bytes() -> None:
    contract = _contract()

    for value in (None, "{}", bytearray(b"{}"), b""):
        with pytest.raises(contract.ContractValidationError):
            contract.parse_browser_evidence_json(value)

    oversized = b"{" + b" " * contract.MAX_CONTRACT_BYTES + b"}"
    with pytest.raises(contract.ContractValidationError, match="1 MiB"):
        contract.parse_browser_evidence_json(oversized)


@pytest.mark.parametrize(
    ("needle", "replacement"),
    [
        (
            b'"schema_version": "1.0"',
            b'"schema_version": "2.0", "schema_version": "1.0"',
        ),
        (
            b'"driver": "in-app-browser"',
            b'"driver": "attacker", "driver": "in-app-browser"',
        ),
    ],
)
def test_duplicate_json_members_fail_closed_at_every_depth(
    needle: bytes, replacement: bytes
) -> None:
    contract = _contract()
    raw = _fixture_bytes().replace(needle, replacement, 1)

    with pytest.raises(contract.ContractValidationError, match="strict v1"):
        contract.parse_browser_evidence_json(raw)


@pytest.mark.parametrize(
    ("mutation", "value"),
    [
        ("schema_version", "2.0"),
        ("schema_name", "shipworthy/browser-evidence"),
        ("unexpected", "forbidden"),
        ("generated_at", "2026-07-15T12:00:00.123Z"),
        ("generated_at", "2026-02-30T12:00:00Z"),
        ("mode", "recording"),
    ],
)
def test_identity_shape_timestamp_and_enum_fail_closed_for_model_and_schema(
    mutation: str, value: str
) -> None:
    contract = _contract()
    candidate = _fixture_json()
    candidate[mutation] = value

    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())
    _assert_schema_rejects(candidate)


@pytest.mark.parametrize(
    "hostile_path",
    [
        "/etc/passwd",
        "C:/Windows/system.ini",
        r"\\server\share\trace.zip",
        "https://example.test/evidence.png",
        "file:///tmp/evidence.png",
        "javascript:alert(1)",
        "%2e%2e/secret.png",
        "evidence/../secret.png",
        "evidence/secret\x00.png",
    ],
)
def test_local_artifact_paths_reject_unsafe_or_remote_values(
    hostile_path: str,
) -> None:
    contract = _contract()
    candidate = _fixture_json()
    candidate["artifacts"][0]["descriptor"]["relative_path"] = hostile_path

    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())
    _assert_schema_rejects(candidate)


@pytest.mark.parametrize(
    "duplicate_case",
    ["step-id", "artifact-id", "finding-id", "unavailable-channel"],
)
def test_duplicate_identifiers_and_channels_are_rejected(duplicate_case: str) -> None:
    contract = _contract()
    candidate = _fixture_json()
    if duplicate_case == "step-id":
        candidate["steps"][1]["step_id"] = candidate["steps"][0]["step_id"]
    elif duplicate_case == "artifact-id":
        candidate["artifacts"][1]["artifact_id"] = candidate["artifacts"][0][
            "artifact_id"
        ]
    elif duplicate_case == "finding-id":
        candidate["finding_ids"].append(candidate["finding_ids"][0])
    else:
        candidate["unavailable_channels"].append(
            candidate["unavailable_channels"][0]
        )

    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())


def test_schema_rejects_duplicate_artifact_ids() -> None:
    candidate = _fixture_json()
    candidate["artifacts"].append(candidate["artifacts"][0])

    _assert_schema_rejects(candidate)


def test_nonidentical_duplicate_artifact_ids_are_runtime_enforced_and_documented() -> None:
    contract = _contract()
    candidate = _fixture_json()
    candidate["artifacts"][1]["artifact_id"] = candidate["artifacts"][0][
        "artifact_id"
    ]

    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())

    expected = {
        "artifact_id_uniqueness": (
            "Runtime enforces unique artifacts[*].artifact_id values; JSON Schema "
            "uniqueItems compares whole array items and cannot express uniqueness "
            "of one property across nonidentical objects."
        ),
        "step_id_uniqueness": (
            "Runtime enforces unique steps[*].step_id values; JSON Schema "
            "uniqueItems compares whole array items and cannot express uniqueness "
            "of one property across nonidentical objects."
        ),
    }
    assert _schema()["x-shipworthy-runtime-constraints"] == expected
    assert contract.browser_evidence_json_schema()[
        "x-shipworthy-runtime-constraints"
    ] == expected


def test_schema_rejects_available_and_unavailable_channel_overlap() -> None:
    candidate = _fixture_json()
    candidate["unavailable_channels"].append("screenshot")

    _assert_schema_rejects(candidate)


@pytest.mark.parametrize(
    ("identity", "malformed"),
    [
        ("step_id", ""),
        ("artifact_id", "FND-WRONG-PREFIX-001"),
        ("finding_id", "ART-WRONG-PREFIX-001"),
    ],
)
def test_malformed_ids_are_rejected_by_model_and_schema(
    identity: str, malformed: str
) -> None:
    contract = _contract()
    candidate = _fixture_json()
    if identity == "step_id":
        candidate["steps"][0]["step_id"] = malformed
    elif identity == "artifact_id":
        candidate["artifacts"][0]["artifact_id"] = malformed
    else:
        candidate["finding_ids"][0] = malformed

    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())
    _assert_schema_rejects(candidate)


def test_sequence_is_forbidden_and_json_array_order_is_canonical() -> None:
    contract = _contract()
    candidate = _fixture_json()
    for step in candidate["steps"]:
        step.pop("sequence", None)
    raw = (json.dumps(candidate, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()

    model = contract.parse_browser_evidence_json(raw)

    assert tuple(step.step_id for step in model.steps) == (
        "open-checkout",
        "submit-empty-form",
    )
    assert contract.serialize_browser_evidence_json(model) == raw

    candidate["steps"][0]["sequence"] = 1
    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())
    _assert_schema_rejects(candidate)


def test_screenshot_only_evidence_requires_explicit_not_proven_statement() -> None:
    contract = _contract()
    candidate = _fixture_json()
    candidate["artifacts"] = [candidate["artifacts"][0]]
    candidate["unavailable_channels"] = [
        "dom_accessibility",
        "console",
        "network",
        "trace",
        "recording",
    ]
    candidate["not_proven"] = []

    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())
    _assert_schema_rejects(candidate)


def test_nonidentical_duplicate_step_ids_are_runtime_enforced_and_documented() -> None:
    contract = _contract()
    candidate = _fixture_json()
    candidate["steps"][1]["step_id"] = candidate["steps"][0]["step_id"]

    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())

    assert _schema()["x-shipworthy-runtime-constraints"][
        "step_id_uniqueness"
    ] == (
        "Runtime enforces unique steps[*].step_id values; JSON Schema uniqueItems "
        "compares whole array items and cannot express uniqueness of one property "
        "across nonidentical objects."
    )


def test_fixture_exercises_a_local_descriptor_for_every_supported_channel() -> None:
    contract = _contract()
    raw = _fixture_bytes("valid-all-channels.json")

    model = contract.parse_browser_evidence_json(raw)

    assert {artifact.channel.value for artifact in model.artifacts} == {
        "screenshot",
        "dom_accessibility",
        "console",
        "network",
        "trace",
        "recording",
    }
    assert all(artifact.descriptor.digest for artifact in model.artifacts)
    assert contract.serialize_browser_evidence_json(model) == raw
    _assert_schema_accepts(json.loads(raw))


def test_steps_are_bounded_and_nonempty() -> None:
    contract = _contract()
    for steps in (
        [],
        [_fixture_json()["steps"][0]] * 129,
    ):
        candidate = _fixture_json()
        candidate["steps"] = steps
        with pytest.raises(contract.ContractValidationError):
            contract.parse_browser_evidence_json(json.dumps(candidate).encode())


def test_artifacts_and_statement_counts_are_bounded() -> None:
    contract = _contract()
    cases = (
        ("artifacts", [_fixture_json()["artifacts"][0]] * 65),
        ("limitations", [f"limitation-{index}" for index in range(65)]),
        ("not_proven", [f"not-proven-{index}" for index in range(65)]),
        ("finding_ids", [f"FND-BOUND-{index}" for index in range(129)]),
    )
    for field, value in cases:
        candidate = _fixture_json()
        candidate[field] = value
        with pytest.raises(contract.ContractValidationError):
            contract.parse_browser_evidence_json(json.dumps(candidate).encode())


def test_excessive_json_depth_fails_closed_without_leaking_input() -> None:
    contract = _contract()
    marker = "SECRET-CANARY-browser-evidence"
    raw = ("[" * 1100 + json.dumps(marker) + "]" * 1100).encode()

    with pytest.raises(contract.ContractValidationError) as captured:
        contract.parse_browser_evidence_json(raw)

    assert marker not in str(captured.value)
    assert captured.value.__cause__ is None
    assert captured.value.__context__ is None


def test_declared_artifact_requires_digest_and_byte_size() -> None:
    contract = _contract()
    for field in ("digest", "byte_size"):
        candidate = _fixture_json()
        candidate["artifacts"][0]["descriptor"][field] = None
        with pytest.raises(contract.ContractValidationError):
            contract.parse_browser_evidence_json(json.dumps(candidate).encode())
        _assert_schema_rejects(candidate)


def test_available_and_unavailable_channels_cannot_overlap() -> None:
    contract = _contract()
    candidate = _fixture_json()
    candidate["unavailable_channels"].append("screenshot")

    with pytest.raises(contract.ContractValidationError):
        contract.parse_browser_evidence_json(json.dumps(candidate).encode())


def test_parsing_supplied_bytes_performs_no_io_or_process_work(monkeypatch) -> None:
    contract = _contract()
    raw = _fixture_bytes()

    def forbidden(*_args, **_kwargs):
        raise AssertionError("browser evidence parsing attempted an external operation")

    monkeypatch.setattr(builtins, "open", forbidden)
    monkeypatch.setattr(Path, "open", forbidden)
    monkeypatch.setattr(Path, "read_bytes", forbidden)
    monkeypatch.setattr(socket, "socket", forbidden)
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(subprocess, "run", forbidden)
    monkeypatch.setattr(subprocess, "Popen", forbidden)

    model = contract.parse_browser_evidence_json(raw)

    assert model.artifacts[0].descriptor.relative_path.endswith("checkout.png")


def test_parsed_envelope_is_deeply_immutable() -> None:
    contract = _contract()
    model = contract.parse_browser_evidence_json(_fixture_bytes())

    with pytest.raises(PydanticValidationError):
        model.mode = "deterministic_replay"
    with pytest.raises(AttributeError):
        model.steps.append(model.steps[0])
    with pytest.raises(PydanticValidationError):
        model.steps[0].step_id = "mutated-step"


def test_serializer_revalidates_copied_models() -> None:
    contract = _contract()
    model = contract.parse_browser_evidence_json(_fixture_bytes())
    invalid = model.model_copy(update={"schema_version": "2.0"})

    with pytest.raises(contract.ContractValidationError):
        contract.serialize_browser_evidence_json(invalid)
