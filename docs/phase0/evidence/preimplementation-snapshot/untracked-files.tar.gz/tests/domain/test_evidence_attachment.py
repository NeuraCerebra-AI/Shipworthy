from __future__ import annotations

import builtins
import copy
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import socket
import subprocess

import pytest

from shipworthy.adapters.importers._evidence_normalization import (
    EvidenceDebtDraft,
    NormalizedEvidenceResult,
    NormalizedObservation,
    SealedAttachmentBytes,
)
from shipworthy.adapters.importers.browser_evidence import import_browser_evidence_json
from shipworthy.adapters.importers.playwright_report import (
    import_playwright_json_report,
)
from shipworthy.domain.contracts import (
    parse_readiness_ledger_json,
    serialize_readiness_ledger_json,
)
from shipworthy.domain.enums import ArtifactAvailability


FIXTURES = Path(__file__).resolve().parents[1] / "fixtures" / "v1"


def _ledger(name: str = "pure-action-first-report-input.json"):
    raw = json.loads((FIXTURES / name).read_bytes())
    candidate = raw.get("source_ledger", raw)
    return parse_readiness_ledger_json(json.dumps(candidate).encode())


def _result(
    *,
    with_debt: bool = False,
    finding_ids: tuple[str, ...] = ("FND-COUPON-001",),
) -> NormalizedEvidenceResult:
    payload = json.loads(
        (FIXTURES.parent / "browser_evidence" / "valid-exploratory.json").read_bytes()
    )
    payload["finding_ids"] = list(finding_ids)
    screenshot = b"synthetic screenshot bytes"
    screenshot_declaration = payload["artifacts"][0]
    screenshot_declaration["descriptor"]["digest"] = hashlib.sha256(
        screenshot
    ).hexdigest()
    screenshot_declaration["descriptor"]["byte_size"] = len(screenshot)
    payload["artifacts"] = [screenshot_declaration]
    attachments = {"evidence/browser/checkout.png": screenshot}
    if with_debt:
        network = {
            "artifact_id": "ART-BROWSER-NETWORK-001",
            "channel": "network",
            "descriptor": {
                "byte_size": 23,
                "declared_media_type": "application/json",
                "digest": "b" * 64,
                "digest_algorithm": "sha256",
                "relative_path": "evidence/browser/network.json",
            },
        }
        payload["artifacts"].append(network)
        payload["unavailable_channels"].remove("network")
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    return import_browser_evidence_json(
        raw,
        source_relative_path="evidence/browser/session.json",
        attachment_bytes=attachments,
    )


def _finding_fields(finding):
    data = finding.model_dump(mode="json")
    data.pop("artifact_ids")
    return data


def test_attach_evidence_is_pure_deterministic_and_preserves_finding_and_gate(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from shipworthy.domain.evidence_attachment import attach_evidence

    ledger = _ledger()
    original_bytes = serialize_readiness_ledger_json(ledger)
    original_finding = ledger.findings[0]
    original_gate = ledger.gate
    normalized = _result()

    first = attach_evidence(ledger, normalized)

    def forbidden(*_args, **_kwargs):
        raise AssertionError("evidence attachment attempted an external side effect")

    monkeypatch.setattr(builtins, "open", forbidden)
    monkeypatch.setattr(socket, "socket", forbidden)
    monkeypatch.setattr(subprocess, "run", forbidden)
    monkeypatch.setattr(subprocess, "Popen", forbidden)
    second = attach_evidence(ledger, normalized)

    assert serialize_readiness_ledger_json(ledger) == original_bytes
    assert serialize_readiness_ledger_json(first) == serialize_readiness_ledger_json(
        second
    )
    assert _finding_fields(first.findings[0]) == _finding_fields(original_finding)
    assert first.findings[0].artifact_ids == (
        *original_finding.artifact_ids,
        first.artifacts[-2].artifact_id,
        "ART-BROWSER-SCREENSHOT-001",
    )
    assert first.gate == original_gate
    assert first.completion_status == ledger.completion_status
    assert first.readiness_disposition == ledger.readiness_disposition
    assert first.artifacts[-2].lineage.producer == normalized.source.producer_name
    assert first.artifacts[-2].lineage.operation.startswith("browser-evidence/v1?")


def test_attach_evidence_rejects_unknown_finding_and_all_artifact_collisions() -> None:
    from shipworthy.domain.evidence_attachment import (
        EvidenceAttachmentError,
        attach_evidence,
    )

    ledger = _ledger()
    result = _result()

    with pytest.raises(EvidenceAttachmentError, match="unknown finding"):
        attach_evidence(ledger, _result(finding_ids=("FND-UNKNOWN-001",)))

    incoming = result.artifacts[0]
    base = json.loads(serialize_readiness_ledger_json(ledger))
    collision_ledgers = []
    for collision_kind in ("artifact_id", "relative_path", "digest"):
        candidate = copy.deepcopy(base)
        extra = copy.deepcopy(candidate["artifacts"][0])
        extra["artifact_id"] = "ART-COLLISION-001"
        extra["descriptor"]["relative_path"] = "evidence/collision.json"
        extra["descriptor"]["digest"] = "d" * 64
        if collision_kind == "artifact_id":
            extra["artifact_id"] = incoming.artifact_id
        elif collision_kind == "relative_path":
            extra["descriptor"]["relative_path"] = incoming.descriptor.relative_path
        else:
            extra["descriptor"]["digest"] = incoming.descriptor.digest
        candidate["artifacts"].append(extra)
        collision_ledgers.append(
            parse_readiness_ledger_json(json.dumps(candidate).encode())
        )
    for colliding_ledger in collision_ledgers:
        with pytest.raises(EvidenceAttachmentError, match="artifact collision"):
            attach_evidence(colliding_ledger, result)


def test_unavailable_artifact_and_limitations_create_named_debt_and_incomplete_gate() -> (
    None
):
    from shipworthy.domain.evidence_attachment import attach_evidence

    ledger = _ledger()
    attached = attach_evidence(ledger, _result(with_debt=True))

    assert attached.gate.outcome.value == "incomplete"
    assert attached.completion_status.value == "incomplete"
    assert attached.readiness_disposition.value == "cannot_determine"
    assert attached.findings[0].artifact_ids[-2:] == (
        attached.artifacts[-3].artifact_id,
        "ART-BROWSER-SCREENSHOT-001",
    )
    assert "ART-BROWSER-NETWORK-001" not in attached.findings[0].artifact_ids
    assert {debt.subject for debt in attached.evidence_debt}.issuperset(
        {
            "evidence/browser/network.json",
            "browser-evidence limitation",
        }
    )
    assert all(
        debt.debt_id.startswith("ED-BROWSER-") for debt in attached.evidence_debt
    )
    assert any(
        debt.artifact_ids == ("ART-BROWSER-NETWORK-001",)
        for debt in attached.evidence_debt
    )
    status_by_subject = {
        debt.subject: debt.status.value for debt in attached.evidence_debt
    }
    assert status_by_subject["evidence/browser/network.json"] == "needs-proof"
    assert status_by_subject["browser-evidence limitation"] == "scoped-out"


def test_informational_native_limitations_are_scoped_out_without_gate_downgrade() -> (
    None
):
    from shipworthy.domain.evidence_attachment import attach_evidence

    ledger = _ledger()
    result = _result()

    attached = attach_evidence(ledger, result)

    assert attached.completion_status == ledger.completion_status
    assert attached.readiness_disposition == ledger.readiness_disposition
    assert attached.gate == ledger.gate
    assert all(debt.status.value == "scoped-out" for debt in attached.evidence_debt)
    assert "LIMITATION: Evidence channel unavailable: network." in {
        debt.reason for debt in attached.evidence_debt
    }


def test_forged_normalized_seals_and_lineage_are_rejected_with_sanitized_error() -> (
    None
):
    from shipworthy.domain.evidence_attachment import (
        EvidenceAttachmentError,
        attach_evidence,
    )

    ledger = _ledger()
    result = _result()
    source = result.source_artifact
    forged = (
        replace(result, sha256="f" * 64),
        replace(result, byte_size=result.byte_size + 1),
        replace(result, driver=""),
        replace(result, target_fingerprint="not-a-sha256"),
        replace(
            result,
            observations=(
                NormalizedObservation(
                    observation_id="forged-observation",
                    official_id=None,
                    project=None,
                    project_id=None,
                    subject="forged subject",
                    action="",
                    observed_outcome="forged outcome",
                    outcome="observed",
                    retry_count=0,
                    flaky=False,
                    artifact_ids=(),
                ),
            ),
        ),
        replace(
            result,
            evidence_debt=(
                EvidenceDebtDraft(
                    code="FORGED",
                    subject="forged debt",
                    proof_needed="Supply evidence.",
                    reason="x" * 1001,
                    artifact_ids=(),
                ),
            ),
        ),
        replace(
            result,
            source_artifact=source.model_copy(
                update={
                    "descriptor": source.descriptor.model_copy(
                        update={"relative_path": "evidence/browser/other.json"}
                    )
                }
            ),
        ),
        replace(
            result,
            source_artifact=source.model_copy(
                update={"availability": ArtifactAvailability.CORRUPT}
            ),
        ),
        replace(
            result,
            source_artifact=source.model_copy(
                update={
                    "descriptor": source.descriptor.model_copy(
                        update={"digest": "e" * 64}
                    )
                }
            ),
        ),
        replace(
            result,
            source_artifact=source.model_copy(
                update={
                    "descriptor": source.descriptor.model_copy(
                        update={"byte_size": result.byte_size + 1}
                    )
                }
            ),
        ),
        replace(
            result,
            source_artifact=source.model_copy(
                update={
                    "lineage": source.lineage.model_copy(
                        update={"operation": "forged-operation"}
                    )
                }
            ),
        ),
        replace(
            result,
            artifacts=(
                result.artifacts[0].model_copy(
                    update={
                        "lineage": result.artifacts[0].lineage.model_copy(
                            update={"source_ids": ()}
                        )
                    }
                ),
            ),
        ),
    )

    for candidate in forged:
        with pytest.raises(
            EvidenceAttachmentError,
            match="normalized browser evidence failed seal validation",
        ) as captured:
            attach_evidence(ledger, candidate)
        assert captured.value.__cause__ is None
        assert captured.value.__context__ is None


def test_existing_cannot_determine_wins_over_confirmed_blocker_on_added_debt() -> None:
    from shipworthy.domain.evidence_attachment import attach_evidence

    candidate = json.loads((FIXTURES / "confirmed-blocker-ledger.json").read_bytes())
    unproven = copy.deepcopy(candidate["findings"][0])
    unproven.update(
        {
            "action": "Prove",
            "artifact_ids": [],
            "confidence": "Hypothesis",
            "finding_id": "FND-CHECKOUT-UNPROVEN",
            "proof": "Not tested",
            "section": "not_proven_not_tested",
            "severity": "Unscored",
            "summary": "The recovery path has not been tested.",
            "verifier_status": "needs-proof",
        }
    )
    candidate["findings"].append(unproven)
    candidate["evidence_debt"].append(
        {
            "artifact_ids": [],
            "debt_id": "ED-CHECKOUT-UNPROVEN",
            "proof_needed": "Test the recovery path.",
            "reason": "The recovery path was unavailable.",
            "status": "needs-proof",
            "subject": "checkout.recovery",
        }
    )
    candidate["completion_status"] = "incomplete"
    candidate["readiness_disposition"] = "cannot_determine"
    ledger = parse_readiness_ledger_json(json.dumps(candidate).encode())

    attached = attach_evidence(
        ledger,
        _result(
            with_debt=True,
            finding_ids=("FND-CHECKOUT-UNPROVEN",),
        ),
    )

    assert attached.readiness_disposition.value == "cannot_determine"
    assert attached.completion_status.value == "incomplete"
    assert attached.gate.outcome.value == "failed"
    assert attached.gate.blocking_finding_ids == ("FND-CHECKOUT-001",)


def test_repeated_attachment_deliberately_rejects_collision() -> None:
    from shipworthy.domain.evidence_attachment import (
        EvidenceAttachmentError,
        attach_evidence,
    )

    result = _result()
    attached = attach_evidence(_ledger(), result)

    with pytest.raises(EvidenceAttachmentError, match="artifact collision"):
        attach_evidence(attached, result)


def _genuine_native_result():
    payload = json.loads(
        (FIXTURES.parent / "browser_evidence" / "valid-exploratory.json").read_bytes()
    )
    payload["finding_ids"] = ["FND-COUPON-001"]
    attachments = {
        "evidence/browser/checkout.png": b"genuine native screenshot",
        "evidence/browser/checkout-accessibility.json": b'{"role":"main"}\n',
    }
    for artifact in payload["artifacts"]:
        descriptor = artifact["descriptor"]
        supplied = attachments[descriptor["relative_path"]]
        descriptor["digest"] = hashlib.sha256(supplied).hexdigest()
        descriptor["byte_size"] = len(supplied)
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    return import_browser_evidence_json(
        raw,
        source_relative_path="evidence/browser/genuine-session.json",
        attachment_bytes=attachments,
    )


def _genuine_playwright_result():
    playwright = FIXTURES.parent / "playwright"
    return import_playwright_json_report(
        (playwright / "basic-report.json").read_bytes(),
        source_relative_path="test-results/playwright-report.json",
        attachment_bytes={
            "test-results/checkout/screenshot.png": (
                playwright / "screenshot.png"
            ).read_bytes(),
            "test-results/expired/trace.zip": (playwright / "trace.zip").read_bytes(),
        },
        finding_ids=("FND-COUPON-001",),
    )


@pytest.mark.parametrize(
    "factory", (_genuine_native_result, _genuine_playwright_result)
)
def test_attachment_provenance_mutations_and_sealed_record_drift_are_rejected(
    factory,
) -> None:
    from shipworthy.domain.evidence_attachment import (
        EvidenceAttachmentError,
        attach_evidence,
    )

    result = factory()
    artifact = result.artifacts[0]
    mutations = (
        artifact.model_copy(
            update={
                "descriptor": artifact.descriptor.model_copy(
                    update={"digest": "e" * 64}
                )
            }
        ),
        artifact.model_copy(
            update={
                "descriptor": artifact.descriptor.model_copy(
                    update={"byte_size": artifact.descriptor.byte_size + 1}
                )
            }
        ),
        artifact.model_copy(
            update={
                "lineage": artifact.lineage.model_copy(
                    update={"producer": "forged-producer"}
                )
            }
        ),
        artifact.model_copy(
            update={
                "lineage": artifact.lineage.model_copy(
                    update={"operation": "forged-operation"}
                )
            }
        ),
        artifact.model_copy(update={"artifact_id": "ART-FORGED-001"}),
        artifact.model_copy(
            update={
                "descriptor": artifact.descriptor.model_copy(
                    update={"relative_path": "evidence/forged.bin"}
                )
            }
        ),
        artifact.model_copy(
            update={
                "descriptor": artifact.descriptor.model_copy(
                    update={"declared_media_type": "application/octet-stream"}
                )
            }
        ),
    )
    forged_results = [
        replace(result, artifacts=(mutation, *result.artifacts[1:]))
        for mutation in mutations
    ]
    forged_results.extend(
        (
            replace(result, sealed_attachments=()),
            replace(
                result,
                sealed_attachments=(
                    *result.sealed_attachments,
                    SealedAttachmentBytes(
                        relative_path="evidence/extra.bin",
                        raw_bytes=b"EXTRA-SECRET-BYTES",
                    ),
                ),
            ),
        )
    )

    for forged in forged_results:
        with pytest.raises(
            EvidenceAttachmentError,
            match="normalized browser evidence failed seal validation",
        ) as captured:
            attach_evidence(_ledger(), forged)
        assert captured.value.__cause__ is None
        assert captured.value.__context__ is None
        assert "EXTRA-SECRET-BYTES" not in str(captured.value)


def _native_with_undeclared_attachment():
    payload = json.loads(
        (FIXTURES.parent / "browser_evidence" / "valid-exploratory.json").read_bytes()
    )
    payload["finding_ids"] = ["FND-COUPON-001"]
    payload["artifacts"] = payload["artifacts"][:1]
    screenshot = b"declared native screenshot"
    descriptor = payload["artifacts"][0]["descriptor"]
    descriptor["digest"] = hashlib.sha256(screenshot).hexdigest()
    descriptor["byte_size"] = len(screenshot)
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    return import_browser_evidence_json(
        raw,
        source_relative_path="evidence/browser/undeclared-session.json",
        attachment_bytes={
            descriptor["relative_path"]: screenshot,
            "evidence/browser/undeclared.bin": b"NATIVE-UNDECLARED-SECRET",
        },
    )


def _playwright_with_undeclared_attachment():
    playwright = FIXTURES.parent / "playwright"
    payload = json.loads((playwright / "basic-report.json").read_bytes())
    kept_path = "test-results/checkout/screenshot.png"
    for suite in payload["suites"]:
        for spec in suite["specs"]:
            for test in spec["tests"]:
                for result in test["results"]:
                    result["attachments"] = [
                        attachment
                        for attachment in result["attachments"]
                        if attachment.get("path") == kept_path
                    ]
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode()
    return import_playwright_json_report(
        raw,
        source_relative_path="test-results/undeclared-report.json",
        attachment_bytes={
            kept_path: (playwright / "screenshot.png").read_bytes(),
            "test-results/undeclared.bin": b"PLAYWRIGHT-UNDECLARED-SECRET",
        },
        finding_ids=("FND-COUPON-001",),
    )


@pytest.mark.parametrize(
    "factory",
    (_native_with_undeclared_attachment, _playwright_with_undeclared_attachment),
)
def test_genuine_undeclared_attachment_debt_replays_and_attaches_without_fake_artifact(
    factory,
) -> None:
    from shipworthy.domain.evidence_attachment import attach_evidence

    normalized = factory()
    undeclared = next(
        debt
        for debt in normalized.evidence_debt
        if debt.code == "ATTACHMENT_UNDECLARED"
    )

    attached = attach_evidence(_ledger(), normalized)

    assert undeclared.artifact_ids == ()
    assert [item.relative_path for item in normalized.sealed_attachments] == sorted(
        item.relative_path for item in normalized.sealed_attachments
    )
    assert not any(
        artifact.descriptor.relative_path.endswith("undeclared.bin")
        for artifact in attached.artifacts
    )
    canonical = next(
        debt
        for debt in attached.evidence_debt
        if debt.reason.startswith("ATTACHMENT_UNDECLARED:")
    )
    assert canonical.status.value == "needs-proof"
    assert canonical.artifact_ids == ()
    assert attached.completion_status.value == "incomplete"
    assert attached.readiness_disposition.value == "cannot_determine"
    assert attached.gate.outcome.value == "incomplete"
    assert "UNDECLARED-SECRET" not in repr(normalized)
